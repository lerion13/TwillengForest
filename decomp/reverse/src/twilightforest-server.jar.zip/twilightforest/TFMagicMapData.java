package twilightforest;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapData;
import net.minecraft.world.storage.MapData.MapCoord;
import twilightforest.TFFeature;
import twilightforest.world.TFWorldChunkManager;

public class TFMagicMapData extends MapData {

   private static final int FEATURE_DATA_BYTE = 18;
   public List featuresVisibleOnMap = new ArrayList();


   public TFMagicMapData(String par1Str) {
      super(par1Str);
   }

   public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readFromNBT(par1NBTTagCompound);
      byte[] featureStorage = par1NBTTagCompound.getByteArray("features");
      if(featureStorage.length > 0) {
         this.updateMPMapData(featureStorage);
      }

   }

   public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeToNBT(par1NBTTagCompound);
      if(this.featuresVisibleOnMap.size() > 0) {
         byte[] featureStorage = this.makeFeatureStorageArray();
         par1NBTTagCompound.setByteArray("features", featureStorage);
      }

   }

   public void addFeatureToMap(TFFeature feature, int x, int z) {
      byte relativeX = (byte)(x - super.xCenter >> super.scale);
      byte relativeZ = (byte)(z - super.zCenter >> super.scale);
      byte rangeX = 64;
      byte rangeY = 64;
      if(relativeX >= -rangeX && relativeZ >= -rangeY && relativeX <= rangeX && relativeZ <= rangeY) {
         byte markerIcon = (byte)feature.featureID;
         byte mapX = (byte)(relativeX << 1);
         byte mapZ = (byte)(relativeZ << 1);
         byte mapRotation = 8;
         boolean featureFound = false;
         Iterator var13 = this.featuresVisibleOnMap.iterator();

         while(var13.hasNext()) {
            MapCoord existingCoord = (MapCoord)var13.next();
            if(existingCoord.centerX == mapX && existingCoord.centerZ == mapZ) {
               featureFound = true;
            }
         }

         if(!featureFound) {
            this.featuresVisibleOnMap.add(new MapCoord(this, markerIcon, mapX, mapZ, mapRotation));
         }
      }

   }

   public void checkExistingFeatures(World world) {
      ArrayList toRemove = null;
      Iterator var3 = this.featuresVisibleOnMap.iterator();

      while(var3.hasNext()) {
         MapCoord coord = (MapCoord)var3.next();
         int worldX = (coord.centerX << super.scale - 1) + super.xCenter;
         int worldZ = (coord.centerZ << super.scale - 1) + super.zCenter;
         if(world != null && world.getWorldChunkManager() instanceof TFWorldChunkManager) {
            TFWorldChunkManager tfManager = (TFWorldChunkManager)world.getWorldChunkManager();
            coord.iconSize = (byte)tfManager.getFeatureID(worldX, worldZ, world);
            if(coord.iconSize == 0) {
               if(toRemove == null) {
                  toRemove = new ArrayList();
               }

               toRemove.add(coord);
            }
         }
      }

      if(toRemove != null) {
         this.featuresVisibleOnMap.removeAll(toRemove);
      }

   }

   public void updateMPMapData(byte[] par1ArrayOfByte) {
      if(par1ArrayOfByte[0] == 18) {
         this.featuresVisibleOnMap.clear();

         for(int i = 0; i < (par1ArrayOfByte.length - 1) / 3; ++i) {
            byte markerIcon = par1ArrayOfByte[i * 3 + 1];
            byte mapX = par1ArrayOfByte[i * 3 + 2];
            byte mapZ = par1ArrayOfByte[i * 3 + 3];
            byte mapRotation = 8;
            this.featuresVisibleOnMap.add(new MapCoord(this, markerIcon, mapX, mapZ, mapRotation));
         }
      } else {
         super.updateMPMapData(par1ArrayOfByte);
      }

   }

   public byte[] makeFeatureStorageArray() {
      byte[] storage = new byte[this.featuresVisibleOnMap.size() * 3 + 1];
      storage[0] = 18;

      for(int i = 0; i < this.featuresVisibleOnMap.size(); ++i) {
         MapCoord featureCoord = (MapCoord)this.featuresVisibleOnMap.get(i);
         storage[i * 3 + 1] = featureCoord.iconSize;
         storage[i * 3 + 2] = featureCoord.centerX;
         storage[i * 3 + 3] = featureCoord.centerZ;
      }

      return storage;
   }
}

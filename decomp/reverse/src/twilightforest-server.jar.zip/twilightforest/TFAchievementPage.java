package twilightforest;

import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Achievement;
import net.minecraftforge.common.AchievementPage;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class TFAchievementPage extends AchievementPage {

   public static Achievement twilightPortal = (new Achievement("TwilightForest1", "twilightPortal", -2, 1, TFBlocks.portal, (Achievement)null)).setSpecial().registerStat();
   public static Achievement twilightArrival = (new Achievement("TwilightForest2", "twilightArrival", 0, 0, new ItemStack(TFBlocks.log, 1, 9), twilightPortal)).registerStat();
   public static Achievement twilightHunter = (new Achievement("TwilightForest3", "twilightHunter", 2, 2, TFItems.feather, twilightArrival)).registerStat();
   public static Achievement twilightMagicMapFocus = (new Achievement("TwilightForest5", "twilightMagicMapFocus", 2, 0, TFItems.magicMapFocus, twilightHunter)).registerStat();
   public static Achievement twilightHill1 = (new Achievement("TwilightForest10", "twilightHill1", -2, -1, Blocks.iron_ore, twilightArrival)).registerStat();
   public static Achievement twilightHill2 = (new Achievement("TwilightForest11", "twilightHill2", -3, -2, Blocks.gold_ore, twilightArrival)).registerStat();
   public static Achievement twilightHill3 = (new Achievement("TwilightForest12", "twilightHill3", -1, -3, Blocks.diamond_ore, twilightArrival)).registerStat();
   public static Achievement twilightHedge = (new Achievement("TwilightForest13", "twilightHedge", 2, -3, TFBlocks.hedge, twilightArrival)).registerStat();
   public static Achievement twilightMagicMap = (new Achievement("TwilightForest14", "twilightMagicMap", 4, -1, TFItems.magicMap, twilightMagicMapFocus)).registerStat();
   public static Achievement twilightKillNaga = (new Achievement("TwilightForest6", "twilightKillNaga", 4, 3, new ItemStack(TFItems.trophy, 1, 1), twilightHunter)).registerStat();
   public static Achievement twilightProgressNaga = (new Achievement("TwilightForest17", "twilightProgressNaga", 4, 5, TFItems.nagaScale, twilightKillNaga)).registerStat();
   public static Achievement twilightKillLich = (new Achievement("TwilightForest8", "twilightKillLich", 2, 5, new ItemStack(TFItems.trophy, 1, 2), twilightProgressNaga)).registerStat();
   public static Achievement twilightProgressLich = (new Achievement("TwilightForest18", "twilightProgressLich", -1, 4, TFItems.scepterLifeDrain, twilightKillLich)).registerStat();
   public static Achievement twilightProgressLabyrinth = (new Achievement("TwilightForest28", "twilightProgressLabyrinth", -4, 6, TFItems.meefStroganoff, twilightProgressLich)).registerStat();
   public static Achievement twilightKillHydra = (new Achievement("TwilightForest30", "twilightKillHydra", -6, 4, new ItemStack(TFItems.trophy, 1, 0), twilightProgressLabyrinth)).registerStat();
   public static Achievement twilightProgressHydra = (new Achievement("TwilightForest20", "twilightProgressHydra", -8, 4, TFItems.fieryBlood, twilightKillHydra)).registerStat();
   public static Achievement twilightProgressTrophyPedestal = (new Achievement("TwilightForest29", "twilightProgressTrophyPedestal", -5, 2, TFBlocks.trophyPedestal, twilightProgressHydra)).registerStat();
   public static Achievement twilightProgressKnights = (new Achievement("TwilightForest21", "twilightProgressKnights", -5, -1, TFItems.phantomHelm, twilightProgressTrophyPedestal)).registerStat();
   public static Achievement twilightProgressUrghast = (new Achievement("TwilightForest22", "twilightProgressUrghast", -7, -1, new ItemStack(TFItems.trophy, 1, 3), twilightProgressKnights)).registerStat();
   public static Achievement twilightProgressYeti = (new Achievement("TwilightForest23", "twilightProgressYeti", -7, -3, TFItems.alphaFur, twilightProgressUrghast)).registerStat();
   public static Achievement twilightProgressGlacier = (new Achievement("TwilightForest24", "twilightProgressGlacier", -5, -5, new ItemStack(TFItems.trophy, 1, 4), twilightProgressYeti)).registerStat();
   public static Achievement twilightProgressTroll = (new Achievement("TwilightForest25", "twilightProgressTroll", -5, -7, TFItems.lampOfCinders, twilightProgressGlacier)).registerStat();
   public static Achievement twilightProgressThorns = (new Achievement("TwilightForest26", "twilightProgressThorns", -3, -7, TFBlocks.thorns, twilightProgressTroll)).registerStat();
   public static Achievement twilightProgressCastle = (new Achievement("TwilightForest27", "twilightProgressCastle", -1, -7, Blocks.stonebrick, twilightProgressThorns)).registerStat();
   public static Achievement twilightNagaArmors = (new Achievement("TwilightForest7", "twilightNagaArmors", 5, 1, TFItems.plateNaga, twilightKillNaga)).setSpecial().registerStat();
   public static Achievement twilightLichScepters = (new Achievement("TwilightForest9", "twilightLichScepters", 3, 7, TFItems.scepterZombie, twilightKillLich)).setSpecial().registerStat();
   public static Achievement twilightMazeMap = (new Achievement("TwilightForest15", "twilightMazeMap", 1, 7, TFItems.mazeMap, twilightProgressLich)).registerStat();
   public static Achievement twilightOreMap = (new Achievement("TwilightForest16", "twilightOreMap", 1, 9, TFItems.oreMap, twilightMazeMap)).setSpecial().registerStat();
   public static Achievement twilightHydraChop = (new Achievement("TwilightForest31", "twilightHydraChop", -6, 6, TFItems.hydraChop, twilightKillHydra)).registerStat();
   public static Achievement twilightMazebreaker = (new Achievement("TwilightForest32", "twilightMazebreaker", -3, 4, TFItems.mazebreakerPick, twilightProgressLich)).setSpecial().registerStat();
   public static Achievement twilightFierySet = (new Achievement("TwilightForest33", "twilightFierySet", -8, 7, TFItems.fierySword, twilightProgressHydra)).setSpecial().registerStat();
   public static Achievement twilightQuestRam = (new Achievement("TwilightForest34", "twilightQuestRam", 1, -5, TFItems.crumbleHorn, twilightArrival)).setSpecial().registerStat();


   public TFAchievementPage() {
      super("Twilight Forest", new Achievement[]{twilightPortal, twilightArrival, twilightHunter, twilightMagicMapFocus, twilightKillNaga, twilightNagaArmors, twilightKillLich, twilightLichScepters, twilightHill1, twilightHill2, twilightHill3, twilightHedge, twilightMagicMap, twilightMazeMap, twilightOreMap, twilightProgressNaga, twilightProgressLich, twilightProgressLabyrinth, twilightHydraChop, twilightProgressKnights, twilightProgressUrghast, twilightProgressYeti, twilightProgressGlacier, twilightProgressTroll, twilightProgressThorns, twilightProgressCastle, twilightKillHydra, twilightHydraChop, twilightProgressTrophyPedestal, twilightProgressHydra, twilightMazebreaker, twilightFierySet, twilightQuestRam});
   }

}

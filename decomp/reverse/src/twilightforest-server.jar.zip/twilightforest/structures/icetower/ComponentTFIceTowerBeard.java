package twilightforest.structures.icetower;

import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFIceTowerBeard extends StructureTFComponent {

   protected int size;
   protected int height;


   public ComponentTFIceTowerBeard() {}

   public ComponentTFIceTowerBeard(int i, ComponentTFTowerWing wing) {
      super(i);
      this.setCoordBaseMode(wing.getCoordBaseMode());
      this.size = wing.size;
      this.height = Math.round((float)this.size * 1.414F);
      super.deco = wing.deco;
      super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX, wing.getBoundingBox().minY - this.height, wing.getBoundingBox().minZ, wing.getBoundingBox().maxX, wing.getBoundingBox().minY, wing.getBoundingBox().maxZ);
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("beardSize", this.size);
      par1NBTTagCompound.setInteger("beardHeight", this.height);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.size = par1NBTTagCompound.getInteger("beardSize");
      this.height = par1NBTTagCompound.getInteger("beardHeight");
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      for(int x = 0; x < this.size; ++x) {
         for(int z = 0; z < this.size; ++z) {
            int rHeight = Math.round(MathHelper.sqrt_float((float)(x * x + z * z)));

            for(int y = 0; y < rHeight; ++y) {
               this.placeBlockAtCurrentPosition(world, super.deco.blockID, super.deco.blockMeta, x, this.height - y, z, sbb);
            }
         }
      }

      return true;
   }
}

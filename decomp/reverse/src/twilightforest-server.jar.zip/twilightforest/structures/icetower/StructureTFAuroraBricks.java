package twilightforest.structures.icetower;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.gen.structure.StructureComponent.BlockSelector;
import twilightforest.block.TFBlocks;

public class StructureTFAuroraBricks extends BlockSelector {

   public void selectBlocks(Random par1Random, int x, int y, int z, boolean wall) {
      if(!wall) {
         super.field_151562_a = Blocks.air;
         super.selectedBlockMetaData = 0;
      } else {
         super.field_151562_a = TFBlocks.auroraBlock;
         super.selectedBlockMetaData = Math.abs(x + z) % 16;
      }

   }
}

package twilightforest.structures.icetower;

import net.minecraft.init.Blocks;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFDecorator;
import twilightforest.structures.icetower.StructureTFAuroraBricks;

public class StructureDecoratorIceTower extends StructureTFDecorator {

   public StructureDecoratorIceTower() {
      super.blockID = TFBlocks.auroraBlock;
      super.blockMeta = 0;
      super.accentID = Blocks.planks;
      super.accentMeta = 2;
      super.fenceID = Blocks.fence;
      super.stairID = Blocks.birch_stairs;
      super.pillarID = TFBlocks.auroraPillar;
      super.pillarMeta = 0;
      super.platformID = Blocks.wooden_slab;
      super.platformMeta = 2;
      super.floorID = Blocks.planks;
      super.floorMeta = 2;
      super.randomBlocks = new StructureTFAuroraBricks();
   }
}

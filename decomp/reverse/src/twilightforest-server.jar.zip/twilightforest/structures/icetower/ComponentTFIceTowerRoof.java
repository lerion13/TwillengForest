package twilightforest.structures.icetower;

import java.util.Random;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.lichtower.ComponentTFTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFIceTowerRoof extends ComponentTFTowerRoof {

   public ComponentTFIceTowerRoof() {}

   public ComponentTFIceTowerRoof(int i, ComponentTFTowerWing wing) {
      super(i, wing);
      this.setCoordBaseMode(wing.getCoordBaseMode());
      super.size = wing.size;
      super.height = 12;
      super.deco = wing.deco;
      this.makeCapBB(wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      super.addComponentParts(world, rand, sbb);

      for(int x = 0; x < super.size; ++x) {
         for(int z = 0; z < super.size; ++z) {
            int rHeight = Math.round(MathHelper.sqrt_float((float)(x * x + z * z)));

            for(int y = 0; y < rHeight; ++y) {
               this.placeBlockAtCurrentPosition(world, super.deco.blockID, super.deco.blockMeta, x, y, z, sbb);
            }
         }
      }

      return true;
   }
}

package twilightforest.structures.icetower;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.structures.icetower.ComponentTFIceTowerBridge;
import twilightforest.structures.icetower.ComponentTFIceTowerEntrance;
import twilightforest.structures.icetower.ComponentTFIceTowerWing;
import twilightforest.structures.icetower.StructureDecoratorIceTower;

public class ComponentTFIceTowerMain extends ComponentTFIceTowerWing {

   public boolean hasBossWing;


   public ComponentTFIceTowerMain() {
      this.hasBossWing = false;
   }

   public ComponentTFIceTowerMain(World world, Random rand, int index, int x, int y, int z) {
      this(world, rand, index, x + 11, y + 40, z + 11, 2);
   }

   public ComponentTFIceTowerMain(World world, Random rand, int index, int x, int y, int z, int rotation) {
      super(index, x, y, z, 11, 31 + rand.nextInt(3) * 10, rotation);
      this.hasBossWing = false;
      if(super.deco == null) {
         super.deco = new StructureDecoratorIceTower();
      }

   }

   protected ComponentTFIceTowerMain(int i, int x, int y, int z, int pSize, int pHeight, int direction) {
      super(i, x, y, z, pSize, pHeight, direction);
      this.hasBossWing = false;
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("hasBossWing", this.hasBossWing);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.hasBossWing = par1NBTTagCompound.getBoolean("hasBossWing");
   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      super.buildComponent(parent, list, rand);
      StructureBoundingBox towerBB = StructureBoundingBox.getNewBoundingBox();
      Iterator myDoor = list.iterator();

      while(myDoor.hasNext()) {
         StructureComponent entranceDoor = (StructureComponent)myDoor.next();
         towerBB.expandTo(entranceDoor.getBoundingBox());
      }

      ChunkCoordinates myDoor1 = (ChunkCoordinates)super.openings.get(0);
      ChunkCoordinates entranceDoor1 = new ChunkCoordinates(myDoor1);
      if(myDoor1.posX == 0) {
         int length = this.getBoundingBox().minX - towerBB.minX;
         if(length >= 0) {
            entranceDoor1.posX -= length;
            this.makeEntranceBridge(list, rand, this.getComponentType() + 1, myDoor1.posX, myDoor1.posY, myDoor1.posZ, length, 2);
         }
      }

      if(myDoor1.posX == super.size - 1) {
         entranceDoor1.posX += towerBB.maxX - this.getBoundingBox().maxX;
      }

      if(myDoor1.posZ == 0) {
         entranceDoor1.posZ += towerBB.minZ - this.getBoundingBox().minZ;
      }

      if(myDoor1.posX == super.size - 1) {
         entranceDoor1.posZ += towerBB.maxZ - this.getBoundingBox().maxZ;
      }

      this.makeEntranceTower(list, rand, this.getComponentType() + 1, entranceDoor1.posX, entranceDoor1.posY, entranceDoor1.posZ, 11, 11, this.getCoordBaseMode());
   }

   private void makeEntranceBridge(List list, Random rand, int index, int x, int y, int z, int length, int rotation) {
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      ChunkCoordinates dest = this.offsetTowerCCoords(x, y, z, 5, direction);
      ComponentTFIceTowerBridge bridge = new ComponentTFIceTowerBridge(index, dest.posX, dest.posY, dest.posZ, length, direction);
      list.add(bridge);
      bridge.buildComponent((StructureComponent)list.get(0), list, rand);
   }

   public boolean makeEntranceTower(List list, Random rand, int index, int x, int y, int z, int wingSize, int wingHeight, int rotation) {
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      int[] dx = this.offsetTowerCoords(x, y, z, wingSize, direction);
      ComponentTFIceTowerEntrance entrance = new ComponentTFIceTowerEntrance(index, dx[0], dx[1], dx[2], wingSize, wingHeight, direction);
      list.add(entrance);
      entrance.buildComponent((StructureComponent)list.get(0), list, rand);
      this.addOpening(x, y, z, rotation);
      return true;
   }
}

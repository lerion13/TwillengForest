package twilightforest.structures.icetower;

import java.util.List;
import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.structures.StructureTFComponent;

public class ComponentTFIceTowerBridge extends StructureTFComponent {

   private int length;


   public ComponentTFIceTowerBridge() {}

   public ComponentTFIceTowerBridge(int index, int x, int y, int z, int length, int direction) {
      super(index);
      this.length = length;
      this.setCoordBaseMode(direction);
      super.boundingBox = StructureTFComponent.getComponentToAddBoundingBox(x, y, z, 0, 0, 0, length, 6, 5, direction);
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("bridgeLength", this.length);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.length = par1NBTTagCompound.getInteger("bridgeLength");
   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      if(parent != null && parent instanceof StructureTFComponent) {
         super.deco = ((StructureTFComponent)parent).deco;
      }

   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      this.fillWithAir(world, sbb, 0, 1, 0, this.length, 5, 4);
      this.fillWithBlocks(world, sbb, 0, 0, 0, this.length, 0, 4, super.deco.blockID, super.deco.blockID, false);
      this.fillWithBlocks(world, sbb, 0, 6, 0, this.length, 6, 4, super.deco.blockID, super.deco.blockID, false);

      for(int x = 2; x < this.length; x += 3) {
         this.fillWithMetadataBlocks(world, sbb, x, 1, 0, x, 5, 0, super.deco.pillarID, super.deco.pillarMeta, super.deco.pillarID, super.deco.pillarMeta, false);
         this.fillWithMetadataBlocks(world, sbb, x, 1, 4, x, 5, 4, super.deco.pillarID, super.deco.pillarMeta, super.deco.pillarID, super.deco.pillarMeta, false);
      }

      return true;
   }
}

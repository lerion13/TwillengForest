package twilightforest.structures.lichtower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.lichtower.ComponentTFTowerRoofSlab;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFTowerRoofAttachedSlab extends ComponentTFTowerRoofSlab {

   public ComponentTFTowerRoofAttachedSlab() {}

   public ComponentTFTowerRoofAttachedSlab(int i, ComponentTFTowerWing wing) {
      super(i, wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      byte slabMeta = 2;
      return this.makeConnectedCap(world, slabMeta, sbb);
   }
}

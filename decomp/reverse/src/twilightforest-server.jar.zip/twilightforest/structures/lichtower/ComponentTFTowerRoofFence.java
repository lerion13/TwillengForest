package twilightforest.structures.lichtower;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.lichtower.ComponentTFTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFTowerRoofFence extends ComponentTFTowerRoof {

   public ComponentTFTowerRoofFence() {}

   public ComponentTFTowerRoofFence(int i, ComponentTFTowerWing wing) {
      super(i, wing);
      this.setCoordBaseMode(wing.getCoordBaseMode());
      super.size = wing.size;
      super.height = 0;
      this.makeCapBB(wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      int y = super.height + 1;

      for(int x = 0; x <= super.size - 1; ++x) {
         for(int z = 0; z <= super.size - 1; ++z) {
            if(x == 0 || x == super.size - 1 || z == 0 || z == super.size - 1) {
               this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, x, y, z, sbb);
            }
         }
      }

      return true;
   }
}

package twilightforest.structures.lichtower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.lichtower.ComponentTFTowerBeard;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFTowerBeardAttached extends ComponentTFTowerBeard {

   public ComponentTFTowerBeardAttached() {}

   public ComponentTFTowerBeardAttached(int i, ComponentTFTowerWing wing) {
      super(i, wing);
      super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX, wing.getBoundingBox().minY - super.height - 1, wing.getBoundingBox().minZ, wing.getBoundingBox().maxX, wing.getBoundingBox().minY - 1, wing.getBoundingBox().maxZ);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      return this.makeAttachedBeard(world, rand, sbb);
   }

   private boolean makeAttachedBeard(World world, Random rand, StructureBoundingBox sbb) {
      for(int y = 0; y <= super.height; ++y) {
         int min = y + 1;
         int max = super.size - y;
         this.fillWithRandomizedBlocks(world, sbb, 0, super.height - y, min, max, super.height - y, max, false, rand, StructureTFComponent.getStrongholdStones());
      }

      return true;
   }
}

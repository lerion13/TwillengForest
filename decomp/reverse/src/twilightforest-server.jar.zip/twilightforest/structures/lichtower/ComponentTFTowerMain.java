package twilightforest.structures.lichtower;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.block.TFBlocks;
import twilightforest.entity.TFCreatures;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.lichtower.ComponentTFTowerOutbuilding;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFTowerMain extends ComponentTFTowerWing {

   public ComponentTFTowerMain() {}

   public ComponentTFTowerMain(World world, Random rand, int index, int x, int y, int z) {
      super(index, x, y, z, 15, 55 + rand.nextInt(32), 0);
   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      this.makeARoof(parent, list, rand);

      int i;
      int[] dest;
      int childHeight;
      for(i = 0; i < 4; ++i) {
         dest = this.getValidOpening(rand, i);
         if(dest[1] < super.height / 2) {
            dest[1] += 20;
         }

         childHeight = Math.min(21 + rand.nextInt(10), super.height - dest[1] - 3);
         if(!this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 9, childHeight, i)) {
            this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 7, childHeight, i);
         }
      }

      for(i = 0; i < 4; ++i) {
         dest = this.getValidOpening(rand, i);
         if(dest[1] < super.height / 2) {
            dest[1] += 10;
         }

         childHeight = Math.min(21 + rand.nextInt(10), super.height - dest[1] - 3);
         if(!this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 9, childHeight, i)) {
            this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 7, childHeight, i);
         }
      }

      for(i = 0; i < 4; ++i) {
         dest = this.getValidOpening(rand, i);
         childHeight = Math.min(7 + rand.nextInt(6), super.height - dest[1] - 3);
         if(!this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 5, childHeight, i)) {
            this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 3, childHeight, i);
         }
      }

      for(i = 0; i < 4; ++i) {
         dest = this.getOutbuildingOpening(rand, i);
         childHeight = 11 + rand.nextInt(10);
         int childSize = 7 + rand.nextInt(2) * 2;
         this.makeTowerOutbuilding(list, rand, 1, dest[0], dest[1], dest[2], childSize, childHeight, i);
      }

      for(i = 0; i < 16; ++i) {
         dest = this.getValidOpening(rand, i % 4);
         childHeight = 6 + rand.nextInt(5);
         if(rand.nextInt(3) == 0 || !this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 5, childHeight, i % 4)) {
            this.makeTowerWing(list, rand, 1, dest[0], dest[1], dest[2], 3, childHeight, i % 4);
         }
      }

   }

   public int[] getOutbuildingOpening(Random rand, int rotation) {
      int rx = 0;
      byte ry = 1;
      int rz = 0;
      switch(rotation) {
      case 0:
         rx = super.size - 1;
         rz = 6 + rand.nextInt(8);
         break;
      case 1:
         rx = 1 + rand.nextInt(11);
         rz = super.size - 1;
         break;
      case 2:
         rx = 0;
         rz = 1 + rand.nextInt(8);
         break;
      case 3:
         rx = 3 + rand.nextInt(11);
         rz = 0;
      }

      return new int[]{rx, ry, rz};
   }

   public boolean makeTowerOutbuilding(List list, Random rand, int index, int x, int y, int z, int wingSize, int wingHeight, int rotation) {
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      int[] dx = this.offsetTowerCoords(x, y, z, wingSize, direction);
      ComponentTFTowerOutbuilding outbuilding = new ComponentTFTowerOutbuilding(index, dx[0], dx[1], dx[2], wingSize, wingHeight, direction);
      StructureComponent intersect = StructureComponent.findIntersecting(list, outbuilding.getBoundingBox());
      if(intersect != null && intersect != this) {
         return false;
      } else {
         list.add(outbuilding);
         outbuilding.buildComponent(this, list, rand);
         this.addOpening(x, y, z, rotation);
         return true;
      }
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      this.fillWithRandomizedBlocks(world, sbb, 0, 0, 0, super.size - 1, super.height - 1, super.size - 1, false, rand, StructureTFComponent.getStrongholdStones());
      this.fillWithAir(world, sbb, 1, 1, 1, super.size - 2, super.height - 2, super.size - 2);

      for(int x = 0; x < super.size; ++x) {
         for(int z = 0; z < super.size; ++z) {
            this.func_151554_b(world, Blocks.cobblestone, 0, x, -1, z, sbb);
         }
      }

      this.nullifySkyLightForBoundingBox(world);
      if(super.height - super.highestOpening > 15) {
         super.highestOpening = super.height - 15;
      }

      this.makeStairs(world, rand, sbb);
      this.makeOpenings(world, sbb);
      this.decorateStairFloor(world, rand, sbb);
      this.makeStairwayCrossings(world, rand, sbb);
      this.makeLichRoom(world, rand, sbb);
      this.makeTowerPaintings(world, rand, sbb);
      return true;
   }

   protected void makeStairwayCrossings(World world, Random rand, StructureBoundingBox sbb) {
      int flights = super.highestOpening / 5 - 2;

      for(int i = 2 + rand.nextInt(2); i < flights; i += 1 + rand.nextInt(5)) {
         this.makeStairCrossing(world, rand, i, sbb);
      }

   }

   protected void makeStairCrossing(World world, Random rand, int flight, StructureBoundingBox sbb) {
      int temp = this.getCoordBaseMode();
      if(flight % 2 == 0) {
         this.setCoordBaseMode((this.getCoordBaseMode() + 1) % 4);
      }

      int floorMeta = rand.nextInt(2) == 0?0:2;
      int floorLevel = 0 + flight * 5;

      int dx;
      int mobID;
      for(dx = 6; dx <= 8; ++dx) {
         for(mobID = 4; mobID <= 10; ++mobID) {
            this.placeBlockAtCurrentPosition(world, Blocks.double_stone_slab, floorMeta, dx, floorLevel, mobID, sbb);
         }
      }

      ++floorLevel;
      byte var10 = 6;

      for(mobID = 3; mobID <= 11; ++mobID) {
         this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, var10, floorLevel, mobID, sbb);
      }

      dx = var10 + 1;

      for(mobID = 3; mobID <= 11; ++mobID) {
         this.placeBlockAtCurrentPosition(world, Blocks.air, 0, dx, floorLevel, mobID, sbb);
      }

      ++dx;

      for(mobID = 3; mobID <= 11; ++mobID) {
         this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, dx, floorLevel, mobID, sbb);
      }

      this.placeBlockAtCurrentPosition(world, Blocks.double_stone_slab, floorMeta, 6, floorLevel - 1, 11, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.double_stone_slab, floorMeta, 8, floorLevel - 1, 3, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 5, floorLevel, 11, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 9, floorLevel, 3, sbb);
      String var11 = "Skeleton";
      switch(rand.nextInt(4)) {
      case 0:
      case 1:
         var11 = "Skeleton";
         break;
      case 2:
         var11 = "Zombie";
         break;
      case 3:
         var11 = TFCreatures.getSpawnerNameFor("Swarm Spider");
      }

      this.placeSpawnerAtCurrentPosition(world, rand, 7, floorLevel + 2, 7, var11, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 6, floorLevel + 1, 7, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 8, floorLevel + 1, 7, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 6, floorLevel + 2, 7, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, 8, floorLevel + 2, 7, sbb);
      this.setCoordBaseMode(temp);
   }

   protected void makeLichRoom(World world, Random rand, StructureBoundingBox sbb) {
      int floorLevel = 2 + super.highestOpening / 5 * 5;
      this.makeLichFloor(world, floorLevel, super.highestOpening / 5 % 2, sbb);
      this.decorateLichChandelier(world, floorLevel, sbb);
      this.decoratePaintings(world, rand, floorLevel, sbb);
      this.decorateTorches(world, rand, floorLevel, sbb);
      this.placeBlockAtCurrentPosition(world, TFBlocks.bossSpawner, 1, super.size / 2, floorLevel + 2, super.size / 2, sbb);
   }

   protected void makeTowerPaintings(World world, Random rand, StructureBoundingBox sbb) {
      byte howMany = 10;
      this.generatePaintingsOnWall(world, rand, howMany, 0, 0, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 0, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 0, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 1, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 1, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 1, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 2, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 2, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 2, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 3, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 3, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, 0, 3, 0, sbb);
   }

   protected void makeLichFloor(World world, int floorLevel, int rotation, StructureBoundingBox sbb) {
      int temp = this.getCoordBaseMode();
      this.setCoordBaseMode((this.getCoordBaseMode() + rotation) % 4);

      for(int fx = 1; fx < 14; ++fx) {
         for(int fz = 1; fz < 14; ++fz) {
            if((fx == 1 || fx == 2) && fz >= 6 && fz <= 12) {
               if(fz == 6) {
                  this.placeBlockAtCurrentPosition(world, Blocks.wooden_slab, 10, fx, floorLevel, fz, sbb);
               }
            } else if((fx == 12 || fx == 13) && fz >= 3 && fz <= 8) {
               if(fz == 8) {
                  this.placeBlockAtCurrentPosition(world, Blocks.wooden_slab, 10, fx, floorLevel, fz, sbb);
               }
            } else if(fx >= 4 && fx <= 10 && fz >= 4 && fz <= 10) {
               if((fx != 4 || fz != 4) && (fx != 10 || fz != 10)) {
                  this.placeBlockAtCurrentPosition(world, Blocks.glass, 0, fx, floorLevel, fz, sbb);
               } else {
                  this.placeBlockAtCurrentPosition(world, Blocks.planks, 2, fx, floorLevel, fz, sbb);
               }
            } else if((fx == 2 || fx == 3) && (fz == 2 || fz == 3)) {
               this.placeBlockAtCurrentPosition(world, Blocks.glass, 0, fx, floorLevel, fz, sbb);
            } else if((fx == 11 || fx == 12) && (fz == 11 || fz == 12)) {
               this.placeBlockAtCurrentPosition(world, Blocks.glass, 0, fx, floorLevel, fz, sbb);
            } else {
               this.placeBlockAtCurrentPosition(world, Blocks.planks, 2, fx, floorLevel, fz, sbb);
            }
         }
      }

      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 3, floorLevel + 1, 11, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 3, floorLevel + 1, 10, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 3, floorLevel + 2, 11, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 11, floorLevel + 1, 3, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 11, floorLevel + 1, 4, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.air, 0, 11, floorLevel + 2, 3, sbb);
      this.setCoordBaseMode(temp);
   }

   protected void decorateLichChandelier(World world, int floorLevel, StructureBoundingBox sbb) {
      int cx = super.size / 2;
      int cy = floorLevel + 4;
      int cz = super.size / 2;
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 2, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 1, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz + 2, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx - 1, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx - 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx - 2, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx - 1, cy, cz - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz - 2, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 1, cy, cz - 1, sbb);
      ++cy;
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 2, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 1, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 0, cy, cz + 2, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx - 1, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx - 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx - 2, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx - 1, cy, cz - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, cy, cz - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 0, cy, cz - 2, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 1, cy, cz - 1, sbb);
      ++cy;
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 0, cy, cz + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx - 1, cy, cz + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.torch, 0, cx + 0, cy, cz - 1, sbb);

      for(int y = floorLevel + 5; y < super.height - 1; ++y) {
         this.placeBlockAtCurrentPosition(world, Blocks.fence, 0, cx + 0, y, cz + 0, sbb);
      }

   }

   protected void decoratePaintings(World world, Random rand, int floorLevel, StructureBoundingBox sbb) {
      byte howMany = 100;
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 0, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 0, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 0, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 1, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 1, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 1, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 2, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 2, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 2, 0, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 3, 48, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 3, 32, sbb);
      this.generatePaintingsOnWall(world, rand, howMany, floorLevel, 3, 0, sbb);
   }

   protected void decorateTorches(World world, Random rand, int floorLevel, StructureBoundingBox sbb) {
      this.generateTorchesOnWall(world, rand, floorLevel, 0, sbb);
      this.generateTorchesOnWall(world, rand, floorLevel, 1, sbb);
      this.generateTorchesOnWall(world, rand, floorLevel, 2, sbb);
      this.generateTorchesOnWall(world, rand, floorLevel, 3, sbb);
   }

   protected void generateTorchesOnWall(World world, Random rand, int floorLevel, int direction, StructureBoundingBox sbb) {
      for(int i = 0; i < 10; ++i) {
         ChunkCoordinates wCoords = this.getRandomWallSpot(rand, floorLevel, direction, sbb);
         ChunkCoordinates tCoords = new ChunkCoordinates(wCoords);
         if(direction == 0) {
            ++tCoords.posZ;
         }

         if(direction == 1) {
            --tCoords.posX;
         }

         if(direction == 2) {
            --tCoords.posZ;
         }

         if(direction == 3) {
            ++tCoords.posX;
         }

         AxisAlignedBB torchBox = AxisAlignedBB.getBoundingBox((double)tCoords.posX, (double)tCoords.posY, (double)tCoords.posZ, (double)tCoords.posX + 1.0D, (double)tCoords.posY + 2.0D, (double)tCoords.posZ + 1.0D);
         if(world.getBlock(tCoords.posX, tCoords.posY, tCoords.posZ) == Blocks.air && world.getBlock(tCoords.posX, tCoords.posY + 1, tCoords.posZ) == Blocks.air && world.getEntitiesWithinAABBExcludingEntity((Entity)null, torchBox).size() == 0) {
            world.setBlock(tCoords.posX, tCoords.posY, tCoords.posZ, Blocks.fence, 0, 2);
            world.setBlock(tCoords.posX, tCoords.posY + 1, tCoords.posZ, Blocks.torch, 5, 2);
         }
      }

   }
}

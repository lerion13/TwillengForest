package twilightforest.structures.lichtower;

import java.util.List;
import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public abstract class ComponentTFTowerRoof extends StructureTFComponent {

   protected int size;
   protected int height;


   public ComponentTFTowerRoof() {}

   public ComponentTFTowerRoof(int i, ComponentTFTowerWing wing) {
      super(i);
      super.spawnListIndex = -1;
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("roofSize", this.size);
      par1NBTTagCompound.setInteger("roofHeight", this.height);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.size = par1NBTTagCompound.getInteger("roofSize");
      this.height = par1NBTTagCompound.getInteger("roofHeight");
   }

   protected void makeAttachedOverhangBB(ComponentTFTowerWing wing) {
      switch(this.getCoordBaseMode()) {
      case 0:
         super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ - 1, wing.getBoundingBox().maxX + 1, wing.getBoundingBox().maxY + this.height - 1, wing.getBoundingBox().maxZ + 1);
         break;
      case 1:
         super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX - 1, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ, wing.getBoundingBox().maxX + 1, wing.getBoundingBox().maxY + this.height - 1, wing.getBoundingBox().maxZ + 1);
         break;
      case 2:
         super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX - 1, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ - 1, wing.getBoundingBox().maxX, wing.getBoundingBox().maxY + this.height - 1, wing.getBoundingBox().maxZ + 1);
         break;
      case 3:
         super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX - 1, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ - 1, wing.getBoundingBox().maxX + 1, wing.getBoundingBox().maxY + this.height - 1, wing.getBoundingBox().maxZ);
      }

   }

   protected void makeCapBB(ComponentTFTowerWing wing) {
      super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ, wing.getBoundingBox().maxX, wing.getBoundingBox().maxY + this.height, wing.getBoundingBox().maxZ);
   }

   protected void makeOverhangBB(ComponentTFTowerWing wing) {
      super.boundingBox = new StructureBoundingBox(wing.getBoundingBox().minX - 1, wing.getBoundingBox().maxY, wing.getBoundingBox().minZ - 1, wing.getBoundingBox().maxX + 1, wing.getBoundingBox().maxY + this.height - 1, wing.getBoundingBox().maxZ + 1);
   }

   public boolean addComponentParts(World world, Random random, StructureBoundingBox structureboundingbox) {
      return false;
   }

   public boolean fits(ComponentTFTowerWing parent, List list, Random rand) {
      return StructureComponent.findIntersecting(list, super.boundingBox) == parent;
   }
}

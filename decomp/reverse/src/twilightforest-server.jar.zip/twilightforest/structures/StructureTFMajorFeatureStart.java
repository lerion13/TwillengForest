package twilightforest.structures;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.structure.MapGenStructureIO;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import net.minecraft.world.gen.structure.StructureStart;
import net.minecraft.world.gen.structure.StructureStrongholdPieces;
import net.minecraft.world.gen.structure.StructureStrongholdPieces.Stairs2;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.block.TFBlocks;
import twilightforest.structures.ComponentTFHedgeMaze;
import twilightforest.structures.ComponentTFHillMaze;
import twilightforest.structures.ComponentTFHollowHill;
import twilightforest.structures.ComponentTFHydraLair;
import twilightforest.structures.ComponentTFNagaCourtyard;
import twilightforest.structures.ComponentTFQuestGrove;
import twilightforest.structures.ComponentTFYetiCave;
import twilightforest.structures.darktower.ComponentTFDarkTowerMain;
import twilightforest.structures.darktower.TFDarkTowerPieces;
import twilightforest.structures.hollowtree.StructureTFHollowTreeStart;
import twilightforest.structures.hollowtree.TFHollowTreePieces;
import twilightforest.structures.icetower.ComponentTFIceTowerMain;
import twilightforest.structures.icetower.TFIceTowerPieces;
import twilightforest.structures.lichtower.ComponentTFTowerMain;
import twilightforest.structures.lichtower.TFLichTowerPieces;
import twilightforest.structures.minotaurmaze.ComponentTFMazeRuins;
import twilightforest.structures.minotaurmaze.TFMinotaurMazePieces;
import twilightforest.structures.mushroomtower.ComponentTFMushroomTowerMain;
import twilightforest.structures.mushroomtower.TFMushroomTowerPieces;
import twilightforest.structures.stronghold.ComponentTFStrongholdEntrance;
import twilightforest.structures.stronghold.TFStrongholdPieces;
import twilightforest.structures.trollcave.ComponentTFTrollCaveMain;
import twilightforest.structures.trollcave.TFTrollCavePieces;
import twilightforest.world.TFWorld;
import twilightforest.world.TFWorldChunkManager;

public class StructureTFMajorFeatureStart extends StructureStart {

   public TFFeature feature;
   public boolean isConquered;


   public StructureTFMajorFeatureStart() {}

   public StructureTFMajorFeatureStart(World world, Random rand, int chunkX, int chunkZ) {
      StructureStrongholdPieces.prepareStructurePieces();
      int x = (chunkX << 4) + 8;
      int z = (chunkZ << 4) + 8;
      int y = TFWorld.SEALEVEL + 1;
      this.feature = TFFeature.getFeatureDirectlyAt(chunkX, chunkZ, world);
      this.isConquered = false;
      StructureComponent firstComponent = this.makeFirstComponent(world, rand, this.feature, x, y, z);
      if(firstComponent != null) {
         super.components.add(firstComponent);
         firstComponent.buildComponent(firstComponent, super.components, rand);
      }

      this.updateBoundingBox();
      if(firstComponent instanceof Stairs2) {
         List var6 = ((Stairs2)firstComponent).field_75026_c;

         while(!var6.isEmpty()) {
            int offY = rand.nextInt(var6.size());
            StructureComponent var8 = (StructureComponent)var6.remove(offY);
            var8.buildComponent(firstComponent, super.components, rand);
         }

         this.updateBoundingBox();
         byte offY1 = -33;
         super.boundingBox.offset(0, offY1, 0);
         Iterator var81 = this.getComponents().iterator();

         while(var81.hasNext()) {
            StructureComponent com = (StructureComponent)var81.next();
            com.getBoundingBox().offset(0, offY1, 0);
         }
      }

      if(firstComponent instanceof ComponentTFTowerMain || firstComponent instanceof ComponentTFDarkTowerMain) {
         this.moveToAvgGroundLevel(world, x, z);
      }

   }

   public StructureComponent makeFirstComponent(World world, Random rand, TFFeature feature, int x, int y, int z) {
      return (StructureComponent)(feature == TFFeature.nagaCourtyard?new ComponentTFNagaCourtyard(world, rand, 0, x, y, z):(feature == TFFeature.hedgeMaze?new ComponentTFHedgeMaze(world, rand, 0, x, y, z):(feature == TFFeature.hill1?new ComponentTFHollowHill(world, rand, 0, 1, x, y, z):(feature == TFFeature.hill2?new ComponentTFHollowHill(world, rand, 0, 2, x, y, z):(feature == TFFeature.hill3?new ComponentTFHollowHill(world, rand, 0, 3, x, y, z):(feature == TFFeature.lichTower?new ComponentTFTowerMain(world, rand, 0, x, y, z):(feature == TFFeature.questGrove?new ComponentTFQuestGrove(world, rand, 0, x, y, z):(feature == TFFeature.hydraLair?new ComponentTFHydraLair(world, rand, 0, x, y, z):(feature == TFFeature.labyrinth?new ComponentTFMazeRuins(world, rand, 0, x, y, z):(feature == TFFeature.darkTower?new ComponentTFDarkTowerMain(world, rand, 0, x, y - 1, z):(feature == TFFeature.tfStronghold?new ComponentTFStrongholdEntrance(world, rand, 0, x, y, z):(feature == TFFeature.iceTower?new ComponentTFIceTowerMain(world, rand, 0, x, y, z):(feature == TFFeature.mushroomTower?new ComponentTFMushroomTowerMain(world, rand, 0, x, y, z):(feature == TFFeature.yetiCave?new ComponentTFYetiCave(world, rand, 0, x, y, z):(feature == TFFeature.trollCave?new ComponentTFTrollCaveMain(world, rand, 0, x, y, z):null)))))))))))))));
   }

   public boolean isSizeableStructure() {
      return this.feature.isStructureEnabled;
   }

   protected void moveToAvgGroundLevel(World world, int x, int z) {
      if(world.getWorldChunkManager() instanceof TFWorldChunkManager) {
         BiomeGenBase biomeAt = world.getBiomeGenForCoords(x, z);
         int offY = (int)((biomeAt.rootHeight + biomeAt.heightVariation) * 8.0F);
         if(biomeAt == TFBiomeBase.darkForest) {
            offY += 4;
         }

         if(offY > 0) {
            super.boundingBox.offset(0, offY, 0);
            Iterator var6 = this.getComponents().iterator();

            while(var6.hasNext()) {
               StructureComponent com = (StructureComponent)var6.next();
               com.getBoundingBox().offset(0, offY, 0);
            }
         }
      }

   }

   private boolean isIntersectingLarger(StructureBoundingBox chunkBB, StructureComponent component) {
      StructureBoundingBox compBB = component.getBoundingBox();
      return compBB.maxX + 1 >= chunkBB.minX && compBB.minX - 1 <= chunkBB.maxX && compBB.maxZ + 1 >= chunkBB.minZ && compBB.minZ - 1 <= chunkBB.maxZ;
   }

   private boolean isShieldable(StructureComponent component) {
      return component.getBoundingBox().maxY <= 32;
   }

   private void addShieldFor(World world, StructureComponent component, List otherComponents, StructureBoundingBox chunkBox) {
      StructureBoundingBox shieldBox = new StructureBoundingBox(component.getBoundingBox());
      --shieldBox.minX;
      --shieldBox.minY;
      --shieldBox.minZ;
      ++shieldBox.maxX;
      ++shieldBox.maxY;
      ++shieldBox.maxZ;
      ArrayList intersecting = new ArrayList();
      Iterator x = otherComponents.iterator();

      while(x.hasNext()) {
         StructureComponent y = (StructureComponent)x.next();
         if(y != component && shieldBox.intersectsWith(y.getBoundingBox())) {
            intersecting.add(y);
         }
      }

      for(int var13 = shieldBox.minX; var13 <= shieldBox.maxX; ++var13) {
         for(int var14 = shieldBox.minY; var14 <= shieldBox.maxY; ++var14) {
            for(int z = shieldBox.minZ; z <= shieldBox.maxZ; ++z) {
               if((var13 == shieldBox.minX || var13 == shieldBox.maxX || var14 == shieldBox.minY || var14 == shieldBox.maxY || z == shieldBox.minZ || z == shieldBox.maxZ) && chunkBox.isVecInside(var13, var14, z)) {
                  boolean notIntersecting = true;
                  Iterator var11 = intersecting.iterator();

                  while(var11.hasNext()) {
                     StructureComponent other = (StructureComponent)var11.next();
                     if(other.getBoundingBox().isVecInside(var13, var14, z)) {
                        notIntersecting = false;
                     }
                  }

                  if(notIntersecting) {
                     world.setBlock(var13, var14, z, TFBlocks.shield, this.calculateShieldMeta(shieldBox, var13, var14, z), 2);
                  }
               }
            }
         }
      }

   }

   private int calculateShieldMeta(StructureBoundingBox shieldBox, int x, int y, int z) {
      byte shieldMeta = 0;
      if(x == shieldBox.minX) {
         shieldMeta = 5;
      }

      if(x == shieldBox.maxX) {
         shieldMeta = 4;
      }

      if(z == shieldBox.minZ) {
         shieldMeta = 3;
      }

      if(z == shieldBox.maxZ) {
         shieldMeta = 2;
      }

      if(y == shieldBox.minY) {
         shieldMeta = 1;
      }

      if(y == shieldBox.maxY) {
         shieldMeta = 0;
      }

      return shieldMeta;
   }

   public void func_143022_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143022_a(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("Conquered", this.isConquered);
      par1NBTTagCompound.setInteger("FeatureID", this.feature.featureID);
   }

   public void func_143017_b(NBTTagCompound nbttagcompound) {
      super.func_143017_b(nbttagcompound);
      this.isConquered = nbttagcompound.getBoolean("Conquered");
      this.feature = TFFeature.featureList[nbttagcompound.getInteger("FeatureID")];
   }

   static {
      MapGenStructureIO.registerStructure(StructureTFMajorFeatureStart.class, "TFFeature");
      MapGenStructureIO.registerStructure(StructureTFHollowTreeStart.class, "TFHollowTree");
      TFStrongholdPieces.registerPieces();
      TFMinotaurMazePieces.registerPieces();
      TFDarkTowerPieces.registerPieces();
      TFLichTowerPieces.registerPieces();
      TFIceTowerPieces.registerPieces();
      TFMushroomTowerPieces.registerPieces();
      TFHollowTreePieces.registerPieces();
      TFTrollCavePieces.registerPieces();
      MapGenStructureIO.func_143031_a(ComponentTFHedgeMaze.class, "TFHedge");
      MapGenStructureIO.func_143031_a(ComponentTFHillMaze.class, "TFHillMaze");
      MapGenStructureIO.func_143031_a(ComponentTFHollowHill.class, "TFHill");
      MapGenStructureIO.func_143031_a(ComponentTFHydraLair.class, "TFHydra");
      MapGenStructureIO.func_143031_a(ComponentTFNagaCourtyard.class, "TFNaga");
      MapGenStructureIO.func_143031_a(ComponentTFQuestGrove.class, "TFQuest1");
      MapGenStructureIO.func_143031_a(ComponentTFYetiCave.class, "TFYeti");
   }
}

package twilightforest.structures.hollowtree;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureStart;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeTrunk;
import twilightforest.world.TFWorld;

public class StructureTFHollowTreeStart extends StructureStart {

   public StructureTFHollowTreeStart() {}

   public StructureTFHollowTreeStart(World world, Random rand, int chunkX, int chunkZ) {
      int x = (chunkX << 4) + 8;
      int z = (chunkZ << 4) + 8;
      int y = TFWorld.SEALEVEL + 1;
      ComponentTFHollowTreeTrunk trunk = new ComponentTFHollowTreeTrunk(world, rand, 0, x, y, z);
      super.components.add(trunk);
      trunk.buildComponent(trunk, super.components, rand);
      this.updateBoundingBox();
   }
}

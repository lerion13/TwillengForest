package twilightforest.structures.hollowtree;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.block.TFBlocks;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeMedBranch;
import twilightforest.world.TFGenerator;

public class ComponentTFHollowTreeRoot extends ComponentTFHollowTreeMedBranch {

   private int groundLevel = -1;


   public ComponentTFHollowTreeRoot() {}

   public ComponentTFHollowTreeRoot(int i, int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
      super(i, sx, sy, sz, length, angle, tilt, leafy);
      super.boundingBox = new StructureBoundingBox(Math.min(super.src.posX, super.dest.posX), Math.min(super.src.posY, super.dest.posY), Math.min(super.src.posZ, super.dest.posZ), Math.max(super.src.posX, super.dest.posX), Math.max(super.src.posY, super.dest.posY), Math.max(super.src.posZ, super.dest.posZ));
   }

   public boolean addComponentParts(World world, Random random, StructureBoundingBox sbb) {
      if(this.groundLevel < 0) {
         int var10000 = super.boundingBox.maxY - super.boundingBox.minY;
         this.groundLevel = this.getSampledDirtLevel(world, sbb);
         if(this.groundLevel < 0) {
            return true;
         }

         super.src.posY = this.groundLevel + 5;
      }

      ChunkCoordinates rSrc = new ChunkCoordinates(super.src.posX - super.boundingBox.minX, super.src.posY - super.boundingBox.minY, super.src.posZ - super.boundingBox.minZ);
      ChunkCoordinates rDest = new ChunkCoordinates(super.dest.posX - super.boundingBox.minX, super.dest.posY - super.boundingBox.minY, super.dest.posZ - super.boundingBox.minZ);
      this.drawRootLine(world, sbb, rSrc.posX, rSrc.posY, rSrc.posZ, rDest.posX, rDest.posY, rDest.posZ, TFBlocks.root, 0);
      this.drawRootLine(world, sbb, rSrc.posX, rSrc.posY - 1, rSrc.posZ, rDest.posX, rDest.posY - 1, rDest.posZ, TFBlocks.root, 0);
      return true;
   }

   protected void drawRootLine(World world, StructureBoundingBox sbb, int x1, int y1, int z1, int x2, int y2, int z2, Block blockValue, int metaValue) {
      ChunkCoordinates[] lineCoords = TFGenerator.getBresehnamArrayCoords(x1, y1, z1, x2, y2, z2);
      ChunkCoordinates[] var12 = lineCoords;
      int var13 = lineCoords.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         ChunkCoordinates coords = var12[var14];
         Block block = this.getBlockAtCurrentPosition(world, coords.posX, coords.posY, coords.posZ, sbb);
         if(block.isNormalCube(world, coords.posX, coords.posY, coords.posZ) && (block == null || block.getMaterial() != Material.grass)) {
            if(block == null || block.getMaterial() != Material.wood) {
               this.placeBlockAtCurrentPosition(world, blockValue, metaValue, coords.posX, coords.posY, coords.posZ, sbb);
            }
         } else {
            this.placeBlockAtCurrentPosition(world, TFBlocks.log, 12, coords.posX, coords.posY, coords.posZ, sbb);
         }
      }

   }
}

package twilightforest.structures.hollowtree;

import java.util.List;
import java.util.Random;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.block.TFBlocks;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeLeafDungeon;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeMedBranch;
import twilightforest.world.TFGenerator;

public class ComponentTFHollowTreeLargeBranch extends ComponentTFHollowTreeMedBranch {

   private static final int LEAF_DUNGEON_CHANCE = 8;
   public boolean hasLeafDungeon = false;


   public ComponentTFHollowTreeLargeBranch() {}

   protected ComponentTFHollowTreeLargeBranch(int i, int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
      super(i, sx, sy, sz, length, angle, tilt, leafy);
   }

   public void buildComponent(StructureComponent structurecomponent, List list, Random rand) {
      int index = this.getComponentType();
      int numMedBranches = rand.nextInt((int)(super.length / 6.0D)) + (int)(super.length / 8.0D);

      for(int i = 0; i <= numMedBranches; ++i) {
         double outVar = rand.nextDouble() * 0.3D + 0.3D;
         double angleVar = rand.nextDouble() * 0.225D * ((i & 1) == 0?1.0D:-1.0D);
         ChunkCoordinates bsrc = TFGenerator.translateCoords(super.src.posX, super.src.posY, super.src.posZ, super.length * outVar, super.angle, super.tilt);
         this.makeMedBranch(list, rand, index + 2 + i, bsrc.posX, bsrc.posY, bsrc.posZ, super.length * 0.6D, super.angle + angleVar, super.tilt, super.leafy);
      }

      this.hasLeafDungeon = rand.nextInt(8) == 0;
      if(this.hasLeafDungeon) {
         this.makeLeafDungeon(list, rand, index + 1, super.dest.posX, super.dest.posY, super.dest.posZ);
      }

   }

   public void makeLeafDungeon(List list, Random rand, int index, int x, int y, int z) {
      ComponentTFHollowTreeLeafDungeon dungeon = new ComponentTFHollowTreeLeafDungeon(index, x, y, z, 4);
      list.add(dungeon);
      dungeon.buildComponent(this, list, rand);
   }

   public void makeMedBranch(List list, Random rand, int index, int x, int y, int z, double branchLength, double branchRotation, double branchAngle, boolean leafy) {
      ComponentTFHollowTreeMedBranch branch = new ComponentTFHollowTreeMedBranch(index, x, y, z, branchLength, branchRotation, branchAngle, leafy);
      list.add(branch);
      branch.buildComponent(this, list, rand);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      ChunkCoordinates rsrc = new ChunkCoordinates(super.src.posX - super.boundingBox.minX, super.src.posY - super.boundingBox.minY, super.src.posZ - super.boundingBox.minZ);
      ChunkCoordinates rdest = new ChunkCoordinates(super.dest.posX - super.boundingBox.minX, super.dest.posY - super.boundingBox.minY, super.dest.posZ - super.boundingBox.minZ);
      this.drawBresehnam(world, sbb, rsrc.posX, rsrc.posY, rsrc.posZ, rdest.posX, rdest.posY, rdest.posZ, TFBlocks.log, 12);
      byte reinforcements = 4;

      int numSmallBranches;
      int i;
      for(int decoRNG = 0; decoRNG <= reinforcements; ++decoRNG) {
         numSmallBranches = (decoRNG & 2) == 0?1:0;
         i = (decoRNG & 1) == 0?1:-1;
         int outVar = (decoRNG & 2) == 0?0:1;
         this.drawBresehnam(world, sbb, rsrc.posX + numSmallBranches, rsrc.posY + i, rsrc.posZ + outVar, rdest.posX, rdest.posY, rdest.posZ, TFBlocks.log, 12);
      }

      Random var15 = new Random(world.getSeed() + (long)(super.boundingBox.minX * 321534781) ^ (long)(super.boundingBox.minZ * 756839));
      numSmallBranches = var15.nextInt(2) + 1;

      for(i = 0; i <= numSmallBranches; ++i) {
         double var16 = (double)(var15.nextFloat() * 0.25F + 0.25F);
         double angleVar = (double)(var15.nextFloat() * 0.25F * ((i & 1) == 0?1.0F:-1.0F));
         ChunkCoordinates bsrc = TFGenerator.translateCoords(rsrc.posX, rsrc.posY, rsrc.posZ, super.length * var16, super.angle, super.tilt);
         this.drawSmallBranch(world, sbb, bsrc.posX, bsrc.posY, bsrc.posZ, Math.max(super.length * 0.30000001192092896D, 2.0D), super.angle + angleVar, super.tilt, super.leafy);
      }

      if(super.leafy && !this.hasLeafDungeon) {
         this.makeLeafBlob(world, sbb, rdest.posX, rdest.posY, rdest.posZ, 3);
      }

      return true;
   }
}

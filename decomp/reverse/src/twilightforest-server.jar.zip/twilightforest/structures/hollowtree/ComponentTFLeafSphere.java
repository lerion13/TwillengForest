package twilightforest.structures.hollowtree;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFComponent;

public class ComponentTFLeafSphere extends StructureTFComponent {

   int radius;


   public ComponentTFLeafSphere() {}

   protected ComponentTFLeafSphere(int index, int x, int y, int z, int radius) {
      super(index);
      this.setCoordBaseMode(0);
      super.boundingBox = new StructureBoundingBox(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);
      this.radius = radius;
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("leafRadius", this.radius);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.radius = par1NBTTagCompound.getInteger("leafRadius");
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      int sx = this.radius;
      int sy = this.radius;
      int sz = this.radius;

      for(byte dx = 0; dx <= this.radius; ++dx) {
         for(byte dy = 0; dy <= this.radius; ++dy) {
            for(byte dz = 0; dz <= this.radius; ++dz) {
               boolean dist = false;
               byte var11;
               if(dx >= dy && dx >= dz) {
                  var11 = (byte)(dx + (byte)((int)((double)Math.max(dy, dz) * 0.5D + (double)Math.min(dy, dz) * 0.25D)));
               } else if(dy >= dx && dy >= dz) {
                  var11 = (byte)(dy + (byte)((int)((double)Math.max(dx, dz) * 0.5D + (double)Math.min(dx, dz) * 0.25D)));
               } else {
                  var11 = (byte)(dz + (byte)((int)((double)Math.max(dx, dy) * 0.5D + (double)Math.min(dx, dy) * 0.25D)));
               }

               if(var11 <= this.radius) {
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx + dx, sy + dy, sz + dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx + dx, sy + dy, sz - dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx - dx, sy + dy, sz + dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx - dx, sy + dy, sz - dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx + dx, sy - dy, sz + dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx + dx, sy - dy, sz - dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx - dx, sy - dy, sz + dz, sbb);
                  this.placeBlockIfEmpty(world, TFBlocks.leaves, 0, sx - dx, sy - dy, sz - dz, sbb);
               }
            }
         }
      }

      return true;
   }

   protected void placeBlockIfEmpty(World world, Block blockID, int meta, int x, int y, int z, StructureBoundingBox sbb) {
      if(this.getBlockAtCurrentPosition(world, x, y, z, sbb) == Blocks.air) {
         this.placeBlockAtCurrentPosition(world, blockID, meta, x, y, z, sbb);
      }

   }
}

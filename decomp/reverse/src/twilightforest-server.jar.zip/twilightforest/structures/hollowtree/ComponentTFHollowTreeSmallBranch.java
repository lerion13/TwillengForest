package twilightforest.structures.hollowtree;

import java.util.List;
import java.util.Random;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.block.TFBlocks;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeMedBranch;

public class ComponentTFHollowTreeSmallBranch extends ComponentTFHollowTreeMedBranch {

   public ComponentTFHollowTreeSmallBranch() {}

   protected ComponentTFHollowTreeSmallBranch(int i, int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
      super(i, sx, sy, sz, length, angle, tilt, leafy);
   }

   public void buildComponent(StructureComponent structurecomponent, List list, Random rand) {}

   public boolean addComponentParts(World world, Random random, StructureBoundingBox sbb) {
      ChunkCoordinates rSrc = new ChunkCoordinates(super.src.posX - super.boundingBox.minX, super.src.posY - super.boundingBox.minY, super.src.posZ - super.boundingBox.minZ);
      ChunkCoordinates rDest = new ChunkCoordinates(super.dest.posX - super.boundingBox.minX, super.dest.posY - super.boundingBox.minY, super.dest.posZ - super.boundingBox.minZ);
      this.drawBresehnam(world, sbb, rSrc.posX, rSrc.posY, rSrc.posZ, rDest.posX, rDest.posY, rDest.posZ, TFBlocks.log, 12);
      if(super.leafy) {
         int leafRad = random.nextInt(2) + 1;
         this.makeLeafBlob(world, sbb, rDest.posX, rDest.posY, rDest.posZ, leafRad);
      }

      return true;
   }
}

package twilightforest.structures.hollowtree;

import net.minecraft.world.gen.structure.MapGenStructureIO;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeLargeBranch;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeLeafDungeon;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeMedBranch;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeRoot;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeSmallBranch;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeTrunk;
import twilightforest.structures.hollowtree.ComponentTFLeafSphere;
import twilightforest.structures.hollowtree.StructureTFHollowTreeStart;

public class TFHollowTreePieces {

   public static void registerPieces() {
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeLargeBranch.class, "TFHTLB");
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeMedBranch.class, "TFHTMB");
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeSmallBranch.class, "TFHTSB");
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeTrunk.class, "TFHTTr");
      MapGenStructureIO.func_143031_a(ComponentTFLeafSphere.class, "TFHTLS");
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeRoot.class, "TFHTRo");
      MapGenStructureIO.func_143031_a(StructureTFHollowTreeStart.class, "TFHTLSt");
      MapGenStructureIO.func_143031_a(ComponentTFHollowTreeLeafDungeon.class, "TFHTLD");
   }
}

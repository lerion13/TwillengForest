package twilightforest.structures.hollowtree;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.hollowtree.ComponentTFHollowTreeSmallBranch;
import twilightforest.world.TFGenerator;

public class ComponentTFHollowTreeMedBranch extends StructureTFComponent {

   ChunkCoordinates src;
   ChunkCoordinates dest;
   double length;
   double angle;
   double tilt;
   boolean leafy;


   public ComponentTFHollowTreeMedBranch() {}

   protected ComponentTFHollowTreeMedBranch(int i, int sx, int sy, int sz, double length, double angle, double tilt, boolean leafy) {
      super(i);
      this.src = new ChunkCoordinates(sx, sy, sz);
      this.dest = TFGenerator.translateCoords(this.src.posX, this.src.posY, this.src.posZ, length, angle, tilt);
      this.length = length;
      this.angle = angle;
      this.tilt = tilt;
      this.leafy = leafy;
      this.setCoordBaseMode(0);
      super.boundingBox = new StructureBoundingBox(Math.min(this.src.posX, this.dest.posX), Math.min(this.src.posY, this.dest.posY), Math.min(this.src.posZ, this.dest.posZ), Math.max(this.src.posX, this.dest.posX), Math.max(this.src.posY, this.dest.posY), Math.max(this.src.posZ, this.dest.posZ));
      super.boundingBox.expandTo(this.makeExpandedBB(0.5D, length, angle, tilt));
      super.boundingBox.expandTo(this.makeExpandedBB(0.10000000149011612D, length, 0.225D, tilt));
      super.boundingBox.expandTo(this.makeExpandedBB(0.10000000149011612D, length, -0.225D, tilt));
   }

   private StructureBoundingBox makeExpandedBB(double outVar, double branchLength, double branchAngle, double branchTilt) {
      ChunkCoordinates branchSrc = TFGenerator.translateCoords(this.src.posX, this.src.posY, this.src.posZ, this.length * outVar, this.angle, this.tilt);
      ChunkCoordinates branchDest = TFGenerator.translateCoords(branchSrc.posX, branchSrc.posY, branchSrc.posZ, branchLength, branchAngle, branchTilt);
      return new StructureBoundingBox(Math.min(branchSrc.posX, branchDest.posX), Math.min(branchSrc.posY, branchDest.posY), Math.min(branchSrc.posZ, branchDest.posZ), Math.max(branchSrc.posX, branchDest.posX), Math.max(branchSrc.posY, branchDest.posY), Math.max(branchSrc.posZ, branchDest.posZ));
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      super.func_143012_a(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("srcPosX", this.src.posX);
      par1NBTTagCompound.setInteger("srcPosY", this.src.posY);
      par1NBTTagCompound.setInteger("srcPosZ", this.src.posZ);
      par1NBTTagCompound.setInteger("destPosX", this.dest.posX);
      par1NBTTagCompound.setInteger("destPosY", this.dest.posY);
      par1NBTTagCompound.setInteger("destPosZ", this.dest.posZ);
      par1NBTTagCompound.setDouble("branchLength", this.length);
      par1NBTTagCompound.setDouble("branchAngle", this.angle);
      par1NBTTagCompound.setDouble("branchTilt", this.tilt);
      par1NBTTagCompound.setBoolean("branchLeafy", this.leafy);
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      super.func_143011_b(par1NBTTagCompound);
      this.src = new ChunkCoordinates(par1NBTTagCompound.getInteger("srcPosX"), par1NBTTagCompound.getInteger("srcPosY"), par1NBTTagCompound.getInteger("srcPosZ"));
      this.dest = new ChunkCoordinates(par1NBTTagCompound.getInteger("destPosX"), par1NBTTagCompound.getInteger("destPosY"), par1NBTTagCompound.getInteger("destPosZ"));
      this.length = par1NBTTagCompound.getDouble("branchLength");
      this.angle = par1NBTTagCompound.getDouble("branchAngle");
      this.tilt = par1NBTTagCompound.getDouble("branchTilt");
      this.leafy = par1NBTTagCompound.getBoolean("branchLeafy");
   }

   public void buildComponent(StructureComponent structurecomponent, List list, Random rand) {
      int index = this.getComponentType();
   }

   public void makeSmallBranch(List list, Random rand, int index, int x, int y, int z, double branchLength, double branchRotation, double branchAngle, boolean leafy) {
      ComponentTFHollowTreeSmallBranch branch = new ComponentTFHollowTreeSmallBranch(index, x, y, z, branchLength, branchRotation, branchAngle, leafy);
      list.add(branch);
      branch.buildComponent(this, list, rand);
   }

   public boolean addComponentParts(World world, Random random, StructureBoundingBox sbb) {
      ChunkCoordinates rSrc = new ChunkCoordinates(this.src.posX - super.boundingBox.minX, this.src.posY - super.boundingBox.minY, this.src.posZ - super.boundingBox.minZ);
      ChunkCoordinates rDest = new ChunkCoordinates(this.dest.posX - super.boundingBox.minX, this.dest.posY - super.boundingBox.minY, this.dest.posZ - super.boundingBox.minZ);
      this.drawBresehnam(world, sbb, rSrc.posX, rSrc.posY, rSrc.posZ, rDest.posX, rDest.posY, rDest.posZ, TFBlocks.log, 12);
      this.drawBresehnam(world, sbb, rSrc.posX, rSrc.posY + 1, rSrc.posZ, rDest.posX, rDest.posY, rDest.posZ, TFBlocks.log, 12);
      Random decoRNG = new Random(world.getSeed() + (long)(super.boundingBox.minX * 321534781) ^ (long)(super.boundingBox.minZ * 756839));
      int numShoots = Math.min(decoRNG.nextInt(3) + 1, (int)(this.length / 5.0D));
      double angleInc = 0.8D / (double)numShoots;

      int numLeafBalls;
      double slength;
      for(numLeafBalls = 0; numLeafBalls < numShoots; ++numLeafBalls) {
         double angleVar = angleInc * (double)numLeafBalls - 0.4D;
         double outVar = decoRNG.nextDouble() * 0.8D + 0.2D;
         double tiltVar = decoRNG.nextDouble() * 0.75D + 0.15D;
         ChunkCoordinates i = TFGenerator.translateCoords(rSrc.posX, rSrc.posY, rSrc.posZ, this.length * outVar, this.angle, this.tilt);
         slength = this.length * 0.4D;
         this.drawSmallBranch(world, sbb, i.posX, i.posY, i.posZ, Math.max(this.length * 0.30000001192092896D, 2.0D), this.angle + angleVar, this.tilt, this.leafy);
      }

      if(this.leafy) {
         numLeafBalls = Math.min(decoRNG.nextInt(3) + 1, (int)(this.length / 5.0D));

         for(int var21 = 0; var21 < numLeafBalls; ++var21) {
            slength = (double)(decoRNG.nextFloat() * 0.6F + 0.2F) * this.length;
            ChunkCoordinates bdst = TFGenerator.translateCoords(rSrc.posX, rSrc.posY, rSrc.posZ, slength, this.angle, this.tilt);
            this.makeLeafBlob(world, sbb, bdst.posX, bdst.posY, bdst.posZ, decoRNG.nextBoolean()?2:3);
         }

         this.makeLeafBlob(world, sbb, rDest.posX, rDest.posY, rDest.posZ, 3);
      }

      return true;
   }

   protected void drawBresehnam(World world, StructureBoundingBox sbb, int x1, int y1, int z1, int x2, int y2, int z2, Block blockValue, int metaValue) {
      ChunkCoordinates[] lineCoords = TFGenerator.getBresehnamArrayCoords(x1, y1, z1, x2, y2, z2);
      ChunkCoordinates[] var12 = lineCoords;
      int var13 = lineCoords.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         ChunkCoordinates coords = var12[var14];
         this.placeBlockAtCurrentPosition(world, blockValue, metaValue, coords.posX, coords.posY, coords.posZ, sbb);
      }

   }

   protected void makeLeafBlob(World world, StructureBoundingBox sbb, int sx, int sy, int sz, int radius) {
      for(int dx = 0; dx <= radius; ++dx) {
         for(int dy = 0; dy <= radius; ++dy) {
            for(int dz = 0; dz <= radius; ++dz) {
               boolean dist = false;
               int var11;
               if(dx >= dy && dx >= dz) {
                  var11 = (int)((float)dx + (float)Math.max(dy, dz) * 0.5F + (float)Math.min(dy, dz) * 0.25F);
               } else if(dy >= dx && dy >= dz) {
                  var11 = (int)((float)dy + (float)Math.max(dx, dz) * 0.5F + (float)Math.min(dx, dz) * 0.25F);
               } else {
                  var11 = (int)((float)dz + (float)Math.max(dx, dy) * 0.5F + (float)Math.min(dx, dy) * 0.25F);
               }

               if(var11 <= radius) {
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx + dx, sy + dy, sz + dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx + dx, sy + dy, sz - dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx - dx, sy + dy, sz + dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx - dx, sy + dy, sz - dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx + dx, sy - dy, sz + dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx + dx, sy - dy, sz - dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx - dx, sy - dy, sz + dz, sbb);
                  this.placeLeafBlock(world, TFBlocks.leaves, 0, sx - dx, sy - dy, sz - dz, sbb);
               }
            }
         }
      }

   }

   protected void placeLeafBlock(World world, Block blockID, int meta, int x, int y, int z, StructureBoundingBox sbb) {
      int offX = this.getXWithOffset(x, z);
      int offY = this.getYWithOffset(y);
      int offZ = this.getZWithOffset(x, z);
      if(sbb.isVecInside(offX, offY, offZ)) {
         Block whatsThere = world.getBlock(offX, offY, offZ);
         if(whatsThere == null || whatsThere.canBeReplacedByLeaves(world, offX, offY, offZ)) {
            world.setBlock(offX, offY, offZ, blockID, meta, 2);
         }
      }

   }

   protected void drawSmallBranch(World world, StructureBoundingBox sbb, int sx, int sy, int sz, double branchLength, double branchAngle, double branchTilt, boolean leafy) {
      ChunkCoordinates branchDest = TFGenerator.translateCoords(sx, sy, sz, branchLength, branchAngle, branchTilt);
      this.drawBresehnam(world, sbb, sx, sy, sz, branchDest.posX, branchDest.posY, branchDest.posZ, TFBlocks.log, 12);
      this.makeLeafBlob(world, sbb, branchDest.posX, branchDest.posY, branchDest.posZ, 2);
   }
}

package twilightforest.structures;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFComponent;

public class ComponentTFNagaCourtyard extends StructureTFComponent {

   static int RADIUS = 46;
   static int DIAMETER = 2 * RADIUS + 1;


   public ComponentTFNagaCourtyard() {}

   public ComponentTFNagaCourtyard(World world, Random rand, int i, int x, int y, int z) {
      super(i);
      this.setCoordBaseMode(0);
      super.boundingBox = StructureTFComponent.getComponentToAddBoundingBox(x, y, z, -RADIUS, -1, -RADIUS, RADIUS * 2, 10, RADIUS * 2, 0);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      int pillarRand;
      int i;
      for(pillarRand = 0; pillarRand <= DIAMETER; ++pillarRand) {
         for(i = 0; i <= DIAMETER; ++i) {
            if(rand.nextInt(3) == 0) {
               this.placeBlockAtCurrentPosition(world, Blocks.double_stone_slab, 0, pillarRand, 0, i, sbb);
               if(rand.nextInt(20) == 0) {
                  this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, pillarRand, 1, i, sbb);
               } else {
                  this.placeBlockAtCurrentPosition(world, Blocks.air, 0, pillarRand, 1, i, sbb);
               }
            } else {
               this.placeBlockAtCurrentPosition(world, Blocks.grass, 0, pillarRand, 0, i, sbb);
            }
         }
      }

      for(pillarRand = 0; pillarRand <= DIAMETER; ++pillarRand) {
         this.randomBrick(world, rand, pillarRand, 0, DIAMETER, sbb);
         this.randomBrick(world, rand, pillarRand, 0, 0, sbb);
         this.randomBrick(world, rand, pillarRand, 1, DIAMETER, sbb);
         this.randomBrick(world, rand, pillarRand, 1, 0, sbb);
         this.randomBrick(world, rand, pillarRand, 2, DIAMETER, sbb);
         this.randomBrick(world, rand, pillarRand, 2, 0, sbb);
         this.randomBrick(world, rand, pillarRand, 3, DIAMETER, sbb);
         this.randomBrick(world, rand, pillarRand, 3, 0, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 5, pillarRand, 4, DIAMETER, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 5, pillarRand, 4, 0, sbb);
         switch(pillarRand % 23) {
         case 2:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 11, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 11, pillarRand, 1, 0, sbb);
            break;
         case 3:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 3, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 3, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, 0, sbb);
            break;
         case 4:
         case 8:
         case 16:
         case 20:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, 0, sbb);
            break;
         case 5:
         case 9:
         case 17:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 10, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 10, pillarRand, 1, 0, sbb);
            break;
         case 6:
         case 10:
         case 14:
         case 18:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 3, 0, sbb);
            break;
         case 7:
         case 15:
         case 19:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 11, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 11, pillarRand, 1, 0, sbb);
            break;
         case 11:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 1, 0, sbb);
         case 12:
         default:
            break;
         case 13:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 7, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 1, 0, sbb);
            break;
         case 21:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 2, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 2, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 12, pillarRand, 1, 0, sbb);
            break;
         case 22:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 6, pillarRand, 3, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, pillarRand, 2, 0, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 10, pillarRand, 1, DIAMETER, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 10, pillarRand, 1, 0, sbb);
         }
      }

      for(pillarRand = 0; pillarRand <= DIAMETER; ++pillarRand) {
         this.randomBrick(world, rand, DIAMETER, 0, pillarRand, sbb);
         this.randomBrick(world, rand, 0, 0, pillarRand, sbb);
         this.randomBrick(world, rand, DIAMETER, 1, pillarRand, sbb);
         this.randomBrick(world, rand, 0, 1, pillarRand, sbb);
         this.randomBrick(world, rand, DIAMETER, 2, pillarRand, sbb);
         this.randomBrick(world, rand, 0, 2, pillarRand, sbb);
         this.randomBrick(world, rand, DIAMETER, 3, pillarRand, sbb);
         this.randomBrick(world, rand, 0, 3, pillarRand, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 5, DIAMETER, 4, pillarRand, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 5, 0, 4, pillarRand, sbb);
         switch(pillarRand % 23) {
         case 2:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 9, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 9, 0, 1, pillarRand, sbb);
            break;
         case 3:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 1, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 1, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, 0, 1, pillarRand, sbb);
            break;
         case 4:
         case 8:
         case 16:
         case 20:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, 0, 1, pillarRand, sbb);
            break;
         case 5:
         case 9:
         case 17:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 8, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 8, 0, 1, pillarRand, sbb);
            break;
         case 6:
         case 10:
         case 14:
         case 18:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, 0, 3, pillarRand, sbb);
            break;
         case 7:
         case 15:
         case 19:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 9, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 9, 0, 1, pillarRand, sbb);
            break;
         case 11:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 1, pillarRand, sbb);
         case 12:
         default:
            break;
         case 13:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 5, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 1, pillarRand, sbb);
            break;
         case 21:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 0, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 0, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 13, 0, 1, pillarRand, sbb);
            break;
         case 22:
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, DIAMETER, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 4, 0, 3, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, DIAMETER, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 14, 0, 2, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 8, DIAMETER, 1, pillarRand, sbb);
            this.placeBlockAtCurrentPosition(world, TFBlocks.nagastone, 8, 0, 1, pillarRand, sbb);
         }
      }

      Random var8 = new Random(world.getSeed() + (long)(super.boundingBox.minX * super.boundingBox.minZ));

      for(i = 0; i < 20; ++i) {
         int rx = 2 + var8.nextInt(DIAMETER - 4);
         int rz = 2 + var8.nextInt(DIAMETER - 4);
         this.makePillar(world, var8, rx, 1, rz, sbb);
      }

      this.placeBlockAtCurrentPosition(world, TFBlocks.bossSpawner, 0, RADIUS + 1, 2, RADIUS + 1, sbb);
      return true;
   }

   public boolean makePillar(World world, Random rand, int x, int y, int z, StructureBoundingBox sbb) {
      byte height = 8;
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 0, z - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 0, y + 0, z - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 0, z - 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 0, z + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 0, z + 0, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 0, z + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 0, y + 0, z + 1, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 0, z + 1, sbb);

      for(int i = 0; i < height; ++i) {
         this.randomBrick(world, rand, x, y + i, z, sbb);
         if(i > 0 && rand.nextInt(2) == 0) {
            switch(rand.nextInt(4)) {
            case 0:
               this.placeBlockAtCurrentPosition(world, Blocks.vine, 8, x - 1, y + i, z + 0, sbb);
               break;
            case 1:
               this.placeBlockAtCurrentPosition(world, Blocks.vine, 2, x + 1, y + i, z + 0, sbb);
               break;
            case 2:
               this.placeBlockAtCurrentPosition(world, Blocks.vine, 4, x + 0, y + i, z + 1, sbb);
               break;
            case 3:
               this.placeBlockAtCurrentPosition(world, Blocks.vine, 1, x + 0, y + i, z - 1, sbb);
            }
         } else if(i > 0 && rand.nextInt(4) == 0) {
            switch(rand.nextInt(4)) {
            case 0:
               this.placeBlockAtCurrentPosition(world, TFBlocks.firefly, 0, x - 1, y + i, z + 0, sbb);
               break;
            case 1:
               this.placeBlockAtCurrentPosition(world, TFBlocks.firefly, 0, x + 1, y + i, z + 0, sbb);
               break;
            case 2:
               this.placeBlockAtCurrentPosition(world, TFBlocks.firefly, 0, x + 0, y + i, z + 1, sbb);
               break;
            case 3:
               this.placeBlockAtCurrentPosition(world, TFBlocks.firefly, 0, x + 0, y + i, z - 1, sbb);
            }
         }
      }

      if(height == 8) {
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 8, z - 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 0, y + 8, z - 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 8, z - 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 8, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 5, x + 0, y + 8, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 8, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x - 1, y + 8, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 0, y + 8, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.stone_slab, 0, x + 1, y + 8, z + 1, sbb);
      }

      return true;
   }

   public void randomBrick(World world, Random rand, int x, int y, int z, StructureBoundingBox sbb) {
      this.placeBlockAtCurrentPosition(world, Blocks.stonebrick, rand.nextInt(3), x, y, z, sbb);
   }

}

package twilightforest.structures.darktower;

import java.util.List;
import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.darktower.ComponentTFDarkTowerWing;

public class ComponentTFDarkTowerBossTrap extends ComponentTFDarkTowerWing {

   public ComponentTFDarkTowerBossTrap() {}

   protected ComponentTFDarkTowerBossTrap(int i, int x, int y, int z, int pSize, int pHeight, int direction) {
      super(i, x, y, z, pSize, pHeight, direction);
      super.spawnListIndex = -1;
   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      if(parent != null && parent instanceof StructureTFComponent) {
         super.deco = ((StructureTFComponent)parent).deco;
      }

      this.addOpening(0, 1, super.size / 2, 2);
      this.makeABeard(parent, list, rand);

      for(int i = 0; i < 4; ++i) {
         if(i != 2 && !rand.nextBoolean()) {
            int[] dest = this.getValidOpening(rand, i);
            dest[1] = 1;
            this.makeTowerBalcony(list, rand, this.getComponentType(), dest[0], dest[1], dest[2], i);
         }
      }

   }

   public void makeARoof(StructureComponent parent, List list, Random rand) {}

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      Random decoRNG = new Random(world.getSeed() + (long)(super.boundingBox.minX * 321534781) ^ (long)(super.boundingBox.minZ * 756839));
      this.makeEncasedWalls(world, rand, sbb, 0, 0, 0, super.size - 1, super.height - 1, super.size - 1);
      this.fillWithAir(world, sbb, 1, 1, 1, super.size - 2, super.height - 2, super.size - 2);
      this.makeOpenings(world, sbb);
      this.addBossTrapFloors(world, decoRNG, sbb, 4, super.height - 1);
      this.destroyTower(world, decoRNG, 5, super.height + 2, 5, 4, sbb);
      this.destroyTower(world, decoRNG, 0, super.height, 0, 3, sbb);
      this.destroyTower(world, decoRNG, 0, super.height, 8, 4, sbb);
      this.destroyTower(world, decoRNG, 5, 6, 5, 2, sbb);
      this.fillWithMetadataBlocks(world, sbb, 1, 0, 1, super.size / 2, 0, super.size - 2, super.deco.blockID, super.deco.blockMeta, Blocks.air, 0, false);
      this.fillWithMetadataBlocks(world, sbb, 1, 1, 1, super.size / 2, 1, super.size - 2, Blocks.air, 0, Blocks.air, 0, false);
      this.placeBlockAtCurrentPosition(world, TFBlocks.towerDevice, 10, 5, 1, 5, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.redstone_wire, 0, 5, 1, 6, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.redstone_wire, 0, 5, 1, 7, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.redstone_wire, 0, 5, 1, 8, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.redstone_wire, 0, 4, 1, 8, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.redstone_wire, 0, 3, 1, 8, sbb);
      this.placeBlockAtCurrentPosition(world, Blocks.wooden_pressure_plate, 0, 2, 1, 8, sbb);
      return true;
   }

   protected void addBossTrapFloors(World world, Random rand, StructureBoundingBox sbb, int bottom, int top) {
      this.makeFullFloor(world, sbb, 3, 4, 4);
      this.addStairsDown(world, sbb, 3, 4, super.size - 2, 4);
      this.addStairsDown(world, sbb, 3, 4, super.size - 3, 4);
      this.addStairsDown(world, sbb, 1, super.height - 1, super.size - 2, 4);
      this.addStairsDown(world, sbb, 1, super.height - 1, super.size - 3, 4);
   }
}

package twilightforest.structures.darktower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.darktower.ComponentTFDarkTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFDarkTowerRoofFourPost extends ComponentTFDarkTowerRoof {

   public ComponentTFDarkTowerRoofFourPost() {}

   public ComponentTFDarkTowerRoofFourPost(int i, ComponentTFTowerWing wing) {
      super(i, wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      super.addComponentParts(world, rand, sbb);
      this.makeSmallAntenna(world, sbb, 4, super.size - 2, super.size - 2);
      this.makeSmallAntenna(world, sbb, 5, 1, super.size - 2);
      this.makeSmallAntenna(world, sbb, 6, super.size - 2, 1);
      this.makeSmallAntenna(world, sbb, 7, 1, 1);
      return true;
   }

   protected void makeSmallAntenna(World world, StructureBoundingBox sbb, int height, int x, int z) {
      for(int y = 1; y < height; ++y) {
         this.placeBlockAtCurrentPosition(world, super.deco.blockID, super.deco.blockMeta, x, y, z, sbb);
      }

      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x, height + 0, z, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x, height + 1, z, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 1, height + 1, z, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x - 1, height + 1, z, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x, height + 1, z + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x, height + 1, z - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x, height + 2, z, sbb);
   }
}

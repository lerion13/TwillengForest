package twilightforest.structures.darktower;

import java.util.List;
import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFDarkTowerBalcony extends ComponentTFTowerWing {

   public ComponentTFDarkTowerBalcony() {}

   protected ComponentTFDarkTowerBalcony(int i, int x, int y, int z, int direction) {
      super(i, x, y, z, 5, 5, direction);
   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      if(parent != null && parent instanceof StructureTFComponent) {
         super.deco = ((StructureTFComponent)parent).deco;
      }

   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      this.fillWithMetadataBlocks(world, sbb, 0, 0, 0, 2, 0, 4, super.deco.accentID, super.deco.accentMeta, Blocks.air, 0, false);
      this.fillWithMetadataBlocks(world, sbb, 0, 0, 1, 1, 0, 3, super.deco.blockID, super.deco.blockMeta, Blocks.air, 0, false);
      this.fillWithMetadataBlocks(world, sbb, 0, 1, 0, 2, 1, 4, super.deco.fenceID, super.deco.fenceMeta, Blocks.air, 0, false);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, 2, 1, 0, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, 2, 1, 4, sbb);
      this.fillWithAir(world, sbb, 0, 1, 1, 1, 1, 3);
      return true;
   }
}

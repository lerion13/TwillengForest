package twilightforest.structures.darktower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.darktower.ComponentTFDarkTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFDarkTowerRoofRings extends ComponentTFDarkTowerRoof {

   public ComponentTFDarkTowerRoofRings() {}

   public ComponentTFDarkTowerRoofRings(int i, ComponentTFTowerWing wing) {
      super(i, wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      super.addComponentParts(world, rand, sbb);

      for(int y = 1; y < 10; ++y) {
         this.placeBlockAtCurrentPosition(world, super.deco.blockID, super.deco.blockMeta, super.size / 2, y, super.size / 2, sbb);
      }

      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 10, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 + 1, sbb);
      this.makeARing(world, 6, sbb);
      this.makeARing(world, 8, sbb);
      return true;
   }

   protected void makeARing(World world, int y, StructureBoundingBox sbb) {
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, y, super.size / 2 + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, y, super.size / 2 + 0, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, y, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, y, super.size / 2 + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, y, super.size / 2 + 0, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, y, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, y, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 0, y, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, y, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, y, super.size / 2 + 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 0, y, super.size / 2 + 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, y, super.size / 2 + 2, sbb);
   }
}

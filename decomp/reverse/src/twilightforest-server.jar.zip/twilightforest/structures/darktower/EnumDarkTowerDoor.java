package twilightforest.structures.darktower;


public enum EnumDarkTowerDoor {

   VANISHING("VANISHING", 0),
   REAPPEARING("REAPPEARING", 1),
   LOCKED("LOCKED", 2);
   // $FF: synthetic field
   private static final EnumDarkTowerDoor[] $VALUES = new EnumDarkTowerDoor[]{VANISHING, REAPPEARING, LOCKED};


   private EnumDarkTowerDoor(String var1, int var2) {}

}

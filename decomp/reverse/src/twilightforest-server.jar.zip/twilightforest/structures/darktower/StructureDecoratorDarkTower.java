package twilightforest.structures.darktower;

import net.minecraft.init.Blocks;
import twilightforest.block.TFBlocks;
import twilightforest.structures.StructureTFDecorator;
import twilightforest.structures.darktower.StructureTFTowerWoods;

public class StructureDecoratorDarkTower extends StructureTFDecorator {

   public StructureDecoratorDarkTower() {
      super.blockID = TFBlocks.towerWood;
      super.blockMeta = 0;
      super.accentID = TFBlocks.towerWood;
      super.accentMeta = 1;
      super.fenceID = Blocks.fence;
      super.stairID = Blocks.spruce_stairs;
      super.pillarID = TFBlocks.towerWood;
      super.pillarMeta = 1;
      super.platformID = TFBlocks.towerWood;
      super.platformMeta = 1;
      super.randomBlocks = new StructureTFTowerWoods();
   }
}

package twilightforest.structures.darktower;

import cpw.mods.fml.common.FMLLog;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.Facing;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenForest;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import twilightforest.TFTreasure;
import twilightforest.block.TFBlocks;
import twilightforest.entity.TFCreatures;
import twilightforest.item.TFItems;
import twilightforest.structures.StructureTFComponent;
import twilightforest.structures.StructureTFDecorator;
import twilightforest.structures.TFMaze;
import twilightforest.structures.darktower.ComponentTFDarkTowerBossBridge;
import twilightforest.structures.darktower.ComponentTFDarkTowerEntranceBridge;
import twilightforest.structures.darktower.ComponentTFDarkTowerMainBridge;
import twilightforest.structures.darktower.ComponentTFDarkTowerWing;
import twilightforest.structures.darktower.EnumDarkTowerDoor;
import twilightforest.structures.darktower.StructureDecoratorDarkTower;
import twilightforest.world.TFGenSmallRainboak;
import twilightforest.world.TFGenSmallTwilightOak;

public class ComponentTFDarkTowerMain extends ComponentTFDarkTowerWing {

   private boolean placedKeys;


   public ComponentTFDarkTowerMain() {
      this.placedKeys = false;
   }

   public ComponentTFDarkTowerMain(World world, Random rand, int index, int x, int y, int z) {
      this(world, rand, index, x + 10, y, z + 10, 2);
   }

   public ComponentTFDarkTowerMain(World world, Random rand, int index, int x, int y, int z, int rotation) {
      super(index, x, y, z, 19, 56 + rand.nextInt(32) / 5 * 5, rotation);
      this.placedKeys = false;
      if(super.boundingBox.maxY > 245) {
         int amtToLower = (super.boundingBox.maxY - 245) / 5 * 5 + 5;
         FMLLog.info("[TwilightForest] Lowering Dark Tower max height by %d to be within world bounds", new Object[]{Integer.valueOf(amtToLower)});
         super.height -= amtToLower;
         super.boundingBox.maxY -= amtToLower;
      }

      if(super.deco == null) {
         super.deco = new StructureDecoratorDarkTower();
      }

   }

   public void buildComponent(StructureComponent parent, List list, Random rand) {
      if(parent != null && parent instanceof StructureTFComponent) {
         super.deco = ((StructureTFComponent)parent).deco;
      }

      if(this.getComponentType() > 0) {
         this.addOpening(0, 1, super.size / 2, 2);
      }

      int mainDir = -1;
      int possibleKeyTowers;
      int[] smallTowers;
      int i;
      if(this.getComponentType() < 2) {
         mainDir = rand.nextInt(4);

         for(possibleKeyTowers = 0; possibleKeyTowers < 4; ++possibleKeyTowers) {
            if(possibleKeyTowers != mainDir) {
               smallTowers = this.getValidOpening(rand, possibleKeyTowers);
               i = this.validateChildHeight(21 + rand.nextInt(10), 11);
               this.makeTowerWing(list, rand, this.getComponentType(), smallTowers[0], smallTowers[1], smallTowers[2], 11, i, possibleKeyTowers);
            }
         }
      } else {
         for(possibleKeyTowers = 0; possibleKeyTowers < 4; ++possibleKeyTowers) {
            smallTowers = this.getValidOpening(rand, possibleKeyTowers);
            this.makeBossTrapWing(list, rand, this.getComponentType(), smallTowers[0], smallTowers[1], smallTowers[2], possibleKeyTowers);
         }
      }

      if(this.getComponentType() > 0) {
         for(possibleKeyTowers = 0; possibleKeyTowers < 4; ++possibleKeyTowers) {
            if(possibleKeyTowers != 2) {
               smallTowers = this.getValidOpening(rand, possibleKeyTowers);
               smallTowers[1] = 1;
               i = this.validateChildHeight(21 + rand.nextInt(10), 11);
               this.makeTowerWing(list, rand, this.getComponentType(), smallTowers[0], smallTowers[1], smallTowers[2], 11, i, possibleKeyTowers);
            }
         }

         this.makeABeard(parent, list, rand);
      } else {
         for(possibleKeyTowers = 0; possibleKeyTowers < 4; possibleKeyTowers += 2) {
            smallTowers = this.getValidOpening(rand, possibleKeyTowers);
            smallTowers[1] = 1;
            i = this.validateChildHeight(10 + rand.nextInt(5), 9);
            this.makeEntranceTower(list, rand, 5, smallTowers[0], smallTowers[1], smallTowers[2], 9, i, possibleKeyTowers);
         }
      }

      if(mainDir > -1) {
         int[] var13 = this.getValidOpening(rand, mainDir);
         this.makeNewLargeTower(list, rand, this.getComponentType() + 1, var13[0], var13[1], var13[2], mainDir);
      }

      this.makeARoof(parent, list, rand);
      if(!this.placedKeys && this.getComponentType() < 2) {
         ArrayList var11 = new ArrayList();
         int var10 = 0;
         Iterator var12 = list.iterator();

         while(var12.hasNext()) {
            Object towerNum = var12.next();
            if(towerNum instanceof ComponentTFDarkTowerWing) {
               ComponentTFDarkTowerWing wing = (ComponentTFDarkTowerWing)towerNum;
               if(wing.size == 9 && wing.getComponentType() == this.getComponentType()) {
                  ++var10;
                  var11.add(wing);
               }
            }
         }

         for(i = 0; i < 4; ++i) {
            if(var11.size() < 1) {
               FMLLog.warning("[TwilightForest] Dark forest tower could not find four small towers to place keys in.", new Object[0]);
               break;
            }

            int var14 = rand.nextInt(var11.size());
            ((ComponentTFDarkTowerWing)var11.get(var14)).setKeyTower(true);
            var11.remove(var14);
         }

         this.placedKeys = true;
      }

   }

   private boolean makeEntranceTower(List list, Random rand, int index, int x, int y, int z, int childSize, int childHeight, int rotation) {
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      int[] dx = this.offsetTowerCoords(x, y, z, 5, direction);
      ComponentTFDarkTowerEntranceBridge bridge = new ComponentTFDarkTowerEntranceBridge(index, dx[0], dx[1], dx[2], childSize, childHeight, direction);
      list.add(bridge);
      bridge.buildComponent(this, list, rand);
      this.addOpening(x, y, z, rotation);
      return true;
   }

   private boolean makeNewLargeTower(List list, Random rand, int index, int x, int y, int z, int rotation) {
      byte wingSize = 15;
      byte wingHeight = 56;
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      int[] dx = this.offsetTowerCoords(x, y, z, 5, direction);
      ComponentTFDarkTowerMainBridge bridge = new ComponentTFDarkTowerMainBridge(index, dx[0], dx[1], dx[2], wingSize, wingHeight, direction);
      list.add(bridge);
      bridge.buildComponent(this, list, rand);
      this.addOpening(x, y, z, rotation, EnumDarkTowerDoor.LOCKED);
      return true;
   }

   private boolean makeBossTrapWing(List list, Random rand, int index, int x, int y, int z, int rotation) {
      byte wingSize = 11;
      byte wingHeight = 9;
      int direction = (this.getCoordBaseMode() + rotation) % 4;
      int[] dx = this.offsetTowerCoords(x, y, z, 5, direction);
      ComponentTFDarkTowerBossBridge bridge = new ComponentTFDarkTowerBossBridge(index, dx[0], dx[1], dx[2], wingSize, wingHeight, direction);
      list.add(bridge);
      bridge.buildComponent(this, list, rand);
      this.addOpening(x, y, z, rotation);
      return true;
   }

   public void makeARoof(StructureComponent parent, List list, Random rand) {
      if(this.getComponentType() < 2) {
         super.makeARoof(parent, list, rand);
      }

   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      Random decoRNG = new Random(world.getSeed() + (long)(super.boundingBox.minX * 321534781) ^ (long)(super.boundingBox.minZ * 756839));
      this.makeEncasedWalls(world, rand, sbb, 0, 0, 0, super.size - 1, super.height - 1, super.size - 1);
      this.fillWithAir(world, sbb, 1, 1, 1, super.size - 2, super.height - 2, super.size - 2);
      int totalFloors;
      if(this.getComponentType() == 0) {
         for(totalFloors = 0; totalFloors < super.size; ++totalFloors) {
            for(int beamMaze = 0; beamMaze < super.size; ++beamMaze) {
               this.func_151554_b(world, super.deco.accentID, super.deco.accentMeta, totalFloors, -1, beamMaze, sbb);
            }
         }
      }

      this.nullifySkyLightForBoundingBox(world);
      totalFloors = super.height / 5;
      boolean var10 = decoRNG.nextBoolean();
      int centerFloors = var10?4:totalFloors / 2;
      int bottomFloors = (totalFloors - centerFloors) / 2;
      int var10000 = totalFloors - bottomFloors * 2;
      int topFloorsStartY = super.height - (bottomFloors * 5 + 1);
      this.addThreeQuarterFloors(world, decoRNG, sbb, 0, bottomFloors * 5);
      if(this.getComponentType() < 2) {
         this.addThreeQuarterFloors(world, decoRNG, sbb, topFloorsStartY, super.height - 1);
      } else {
         this.addThreeQuarterFloorsDecorateBoss(world, decoRNG, sbb, topFloorsStartY, super.height - 1);
         this.destroyTower(world, decoRNG, 12, super.height + 4, 3, 4, sbb);
         this.destroyTower(world, decoRNG, 3, super.height + 4, 12, 4, sbb);
         this.destroyTower(world, decoRNG, 3, super.height + 4, 3, 4, sbb);
         this.destroyTower(world, decoRNG, 12, super.height + 4, 12, 4, sbb);
         this.destroyTower(world, decoRNG, 8, super.height + 4, 8, 5, sbb);
         this.decorateBossSpawner(world, decoRNG, sbb, 0, super.height - 6);
      }

      if(var10) {
         this.addTimberMaze(world, decoRNG, sbb, bottomFloors * 5, topFloorsStartY);
      } else {
         this.addBuilderPlatforms(world, decoRNG, sbb, bottomFloors * 5, topFloorsStartY);
      }

      this.makeOpenings(world, sbb);
      return true;
   }

   protected void addThreeQuarterFloors(World world, Random decoRNG, StructureBoundingBox sbb, int bottom, int top) {
      byte spacing = 5;
      int rotation = (super.boundingBox.minY + bottom) % 4;
      if(bottom == 0) {
         this.makeLargeStairsUp(world, sbb, rotation, 0);
         rotation += 3;
         rotation %= 4;
         this.makeBottomEntrance(world, decoRNG, sbb, rotation, bottom);
         bottom += spacing;
      }

      for(int y = bottom; y < top; y += spacing) {
         boolean isBottomFloor = y == bottom && bottom != spacing;
         boolean isTopFloor = y >= top - spacing;
         boolean isTowerTopFloor = y >= super.height - spacing - 2;
         this.makeThreeQuarterFloor(world, sbb, rotation, y, isBottomFloor, isTowerTopFloor);
         if(!isTopFloor) {
            this.makeLargeStairsUp(world, sbb, rotation, y);
         }

         if(!isTopFloor || isTowerTopFloor) {
            this.decorateFloor(world, decoRNG, sbb, rotation, y, isBottomFloor, isTopFloor);
         }

         rotation += 3;
         rotation %= 4;
      }

   }

   protected void addThreeQuarterFloorsDecorateBoss(World world, Random decoRNG, StructureBoundingBox sbb, int bottom, int top) {
      byte spacing = 5;
      int rotation = (super.boundingBox.minY + bottom) % 4;
      if(bottom == 0) {
         this.makeLargeStairsUp(world, sbb, rotation, 0);
         rotation += 3;
         rotation %= 4;
         bottom += spacing;
      }

      for(int y = bottom; y < top; y += spacing) {
         boolean isBottomFloor = y == bottom && bottom != spacing;
         boolean isTopFloor = y >= top - spacing;
         boolean isTowerTopFloor = y >= super.height - spacing - 2;
         this.makeThreeQuarterFloor(world, sbb, rotation, y, isBottomFloor, isTowerTopFloor);
         if(!isTopFloor) {
            this.makeLargeStairsUp(world, sbb, rotation, y);
            this.decorateExperiment(world, decoRNG, sbb, rotation, y);
         }

         rotation += 3;
         rotation %= 4;
      }

   }

   private void decorateFloor(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y, boolean isBottom, boolean isTop) {
      if(isTop) {
         switch(decoRNG.nextInt(3)) {
         case 0:
         default:
            this.decorateAquarium(world, decoRNG, sbb, rotation, y);
            break;
         case 1:
            this.decorateBotanical(world, decoRNG, sbb, rotation, y);
            break;
         case 2:
            this.decorateNetherwart(world, decoRNG, sbb, rotation, y, isTop);
         }
      } else if(isBottom) {
         switch(decoRNG.nextInt(4)) {
         case 0:
         default:
            this.decorateAquarium(world, decoRNG, sbb, rotation, y);
            break;
         case 1:
            this.decorateBotanical(world, decoRNG, sbb, rotation, y);
            break;
         case 2:
            if(y + super.boundingBox.minY > 64) {
               this.decorateNetherwart(world, decoRNG, sbb, rotation, y, isTop);
               break;
            }
         case 3:
            this.decorateForge(world, decoRNG, sbb, rotation, y);
         }
      } else {
         switch(decoRNG.nextInt(8)) {
         case 0:
         case 1:
         default:
            this.decorateReappearingMaze(world, decoRNG, sbb, rotation, y);
            break;
         case 2:
            this.decorateUnbuilderMaze(world, decoRNG, sbb, rotation, y);
            break;
         case 3:
            this.decorateAquarium(world, decoRNG, sbb, rotation, y);
            break;
         case 4:
            this.decorateBotanical(world, decoRNG, sbb, rotation, y);
            break;
         case 5:
            if(y + super.boundingBox.minY > 64) {
               this.decorateNetherwart(world, decoRNG, sbb, rotation, y, isTop);
               break;
            }
         case 6:
            this.decorateLounge(world, decoRNG, sbb, rotation, y);
            break;
         case 7:
            this.decorateForge(world, decoRNG, sbb, rotation, y);
         }
      }

   }

   protected void makeThreeQuarterFloor(World world, StructureBoundingBox sbb, int rotation, int y, boolean isBottom, boolean isTowerTopFloor) {
      int half = super.size / 2;
      this.fillBlocksRotated(world, sbb, half + 1, y, 1, super.size - 2, y, half + 1, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 1, y, half + 1, super.size - 2, y, super.size - 2, super.deco.blockID, super.deco.blockMeta, rotation);
      int startZ = isBottom?1:3;
      this.fillBlocksRotated(world, sbb, 1, y, half, half, y, half, super.deco.accentID, super.deco.accentMeta, rotation);
      this.fillBlocksRotated(world, sbb, half, y, startZ, half, y, half, super.deco.accentID, super.deco.accentMeta, rotation);
      this.fillBlocksRotated(world, sbb, 1, y + 1, half, half, y + 1, half, super.deco.fenceID, super.deco.fenceMeta, rotation);
      this.fillBlocksRotated(world, sbb, half, y + 1, startZ, half, y + 1, half, super.deco.fenceID, super.deco.fenceMeta, rotation);
      if(isTowerTopFloor) {
         this.fillBlocksRotated(world, sbb, 1, y + 0, half - 2, 3, y + 0, half, super.deco.accentID, super.deco.accentMeta, rotation);
         this.fillBlocksRotated(world, sbb, 1, y + 1, half - 2, 3, y + 1, half, super.deco.fenceID, super.deco.fenceMeta, rotation);
         this.fillBlocksRotated(world, sbb, 1, y + 0, half - 1, 2, y + 0, half, super.deco.blockID, super.deco.blockMeta, rotation);
         this.fillBlocksRotated(world, sbb, 1, y + 1, half - 1, 2, y + 1, half, Blocks.air, 0, rotation);
      }

   }

   protected void makeLargeStairsUp(World world, StructureBoundingBox sbb, int rotation, int y) {
      for(int i = 0; i < 5; ++i) {
         int z = super.size / 2 - i + 4;
         int sy = y + i + 1;
         this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(3 + rotation), 1, sy, z, rotation, sbb);
         this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(3 + rotation), 2, sy, z, rotation, sbb);
         this.placeBlockRotated(world, super.deco.blockID, super.deco.blockMeta, 1, sy, z - 1, rotation, sbb);
         this.placeBlockRotated(world, super.deco.blockID, super.deco.blockMeta, 2, sy, z - 1, rotation, sbb);
         this.placeBlockRotated(world, super.deco.blockID, super.deco.blockMeta, 3, sy, z - 1, rotation, sbb);
         if(i > 0 && i < 4) {
            this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 3, sy, z, rotation, sbb);
            this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 3, sy + 1, z, rotation, sbb);
            this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 3, sy + 2, z, rotation, sbb);
         } else if(i == 0) {
            this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation), 3, sy, z, rotation, sbb);
         }
      }

   }

   private void decorateReappearingMaze(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      byte mazeSize = 6;
      TFMaze maze = new TFMaze(mazeSize, mazeSize);
      maze.setSeed(world.getSeed() + (long)(super.boundingBox.minX * 90342903) + (long)(y * 90342903) ^ (long)super.boundingBox.minZ);

      int x;
      for(x = 0; x < 13; ++x) {
         maze.putRaw(x, 0, 5);
         maze.putRaw(x, 12, 5);
         maze.putRaw(0, x, 5);
         maze.putRaw(12, x, 5);
      }

      maze.doorRarity = 0.3F;
      int z;
      switch(rotation) {
      case 0:
         for(x = 1; x < 6; ++x) {
            for(z = 1; z < 6; ++z) {
               maze.putRaw(x, z, 5);
            }
         }

         maze.putRaw(1, 6, 5);
         maze.putRaw(1, 7, 5);
         maze.putRaw(1, 8, 5);
         maze.putRaw(1, 9, 5);
         maze.putRaw(1, 10, 6);
         maze.putRaw(6, 1, 5);
         maze.putRaw(7, 1, 5);
         maze.putRaw(8, 1, 6);
         maze.generateRecursiveBacktracker(0, 5);
         break;
      case 1:
         for(x = 7; x < 12; ++x) {
            for(z = 1; z < 6; ++z) {
               maze.putRaw(x, z, 5);
            }
         }

         maze.putRaw(6, 1, 5);
         maze.putRaw(5, 1, 5);
         maze.putRaw(4, 1, 5);
         maze.putRaw(3, 1, 5);
         maze.putRaw(2, 1, 6);
         maze.putRaw(11, 6, 5);
         maze.putRaw(11, 7, 5);
         maze.putRaw(11, 8, 6);
         maze.generateRecursiveBacktracker(0, 0);
         break;
      case 2:
         for(x = 7; x < 12; ++x) {
            for(z = 7; z < 12; ++z) {
               maze.putRaw(x, z, 5);
            }
         }

         maze.putRaw(11, 6, 5);
         maze.putRaw(11, 5, 5);
         maze.putRaw(11, 4, 5);
         maze.putRaw(11, 3, 5);
         maze.putRaw(11, 2, 6);
         maze.putRaw(6, 11, 5);
         maze.putRaw(5, 11, 5);
         maze.putRaw(4, 11, 6);
         maze.generateRecursiveBacktracker(5, 0);
         break;
      case 3:
         for(x = 1; x < 6; ++x) {
            for(z = 7; z < 12; ++z) {
               maze.putRaw(x, z, 5);
            }
         }

         maze.putRaw(6, 11, 5);
         maze.putRaw(7, 11, 5);
         maze.putRaw(8, 11, 5);
         maze.putRaw(9, 11, 5);
         maze.putRaw(10, 11, 6);
         maze.putRaw(1, 6, 5);
         maze.putRaw(1, 5, 5);
         maze.putRaw(1, 4, 6);
         maze.generateRecursiveBacktracker(5, 5);
      }

      maze.wallBlockID = super.deco.blockID;
      maze.wallBlockMeta = super.deco.blockMeta;
      maze.headBlockID = super.deco.accentID;
      maze.headBlockMeta = super.deco.accentMeta;
      maze.pillarBlockID = super.deco.accentID;
      maze.pillarBlockMeta = super.deco.accentMeta;
      maze.doorBlockID = TFBlocks.towerDevice;
      maze.doorBlockMeta = 0;
      maze.torchRarity = 0.0F;
      maze.tall = 3;
      maze.head = 1;
      maze.oddBias = 2;
      maze.copyToStructure(world, 0, y + 1, 0, this, sbb);
      this.decorateMazeDeadEnds(world, decoRNG, maze, y, rotation, sbb);
   }

   protected void decorateMazeDeadEnds(World world, Random decoRNG, TFMaze maze, int y, int rotation, StructureBoundingBox sbb) {
      for(int x = 0; x < maze.width; ++x) {
         for(int z = 0; z < maze.depth; ++z) {
            if(!maze.isWall(x, z, x - 1, z) && maze.isWall(x, z, x + 1, z) && maze.isWall(x, z, x, z - 1) && maze.isWall(x, z, x, z + 1)) {
               this.decorateDeadEnd(world, decoRNG, maze, x, y, z, 3, rotation, sbb);
            }

            if(maze.isWall(x, z, x - 1, z) && !maze.isWall(x, z, x + 1, z) && maze.isWall(x, z, x, z - 1) && maze.isWall(x, z, x, z + 1)) {
               this.decorateDeadEnd(world, decoRNG, maze, x, y, z, 1, rotation, sbb);
            }

            if(maze.isWall(x, z, x - 1, z) && maze.isWall(x, z, x + 1, z) && !maze.isWall(x, z, x, z - 1) && maze.isWall(x, z, x, z + 1)) {
               this.decorateDeadEnd(world, decoRNG, maze, x, y, z, 0, rotation, sbb);
            }

            if(maze.isWall(x, z, x - 1, z) && maze.isWall(x, z, x + 1, z) && maze.isWall(x, z, x, z - 1) && !maze.isWall(x, z, x, z + 1)) {
               this.decorateDeadEnd(world, decoRNG, maze, x, y, z, 2, rotation, sbb);
            }
         }
      }

   }

   private void decorateDeadEnd(World world, Random decoRNG, TFMaze maze, int mx, int y, int mz, int facing, int rotation, StructureBoundingBox sbb) {
      int x = mx * 3 + 1;
      int z = mz * 3 + 1;
      switch(facing) {
      case 0:
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 0, y + 1, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 1, y + 1, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.chest, 0, x + 0, y + 2, z + 1, sbb);
         this.placeTreasureAtCurrentPosition(world, decoRNG, x + 1, y + 2, z + 1, TFTreasure.darktower_cache, sbb);
         break;
      case 1:
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 0, y + 1, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 0, y + 1, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.chest, rotation, x + 0, y + 2, z + 0, sbb);
         this.placeTreasureAtCurrentPosition(world, decoRNG, x + 0, y + 2, z + 1, TFTreasure.darktower_cache, sbb);
         break;
      case 2:
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 0, y + 1, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 1, y + 1, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.chest, rotation, x + 0, y + 2, z + 0, sbb);
         this.placeTreasureAtCurrentPosition(world, decoRNG, x + 1, y + 2, z + 0, TFTreasure.darktower_cache, sbb);
         break;
      case 3:
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 1, y + 1, z + 0, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, x + 1, y + 1, z + 1, sbb);
         this.placeBlockAtCurrentPosition(world, Blocks.chest, rotation, x + 1, y + 2, z + 0, sbb);
         this.placeTreasureAtCurrentPosition(world, decoRNG, x + 1, y + 2, z + 1, TFTreasure.darktower_cache, sbb);
      }

   }

   private void decorateUnbuilderMaze(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      for(int x = super.size / 2; x < super.size - 1; ++x) {
         for(int z = 3; z < super.size - 1; ++z) {
            int ay;
            if(x % 2 == 1 && z % 2 == 1) {
               for(ay = 1; ay < 5; ++ay) {
                  this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, x, y + ay, z, rotation, sbb);
               }
            } else if(x % 2 == 1 || z % 2 == 1) {
               for(ay = 1; ay < 5; ++ay) {
                  this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, x, y + ay, z, rotation, sbb);
               }

               if(x != super.size / 2 && x != super.size - 2 && z != super.size - 2) {
                  ay = decoRNG.nextInt(4) + 1;
                  this.placeBlockRotated(world, Blocks.air, 0, x, y + ay, z, rotation, sbb);
                  if(x > super.size - 7) {
                     ay = decoRNG.nextInt(3) + 1;
                     this.placeBlockRotated(world, Blocks.air, 0, x, y + ay, z, rotation, sbb);
                  }
               }
            }
         }
      }

      this.placeBlockRotated(world, TFBlocks.towerDevice, 9, 15, y + 2, 7, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 9, 11, y + 3, 7, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 9, 15, y + 2, 13, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 9, 11, y + 3, 13, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 9, 5, y + 3, 13, rotation, sbb);
   }

   private void decorateLounge(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      this.fillBlocksRotated(world, sbb, 17, y + 1, 1, 17, y + 4, 6, super.deco.pillarID, super.deco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 1, 17, y + 4, 1, super.deco.pillarID, super.deco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 2, 16, y + 1, 5, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 2, 12, y + 1, 6, super.deco.stairID, this.getStairMeta(0 + rotation), rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 6, 16, y + 1, 6, super.deco.stairID, this.getStairMeta(3 + rotation), rotation);
      this.makeDispenserPillar(world, super.deco, 13, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeDispenserPillar(world, super.deco, 15, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeDispenserPillar(world, super.deco, 17, y, 3, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeDispenserPillar(world, super.deco, 17, y, 5, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, super.deco, 12, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeStonePillar(world, super.deco, 17, y, 6, this.getStairMeta(0 + rotation), rotation, sbb);
      this.placeBlockRotated(world, Blocks.brewing_stand, 0, 13, y + 2, 5, rotation, sbb);
      this.placeBlockRotated(world, Blocks.cauldron, 3, 15, y + 2, 3, rotation, sbb);
      this.fillBlocksRotated(world, sbb, 10, y + 1, 17, 17, y + 4, 17, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 17, y + 1, 10, 17, y + 4, 17, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 11, y + 1, 17, 12, y + 4, 17, Blocks.bookshelf, 0, rotation);
      this.fillBlocksRotated(world, sbb, 14, y + 1, 17, 15, y + 4, 17, Blocks.bookshelf, 0, rotation);
      this.fillBlocksRotated(world, sbb, 17, y + 1, 11, 17, y + 4, 12, Blocks.bookshelf, 0, rotation);
      this.fillBlocksRotated(world, sbb, 17, y + 1, 14, 17, y + 4, 15, Blocks.bookshelf, 0, rotation);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(0 + rotation) + 4, 13, y + 1, 14, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(3 + rotation) + 4, 14, y + 1, 14, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation) + 4, 14, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(1 + rotation) + 4, 13, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation), 11, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(3 + rotation), 13, y + 1, 11, rotation, sbb);
      this.placeBlockRotated(world, Blocks.redstone_lamp, 0, 8, y + 3, 8, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, decoRNG.nextBoolean()?0:7, 8, y + 2, 8, rotation, sbb);
      this.placeTreePlanter(world, decoRNG.nextInt(5), 6, y + 1, 12, rotation, sbb);
   }

   private void makeDispenserPillar(World world, StructureTFDecorator forgeDeco, int x, int y, int z, int stairMeta, int rotation, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, forgeDeco.stairID, stairMeta + 4, x, y + 2, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.dispenser, stairMeta + 4, x, y + 3, z, rotation, sbb);
      this.placeBlockRotated(world, forgeDeco.stairID, stairMeta, x, y + 4, z, rotation, sbb);
   }

   private void decorateBossSpawner(World world, Random rand, StructureBoundingBox sbb, int rotation, int y) {
      this.placeBlockRotated(world, TFBlocks.bossSpawner, 3, 9, y + 4, 9, rotation, sbb);
   }

   private void decorateExperiment(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      this.fillBlocksRotated(world, sbb, 17, y + 1, 1, 17, y + 4, 6, super.deco.pillarID, super.deco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 1, 17, y + 4, 1, super.deco.pillarID, super.deco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 2, 16, y + 1, 5, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 2, 12, y + 1, 6, super.deco.stairID, this.getStairMeta(0 + rotation), rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 6, 16, y + 1, 6, super.deco.stairID, this.getStairMeta(3 + rotation), rotation);
      this.makeWoodPillar(world, super.deco, 13, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeWoodPillar(world, super.deco, 15, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeWoodPillar(world, super.deco, 17, y, 3, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeWoodPillar(world, super.deco, 17, y, 5, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, super.deco, 12, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeStonePillar(world, super.deco, 17, y, 6, this.getStairMeta(0 + rotation), rotation, sbb);
      this.placeBlockRotated(world, Blocks.crafting_table, 0, 14, y + 2, 4, rotation, sbb);
      this.placeItemFrameRotated(world, 13, y + 2, 1, rotation, 0, new ItemStack(TFItems.borerEssence), sbb);
      this.placeItemFrameRotated(world, 14, y + 2, 1, rotation, 0, new ItemStack(Items.redstone), sbb);
      this.placeItemFrameRotated(world, 15, y + 2, 1, rotation, 0, new ItemStack(TFItems.borerEssence), sbb);
      this.placeItemFrameRotated(world, 13, y + 3, 1, rotation, 0, new ItemStack(Items.redstone), sbb);
      this.placeItemFrameRotated(world, 14, y + 3, 1, rotation, 0, new ItemStack(Items.ghast_tear), sbb);
      this.placeItemFrameRotated(world, 15, y + 3, 1, rotation, 0, new ItemStack(Items.redstone), sbb);
      this.placeItemFrameRotated(world, 13, y + 4, 1, rotation, 0, new ItemStack(TFItems.borerEssence), sbb);
      this.placeItemFrameRotated(world, 14, y + 4, 1, rotation, 0, new ItemStack(Items.redstone), sbb);
      this.placeItemFrameRotated(world, 15, y + 4, 1, rotation, 0, new ItemStack(TFItems.borerEssence), sbb);
      this.placeItemFrameRotated(world, 17, y + 2, 3, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 1), sbb);
      this.placeItemFrameRotated(world, 17, y + 2, 4, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 0), sbb);
      this.placeItemFrameRotated(world, 17, y + 2, 5, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 1), sbb);
      this.placeItemFrameRotated(world, 17, y + 3, 3, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 0), sbb);
      this.placeItemFrameRotated(world, 17, y + 3, 4, rotation, 1, new ItemStack(TFItems.carminite), sbb);
      this.placeItemFrameRotated(world, 17, y + 3, 5, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 0), sbb);
      this.placeItemFrameRotated(world, 17, y + 4, 3, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 1), sbb);
      this.placeItemFrameRotated(world, 17, y + 4, 4, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 0), sbb);
      this.placeItemFrameRotated(world, 17, y + 4, 5, rotation, 1, new ItemStack(TFBlocks.towerWood, 1, 1), sbb);
      if(y < super.height - 13) {
         this.placeBlockRotated(world, Blocks.obsidian, 0, 13, y + 1, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 15, y + 1, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 13, y + 1, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 15, y + 1, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 13, y + 1, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 14, y + 1, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 15, y + 1, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 14, y + 1, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.redstone_block, 0, 14, y + 1, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 13, y + 2, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 15, y + 2, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 13, y + 2, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 15, y + 2, 15, rotation, sbb);
         this.placeBlockRotated(world, TFBlocks.towerDevice, 12, 14, y + 2, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 13, y + 3, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 15, y + 3, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 13, y + 3, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.obsidian, 0, 15, y + 3, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 13, y + 3, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 14, y + 3, 13, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 15, y + 3, 14, rotation, sbb);
         this.placeBlockRotated(world, Blocks.netherrack, 0, 14, y + 3, 15, rotation, sbb);
         this.placeBlockRotated(world, Blocks.redstone_block, 0, 14, y + 3, 14, rotation, sbb);
      }

      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 14, y + 1, 17, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 4), 13, y + 1, 17, rotation, sbb);
      this.placeBlockRotated(world, Blocks.piston, 5 - this.getStairMeta(3 + rotation), 14, y + 2, 17, rotation, sbb);
      this.placeBlockRotated(world, Blocks.redstone_block, 0, 14, y + 2, 16, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 17, y + 1, 14, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 2), 17, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, Blocks.piston, 5 - this.getStairMeta(2 + rotation), 17, y + 2, 14, rotation, sbb);
      this.placeBlockRotated(world, Blocks.redstone_block, 0, 16, y + 2, 14, rotation, sbb);
      this.placeBlockRotated(world, Blocks.redstone_block, 0, 14, y + 2, 11, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 14, y + 1, 11, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 4) + 8, 13, y + 1, 11, rotation, sbb);
      this.placeBlockRotated(world, Blocks.piston, 5 - this.getStairMeta(1 + rotation), 14, y + 2, 10, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 14, y + 1, 9, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 4), 13, y + 1, 9, rotation, sbb);
      this.placeBlockRotated(world, Blocks.sticky_piston, 5 - this.getStairMeta(1 + rotation), 14, y + 2, 9, rotation, sbb);
      this.placeBlockRotated(world, Blocks.redstone_block, 0, 11, y + 2, 14, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 11, y + 1, 14, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 2) + 8, 11, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, Blocks.piston, 5 - this.getStairMeta(0 + rotation), 10, y + 2, 14, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 9, y + 1, 14, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, 2), 9, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, Blocks.sticky_piston, 5 - this.getStairMeta(0 + rotation), 9, y + 2, 14, rotation, sbb);
   }

   private void makeWoodPillar(World world, StructureTFDecorator forgeDeco, int x, int y, int z, int stairMeta, int rotation, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, TFBlocks.log, 3, x, y + 2, z, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.log, 3, x, y + 3, z, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.log, 3, x, y + 4, z, rotation, sbb);
   }

   private void placeItemFrameRotated(World world, int x, int y, int z, int rotation, int direction, ItemStack itemStack, StructureBoundingBox sbb) {
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      if(sbb.isVecInside(dx, dy, dz)) {
         EntityItemFrame frame = new EntityItemFrame(world, dx, dy, dz, (this.getCoordBaseMode() + direction + rotation) % 4);
         if(itemStack != null) {
            frame.setDisplayedItem(itemStack);
         }

         world.spawnEntityInWorld(frame);
      }

   }

   private void decorateAquarium(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      this.makePillarFrame(world, sbb, super.deco, rotation, 12, y, 3, 4, 4, 13, false);
      this.fillBlocksRotated(world, sbb, 13, y + 4, 4, 14, y + 4, 14, Blocks.flowing_water, 0, rotation);
      this.makePillarFrame(world, sbb, super.deco, rotation, 6, y, 12, 4, 4, 4, false);
      this.fillBlocksRotated(world, sbb, 6, y + 5, 12, 9, y + 5, 15, super.deco.accentID, super.deco.accentMeta, rotation);
      this.fillBlocksRotated(world, sbb, 7, y + 4, 13, 8, y + 5, 14, Blocks.flowing_water, 0, rotation);
   }

   private void decorateForge(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      StructureTFDecorator forgeDeco = super.deco;
      this.fillBlocksRotated(world, sbb, 17, y + 1, 1, 17, y + 4, 6, forgeDeco.pillarID, forgeDeco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 1, 17, y + 4, 1, forgeDeco.pillarID, forgeDeco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 17, 17, y + 4, 17, forgeDeco.pillarID, forgeDeco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 17, y + 1, 12, 17, y + 4, 17, forgeDeco.pillarID, forgeDeco.pillarMeta, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 2, 16, y + 1, 5, forgeDeco.blockID, forgeDeco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 2, 12, y + 1, 6, forgeDeco.stairID, this.getStairMeta(0 + rotation), rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 6, 16, y + 1, 6, forgeDeco.stairID, this.getStairMeta(3 + rotation), rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 13, 16, y + 1, 16, forgeDeco.blockID, forgeDeco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 12, 12, y + 1, 16, forgeDeco.stairID, this.getStairMeta(0 + rotation), rotation);
      this.fillBlocksRotated(world, sbb, 12, y + 1, 12, 16, y + 1, 12, forgeDeco.stairID, this.getStairMeta(1 + rotation), rotation);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 13, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 15, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 17, y, 3, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 17, y, 5, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 13, y, 17, this.getStairMeta(1 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 15, y, 17, this.getStairMeta(1 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 17, y, 13, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeFurnacePillar(world, forgeDeco, decoRNG, 17, y, 15, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 12, y, 1, this.getStairMeta(3 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 17, y, 6, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 12, y, 17, this.getStairMeta(1 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 17, y, 12, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 17, y, 9, this.getStairMeta(0 + rotation), rotation, sbb);
      this.makeStonePillar(world, forgeDeco, 9, y, 17, this.getStairMeta(1 + rotation), rotation, sbb);
      this.placeBlockRotated(world, Blocks.anvil, decoRNG.nextInt(16), 13, y + 2, 5, rotation, sbb);
      this.placeBlockRotated(world, Blocks.anvil, decoRNG.nextInt(16), 13, y + 2, 13, rotation, sbb);
      this.makeFirePit(world, forgeDeco, 6, y + 1, 12, rotation, sbb);
   }

   private void makeFurnacePillar(World world, StructureTFDecorator forgeDeco, Random rand, int x, int y, int z, int stairMeta, int rotation, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, forgeDeco.stairID, stairMeta + 4, x, y + 2, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.furnace, stairMeta + 4, x, y + 3, z, rotation, sbb);
      int amount = rand.nextBoolean()?rand.nextInt(5) + 4:0;
      if(amount > 0) {
         int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
         int dy = this.getYWithOffset(y + 3);
         int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
         if(sbb.isVecInside(dx, dy, dz) && world.getBlock(dx, dy, dz) == Blocks.furnace) {
            IInventory inv = (IInventory)world.getTileEntity(dx, dy, dz);
            inv.setInventorySlotContents(1, new ItemStack(Items.coal, amount, 1));
         }
      }

      this.placeBlockRotated(world, forgeDeco.stairID, stairMeta, x, y + 4, z, rotation, sbb);
   }

   private void makeStonePillar(World world, StructureTFDecorator forgeDeco, int x, int y, int z, int stairMeta, int rotation, StructureBoundingBox sbb) {
      int sx;
      for(sx = 1; sx <= 4; ++sx) {
         this.placeBlockRotated(world, forgeDeco.pillarID, forgeDeco.pillarMeta, x, y + sx, z, rotation, sbb);
      }

      sx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int sy = this.getYWithOffset(y + 1);
      int sz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      switch(stairMeta) {
      case 0:
         --sx;
         break;
      case 1:
         ++sx;
         break;
      case 2:
         --sz;
         break;
      case 3:
         ++sz;
      }

      if(sbb.isVecInside(sx, sy, sz)) {
         world.setBlock(sx, sy + 0, sz, forgeDeco.stairID, stairMeta, 0);
         world.setBlock(sx, sy + 3, sz, forgeDeco.stairID, stairMeta + 4, 0);
      }

   }

   private void makeFirePit(World world, StructureTFDecorator myDeco, int x, int y, int z, int rotation, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, myDeco.pillarID, myDeco.pillarMeta, x + 1, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, myDeco.pillarID, myDeco.pillarMeta, x + 1, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, myDeco.pillarID, myDeco.pillarMeta, x - 1, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, myDeco.pillarID, myDeco.pillarMeta, x - 1, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, myDeco.stairID, this.getStairMeta(0 + rotation), x - 1, y, z + 0, rotation, sbb);
      this.placeBlockRotated(world, myDeco.stairID, this.getStairMeta(2 + rotation), x + 1, y, z + 0, rotation, sbb);
      this.placeBlockRotated(world, myDeco.stairID, this.getStairMeta(3 + rotation), x + 0, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, myDeco.stairID, this.getStairMeta(1 + rotation), x + 0, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, Blocks.netherrack, 0, x, y, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.fire, 0, x, y + 1, z, rotation, sbb);
   }

   private void decorateNetherwart(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y, boolean isTop) {
      StructureTFDecorator netherDeco = super.deco;
      this.makePillarFrame(world, sbb, netherDeco, rotation, 12, y, 9, 4, 4, 7, true);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 10, 14, y + 1, 14, Blocks.soul_sand, 0, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 2, 10, 14, y + 2, 14, Blocks.nether_wart, 0, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 4, 10, 14, y + 4, 14, Blocks.soul_sand, 0, rotation);
      this.makePillarFrame(world, sbb, netherDeco, rotation, 5, y, 12, 3, isTop?4:9, 3, true);
      this.placeBlockRotated(world, netherDeco.blockID, netherDeco.blockMeta, 6, y + 1, 13, rotation, sbb);
      this.placeBlockRotated(world, netherDeco.blockID, netherDeco.blockMeta, 6, y + (isTop?4:9), 13, rotation, sbb);
      this.placeSpawnerRotated(world, 6, y + 3, 13, rotation, "Blaze", sbb);
      this.destroyTower(world, decoRNG, 12, y, 3, 2, sbb);
   }

   private void decorateBotanical(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      this.makePillarFrame(world, sbb, super.deco, rotation, 12, y, 12, 4, 4, 4, true);
      this.fillBlocksRotated(world, sbb, 13, y + 1, 13, 14, y + 1, 14, super.deco.blockID, super.deco.blockMeta, rotation);
      this.fillBlocksRotated(world, sbb, 13, y + 4, 13, 14, y + 4, 14, super.deco.blockID, super.deco.blockMeta, rotation);
      this.placeRandomPlant(world, decoRNG, 13, y + 2, 13, rotation, sbb);
      this.placeRandomPlant(world, decoRNG, 13, y + 2, 14, rotation, sbb);
      this.placeRandomPlant(world, decoRNG, 14, y + 2, 13, rotation, sbb);
      this.placeRandomPlant(world, decoRNG, 14, y + 2, 14, rotation, sbb);

      int x;
      for(x = 1; x <= 4; ++x) {
         this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, 12, y + x, 4, rotation, sbb);
         this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, 15, y + x, 4, rotation, sbb);
      }

      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation) + 4, 13, y + 1, 4, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(0 + rotation) + 4, 14, y + 1, 4, rotation, sbb);
      this.placeTreasureRotated(world, 13, y + 2, 4, rotation, TFTreasure.basement, sbb);
      this.placeBlockRotated(world, Blocks.crafting_table, 0, 14, y + 2, 4, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation) + 4, 12, y + 1, 7, rotation, sbb);
      this.placeBlockRotated(world, Blocks.wooden_slab, 9, 13, y + 1, 7, rotation, sbb);
      this.placeBlockRotated(world, Blocks.wooden_slab, 9, 14, y + 1, 7, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(0 + rotation) + 4, 15, y + 1, 7, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation) + 4, 12, y + 1, 10, rotation, sbb);
      this.placeBlockRotated(world, Blocks.wooden_slab, 9, 13, y + 1, 10, rotation, sbb);
      this.placeBlockRotated(world, Blocks.wooden_slab, 9, 14, y + 1, 10, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(0 + rotation) + 4, 15, y + 1, 10, rotation, sbb);

      for(x = 12; x <= 15; ++x) {
         this.placeRandomPlant(world, decoRNG, x, y + 2, 7, rotation, sbb);
         this.placeRandomPlant(world, decoRNG, x, y + 2, 10, rotation, sbb);
      }

      this.placeTreePlanter(world, decoRNG.nextInt(5), 6, y + 1, 12, rotation, sbb);
   }

   private void placeTreePlanter(World world, int treeNum, int x, int y, int z, int rotation, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, x + 1, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, x + 1, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, x - 1, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.pillarID, super.deco.pillarMeta, x - 1, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(0 + rotation), x - 1, y, z + 0, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(2 + rotation), x + 1, y, z + 0, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(3 + rotation), x + 0, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.stairID, this.getStairMeta(1 + rotation), x + 0, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, Blocks.dirt, 0, x, y, z, rotation, sbb);
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y + 1);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      if(sbb.isVecInside(dx, dy, dz)) {
         Object treeGen;
         switch(treeNum) {
         case 0:
         default:
            treeGen = new WorldGenTrees(false);
            break;
         case 1:
            treeGen = new WorldGenTrees(true, 3, 3, 3, false);
            break;
         case 2:
            treeGen = new WorldGenForest(true, false);
            break;
         case 3:
            treeGen = new TFGenSmallTwilightOak(false);
            break;
         case 4:
            treeGen = new TFGenSmallRainboak(false);
         }

         for(int i = 0; i < 100 && !((WorldGenerator)treeGen).generate(world, world.rand, dx, dy, dz); ++i) {
            ;
         }
      }

   }

   private void placeRandomPlant(World world, Random decoRNG, int x, int y, int z, int rotation, StructureBoundingBox sbb) {
      int potMeta = decoRNG.nextInt(12);
      this.placeBlockRotated(world, Blocks.flower_pot, potMeta, x, y, z, rotation, sbb);
   }

   private void makeBottomEntrance(World world, Random decoRNG, StructureBoundingBox sbb, int rotation, int y) {
      this.makeFirePit(world, super.deco, 13, y + 1, 3, rotation, sbb);
      this.makeFirePit(world, super.deco, 3, y + 1, 13, rotation, sbb);
      this.makeFirePit(world, super.deco, 13, y + 1, 13, rotation, sbb);
      this.makePillarFrame(world, sbb, super.deco, rotation, 7, y, 7, 3, 4, 3, false);
   }

   protected void addTimberMaze(World world, Random rand, StructureBoundingBox sbb, int bottom, int top) {
      byte spacing = 5;
      int floorside = 0;
      if(bottom == 0) {
         bottom += spacing;
      }

      for(int y = bottom; y < top; y += spacing) {
         ++floorside;
         floorside %= 4;
         this.makeTimberBeams(world, rand, sbb, floorside, y, y == bottom && bottom != spacing, y >= top - spacing, top);
      }

   }

   protected void makeTimberBeams(World world, Random rand, StructureBoundingBox sbb, int rotation, int y, boolean isBottom, boolean isTop, int top) {
      Block beamID = TFBlocks.log;
      byte beamMetaBase = 3;
      int beamMetaNS = (super.coordBaseMode + rotation) % 2 == 0?4:8;
      int beamMetaEW = beamMetaNS == 4?8:4;
      byte beamMetaUD = 0;

      int z;
      for(z = 1; z < super.size - 1; ++z) {
         this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaEW, 4, y, z, rotation, sbb);
         this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaEW, 9, y, z, rotation, sbb);
         this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaEW, 14, y, z, rotation, sbb);
      }

      z = this.pickBetweenExcluding(3, super.size - 3, rand, 4, 9, 14);

      int x1;
      for(x1 = 5; x1 < 9; ++x1) {
         this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaNS, x1, y, z, rotation, sbb);
      }

      z = this.pickBetweenExcluding(3, super.size - 3, rand, 4, 9, 14);

      for(x1 = 10; x1 < 14; ++x1) {
         this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaNS, x1, y, z, rotation, sbb);
      }

      byte var26 = 4;
      int z1 = this.pickFrom(rand, 4, 9, 14);
      byte x2 = 9;
      int z2 = this.pickFrom(rand, 4, 9, 14);
      byte x3 = 14;
      int z3 = this.pickFrom(rand, 4, 9, 14);

      int lx;
      for(lx = 1; lx < 5; ++lx) {
         if(!isBottom || this.checkPost(world, var26, y - 5, z1, rotation, sbb)) {
            this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaUD, var26, y - lx, z1, rotation, sbb);
            this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, rotation), var26 + 1, y - lx, z1, rotation, sbb);
         }

         if(!isBottom || this.checkPost(world, x2, y - 5, z2, rotation, sbb)) {
            this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaUD, x2, y - lx, z2, rotation, sbb);
         }

         if(!isBottom || this.checkPost(world, x3, y - 5, z3, rotation, sbb)) {
            this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaUD, x3, y - lx, z3, rotation, sbb);
            this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(4, rotation), x3 - 1, y - lx, z3, rotation, sbb);
         }
      }

      if(isTop) {
         lx = (super.boundingBox.minY + top + 1) % 4;
         byte lz = 4;
         byte ladderZ = 10;
         byte ladderMeta = 3;

         for(int by = 1; by < 5; ++by) {
            this.placeBlockRotated(world, beamID, beamMetaBase + beamMetaUD, lz, y + by, 9, lx, sbb);
            this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(ladderMeta, lx), lz, y + by, ladderZ, lx, sbb);
         }

         this.placeBlockRotated(world, Blocks.air, 0, lz, y + 6, 9, lx, sbb);
         this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, lz + 1, y + 5, ladderZ, lx, sbb);
         this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, lz - 1, y + 5, ladderZ, lx, sbb);
         this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, lz + 1, y + 6, ladderZ, lx, sbb);
         this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, lz - 1, y + 6, ladderZ, lx, sbb);
      }

      int var27;
      if(!isBottom && !isTop) {
         lx = this.pickFrom(rand, 6, 7, 11);
         var27 = this.pickFrom(rand, 6, 11, 12);
         this.makeMiniGhastSpawner(world, rand, y, lx, var27, sbb);
      }

      lx = this.pickFrom(rand, 2, 12, 16);
      var27 = 2 + rand.nextInt(15);
      this.placeBlockRotated(world, Blocks.redstone_lamp, 0, lx, y + 2, var27, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, rand.nextBoolean()?0:7, lx, y + 1, var27, rotation, sbb);
   }

   private void makeMiniGhastSpawner(World world, Random rand, int y, int sx, int sz, StructureBoundingBox sbb) {
      TileEntityMobSpawner spawner = this.placeSpawnerAtCurrentPosition(world, rand, sx, y + 2, sz, TFCreatures.getSpawnerNameFor("Mini Ghast"), sbb);
      if(spawner != null) {
         NBTTagCompound tags = new NBTTagCompound();
         spawner.writeToNBT(tags);
         tags.setShort("SpawnRange", (short)16);
         tags.setShort("MaxNearbyEntities", (short)2);
         tags.setShort("SpawnCount", (short)1);
         spawner.readFromNBT(tags);
      }

   }

   protected void addBuilderPlatforms(World world, Random rand, StructureBoundingBox sbb, int bottom, int top) {
      byte spacing = 5;
      int floorside = 0;
      if(bottom == 0) {
         bottom += spacing;
      }

      int y;
      for(y = bottom; y < top - spacing; y += spacing) {
         this.makeBuilderPlatforms(world, rand, sbb, floorside, y, y == bottom && bottom != spacing, y >= top - spacing);
         floorside += 1 + rand.nextInt(3);
         floorside %= 4;
      }

      this.makeBuilderPlatform(world, rand, 1, bottom, 5, true, sbb);
      this.makeBuilderPlatform(world, rand, 3, bottom, 5, true, sbb);

      for(y = bottom - 4; y < bottom; ++y) {
         this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, 1), 1, y, 5, 1, sbb);
         this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, 3), 1, y, 5, 3, sbb);
      }

      this.addTopBuilderPlatform(world, rand, bottom, top, spacing, sbb);
   }

   protected void makeBuilderPlatforms(World world, Random rand, StructureBoundingBox sbb, int rotation, int y, boolean bottom, boolean top) {
      int z = super.size / 2 + rand.nextInt(5) - rand.nextInt(5);
      this.makeBuilderPlatform(world, rand, rotation, y, z, false, sbb);
      this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, rotation), 1, y + 1, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, rotation), 1, y + 2, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, rotation), 1, y + 3, z, rotation, sbb);
      this.placeBlockRotated(world, Blocks.ladder, this.getLadderMeta(2, rotation), 1, y + 4, z, rotation, sbb);
      this.makeBuilderPlatform(world, rand, rotation, y + 5, z, true, sbb);
      int sx;
      int sz;
      if(y % 2 == 1) {
         sx = this.pickFrom(rand, 5, 9, 13);
         sz = sx == 9?(rand.nextBoolean()?5:13):9;
         this.placeBlockRotated(world, TFBlocks.towerDevice, 9, sx, y + 2, sz, rotation, sbb);
      } else {
         sx = rand.nextBoolean()?5:13;
         sz = rand.nextBoolean()?5:13;
         this.makeLampCluster(world, rand, sx, y, sz, rotation, sbb);
      }

   }

   private void addTopBuilderPlatform(World world, Random rand, int bottom, int top, int spacing, StructureBoundingBox sbb) {
      int rotation = (super.boundingBox.minY + top + 1) % 4;
      this.fillBlocksRotated(world, sbb, 5, top - spacing, 9, 7, top - spacing, 11, super.deco.accentID, super.deco.accentMeta, rotation);
      this.fillBlocksRotated(world, sbb, 6, top - spacing, 9, 6, top, 9, super.deco.accentID, super.deco.accentMeta, rotation);
      this.fillBlocksRotated(world, sbb, 6, top - spacing + 1, 10, 6, top - 1, 10, Blocks.ladder, this.getLadderMeta(3, rotation), rotation);
      this.placeBlockRotated(world, Blocks.air, 0, 6, top + 1, 9, rotation, sbb);
      this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 5, top + 0, 10, rotation, sbb);
      this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 7, top + 0, 10, rotation, sbb);
      this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 5, top + 1, 10, rotation, sbb);
      this.placeBlockRotated(world, super.deco.fenceID, super.deco.fenceMeta, 7, top + 1, 10, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 6, 7, top - spacing, 10, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, rand.nextBoolean()?5:6, 7, top - spacing + 1, 11, rotation, sbb);
   }

   private void makeBuilderPlatform(World world, Random rand, int rotation, int y, int z, boolean hole, StructureBoundingBox sbb) {
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 1, y, z - 1, rotation, sbb);
      if(!hole) {
         this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 1, y, z - 0, rotation, sbb);
      }

      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 1, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 2, y, z - 1, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 2, y, z - 0, rotation, sbb);
      this.placeBlockRotated(world, super.deco.accentID, super.deco.accentMeta, 2, y, z + 1, rotation, sbb);
      this.placeBlockRotated(world, TFBlocks.towerDevice, 6, 2, y, hole?z + 1:z - 1, rotation, sbb);
      this.placeBlockRotated(world, Blocks.lever, rand.nextBoolean()?5:6, 2, y + 1, z + 0, rotation, sbb);
   }

   private void makeLampCluster(World world, Random rand, int sx, int y, int sz, int rotation, StructureBoundingBox sbb) {
      byte radius = 4;
      int i = 0;

      int lx;
      int ly;
      int lz;
      int move;
      while(i < 5) {
         lx = sx;
         ly = y;
         lz = sz;
         int directions = 0;

         while(true) {
            if(directions < 10) {
               this.placeBlockRotated(world, Blocks.redstone_lamp, 0, lx, ly, lz, rotation, sbb);
               move = rand.nextInt(8);
               if(move > 5) {
                  move -= 2;
               }

               lx += Facing.offsetsXForSide[move];
               ly += Facing.offsetsYForSide[move];
               lz += Facing.offsetsZForSide[move];
               if(lx <= sx + radius && lx >= sx - radius && ly <= y + radius && ly >= y - radius && lz <= sz + radius && lz >= sz - radius) {
                  ++directions;
                  continue;
               }
            }

            ++i;
            break;
         }
      }

      for(i = 0; i < 5; ++i) {
         lx = sx;
         ly = y;
         lz = sz;
         int[] var16 = new int[10];

         for(move = 0; move < 10; ++move) {
            var16[move] = rand.nextInt(8);
            if(var16[move] > 5) {
               var16[move] -= 2;
            }
         }

         for(move = 0; move < 10; ++move) {
            int direction = var16[move];
            lx += Facing.offsetsXForSide[direction];
            ly += Facing.offsetsYForSide[direction];
            lz += Facing.offsetsZForSide[direction];
            if(lx > sx + radius || lx < sx - radius || ly > y + radius || ly < y - radius || lz > sz + radius || lz < sz - radius) {
               break;
            }

            if(this.getBlockIDRotated(world, lx, ly, lz, rotation, sbb) != Blocks.redstone_lamp) {
               this.placeBlockRotated(world, Blocks.lever, this.getLeverMeta(rotation, direction), lx, ly, lz, rotation, sbb);
               break;
            }
         }
      }

   }
}

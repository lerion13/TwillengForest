package twilightforest.structures.darktower;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.gen.structure.StructureComponent.BlockSelector;
import twilightforest.block.TFBlocks;

public class StructureTFTowerWoods extends BlockSelector {

   public void selectBlocks(Random par1Random, int x, int y, int z, boolean isWall) {
      if(!isWall) {
         super.field_151562_a = Blocks.air;
         super.selectedBlockMetaData = 0;
      } else {
         super.field_151562_a = TFBlocks.towerWood;
         float randFloat = par1Random.nextFloat();
         if(randFloat < 0.1F) {
            super.selectedBlockMetaData = 2;
         } else if(randFloat < 0.2F) {
            super.selectedBlockMetaData = 3;
         } else if(randFloat < 0.225F) {
            super.selectedBlockMetaData = 4;
         } else {
            super.selectedBlockMetaData = 0;
         }
      }

   }
}

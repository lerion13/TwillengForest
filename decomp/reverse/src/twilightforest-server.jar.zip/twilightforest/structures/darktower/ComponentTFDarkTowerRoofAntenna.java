package twilightforest.structures.darktower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.darktower.ComponentTFDarkTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFDarkTowerRoofAntenna extends ComponentTFDarkTowerRoof {

   public ComponentTFDarkTowerRoofAntenna() {}

   public ComponentTFDarkTowerRoofAntenna(int i, ComponentTFTowerWing wing) {
      super(i, wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      super.addComponentParts(world, rand, sbb);

      int y;
      for(y = 1; y < 10; ++y) {
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, y, super.size / 2, sbb);
      }

      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 + 1, sbb);

      for(y = 7; y < 10; ++y) {
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, y, super.size / 2, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, y, super.size / 2, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, y, super.size / 2 - 1, sbb);
         this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, y, super.size / 2 + 1, sbb);
      }

      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 8, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 8, super.size / 2 + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 8, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 8, super.size / 2 + 1, sbb);
      return true;
   }
}

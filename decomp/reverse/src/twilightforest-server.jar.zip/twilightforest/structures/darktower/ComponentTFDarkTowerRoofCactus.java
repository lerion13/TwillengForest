package twilightforest.structures.darktower;

import java.util.Random;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.structures.darktower.ComponentTFDarkTowerRoof;
import twilightforest.structures.lichtower.ComponentTFTowerWing;

public class ComponentTFDarkTowerRoofCactus extends ComponentTFDarkTowerRoof {

   public ComponentTFDarkTowerRoofCactus() {}

   public ComponentTFDarkTowerRoofCactus(int i, ComponentTFTowerWing wing) {
      super(i, wing);
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      super.addComponentParts(world, rand, sbb);

      for(int y = 1; y < 10; ++y) {
         this.placeBlockAtCurrentPosition(world, super.deco.blockID, super.deco.blockMeta, super.size / 2, y, super.size / 2, sbb);
      }

      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 10, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 1, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 1, super.size / 2 + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 1, 7, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, 7, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, 8, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 2, 9, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 + 3, 9, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 6, super.size / 2 + 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 6, super.size / 2 + 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 7, super.size / 2 + 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 8, super.size / 2 + 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 8, super.size / 2 + 3, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 1, 5, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, 5, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, 6, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 2, 7, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2 - 3, 7, super.size / 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 4, super.size / 2 - 1, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 4, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 5, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 6, super.size / 2 - 2, sbb);
      this.placeBlockAtCurrentPosition(world, super.deco.accentID, super.deco.accentMeta, super.size / 2, 6, super.size / 2 - 3, sbb);
      return true;
   }
}

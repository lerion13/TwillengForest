package twilightforest.structures;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.gen.structure.StructureComponent.BlockSelector;

public class StructureTFStrongholdStones extends BlockSelector {

   public void selectBlocks(Random par1Random, int par2, int par3, int par4, boolean par5) {
      if(!par5) {
         super.field_151562_a = Blocks.air;
         super.selectedBlockMetaData = 0;
      } else {
         super.field_151562_a = Blocks.stonebrick;
         float var6 = par1Random.nextFloat();
         if(var6 < 0.2F) {
            super.selectedBlockMetaData = 2;
         } else if(var6 < 0.5F) {
            super.selectedBlockMetaData = 1;
         } else if(var6 < 0.55F) {
            super.field_151562_a = Blocks.monster_egg;
            super.selectedBlockMetaData = 2;
         } else {
            super.selectedBlockMetaData = 0;
         }
      }

   }
}

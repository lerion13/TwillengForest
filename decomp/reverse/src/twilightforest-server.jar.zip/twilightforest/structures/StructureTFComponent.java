package twilightforest.structures;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import net.minecraft.world.gen.structure.StructureComponent;
import net.minecraft.world.gen.structure.StructureComponent.BlockSelector;
import twilightforest.TFTreasure;
import twilightforest.structures.StructureTFDecorator;
import twilightforest.structures.StructureTFStrongholdStones;

public abstract class StructureTFComponent extends StructureComponent {

   private static final StructureTFStrongholdStones strongholdStones = new StructureTFStrongholdStones();
   public StructureTFDecorator deco = null;
   public int spawnListIndex = 0;


   public StructureTFComponent() {}

   public StructureTFComponent(int i) {
      super(i);
   }

   protected void func_143012_a(NBTTagCompound par1NBTTagCompound) {
      par1NBTTagCompound.setInteger("si", this.spawnListIndex);
      par1NBTTagCompound.setString("deco", StructureTFDecorator.getDecoString(this.deco));
   }

   protected void func_143011_b(NBTTagCompound par1NBTTagCompound) {
      this.spawnListIndex = par1NBTTagCompound.getInteger("si");
      this.deco = StructureTFDecorator.getDecoFor(par1NBTTagCompound.getString("deco"));
   }

   public static StructureBoundingBox getComponentToAddBoundingBox(int x, int y, int z, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int dir) {
      switch(dir) {
      case 0:
         return new StructureBoundingBox(x + minX, y + minY, z + minZ, x + maxX + minX, y + maxY + minY, z + maxZ + minZ);
      case 1:
         return new StructureBoundingBox(x - maxZ + minZ, y + minY, z + minX, x + minZ, y + maxY + minY, z + maxX + minX);
      case 2:
         return new StructureBoundingBox(x - maxX - minX, y + minY, z - maxZ - minZ, x - minX, y + maxY + minY, z - minZ);
      case 3:
         return new StructureBoundingBox(x + minZ, y + minY, z - maxX, x + maxZ + minZ, y + maxY + minY, z + minX);
      default:
         return new StructureBoundingBox(x + minX, y + minY, z + minZ, x + maxX + minX, y + maxY + minY, z + maxZ + minZ);
      }
   }

   protected TileEntityMobSpawner placeSpawnerAtCurrentPosition(World world, Random rand, int x, int y, int z, String monsterID, StructureBoundingBox sbb) {
      TileEntityMobSpawner tileEntitySpawner = null;
      int dx = this.getXWithOffset(x, z);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffset(x, z);
      if(sbb.isVecInside(dx, dy, dz) && world.getBlock(dx, dy, dz) != Blocks.mob_spawner) {
         world.setBlock(dx, dy, dz, Blocks.mob_spawner, 0, 2);
         tileEntitySpawner = (TileEntityMobSpawner)world.getTileEntity(dx, dy, dz);
         if(tileEntitySpawner != null) {
            tileEntitySpawner.func_145881_a().setEntityName(monsterID);
         }
      }

      return tileEntitySpawner;
   }

   protected TileEntityMobSpawner placeSpawnerRotated(World world, int x, int y, int z, int rotation, String monsterID, StructureBoundingBox sbb) {
      TileEntityMobSpawner tileEntitySpawner = null;
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      if(sbb.isVecInside(dx, dy, dz) && world.getBlock(dx, dy, dz) != Blocks.mob_spawner) {
         world.setBlock(dx, dy, dz, Blocks.mob_spawner, 0, 2);
         tileEntitySpawner = (TileEntityMobSpawner)world.getTileEntity(dx, dy, dz);
         if(tileEntitySpawner != null) {
            tileEntitySpawner.func_145881_a().setEntityName(monsterID);
         }
      }

      return tileEntitySpawner;
   }

   protected void placeTreasureAtCurrentPosition(World world, Random rand, int x, int y, int z, TFTreasure treasureType, StructureBoundingBox sbb) {
      this.placeTreasureAtCurrentPosition(world, rand, x, y, z, treasureType, false, sbb);
   }

   protected void placeTreasureAtCurrentPosition(World world, Random rand, int x, int y, int z, TFTreasure treasureType, boolean trapped, StructureBoundingBox sbb) {
      int dx = this.getXWithOffset(x, z);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffset(x, z);
      if(sbb.isVecInside(dx, dy, dz) && world.getBlock(dx, dy, dz) != Blocks.chest) {
         treasureType.generate(world, rand, dx, dy, dz, (Block)(trapped?Blocks.trapped_chest:Blocks.chest));
      }

   }

   protected void placeTreasureRotated(World world, int x, int y, int z, int rotation, TFTreasure treasureType, StructureBoundingBox sbb) {
      this.placeTreasureRotated(world, x, y, z, rotation, treasureType, false, sbb);
   }

   protected void placeTreasureRotated(World world, int x, int y, int z, int rotation, TFTreasure treasureType, boolean trapped, StructureBoundingBox sbb) {
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      if(sbb.isVecInside(dx, dy, dz) && world.getBlock(dx, dy, dz) != Blocks.chest) {
         treasureType.generate(world, (Random)null, dx, dy, dz, (Block)(trapped?Blocks.trapped_chest:Blocks.chest));
      }

   }

   protected int[] offsetTowerCoords(int x, int y, int z, int towerSize, int direction) {
      int dx = this.getXWithOffset(x, z);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffset(x, z);
      return direction == 0?new int[]{dx + 1, dy - 1, dz - towerSize / 2}:(direction == 1?new int[]{dx + towerSize / 2, dy - 1, dz + 1}:(direction == 2?new int[]{dx - 1, dy - 1, dz + towerSize / 2}:(direction == 3?new int[]{dx - towerSize / 2, dy - 1, dz - 1}:new int[]{x, y, z})));
   }

   protected ChunkCoordinates offsetTowerCCoords(int x, int y, int z, int towerSize, int direction) {
      int dx = this.getXWithOffset(x, z);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffset(x, z);
      return direction == 0?new ChunkCoordinates(dx + 1, dy - 1, dz - towerSize / 2):(direction == 1?new ChunkCoordinates(dx + towerSize / 2, dy - 1, dz + 1):(direction == 2?new ChunkCoordinates(dx - 1, dy - 1, dz + towerSize / 2):(direction == 3?new ChunkCoordinates(dx - towerSize / 2, dy - 1, dz - 1):new ChunkCoordinates(x, y, z))));
   }

   public int[] getOffsetAsIfRotated(int[] src, int rotation) {
      int temp = this.getCoordBaseMode();
      int[] dest = new int[3];
      this.setCoordBaseMode(rotation);
      dest[0] = this.getXWithOffset(src[0], src[2]);
      dest[1] = this.getYWithOffset(src[1]);
      dest[2] = this.getZWithOffset(src[0], src[2]);
      this.setCoordBaseMode(temp);
      return dest;
   }

   protected int getXWithOffset(int x, int z) {
      switch(this.getCoordBaseMode()) {
      case 0:
         return super.boundingBox.minX + x;
      case 1:
         return super.boundingBox.maxX - z;
      case 2:
         return super.boundingBox.maxX - x;
      case 3:
         return super.boundingBox.minX + z;
      default:
         return x;
      }
   }

   protected int getYWithOffset(int par1) {
      return super.getYWithOffset(par1);
   }

   protected int getZWithOffset(int x, int z) {
      switch(this.getCoordBaseMode()) {
      case 0:
         return super.boundingBox.minZ + z;
      case 1:
         return super.boundingBox.minZ + x;
      case 2:
         return super.boundingBox.maxZ - z;
      case 3:
         return super.boundingBox.maxZ - x;
      default:
         return z;
      }
   }

   protected int getXWithOffsetAsIfRotated(int x, int z, int rotation) {
      if(super.coordBaseMode < 0) {
         return x;
      } else {
         switch((super.coordBaseMode + rotation) % 4) {
         case 0:
            return super.boundingBox.minX + x;
         case 1:
            return super.boundingBox.maxX - z;
         case 2:
            return super.boundingBox.maxX - x;
         case 3:
            return super.boundingBox.minX + z;
         default:
            return x;
         }
      }
   }

   protected int getZWithOffsetAsIfRotated(int x, int z, int rotation) {
      if(super.coordBaseMode < 0) {
         return x;
      } else {
         switch((super.coordBaseMode + rotation) % 4) {
         case 0:
            return super.boundingBox.minZ + z;
         case 1:
            return super.boundingBox.minZ + x;
         case 2:
            return super.boundingBox.maxZ - z;
         case 3:
            return super.boundingBox.maxZ - x;
         default:
            return z;
         }
      }
   }

   public int getCoordBaseMode() {
      return super.coordBaseMode;
   }

   public void setCoordBaseMode(int coordBaseMode) {
      super.coordBaseMode = coordBaseMode;
   }

   protected Block getBlockAtCurrentPosition(World par1World, int par2, int par3, int par4, StructureBoundingBox par5StructureBoundingBox) {
      return super.getBlockAtCurrentPosition(par1World, par2, par3, par4, par5StructureBoundingBox);
   }

   protected void placeBlockAtCurrentPosition(World par1World, Block par2, int par3, int par4, int par5, int par6, StructureBoundingBox par7StructureBoundingBox) {
      super.placeBlockAtCurrentPosition(par1World, par2, par3, par4, par5, par6, par7StructureBoundingBox);
   }

   protected void placeBlockRotated(World world, Block blockID, int meta, int x, int y, int z, int rotation, StructureBoundingBox sbb) {
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      if(sbb.isVecInside(dx, dy, dz)) {
         world.setBlock(dx, dy, dz, blockID, meta, 2);
      }

   }

   protected Block getBlockIDRotated(World world, int x, int y, int z, int rotation, StructureBoundingBox sbb) {
      int dx = this.getXWithOffsetAsIfRotated(x, z, rotation);
      int dy = this.getYWithOffset(y);
      int dz = this.getZWithOffsetAsIfRotated(x, z, rotation);
      return sbb.isVecInside(dx, dy, dz)?world.getBlock(dx, dy, dz):Blocks.air;
   }

   protected void fillBlocksRotated(World world, StructureBoundingBox sbb, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Block blockID, int meta, int rotation) {
      for(int dx = minY; dx <= maxY; ++dx) {
         for(int dy = minX; dy <= maxX; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               this.placeBlockRotated(world, blockID, meta, dy, dx, dz, rotation, sbb);
            }
         }
      }

   }

   protected void randomlyFillBlocksRotated(World world, StructureBoundingBox sbb, Random rand, float chance, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Block blockID, int meta, Block blockID2, int meta2, int rotation) {
      for(int dx = minY; dx <= maxY; ++dx) {
         for(int dy = minX; dy <= maxX; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               if(rand.nextFloat() < chance) {
                  this.placeBlockRotated(world, blockID, meta, dy, dx, dz, rotation, sbb);
               } else {
                  this.placeBlockRotated(world, blockID2, meta2, dy, dx, dz, rotation, sbb);
               }
            }
         }
      }

   }

   protected void fillAirRotated(World world, StructureBoundingBox sbb, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int rotation) {
      this.fillBlocksRotated(world, sbb, minX, minY, minZ, maxX, maxY, maxZ, Blocks.air, 0, rotation);
   }

   public static BlockSelector getStrongholdStones() {
      return strongholdStones;
   }

   protected int getStairMeta(int dir) {
      switch((this.getCoordBaseMode() + dir) % 4) {
      case 0:
         return 0;
      case 1:
         return 2;
      case 2:
         return 1;
      case 3:
         return 3;
      default:
         return -1;
      }
   }

   protected int getLadderMeta(int ladderDir) {
      switch((this.getCoordBaseMode() + ladderDir) % 4) {
      case 0:
         return 4;
      case 1:
         return 2;
      case 2:
         return 5;
      case 3:
         return 3;
      default:
         return -1;
      }
   }

   protected int getLadderMeta(int ladderDir, int rotation) {
      return this.getLadderMeta(ladderDir + rotation);
   }

   public void nullifySkyLightForBoundingBox(World world) {
      this.nullifySkyLight(world, super.boundingBox.minX - 1, super.boundingBox.minY - 1, super.boundingBox.minZ - 1, super.boundingBox.maxX + 1, super.boundingBox.maxY + 1, super.boundingBox.maxZ + 1);
   }

   public void nullifySkyLightAtCurrentPosition(World world, int sx, int sy, int sz, int dx, int dy, int dz) {
      this.nullifySkyLight(world, this.getXWithOffset(sx, sz), this.getYWithOffset(sy), this.getZWithOffset(sx, sz), this.getXWithOffset(dx, dz), this.getYWithOffset(dy), this.getZWithOffset(dx, dz));
   }

   public void nullifySkyLight(World world, int sx, int sy, int sz, int dx, int dy, int dz) {
      for(int x = sx; x <= dx; ++x) {
         for(int z = sz; z <= dz; ++z) {
            for(int y = sy; y <= dy; ++y) {
               world.setLightValue(EnumSkyBlock.Sky, x, y, z, 0);
            }
         }
      }

   }

   protected int getAverageGroundLevel(World world, StructureBoundingBox sbb) {
      int totalHeight = 0;
      int heightCount = 0;

      for(int bz = super.boundingBox.minZ; bz <= super.boundingBox.maxZ; ++bz) {
         for(int by = super.boundingBox.minX; by <= super.boundingBox.maxX; ++by) {
            if(sbb.isVecInside(by, 64, bz)) {
               totalHeight += Math.max(world.getTopSolidOrLiquidBlock(by, bz), world.provider.getAverageGroundLevel());
               ++heightCount;
            }
         }
      }

      if(heightCount == 0) {
         return -1;
      } else {
         return totalHeight / heightCount;
      }
   }

   protected int getSampledDirtLevel(World world, StructureBoundingBox sbb) {
      int dirtLevel = 256;

      for(int y = 90; y > 0; --y) {
         int cx = sbb.getCenterX();
         int cz = sbb.getCenterZ();
         Material material = world.getBlock(cx, y, cz).getMaterial();
         if(material == Material.ground || material == Material.rock || material == Material.grass) {
            dirtLevel = y;
            break;
         }
      }

      return dirtLevel;
   }

   protected void randomlyPlaceBlock(World world, StructureBoundingBox sbb, Random rand, float chance, int x, int y, int z, Block blockPlaced, int meta) {
      this.func_151552_a(world, sbb, rand, chance, x, y, z, blockPlaced, meta);
   }

   public boolean isComponentProtected() {
      return true;
   }

}

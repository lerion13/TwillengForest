package twilightforest.structures;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.StructureBoundingBox;
import twilightforest.entity.boss.EntityTFYetiAlpha;
import twilightforest.structures.ComponentTFHollowHill;
import twilightforest.world.TFWorld;

public class ComponentTFYetiCave extends ComponentTFHollowHill {

   private boolean yetiPlaced;


   public ComponentTFYetiCave() {}

   public ComponentTFYetiCave(World world, Random rand, int i, int x, int y, int z) {
      super(world, rand, i, 2, x, y + 2, z);
   }

   boolean isInHill(int cx, int cz) {
      return cx < super.radius * 2 && cx > 0 && cz < super.radius * 2 && cz > 0;
   }

   boolean isInHill(int mapX, int mapY, int mapZ) {
      return mapX < super.radius * 2 && mapX > 0 && mapZ < super.radius * 2 && mapZ > 0 && mapY > TFWorld.SEALEVEL && mapY < TFWorld.SEALEVEL + 20;
   }

   public boolean addComponentParts(World world, Random rand, StructureBoundingBox sbb) {
      short sn = 128;

      int bx;
      int[] by;
      for(bx = 0; bx < sn; ++bx) {
         by = this.getCoordsInHill2D(rand);
         this.generateBlockStalactite(world, Blocks.stone, 1.0F, true, by[0], 1, by[1], sbb);
      }

      for(bx = 0; bx < sn; ++bx) {
         by = this.getCoordsInHill2D(rand);
         this.generateBlockStalactite(world, Blocks.ice, 1.0F, true, by[0], 1, by[1], sbb);
      }

      for(bx = 0; bx < sn; ++bx) {
         by = this.getCoordsInHill2D(rand);
         this.generateBlockStalactite(world, Blocks.packed_ice, 0.9F, true, by[0], 1, by[1], sbb);
      }

      if(!this.yetiPlaced) {
         bx = this.getXWithOffset(super.radius, super.radius);
         int var9 = this.getYWithOffset(0);
         int bz = this.getZWithOffset(super.radius, super.radius);
         if(sbb.isVecInside(bx, var9, bz)) {
            this.yetiPlaced = true;
            EntityTFYetiAlpha yeti = new EntityTFYetiAlpha(world);
            yeti.setPosition((double)bx, (double)var9, (double)bz);
            yeti.setHomeArea(bx, var9, bz, 30);
            world.spawnEntityInWorld(yeti);
         }
      }

      return true;
   }
}

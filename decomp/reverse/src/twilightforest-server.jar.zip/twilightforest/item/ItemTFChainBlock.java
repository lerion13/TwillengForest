package twilightforest.item;

import com.google.common.collect.Sets;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.HashMap;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFChainBlock;
import twilightforest.item.TFItems;

public class ItemTFChainBlock extends ItemTool {

   private HashMap launchedBlocksMap = new HashMap();


   protected ItemTFChainBlock() {
      super(6.0F, TFItems.TOOL_KNIGHTLY, Sets.newHashSet(new Block[]{Blocks.stone}));
      super.maxStackSize = 1;
      this.setMaxDamage(99);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public ItemStack onItemRightClick(ItemStack stack, World worldObj, EntityPlayer player) {
      player.setItemInUse(stack, this.getMaxItemUseDuration(stack));
      if(!worldObj.isRemote && !this.hasLaunchedBlock(stack)) {
         worldObj.playSoundAtEntity(player, "random.bow", 1.0F, 1.0F / (Item.itemRand.nextFloat() * 0.4F + 1.2F));
         EntityTFChainBlock launchedBlock = new EntityTFChainBlock(worldObj, player);
         worldObj.spawnEntityInWorld(launchedBlock);
         this.setLaunchedBlock(stack, launchedBlock);
         setChainAsThrown(stack);
         stack.damageItem(1, player);
      }

      return stack;
   }

   public static void setChainAsThrown(ItemStack stack) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      stack.getTagCompound().setBoolean("thrown", true);
   }

   public static void setChainAsReturned(ItemStack stack) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      stack.getTagCompound().setBoolean("thrown", false);
   }

   public static boolean doesChainHaveBlock(ItemStack stack) {
      return stack.getTagCompound() == null?true:!stack.getTagCompound().getBoolean("thrown");
   }

   public static void setChainAsReturned(EntityPlayer player) {
      if(player.getCurrentEquippedItem() != null && player.getCurrentEquippedItem().getItem() == TFItems.chainBlock) {
         setChainAsReturned(player.getCurrentEquippedItem());
      }

   }

   public boolean hasLaunchedBlock(ItemStack stack) {
      Entity cube = (Entity)this.launchedBlocksMap.get(stack);
      return cube != null && !cube.isDead;
   }

   public void setLaunchedBlock(ItemStack stack, EntityTFChainBlock launchedCube) {
      this.launchedBlocksMap.put(stack, launchedCube);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      return doesChainHaveBlock(stack)?super.itemIcon:TFItems.knightmetalRing.getIconIndex(stack);
   }

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 72000;
   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return EnumAction.block;
   }

   public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
      return false;
   }

   public int getHarvestLevel(ItemStack stack, String toolClass) {
      return toolClass != null && toolClass.equals("pickaxe")?2:-1;
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.knightMetal?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }
}

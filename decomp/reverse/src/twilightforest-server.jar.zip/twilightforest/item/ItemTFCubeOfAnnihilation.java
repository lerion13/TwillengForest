package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.HashMap;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFCubeOfAnnihilation;
import twilightforest.item.ItemTF;
import twilightforest.item.TFItems;

public class ItemTFCubeOfAnnihilation extends ItemTF {

   private IIcon annihilateIcon;
   private HashMap launchedCubesMap = new HashMap();


   protected ItemTFCubeOfAnnihilation() {
      super.maxStackSize = 1;
      this.setCreativeTab(TFItems.creativeTab);
   }

   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
      return false;
   }

   public ItemStack onItemRightClick(ItemStack stack, World worldObj, EntityPlayer player) {
      player.setItemInUse(stack, this.getMaxItemUseDuration(stack));
      if(!worldObj.isRemote && !this.hasLaunchedCube(stack)) {
         EntityTFCubeOfAnnihilation launchedCube = new EntityTFCubeOfAnnihilation(worldObj, player);
         worldObj.spawnEntityInWorld(launchedCube);
         this.setLaunchedCube(stack, launchedCube);
         setCubeAsThrown(stack);
      }

      return stack;
   }

   public static void setCubeAsThrown(ItemStack stack) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      stack.getTagCompound().setBoolean("thrown", true);
   }

   public static void setCubeAsReturned(ItemStack stack) {
      if(stack.getTagCompound() == null) {
         stack.setTagCompound(new NBTTagCompound());
      }

      stack.getTagCompound().setBoolean("thrown", false);
   }

   public static boolean doesTalismanHaveCube(ItemStack stack) {
      return stack.getTagCompound() == null?true:!stack.getTagCompound().getBoolean("thrown");
   }

   public static void setCubeAsReturned(EntityPlayer player) {
      if(player.getCurrentEquippedItem() != null && player.getCurrentEquippedItem().getItem() == TFItems.cubeOfAnnihilation) {
         setCubeAsReturned(player.getCurrentEquippedItem());
      }

   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      return doesTalismanHaveCube(stack)?super.itemIcon:TFItems.cubeTalisman.getIconIndex(stack);
   }

   public boolean hasLaunchedCube(ItemStack stack) {
      Entity cube = (Entity)this.launchedCubesMap.get(stack);
      return cube != null && !cube.isDead;
   }

   public void setLaunchedCube(ItemStack stack, EntityTFCubeOfAnnihilation launchedCube) {
      this.launchedCubesMap.put(stack, launchedCube);
   }

   public void onUsingTick(ItemStack stack, EntityPlayer player, int count) {}

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 72000;
   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return EnumAction.block;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
      this.annihilateIcon = par1IconRegister.registerIcon("TwilightForest:annihilate_particle");
   }

   public IIcon getAnnihilateIcon() {
      return this.annihilateIcon;
   }
}

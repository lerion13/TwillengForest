package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemMultiTexture;
import twilightforest.block.BlockTFThorns;

public class ItemBlockTFThorns extends ItemMultiTexture {

   public ItemBlockTFThorns(Block p_i45346_1_, BlockTFThorns p_i45346_2_, String[] p_i45346_3_) {
      super(p_i45346_1_, p_i45346_2_, p_i45346_3_);
   }
}

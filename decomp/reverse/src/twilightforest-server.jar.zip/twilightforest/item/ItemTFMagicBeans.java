package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.block.TFBlocks;
import twilightforest.item.ItemTF;
import twilightforest.world.WorldProviderTwilightForest;

public class ItemTFMagicBeans extends ItemTF {

   public ItemTFMagicBeans() {
      this.makeRare();
   }

   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
      Block blockAt = world.getBlock(x, y, z);
      int minY = y + 1;
      int maxY = (int)(this.getCloudHeight(world) + 5.0F);
      if(y < maxY && blockAt == TFBlocks.uberousSoil) {
         if(!world.isRemote) {
            this.makeHugeStalk(world, x, z, minY, maxY);
         }

         return true;
      } else {
         return false;
      }
   }

   private float getCloudHeight(World world) {
      if(world.provider instanceof WorldProviderTwilightForest) {
         return ((WorldProviderTwilightForest)world.provider).getCloudHeight();
      } else {
         try {
            return world.provider.getCloudHeight();
         } catch (NoSuchMethodError var3) {
            return world.provider.terrainType.getCloudHeight();
         }
      }
   }

   private void makeHugeStalk(World world, int x, int z, int minY, int maxY) {
      int yOffset = world.rand.nextInt(100);
      float cScale = world.rand.nextFloat() * 0.25F + 0.125F;
      float rScale = world.rand.nextFloat() * 0.25F + 0.125F;
      float radius = 4.0F + MathHelper.sin((float)(minY + yOffset) * rScale) * 3.0F;
      x = (int)((float)x - MathHelper.sin((float)(minY + yOffset) * cScale) * radius);
      z = (int)((float)z - MathHelper.cos((float)(minY + yOffset) * cScale) * radius);
      int nextLeafY = minY + 10 + world.rand.nextInt(20);
      boolean isClear = true;

      for(int dy = minY; dy < maxY && isClear; ++dy) {
         radius = 5.0F + MathHelper.sin((float)(dy + yOffset) * rScale) * 2.5F;
         float cx = (float)x + MathHelper.sin((float)(dy + yOffset) * cScale) * radius;
         float cz = (float)z + MathHelper.cos((float)(dy + yOffset) * cScale) * radius;
         float stalkThickness = 2.5F;
         if(maxY - dy < 5) {
            stalkThickness *= (float)(maxY - dy) / 5.0F;
         }

         int minX = MathHelper.floor_float((float)x - radius - stalkThickness);
         int maxX = MathHelper.ceiling_float_int((float)x + radius + stalkThickness);
         int minZ = MathHelper.floor_float((float)z - radius - stalkThickness);
         int maxZ = MathHelper.ceiling_float_int((float)z + radius + stalkThickness);

         int lz;
         int lx;
         for(lx = minX; lx < maxX; ++lx) {
            for(lz = minZ; lz < maxZ; ++lz) {
               if(((float)lx - cx) * ((float)lx - cx) + ((float)lz - cz) * ((float)lz - cz) < stalkThickness * stalkThickness) {
                  isClear &= this.tryToPlaceStalk(world, lx, dy, lz);
               }
            }
         }

         if(dy == nextLeafY) {
            lx = (int)((float)x + MathHelper.sin((float)(dy + yOffset) * cScale) * (radius + stalkThickness));
            lz = (int)((float)z + MathHelper.cos((float)(dy + yOffset) * cScale) * (radius + stalkThickness));
            this.placeLeaves(world, lx, dy, lz);
            nextLeafY = dy + 5 + world.rand.nextInt(10);
         }
      }

   }

   private void placeLeaves(World world, int x, int y, int z) {
      world.setBlock(x, y, z, TFBlocks.hugeStalk);

      int dx;
      int dz;
      for(dx = -1; dx <= 1; ++dx) {
         for(dz = -1; dz <= 1; ++dz) {
            this.tryToPlaceLeaves(world, x + dx, y - 1, z + dz);
            this.tryToPlaceLeaves(world, x + dx, y + 1, z + dz);
         }
      }

      for(dx = -2; dx <= 2; ++dx) {
         for(dz = -2; dz <= 2; ++dz) {
            if(dx != 2 && dx != -2 || dz != 2 && dz != -2) {
               this.tryToPlaceLeaves(world, x + dx, y + 0, z + dz);
            }
         }
      }

   }

   private boolean tryToPlaceStalk(World world, int x, int y, int z) {
      Block blockThere = world.getBlock(x, y, z);
      if(blockThere != Blocks.air && !blockThere.canBeReplacedByLeaves(world, x, y, z)) {
         return false;
      } else {
         world.setBlock(x, y, z, TFBlocks.hugeStalk);
         return true;
      }
   }

   private void tryToPlaceLeaves(World world, int x, int y, int z) {
      Block blockThere = world.getBlock(x, y, z);
      if(blockThere == Blocks.air || blockThere.canBeReplacedByLeaves(world, x, y, z)) {
         world.setBlock(x, y, z, TFBlocks.leaves3, 1, 2);
      }

   }
}

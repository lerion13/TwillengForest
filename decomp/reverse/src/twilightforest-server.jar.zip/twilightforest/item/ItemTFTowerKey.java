package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import twilightforest.block.BlockTFTowerDevice;
import twilightforest.block.TFBlocks;
import twilightforest.item.ItemTF;

public class ItemTFTowerKey extends ItemTF {

   public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int x, int y, int z, int side, float fx, float fy, float fz) {
      if(!world.isRemote && world.getBlock(x, y, z) == TFBlocks.towerDevice && world.getBlockMetadata(x, y, z) == 4) {
         BlockTFTowerDevice.unlockBlock(world, x, y, z);
         --itemStack.stackSize;
         return true;
      } else {
         return false;
      }
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

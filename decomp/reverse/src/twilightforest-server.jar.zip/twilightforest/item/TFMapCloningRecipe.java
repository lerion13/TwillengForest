package twilightforest.item;

import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.world.World;

public class TFMapCloningRecipe implements IRecipe {

   public Item fullMapID;
   public Item blankMapID;


   public TFMapCloningRecipe(Item magicMap, Item emptyMagicMap) {
      this.fullMapID = magicMap;
      this.blankMapID = emptyMagicMap;
   }

   public boolean matches(InventoryCrafting par1InventoryCrafting, World par2World) {
      int var3 = 0;
      ItemStack var4 = null;

      for(int var5 = 0; var5 < par1InventoryCrafting.getSizeInventory(); ++var5) {
         ItemStack var6 = par1InventoryCrafting.getStackInSlot(var5);
         if(var6 != null) {
            if(var6.getItem() == this.fullMapID) {
               if(var4 != null) {
                  return false;
               }

               var4 = var6;
            } else {
               if(var6.getItem() != this.blankMapID) {
                  return false;
               }

               ++var3;
            }
         }
      }

      return var4 != null && var3 > 0;
   }

   public ItemStack getCraftingResult(InventoryCrafting par1InventoryCrafting) {
      int var2 = 0;
      ItemStack var3 = null;

      for(int var6 = 0; var6 < par1InventoryCrafting.getSizeInventory(); ++var6) {
         ItemStack var5 = par1InventoryCrafting.getStackInSlot(var6);
         if(var5 != null) {
            if(var5.getItem() == this.fullMapID) {
               if(var3 != null) {
                  return null;
               }

               var3 = var5;
            } else {
               if(var5.getItem() != this.blankMapID) {
                  return null;
               }

               ++var2;
            }
         }
      }

      if(var3 != null && var2 >= 1) {
         ItemStack var61 = new ItemStack(this.fullMapID, var2 + 1, var3.getItemDamage());
         if(var3.hasDisplayName()) {
            var61.setStackDisplayName(var3.getDisplayName());
         }

         return var61;
      } else {
         return null;
      }
   }

   public int getRecipeSize() {
      return 9;
   }

   public ItemStack getRecipeOutput() {
      return null;
   }
}

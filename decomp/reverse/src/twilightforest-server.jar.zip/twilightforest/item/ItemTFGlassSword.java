package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.Item.ToolMaterial;
import twilightforest.item.TFItems;

public class ItemTFGlassSword extends ItemSword {

   public ItemTFGlassSword(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
      this.setTextureName("TwilightForest:glassSword");
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return false;
   }

   public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLiving, EntityLivingBase par3EntityLiving) {
      boolean result = super.hitEntity(par1ItemStack, par2EntityLiving, par3EntityLiving);
      if(result) {
         par1ItemStack.damageItem(1000, par3EntityLiving);
      }

      return result;
   }

   public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
      if(player.worldObj.isRemote) {
         for(int var1 = 0; var1 < 20; ++var1) {
            double px = entity.posX + (double)(Item.itemRand.nextFloat() * entity.width * 2.0F) - (double)entity.width;
            double py = entity.posY + (double)(Item.itemRand.nextFloat() * entity.height);
            double pz = entity.posZ + (double)(Item.itemRand.nextFloat() * entity.width * 2.0F) - (double)entity.width;
            entity.worldObj.spawnParticle("blockcrack_" + Block.getIdFromBlock(Blocks.stained_glass) + "_" + 0, px, py, pz, 0.0D, 0.0D, 0.0D);
         }

         player.playSound(Blocks.glass.stepSound.getBreakSound(), 1.0F, 0.5F);
      }

      return false;
   }
}

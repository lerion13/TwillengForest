package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.storage.MapData.MapInfo;
import twilightforest.TFFeature;
import twilightforest.TFMagicMapData;
import twilightforest.TFMapPacketHandler;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.world.TFWorldChunkManager;

public class ItemTFMagicMap extends ItemMap {

   public static final String STR_ID = "magicmap";


   @SideOnly(Side.CLIENT)
   public static TFMagicMapData getMPMapData(int par0, World par1World) {
      String mapName = "magicmap_" + par0;
      TFMagicMapData mapData = (TFMagicMapData)par1World.loadItemData(TFMagicMapData.class, mapName);
      if(mapData == null) {
         mapData = new TFMagicMapData(mapName);
         par1World.setItemData(mapName, mapData);
      }

      return mapData;
   }

   public TFMagicMapData getMapData(ItemStack par1ItemStack, World par2World) {
      String mapName = "magicmap_" + par1ItemStack.getItemDamage();
      TFMagicMapData mapData = (TFMagicMapData)par2World.loadItemData(TFMagicMapData.class, mapName);
      if(mapData == null && !par2World.isRemote) {
         par1ItemStack.setItemDamage(par2World.getUniqueDataId("magicmap"));
         mapName = "magicmap_" + par1ItemStack.getItemDamage();
         mapData = new TFMagicMapData(mapName);
         mapData.xCenter = par2World.getWorldInfo().getSpawnX();
         mapData.zCenter = par2World.getWorldInfo().getSpawnZ();
         mapData.scale = 4;
         mapData.dimension = par2World.provider.dimensionId;
         mapData.markDirty();
         par2World.setItemData(mapName, mapData);
      }

      return mapData;
   }

   public void updateMapData(World par1World, Entity par2Entity, TFMagicMapData par3MapData) {
      if(par1World.provider.dimensionId == par3MapData.dimension && par2Entity instanceof EntityPlayer) {
         short xSize = 128;
         short zSize = 128;
         int scaleFactor = 1 << par3MapData.scale;
         int xCenter = par3MapData.xCenter;
         int zCenter = par3MapData.zCenter;
         int xDraw = MathHelper.floor_double(par2Entity.posX - (double)xCenter) / scaleFactor + xSize / 2;
         int zDraw = MathHelper.floor_double(par2Entity.posZ - (double)zCenter) / scaleFactor + zSize / 2;
         int drawSize = 512 / scaleFactor;
         MapInfo mapInfo = par3MapData.func_82568_a((EntityPlayer)par2Entity);
         ++mapInfo.field_82569_d;

         for(int xStep = xDraw - drawSize + 1; xStep < xDraw + drawSize; ++xStep) {
            if((xStep & 15) == (mapInfo.field_82569_d & 15)) {
               int highNumber = 255;
               int lowNumber = 0;

               for(int zStep = zDraw - drawSize - 1; zStep < zDraw + drawSize; ++zStep) {
                  if(xStep >= 0 && zStep >= -1 && xStep < xSize && zStep < zSize) {
                     int xOffset = xStep - xDraw;
                     int zOffset = zStep - zDraw;
                     boolean var20 = xOffset * xOffset + zOffset * zOffset > (drawSize - 2) * (drawSize - 2);
                     int xDraw2 = (xCenter / scaleFactor + xStep - xSize / 2) * scaleFactor;
                     int zDraw2 = (zCenter / scaleFactor + zStep - zSize / 2) * scaleFactor;
                     int[] biomeFrequencies = new int[256];

                     for(int xStep2 = 0; xStep2 < scaleFactor; ++xStep2) {
                        for(int zStep2 = 0; zStep2 < scaleFactor; ++zStep2) {
                           int biomeID = par1World.getBiomeGenForCoords(xDraw2 + xStep2, zDraw2 + zStep2).biomeID;
                           ++biomeFrequencies[biomeID];
                           if(biomeID == BiomeGenBase.river.biomeID || biomeID == TFBiomeBase.stream.biomeID) {
                              biomeFrequencies[biomeID] += 2;
                           }

                           if(par1World.getWorldChunkManager() instanceof TFWorldChunkManager) {
                              TFWorldChunkManager biomeIDToShow = (TFWorldChunkManager)par1World.getWorldChunkManager();
                              if(biomeIDToShow.isInFeatureChunk(par1World, xDraw2 + xStep2, zDraw2 + zStep2) && zStep >= 0 && xOffset * xOffset + zOffset * zOffset < drawSize * drawSize) {
                                 par3MapData.addFeatureToMap(TFFeature.getNearestFeature(xDraw2 + xStep2 >> 4, zDraw2 + zStep2 >> 4, par1World), xDraw2, zDraw2);
                              }
                           }
                        }
                     }

                     byte var30 = 0;
                     int highestFrequency = 0;

                     for(int existingColor = 0; existingColor < 256; ++existingColor) {
                        if(biomeFrequencies[existingColor] > highestFrequency) {
                           var30 = (byte)existingColor;
                           highestFrequency = biomeFrequencies[existingColor];
                        }
                     }

                     ++var30;
                     if(zStep >= 0 && xOffset * xOffset + zOffset * zOffset < drawSize * drawSize && (!var20 || (xStep + zStep & 1) != 0)) {
                        byte var29 = par3MapData.colors[xStep + zStep * xSize];
                        if(var29 != var30) {
                           if(highNumber > zStep) {
                              highNumber = zStep;
                           }

                           if(lowNumber < zStep) {
                              lowNumber = zStep;
                           }

                           par3MapData.colors[xStep + zStep * xSize] = var30;
                        }
                     }
                  }
               }

               if(highNumber <= lowNumber) {
                  par3MapData.setColumnDirty(xStep, highNumber, lowNumber);
               }
            }
         }
      }

   }

   public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5) {
      if(!par2World.isRemote) {
         TFMagicMapData mapData = this.getMapData(par1ItemStack, par2World);
         if(par3Entity instanceof EntityPlayer) {
            EntityPlayer var7 = (EntityPlayer)par3Entity;
            mapData.updateVisiblePlayers(var7, par1ItemStack);
         }

         if(par5) {
            this.updateMapData(par2World, par3Entity, mapData);
         }
      }

   }

   public void onCreated(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {}

   public EnumRarity getRarity(ItemStack par1ItemStack) {
      return EnumRarity.uncommon;
   }

   public boolean hasEffect(ItemStack par1ItemStack) {
      return false;
   }

   public Packet func_150911_c(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      byte[] mapBytes = this.getMapData(par1ItemStack, par2World).getUpdatePacketData(par1ItemStack, par2World, par3EntityPlayer);
      if(mapBytes == null) {
         return null;
      } else {
         if(mapBytes[0] == 1 && par2World.rand.nextInt(4) == 0) {
            this.getMapData(par1ItemStack, par2World).checkExistingFeatures(par2World);
            mapBytes = this.getMapData(par1ItemStack, par2World).makeFeatureStorageArray();
         }

         short uniqueID = (short)par1ItemStack.getItemDamage();
         return TFMapPacketHandler.makeMagicMapPacket("magicmap", uniqueID, mapBytes);
      }
   }

   public String getItemStackDisplayName(ItemStack par1ItemStack) {
      return ("" + StatCollector.translateToLocal(this.getUnlocalizedNameInefficiently(par1ItemStack) + ".name") + " #" + par1ItemStack.getItemDamage()).trim();
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

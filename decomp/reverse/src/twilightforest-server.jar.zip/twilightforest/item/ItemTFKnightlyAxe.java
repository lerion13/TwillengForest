package twilightforest.item;

import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.util.StatCollector;
import twilightforest.item.TFItems;

public class ItemTFKnightlyAxe extends ItemAxe {

   private static final int BONUS_DAMAGE = 2;
   private EntityPlayer bonusDamagePlayer;
   private Entity bonusDamageEntity;
   private float damageVsEntity;


   protected ItemTFKnightlyAxe(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
      this.damageVsEntity = 4.0F + par2EnumToolMaterial.getDamageVsEntity();
   }

   public EnumRarity getRarity(ItemStack par1ItemStack) {
      return EnumRarity.rare;
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.knightMetal?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
      if(entity instanceof EntityLivingBase && ((EntityLivingBase)entity).getTotalArmorValue() == 0) {
         this.bonusDamageEntity = entity;
         this.bonusDamagePlayer = player;
      }

      return false;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);
      par3List.add(StatCollector.translateToLocal(this.getUnlocalizedName() + ".tooltip"));
   }

   public Multimap getItemAttributeModifiers() {
      Multimap multimap = super.getItemAttributeModifiers();
      multimap.removeAll(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName());
      multimap.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(Item.field_111210_e, "Tool modifier", (double)this.damageVsEntity, 0));
      return multimap;
   }
}

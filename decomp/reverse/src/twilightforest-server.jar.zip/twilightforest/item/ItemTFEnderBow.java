package twilightforest.item;

import twilightforest.item.ItemTFBowBase;
import twilightforest.item.TFItems;

public class ItemTFEnderBow extends ItemTFBowBase {

   public ItemTFEnderBow() {
      this.setTextureName("TwilightForest:enderbow");
      this.setCreativeTab(TFItems.creativeTab);
   }
}

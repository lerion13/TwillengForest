package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class ItemTFFieryPick extends ItemPickaxe {

   protected ItemTFFieryPick(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public boolean onBlockDestroyed(ItemStack par1ItemStack, World par2World, Block blockID, int x, int y, int z, EntityLivingBase par7EntityLiving) {
      if(super.onBlockDestroyed(par1ItemStack, par2World, blockID, x, y, z, par7EntityLiving) && this.func_150897_b(blockID)) {
         if(par2World.isRemote) {
            int meta = par2World.getBlockMetadata(x, y, z);
            ArrayList items = blockID.getDrops(par2World, x, y, z, meta, 0);
            Iterator var10 = items.iterator();

            while(var10.hasNext()) {
               ItemStack input = (ItemStack)var10.next();
               ItemStack result = FurnaceRecipes.smelting().getSmeltingResult(input);
               if(result != null) {
                  for(int var1 = 0; var1 < 5; ++var1) {
                     double rx = Item.itemRand.nextGaussian() * 0.02D;
                     double ry = Item.itemRand.nextGaussian() * 0.02D;
                     double rz = Item.itemRand.nextGaussian() * 0.02D;
                     double magnitude = 20.0D;
                     par2World.spawnParticle("flame", (double)x + 0.5D + rx * magnitude, (double)y + 0.5D + ry * magnitude, (double)z + 0.5D + rz * magnitude, -rx, -ry, -rz);
                  }
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLiving, EntityLivingBase par3EntityLiving) {
      boolean result = super.hitEntity(par1ItemStack, par2EntityLiving, par3EntityLiving);
      if(result && !par2EntityLiving.isImmuneToFire()) {
         if(par2EntityLiving.worldObj.isRemote) {
            for(int var1 = 0; var1 < 20; ++var1) {
               double var2 = Item.itemRand.nextGaussian() * 0.02D;
               double var4 = Item.itemRand.nextGaussian() * 0.02D;
               double var6 = Item.itemRand.nextGaussian() * 0.02D;
               double var8 = 10.0D;
               par2EntityLiving.worldObj.spawnParticle("flame", par2EntityLiving.posX + (double)(Item.itemRand.nextFloat() * par2EntityLiving.width * 2.0F) - (double)par2EntityLiving.width - var2 * var8, par2EntityLiving.posY + (double)(Item.itemRand.nextFloat() * par2EntityLiving.height) - var4 * var8, par2EntityLiving.posZ + (double)(Item.itemRand.nextFloat() * par2EntityLiving.width * 2.0F) - (double)par2EntityLiving.width - var6 * var8, var2, var4, var6);
            }
         } else {
            par2EntityLiving.setFire(15);
         }
      }

      return result;
   }

   public EnumRarity getRarity(ItemStack par1ItemStack) {
      return EnumRarity.rare;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);
      par3List.add(StatCollector.translateToLocal(this.getUnlocalizedName() + ".tooltip"));
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.fieryIngot?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   public boolean func_150897_b(Block par1Block) {
      return par1Block == Blocks.obsidian?true:super.func_150897_b(par1Block);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

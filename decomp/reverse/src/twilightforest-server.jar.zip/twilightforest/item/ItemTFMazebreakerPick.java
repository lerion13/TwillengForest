package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class ItemTFMazebreakerPick extends ItemPickaxe {

   protected ItemTFMazebreakerPick(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public void getSubItems(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      ItemStack istack = new ItemStack(par1, 1, 0);
      istack.addEnchantment(Enchantment.efficiency, 4);
      istack.addEnchantment(Enchantment.unbreaking, 3);
      istack.addEnchantment(Enchantment.fortune, 2);
      par3List.add(istack);
   }

   public float func_150893_a(ItemStack par1ItemStack, Block par2Block) {
      float strVsBlock = super.func_150893_a(par1ItemStack, par2Block);
      return par2Block == TFBlocks.mazestone?strVsBlock * 16.0F:strVsBlock;
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemMapBase;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFMagicMapData;
import twilightforest.item.TFItems;

public class ItemTFEmptyMagicMap extends ItemMapBase {

   protected ItemTFEmptyMagicMap() {
      this.setCreativeTab(TFItems.creativeTab);
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      ItemStack mapItem = new ItemStack(TFItems.magicMap, 1, par2World.getUniqueDataId("magicmap"));
      String mapName = "magicmap_" + mapItem.getItemDamage();
      TFMagicMapData mapData = new TFMagicMapData(mapName);
      par2World.setItemData(mapName, mapData);
      mapData.scale = 4;
      int step = 128 * (1 << mapData.scale);
      mapData.xCenter = (int)(Math.round(par3EntityPlayer.posX / (double)step) * (long)step);
      mapData.zCenter = (int)(Math.round(par3EntityPlayer.posZ / (double)step) * (long)step);
      mapData.dimension = (byte)par2World.provider.dimensionId;
      mapData.markDirty();
      --par1ItemStack.stackSize;
      if(mapItem.getItem() == TFItems.magicMap) {
         par3EntityPlayer.triggerAchievement(TFAchievementPage.twilightMagicMap);
      }

      if(par1ItemStack.stackSize <= 0) {
         return mapItem;
      } else {
         if(!par3EntityPlayer.inventory.addItemStackToInventory(mapItem.copy())) {
            par3EntityPlayer.dropPlayerItemWithRandomChoice(mapItem, false);
         }

         return par1ItemStack;
      }
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

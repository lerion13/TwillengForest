package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemMapBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.TFMazeMapData;
import twilightforest.item.TFItems;
import twilightforest.world.WorldProviderTwilightForest;

public class ItemTFEmptyMazeMap extends ItemMapBase {

   boolean mapOres;


   protected ItemTFEmptyMazeMap(boolean mapOres) {
      this.setCreativeTab(TFItems.creativeTab);
      this.mapOres = mapOres;
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      ItemStack mapItem = new ItemStack(this.mapOres?TFItems.oreMap:TFItems.mazeMap, 1, par2World.getUniqueDataId("mazemap"));
      String var5 = "mazemap_" + mapItem.getItemDamage();
      TFMazeMapData mapData = new TFMazeMapData(var5);
      par2World.setItemData(var5, mapData);
      mapData.scale = 0;
      int step = 128 * (1 << mapData.scale);
      if(par2World.provider instanceof WorldProviderTwilightForest && TFFeature.getFeatureForRegion(MathHelper.floor_double(par3EntityPlayer.posX) >> 4, MathHelper.floor_double(par3EntityPlayer.posZ) >> 4, par2World) == TFFeature.labyrinth) {
         ChunkCoordinates mc = TFFeature.getNearestCenterXYZ(MathHelper.floor_double(par3EntityPlayer.posX) >> 4, MathHelper.floor_double(par3EntityPlayer.posZ) >> 4, par2World);
         mapData.xCenter = mc.posX;
         mapData.zCenter = mc.posZ;
         mapData.yCenter = MathHelper.floor_double(par3EntityPlayer.posY);
      } else {
         mapData.xCenter = (int)(Math.round(par3EntityPlayer.posX / (double)step) * (long)step) + 10;
         mapData.zCenter = (int)(Math.round(par3EntityPlayer.posZ / (double)step) * (long)step) + 10;
         mapData.yCenter = MathHelper.floor_double(par3EntityPlayer.posY);
      }

      mapData.dimension = par2World.provider.dimensionId;
      mapData.markDirty();
      --par1ItemStack.stackSize;
      if(mapItem.getItem() == TFItems.mazeMap) {
         par3EntityPlayer.triggerAchievement(TFAchievementPage.twilightMazeMap);
      }

      if(mapItem.getItem() == TFItems.oreMap) {
         par3EntityPlayer.triggerAchievement(TFAchievementPage.twilightOreMap);
      }

      if(par1ItemStack.stackSize <= 0) {
         return mapItem;
      } else {
         if(!par3EntityPlayer.inventory.addItemStackToInventory(mapItem.copy())) {
            par3EntityPlayer.dropPlayerItemWithRandomChoice(mapItem, false);
         }

         return par1ItemStack;
      }
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

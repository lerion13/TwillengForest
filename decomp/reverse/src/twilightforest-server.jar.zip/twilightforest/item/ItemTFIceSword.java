package twilightforest.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import twilightforest.TwilightForestMod;
import twilightforest.item.TFItems;

public class ItemTFIceSword extends ItemSword {

   public ItemTFIceSword(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
      this.setTextureName("TwilightForest:iceSword");
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == Item.getItemFromBlock(Blocks.packed_ice)?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   public boolean hitEntity(ItemStack par1ItemStack, EntityLivingBase par2EntityLiving, EntityLivingBase par3EntityLiving) {
      boolean result = super.hitEntity(par1ItemStack, par2EntityLiving, par3EntityLiving);
      if(result) {
         byte chillLevel = 2;
         par2EntityLiving.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 200, chillLevel, true));
      }

      return result;
   }

   public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
      if(player.worldObj.isRemote) {
         for(int var1 = 0; var1 < 20; ++var1) {
            double px = entity.posX + (double)(Item.itemRand.nextFloat() * entity.width * 2.0F) - (double)entity.width;
            double py = entity.posY + (double)(Item.itemRand.nextFloat() * entity.height);
            double pz = entity.posZ + (double)(Item.itemRand.nextFloat() * entity.width * 2.0F) - (double)entity.width;
            TwilightForestMod.proxy.spawnParticle(entity.worldObj, "snowstuff", px, py, pz, 0.0D, 0.0D, 0.0D);
         }
      }

      return false;
   }
}

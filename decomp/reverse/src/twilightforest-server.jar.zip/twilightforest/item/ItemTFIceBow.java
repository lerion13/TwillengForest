package twilightforest.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import twilightforest.entity.EntityIceArrow;
import twilightforest.item.ItemTFBowBase;
import twilightforest.item.TFItems;

public class ItemTFIceBow extends ItemTFBowBase {

   public ItemTFIceBow() {
      this.setTextureName("TwilightForest:icebow");
      this.setCreativeTab(TFItems.creativeTab);
   }

   protected EntityArrow getArrow(World world, EntityPlayer entityPlayer, float velocity) {
      return new EntityIceArrow(world, entityPlayer, velocity);
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == Item.getItemFromBlock(Blocks.ice)?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }
}

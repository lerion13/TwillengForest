package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import twilightforest.TwilightForestMod;
import twilightforest.item.TFItems;

public class ItemTFArcticArmor extends ItemArmor {

   public ItemTFArcticArmor(ArmorMaterial par2EnumArmorMaterial, int renderIndex, int armorType) {
      super(par2EnumArmorMaterial, renderIndex, armorType);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public EnumRarity getRarity(ItemStack par1ItemStack) {
      return EnumRarity.uncommon;
   }

   public String getArmorTexture(ItemStack itemstack, Entity entity, int slot, String layer) {
      switch(slot) {
      case 0:
      case 1:
      case 3:
      default:
         return "twilightforest:textures/armor/arcticarmor_1.png";
      case 2:
         return "twilightforest:textures/armor/arcticarmor_2.png";
      }
   }

   public void getSubItems(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      ItemStack istack = new ItemStack(par1, 1, 0);
      par3List.add(istack);
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.arcticFur?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }

   @SideOnly(Side.CLIENT)
   public ModelBiped getArmorModel(EntityLivingBase entityLiving, ItemStack itemStack, int armorSlot) {
      return TwilightForestMod.proxy.getArcticArmorModel(armorSlot);
   }
}

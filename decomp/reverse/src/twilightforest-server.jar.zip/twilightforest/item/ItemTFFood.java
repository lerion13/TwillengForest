package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class ItemTFFood extends ItemFood {

   protected Item looksLike;
   protected boolean isSoup;


   public ItemTFFood(int par2) {
      super(par2, false);
      this.setCreativeTab(TFItems.creativeTab);
      this.setSoup(true);
   }

   public ItemTFFood(int par2, float par3, boolean par4) {
      super(par2, par3, par4);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public Item getLooksLike() {
      return this.looksLike;
   }

   public ItemTFFood setLooksLike(Item itemLike) {
      this.looksLike = itemLike;
      return this;
   }

   public IIcon getIconFromDamage(int par1) {
      return this.looksLike != null?this.looksLike.getIconFromDamage(0):super.getIconFromDamage(par1);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      if(this.looksLike == null) {
         super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
      }

   }

   public boolean isSoup() {
      return this.isSoup;
   }

   public void setSoup(boolean isSoup) {
      this.isSoup = isSoup;
      this.setMaxStackSize(1);
   }

   public ItemStack onEaten(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) {
      super.onEaten(par1ItemStack, par2World, par3EntityPlayer);
      return this.isSoup?new ItemStack(Items.bowl):par1ItemStack;
   }
}

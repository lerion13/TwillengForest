package twilightforest.item;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.world.World;
import twilightforest.entity.EntitySeekerArrow;
import twilightforest.item.ItemTFBowBase;
import twilightforest.item.TFItems;

public class ItemTFSeekerBow extends ItemTFBowBase {

   public ItemTFSeekerBow() {
      this.setTextureName("TwilightForest:seekerbow");
      this.setCreativeTab(TFItems.creativeTab);
   }

   protected EntityArrow getArrow(World world, EntityPlayer entityPlayer, float velocity) {
      return new EntitySeekerArrow(world, entityPlayer, velocity * 0.5F);
   }
}

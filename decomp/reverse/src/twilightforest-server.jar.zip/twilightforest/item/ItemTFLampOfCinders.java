package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.block.TFBlocks;
import twilightforest.item.ItemTF;
import twilightforest.item.TFItems;

public class ItemTFLampOfCinders extends ItemTF {

   private static final int FIRING_TIME = 12;


   public ItemTFLampOfCinders() {
      this.setCreativeTab(TFItems.creativeTab);
      super.maxStackSize = 1;
      this.setMaxDamage(1024);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World world, EntityPlayer player) {
      if(par1ItemStack.getItemDamage() < this.getMaxDamage()) {
         player.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
      } else {
         player.stopUsingItem();
      }

      return par1ItemStack;
   }

   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
      if(!this.burnBlock(player, world, x, y, z)) {
         return false;
      } else {
         world.playSoundAtEntity(player, this.getSound(), 0.5F, 1.5F);

         for(int i = 0; i < 10; ++i) {
            float dx = (float)x + 0.5F + (Item.itemRand.nextFloat() - Item.itemRand.nextFloat()) * 0.75F;
            float dy = (float)y + 0.5F + (Item.itemRand.nextFloat() - Item.itemRand.nextFloat()) * 0.75F;
            float dz = (float)z + 0.5F + (Item.itemRand.nextFloat() - Item.itemRand.nextFloat()) * 0.75F;
            world.spawnParticle("smoke", (double)dx, (double)dy, (double)dz, 0.0D, 0.0D, 0.0D);
            world.spawnParticle("flame", (double)dx, (double)dy, (double)dz, 0.0D, 0.0D, 0.0D);
         }

         return true;
      }
   }

   private boolean burnBlock(EntityPlayer player, World world, int x, int y, int z) {
      Block block = world.getBlock(x, y, z);
      if(block == TFBlocks.thorns) {
         world.setBlock(x, y, z, TFBlocks.burntThorns, world.getBlockMetadata(x, y, z) & 12, 2);
         return true;
      } else {
         return false;
      }
   }

   public void onPlayerStoppedUsing(ItemStack par1ItemStack, World world, EntityPlayer player, int useRemaining) {
      int useTime = this.getMaxItemUseDuration(par1ItemStack) - useRemaining;
      if(useTime > 12 && par1ItemStack.getItemDamage() + 1 < this.getMaxDamage()) {
         this.doBurnEffect(world, player);
         player.triggerAchievement(TFAchievementPage.twilightProgressTroll);
      }

   }

   private void doBurnEffect(World world, EntityPlayer player) {
      int px = MathHelper.floor_double(player.lastTickPosX);
      int py = MathHelper.floor_double(player.lastTickPosY + (double)player.getEyeHeight());
      int pz = MathHelper.floor_double(player.lastTickPosZ);
      byte range = 4;
      int i;
      int rx;
      int ry;
      if(!world.isRemote) {
         world.playSoundAtEntity(player, this.getSound(), 1.5F, 0.8F);

         for(i = -range; i <= range; ++i) {
            for(rx = -range; rx <= range; ++rx) {
               for(ry = -range; ry <= range; ++ry) {
                  this.burnBlock(player, world, px + i, py + rx, pz + ry);
               }
            }
         }
      }

      for(i = 0; i < 6; ++i) {
         rx = px + Item.itemRand.nextInt(range) - Item.itemRand.nextInt(range);
         ry = py + Item.itemRand.nextInt(2);
         int rz = pz + Item.itemRand.nextInt(range) - Item.itemRand.nextInt(range);
         world.playAuxSFXAtEntity(player, 2004, rx, ry, rz, 0);
      }

   }

   public String getSound() {
      return "mob.ghast.fireball";
   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return EnumAction.bow;
   }

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 72000;
   }
}

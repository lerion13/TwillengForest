package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import twilightforest.block.TFBlocks;
import twilightforest.entity.EntityTFMoonwormShot;
import twilightforest.item.ItemTF;
import twilightforest.item.TFItems;

public class ItemTFMoonwormQueen extends ItemTF {

   private static final int FIRING_TIME = 12;
   private IIcon[] icons;
   private String[] iconNames = new String[]{"moonwormQueen", "moonwormQueenAlt"};


   protected ItemTFMoonwormQueen() {
      this.setCreativeTab(TFItems.creativeTab);
      super.maxStackSize = 1;
      this.setMaxDamage(256);
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World world, EntityPlayer player) {
      if(par1ItemStack.getItemDamage() < this.getMaxDamage()) {
         player.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
      } else {
         player.stopUsingItem();
      }

      return par1ItemStack;
   }

   public boolean onItemUse(ItemStack par1ItemStack, EntityPlayer player, World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ) {
      Block currentBlockID = world.getBlock(x, y, z);
      if(currentBlockID == TFBlocks.moonworm) {
         return false;
      } else if(par1ItemStack != null && par1ItemStack.getItemDamage() == this.getMaxDamage()) {
         return false;
      } else {
         if(currentBlockID == Blocks.snow) {
            side = 1;
         } else if(currentBlockID != Blocks.vine && currentBlockID != Blocks.tallgrass && currentBlockID != Blocks.deadbush && (currentBlockID == Blocks.air || !currentBlockID.isReplaceable(world, x, y, z))) {
            if(side == 0) {
               --y;
            }

            if(side == 1) {
               ++y;
            }

            if(side == 2) {
               --z;
            }

            if(side == 3) {
               ++z;
            }

            if(side == 4) {
               --x;
            }

            if(side == 5) {
               ++x;
            }
         }

         Block block = world.getBlock(x, y, z);
         int currentMeta = world.getBlockMetadata(x, y, z);
         BreakEvent event = new BreakEvent(x, y, z, world, block, currentMeta, player);
         MinecraftForge.EVENT_BUS.post(event);
         if(world.canPlaceEntityOnSide(TFBlocks.moonworm, x, y, z, false, side, player, par1ItemStack) && !event.isCanceled()) {
            int placementMeta = TFBlocks.moonworm.onBlockPlaced(world, x, y, z, side, hitX, hitY, hitZ, 0);
            if(world.setBlock(x, y, z, TFBlocks.moonworm, placementMeta, 3)) {
               if(world.getBlock(x, y, z) == TFBlocks.moonworm) {
                  TFBlocks.moonworm.onBlockPlacedBy(world, x, y, z, player, par1ItemStack);
               }

               world.playSoundEffect((double)((float)x + 0.5F), (double)((float)y + 0.5F), (double)((float)z + 0.5F), this.getSound(), TFBlocks.moonworm.stepSound.getVolume() / 2.0F, TFBlocks.moonworm.stepSound.getPitch() * 0.8F);
               if(par1ItemStack != null) {
                  par1ItemStack.damageItem(1, player);
                  player.stopUsingItem();
               }
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public String getSound() {
      return "mob.slime.big";
   }

   public void onPlayerStoppedUsing(ItemStack par1ItemStack, World world, EntityPlayer player, int useRemaining) {
      int useTime = this.getMaxItemUseDuration(par1ItemStack) - useRemaining;
      if(!world.isRemote && useTime > 12 && par1ItemStack.getItemDamage() + 1 < this.getMaxDamage()) {
         boolean fired = world.spawnEntityInWorld(new EntityTFMoonwormShot(world, player));
         if(fired) {
            par1ItemStack.damageItem(2, player);
            world.playSoundAtEntity(player, this.getSound(), 1.0F, 1.0F);
         }
      }

   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      if(usingItem != null && usingItem.getItem() == this) {
         int useTime = usingItem.getMaxItemUseDuration() - useRemaining;
         if(useTime >= 12) {
            return (useTime >> 1) % 2 == 0?this.icons[0]:this.icons[1];
         }
      }

      return this.icons[0];
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.registerIcons(par1IconRegister);
      this.icons = new IIcon[this.iconNames.length];

      for(int i = 0; i < this.iconNames.length; ++i) {
         this.icons[i] = par1IconRegister.registerIcon("TwilightForest:" + this.iconNames[i]);
      }

   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return EnumAction.bow;
   }

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 72000;
   }
}

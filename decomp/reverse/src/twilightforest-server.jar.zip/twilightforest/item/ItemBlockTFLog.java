package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import twilightforest.block.TFBlocks;

public class ItemBlockTFLog extends ItemBlock {

   public static final String[] woodNames = new String[]{"oak", "canopy", "mangrove", "darkwood", "x", "root", "oreroot", "rotten"};


   public ItemBlockTFLog(Block log) {
      super(log);
      this.setHasSubtypes(true);
      this.setMaxDamage(0);
   }

   public IIcon getIconFromDamage(int par1) {
      return TFBlocks.log.getIcon(2, par1);
   }

   public String getUnlocalizedName(ItemStack itemstack) {
      int meta = itemstack.getItemDamage();
      int i;
      if((meta & 8) == 0) {
         i = MathHelper.clamp_int(meta, 0, 7);
         return super.getUnlocalizedName() + "." + woodNames[i];
      } else {
         meta &= 7;
         i = MathHelper.clamp_int(meta, 0, 7);
         return super.getUnlocalizedName() + "." + woodNames[i] + ".log";
      }
   }

   public int getMetadata(int i) {
      return i;
   }

}

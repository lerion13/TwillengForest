package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import twilightforest.item.TFItems;

public class ItemTFIronwoodArmor extends ItemArmor {

   public ItemTFIronwoodArmor(ArmorMaterial par2EnumArmorMaterial, int renderIndex, int armorType) {
      super(par2EnumArmorMaterial, renderIndex, armorType);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public EnumRarity getRarity(ItemStack par1ItemStack) {
      return EnumRarity.uncommon;
   }

   public String getArmorTexture(ItemStack itemstack, Entity entity, int slot, String layer) {
      return itemstack.getItem() != TFItems.ironwoodPlate && itemstack.getItem() != TFItems.ironwoodHelm && itemstack.getItem() != TFItems.ironwoodBoots?(itemstack.getItem() == TFItems.ironwoodLegs?"twilightforest:textures/armor/ironwood_2.png":"twilightforest:textures/armor/ironwood_1.png"):"twilightforest:textures/armor/ironwood_1.png";
   }

   public void getSubItems(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      ItemStack istack = new ItemStack(par1, 1, 0);
      switch(super.armorType) {
      case 0:
         istack.addEnchantment(Enchantment.aquaAffinity, 1);
         break;
      case 1:
         istack.addEnchantment(Enchantment.protection, 1);
         break;
      case 2:
         istack.addEnchantment(Enchantment.protection, 1);
         break;
      case 3:
         istack.addEnchantment(Enchantment.featherFalling, 1);
      }

      par3List.add(istack);
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.ironwoodIngot?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

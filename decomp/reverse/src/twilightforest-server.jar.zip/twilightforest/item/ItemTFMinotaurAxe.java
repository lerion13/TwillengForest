package twilightforest.item;

import com.google.common.collect.Multimap;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.util.StatCollector;
import twilightforest.item.TFItems;

public class ItemTFMinotaurAxe extends ItemAxe {

   public static final int BONUS_CHARGING_DAMAGE = 7;
   private Entity bonusDamageEntity;
   private EntityPlayer bonusDamagePlayer;
   private float damageVsEntity;


   protected ItemTFMinotaurAxe(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.damageVsEntity = 4.0F + par2EnumToolMaterial.getDamageVsEntity();
      this.setCreativeTab(TFItems.creativeTab);
   }

   public void getSubItems(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      ItemStack istack = new ItemStack(par1, 1, 0);
      par3List.add(istack);
   }

   public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
      if(player.isSprinting()) {
         this.bonusDamageEntity = entity;
         this.bonusDamagePlayer = player;
      }

      return false;
   }

   public float getDamageVsEntity(Entity par1Entity, ItemStack itemStack) {
      if(this.bonusDamagePlayer != null && this.bonusDamageEntity != null && par1Entity == this.bonusDamageEntity) {
         this.bonusDamagePlayer.onEnchantmentCritical(par1Entity);
         this.bonusDamagePlayer = null;
         this.bonusDamageEntity = null;
         return this.damageVsEntity + 7.0F;
      } else {
         return this.damageVsEntity;
      }
   }

   public int getItemEnchantability() {
      return ToolMaterial.GOLD.getEnchantability();
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack par1ItemStack, EntityPlayer par2EntityPlayer, List par3List, boolean par4) {
      super.addInformation(par1ItemStack, par2EntityPlayer, par3List, par4);
      par3List.add(StatCollector.translateToLocal(this.getUnlocalizedName() + ".tooltip"));
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }

   public Multimap getItemAttributeModifiers() {
      Multimap multimap = super.getItemAttributeModifiers();
      multimap.removeAll(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName());
      multimap.put(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName(), new AttributeModifier(Item.field_111210_e, "Tool modifier", (double)this.damageVsEntity, 0));
      return multimap;
   }
}

package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import twilightforest.block.TFBlocks;

public class ItemBlockNagastone extends ItemBlock {

   public ItemBlockNagastone(Block block) {
      super(block);
      this.setHasSubtypes(true);
      this.setMaxDamage(0);
   }

   public IIcon getIconFromDamage(int i) {
      int j = MathHelper.clamp_int(i, 0, 15);
      return TFBlocks.nagastone.getIcon(2, j);
   }

   public String getUnlocalizedName(ItemStack itemstack) {
      int meta = itemstack.getItemDamage();
      return super.getUnlocalizedName() + "." + meta;
   }

   public int getMetadata(int i) {
      return i;
   }
}

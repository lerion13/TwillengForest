package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemMultiTexture;
import twilightforest.block.BlockTFDeadrock;

public class ItemBlockTFDeadrock extends ItemMultiTexture {

   public ItemBlockTFDeadrock(Block p_i45346_1_, BlockTFDeadrock p_i45346_2_, String[] p_i45346_3_) {
      super(p_i45346_1_, p_i45346_2_, p_i45346_3_);
   }
}

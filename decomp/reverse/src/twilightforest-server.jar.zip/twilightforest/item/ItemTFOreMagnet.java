package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.IIcon;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import twilightforest.block.TFBlocks;
import twilightforest.item.ItemTF;
import twilightforest.item.TFItems;
import twilightforest.world.TFGenerator;

public class ItemTFOreMagnet extends ItemTF {

   private static final float WIGGLE = 10.0F;
   private IIcon[] icons;
   private String[] iconNames = new String[]{"oreMagnet", "oreMagnet1", "oreMagnet2"};


   protected ItemTFOreMagnet() {
      this.setCreativeTab(TFItems.creativeTab);
      super.maxStackSize = 1;
      this.setMaxDamage(12);
   }

   public ItemStack onItemRightClick(ItemStack par1ItemStack, World world, EntityPlayer player) {
      player.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
      return par1ItemStack;
   }

   public void onPlayerStoppedUsing(ItemStack par1ItemStack, World world, EntityPlayer player, int useRemaining) {
      int useTime = this.getMaxItemUseDuration(par1ItemStack) - useRemaining;
      if(!world.isRemote && useTime > 10) {
         int moved = this.doMagnet(world, player, 0.0F, 0.0F);
         if(moved == 0) {
            moved = this.doMagnet(world, player, 10.0F, 0.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, 10.0F, 10.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, 0.0F, 10.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, -10.0F, 10.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, -10.0F, 0.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, -10.0F, -10.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, 0.0F, -10.0F);
         }

         if(moved == 0) {
            moved = this.doMagnet(world, player, 10.0F, -10.0F);
         }

         if(moved > 0) {
            par1ItemStack.damageItem(moved, player);
            if(par1ItemStack.stackSize == 0) {
               player.destroyCurrentEquippedItem();
            }

            world.playSoundAtEntity(player, "mob.endermen.portal", 1.0F, 1.0F);
         }
      }

   }

   public IIcon getIcon(ItemStack stack, int renderPass, EntityPlayer player, ItemStack usingItem, int useRemaining) {
      if(usingItem != null && usingItem.getItem() == this) {
         int useTime = usingItem.getMaxItemUseDuration() - useRemaining;
         if(useTime >= 20) {
            return (useTime >> 2) % 2 == 0?this.icons[2]:this.icons[1];
         }

         if(useTime > 10) {
            return this.icons[1];
         }
      }

      return this.icons[0];
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.registerIcons(par1IconRegister);
      this.icons = new IIcon[this.iconNames.length];

      for(int i = 0; i < this.iconNames.length; ++i) {
         this.icons[i] = par1IconRegister.registerIcon("TwilightForest:" + this.iconNames[i]);
      }

   }

   public EnumAction getItemUseAction(ItemStack par1ItemStack) {
      return EnumAction.bow;
   }

   public int getMaxItemUseDuration(ItemStack par1ItemStack) {
      return 72000;
   }

   protected int doMagnet(World world, EntityPlayer player, float yawOffset, float pitchOffset) {
      double range = 32.0D;
      Vec3 srcVec = Vec3.createVectorHelper(player.posX, player.posY + (double)player.getEyeHeight(), player.posZ);
      Vec3 lookVec = this.getOffsetLook(player, yawOffset, pitchOffset);
      Vec3 destVec = srcVec.addVector(lookVec.xCoord * range, lookVec.yCoord * range, lookVec.zCoord * range);
      int useX = MathHelper.floor_double(srcVec.xCoord);
      int useY = MathHelper.floor_double(srcVec.yCoord);
      int useZ = MathHelper.floor_double(srcVec.zCoord);
      int destX = MathHelper.floor_double(destVec.xCoord);
      int destY = MathHelper.floor_double(destVec.yCoord);
      int destZ = MathHelper.floor_double(destVec.zCoord);
      int blocksMoved = doMagnet(world, useX, useY, useZ, destX, destY, destZ, player);
      return blocksMoved;
   }

   public static int doMagnet(World world, int useX, int useY, int useZ, int destX, int destY, int destZ) {
      int blocksMoved = 0;
      ChunkCoordinates[] lineArray = TFGenerator.getBresehnamArrayCoords(useX, useY, useZ, destX, destY, destZ);
      Block foundID = Blocks.air;
      int foundMeta = -1;
      int foundX = -1;
      int foundY = -1;
      int foundZ = -1;
      int baseX = -1;
      int baseY = -1;
      int baseZ = -1;
      boolean isNetherrack = false;
      ChunkCoordinates[] veinBlocks = lineArray;
      int offX = lineArray.length;

      int offY;
      for(offY = 0; offY < offX; ++offY) {
         ChunkCoordinates var29 = veinBlocks[offY];
         Block var32 = world.getBlock(var29.posX, var29.posY, var29.posZ);
         int var30 = world.getBlockMetadata(var29.posX, var29.posY, var29.posZ);
         if(baseY == -1) {
            if(isReplaceable(world, var32, var30, var29.posX, var29.posY, var29.posZ)) {
               baseX = var29.posX;
               baseY = var29.posY;
               baseZ = var29.posZ;
            } else if(isNetherReplaceable(world, var32, var30, var29.posX, var29.posY, var29.posZ)) {
               isNetherrack = true;
               baseX = var29.posX;
               baseY = var29.posY;
               baseZ = var29.posZ;
            }
         }

         if(var32 != Blocks.air && isOre(var32, var30)) {
            foundID = var32;
            foundMeta = var30;
            foundX = var29.posX;
            foundY = var29.posY;
            foundZ = var29.posZ;
            break;
         }
      }

      if(baseY != -1 && foundID != Blocks.air) {
         ArrayList var321 = new ArrayList();
         findVein(world, foundX, foundY, foundZ, foundID, foundMeta, var321);
         offX = baseX - foundX;
         offY = baseY - foundY;
         int var301 = baseZ - foundZ;
         Iterator var311 = var321.iterator();

         while(var311.hasNext()) {
            int replaceX;
            int replaceY;
            ChunkCoordinates var31;
            int replaceZ;
            label43: {
               var31 = (ChunkCoordinates)var311.next();
               replaceX = var31.posX + offX;
               replaceY = var31.posY + offY;
               replaceZ = var31.posZ + var301;
               Block replaceID = world.getBlock(replaceX, replaceY, replaceZ);
               int replaceMeta = world.getBlockMetadata(replaceX, replaceY, replaceZ);
               if(isNetherrack) {
                  if(isNetherReplaceable(world, replaceID, replaceMeta, replaceX, replaceY, replaceZ)) {
                     break label43;
                  }
               } else if(isReplaceable(world, replaceID, replaceMeta, replaceX, replaceY, replaceZ)) {
                  break label43;
               }

               if(replaceID != Blocks.air) {
                  continue;
               }
            }

            world.setBlock(var31.posX, var31.posY, var31.posZ, isNetherrack?Blocks.netherrack:Blocks.stone, 0, 2);
            world.setBlock(replaceX, replaceY, replaceZ, foundID, foundMeta, 2);
            ++blocksMoved;
         }
      }

      return blocksMoved;
   }

   public static int doMagnet(World world, int useX, int useY, int useZ, int destX, int destY, int destZ, EntityPlayer player) {
      int blocksMoved = 0;
      ChunkCoordinates[] lineArray = TFGenerator.getBresehnamArrayCoords(useX, useY, useZ, destX, destY, destZ);
      Block foundID = Blocks.air;
      int foundMeta = -1;
      int foundX = -1;
      int foundY = -1;
      int foundZ = -1;
      int baseX = -1;
      int baseY = -1;
      int baseZ = -1;
      boolean isNetherrack = false;
      ChunkCoordinates[] veinBlocks = lineArray;
      int offX = lineArray.length;

      int offY;
      for(offY = 0; offY < offX; ++offY) {
         ChunkCoordinates var29 = veinBlocks[offY];
         Block var32 = world.getBlock(var29.posX, var29.posY, var29.posZ);
         int var30 = world.getBlockMetadata(var29.posX, var29.posY, var29.posZ);
         if(baseY == -1) {
            if(isReplaceable(world, var32, var30, var29.posX, var29.posY, var29.posZ)) {
               baseX = var29.posX;
               baseY = var29.posY;
               baseZ = var29.posZ;
            } else if(isNetherReplaceable(world, var32, var30, var29.posX, var29.posY, var29.posZ)) {
               isNetherrack = true;
               baseX = var29.posX;
               baseY = var29.posY;
               baseZ = var29.posZ;
            }
         }

         if(var32 != Blocks.air && isOre(var32, var30)) {
            foundID = var32;
            foundMeta = var30;
            foundX = var29.posX;
            foundY = var29.posY;
            foundZ = var29.posZ;
            break;
         }
      }

      if(baseY != -1 && foundID != Blocks.air) {
         ArrayList var311 = new ArrayList();
         findVein(world, foundX, foundY, foundZ, foundID, foundMeta, var311);
         offX = baseX - foundX;
         offY = baseY - foundY;
         int var321 = baseZ - foundZ;
         Iterator var33 = var311.iterator();

         while(var33.hasNext()) {
            int replaceY;
            int replaceZ;
            int replaceX;
            ChunkCoordinates var31;
            label54: {
               var31 = (ChunkCoordinates)var33.next();
               replaceX = var31.posX + offX;
               replaceY = var31.posY + offY;
               replaceZ = var31.posZ + var321;
               Block event = world.getBlock(replaceX, replaceY, replaceZ);
               int event2 = world.getBlockMetadata(replaceX, replaceY, replaceZ);
               if(isNetherrack) {
                  if(isNetherReplaceable(world, event, event2, replaceX, replaceY, replaceZ)) {
                     break label54;
                  }
               } else if(isReplaceable(world, event, event2, replaceX, replaceY, replaceZ)) {
                  break label54;
               }

               if(event != Blocks.air) {
                  continue;
               }
            }

            BreakEvent var35 = new BreakEvent(var31.posX, var31.posY, var31.posZ, world, isNetherrack?Blocks.netherrack:Blocks.stone, 0, player);
            BreakEvent var34 = new BreakEvent(replaceX, replaceY, replaceZ, world, foundID, foundMeta, player);
            MinecraftForge.EVENT_BUS.post(var35);
            MinecraftForge.EVENT_BUS.post(var34);
            if(!var35.isCanceled() && !var34.isCanceled()) {
               world.setBlock(var31.posX, var31.posY, var31.posZ, isNetherrack?Blocks.netherrack:Blocks.stone, 0, 2);
               world.setBlock(replaceX, replaceY, replaceZ, foundID, foundMeta, 2);
            }

            ++blocksMoved;
         }
      }

      return blocksMoved;
   }

   private Vec3 getOffsetLook(EntityPlayer player, float yawOffset, float pitchOffset) {
      float var2 = MathHelper.cos(-(player.rotationYaw + yawOffset) * 0.017453292F - 3.1415927F);
      float var3 = MathHelper.sin(-(player.rotationYaw + yawOffset) * 0.017453292F - 3.1415927F);
      float var4 = -MathHelper.cos(-(player.rotationPitch + pitchOffset) * 0.017453292F);
      float var5 = MathHelper.sin(-(player.rotationPitch + pitchOffset) * 0.017453292F);
      return Vec3.createVectorHelper((double)(var3 * var4), (double)var5, (double)(var2 * var4));
   }

   private static boolean isReplaceable(World world, Block replaceID, int replaceMeta, int x, int y, int z) {
      return replaceID == Blocks.dirt?true:(replaceID == Blocks.grass?true:(replaceID == Blocks.gravel?true:replaceID != Blocks.air && replaceID.isReplaceableOreGen(world, x, y, z, Blocks.stone)));
   }

   private static boolean isNetherReplaceable(World world, Block replaceID, int replaceMeta, int x, int y, int z) {
      return replaceID == Blocks.netherrack?true:replaceID != Blocks.air && replaceID.isReplaceableOreGen(world, x, y, z, Blocks.netherrack);
   }

   private static boolean findVein(World world, int x, int y, int z, Block oreID, int oreMeta, ArrayList veinBlocks) {
      ChunkCoordinates here = new ChunkCoordinates(x, y, z);
      if(veinBlocks.contains(here)) {
         return false;
      } else if(veinBlocks.size() >= 24) {
         return false;
      } else if(world.getBlock(x, y, z) == oreID && world.getBlockMetadata(x, y, z) == oreMeta) {
         veinBlocks.add(here);
         findVein(world, x + 1, y, z, oreID, oreMeta, veinBlocks);
         findVein(world, x - 1, y, z, oreID, oreMeta, veinBlocks);
         findVein(world, x, y + 1, z, oreID, oreMeta, veinBlocks);
         findVein(world, x, y - 1, z, oreID, oreMeta, veinBlocks);
         findVein(world, x, y, z + 1, oreID, oreMeta, veinBlocks);
         findVein(world, x, y, z - 1, oreID, oreMeta, veinBlocks);
         return true;
      } else {
         return false;
      }
   }

   public static boolean isOre(Block blockID, int meta) {
      return blockID == Blocks.coal_ore?false:(blockID == Blocks.iron_ore?true:(blockID == Blocks.diamond_ore?true:(blockID == Blocks.emerald_ore?true:(blockID == Blocks.gold_ore?true:(blockID == Blocks.lapis_ore?true:(blockID == Blocks.redstone_ore?true:(blockID == Blocks.lit_redstone_ore?true:(blockID == Blocks.quartz_ore?true:(blockID == TFBlocks.root && meta == 1?true:blockID.getUnlocalizedName().toLowerCase().contains("ore"))))))))));
   }
}

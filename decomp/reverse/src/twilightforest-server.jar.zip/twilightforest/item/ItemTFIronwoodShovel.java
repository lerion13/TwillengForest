package twilightforest.item;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item.ToolMaterial;
import twilightforest.item.TFItems;

public class ItemTFIronwoodShovel extends ItemSpade {

   public ItemTFIronwoodShovel(ToolMaterial par2EnumToolMaterial) {
      super(par2EnumToolMaterial);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public void getSubItems(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      ItemStack istack = new ItemStack(par1, 1, 0);
      istack.addEnchantment(Enchantment.unbreaking, 1);
      par3List.add(istack);
   }

   public boolean getIsRepairable(ItemStack par1ItemStack, ItemStack par2ItemStack) {
      return par2ItemStack.getItem() == TFItems.ironwoodIngot?true:super.getIsRepairable(par1ItemStack, par2ItemStack);
   }

   @SideOnly(Side.CLIENT)
   public void registerIcons(IIconRegister par1IconRegister) {
      super.itemIcon = par1IconRegister.registerIcon("TwilightForest:" + this.getUnlocalizedName().substring(5));
   }
}

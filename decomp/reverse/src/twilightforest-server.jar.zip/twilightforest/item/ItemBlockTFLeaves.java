package twilightforest.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import twilightforest.block.TFBlocks;

public class ItemBlockTFLeaves extends ItemBlock {

   public ItemBlockTFLeaves(Block par1) {
      super(par1);
      this.setHasSubtypes(true);
      this.setMaxDamage(0);
   }

   public IIcon getIconFromDamage(int par1) {
      return TFBlocks.leaves.getIcon(2, par1);
   }

   public String getUnlocalizedName(ItemStack itemstack) {
      int meta = itemstack.getItemDamage();
      return super.getUnlocalizedName() + "." + meta;
   }

   public int getMetadata(int i) {
      return i;
   }
}

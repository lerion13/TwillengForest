package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

public class ModelTFKobold extends ModelBiped {

   ModelRenderer rightear;
   ModelRenderer leftear;
   ModelRenderer snout;
   ModelRenderer jaw;
   boolean isJumping = false;


   public ModelTFKobold() {
      super.textureWidth = 64;
      super.textureHeight = 32;
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-3.5F, -7.0F, -3.0F, 7, 6, 6);
      super.bipedHead.setRotationPoint(0.0F, 13.0F, 0.0F);
      super.bipedBody = new ModelRenderer(this, 12, 19);
      super.bipedBody.addBox(0.0F, 0.0F, 0.0F, 7, 7, 4);
      super.bipedBody.setRotationPoint(-3.5F, 12.0F, -2.0F);
      super.bipedRightArm = new ModelRenderer(this, 36, 17);
      super.bipedRightArm.addBox(-3.0F, -1.0F, -1.5F, 3, 7, 3);
      super.bipedRightArm.setRotationPoint(-3.5F, 12.0F, 0.0F);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm = new ModelRenderer(this, 36, 17);
      super.bipedLeftArm.addBox(0.0F, -1.0F, -1.5F, 3, 7, 3);
      super.bipedLeftArm.setRotationPoint(3.5F, 12.0F, 0.0F);
      super.bipedLeftArm.mirror = false;
      super.bipedRightLeg = new ModelRenderer(this, 0, 20);
      super.bipedRightLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 5, 3);
      super.bipedRightLeg.setRotationPoint(-2.0F, 19.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 20);
      super.bipedLeftLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 5, 3);
      super.bipedLeftLeg.setRotationPoint(2.0F, 19.0F, 0.0F);
      this.rightear = new ModelRenderer(this, 48, 20);
      this.rightear.addBox(0.0F, -4.0F, 0.0F, 4, 4, 1);
      this.rightear.setRotationPoint(3.5F, -3.0F, -1.0F);
      this.rightear.rotateAngleY = 0.2617994F;
      this.rightear.rotateAngleZ = -0.3490659F;
      super.bipedHead.addChild(this.rightear);
      this.leftear = new ModelRenderer(this, 48, 25);
      this.leftear.addBox(-4.0F, -4.0F, 0.0F, 4, 4, 1);
      this.leftear.setRotationPoint(-3.5F, -3.0F, -1.0F);
      this.leftear.rotateAngleY = -0.2617994F;
      this.leftear.rotateAngleZ = 0.3490659F;
      super.bipedHead.addChild(this.leftear);
      this.snout = new ModelRenderer(this, 28, 0);
      this.snout.addBox(-1.5F, -2.0F, -2.0F, 3, 2, 3);
      this.snout.setRotationPoint(0.0F, -2.0F, -3.0F);
      super.bipedHead.addChild(this.snout);
      this.jaw = new ModelRenderer(this, 28, 5);
      this.jaw.addBox(-1.5F, 0.0F, -2.0F, 3, 1, 3);
      this.jaw.setRotationPoint(0.0F, -2.0F, -3.0F);
      this.jaw.rotateAngleX = 0.20944F;
      super.bipedHead.addChild(this.jaw);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6) {
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightArm.rotateAngleX = -0.47123894F;
      super.bipedLeftArm.rotateAngleX = -0.47123894F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.19F) * 0.15F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.19F) * 0.15F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.267F) * 0.25F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.267F) * 0.25F;
      if(this.isJumping) {
         this.jaw.rotateAngleX = 1.44F;
      } else {
         this.jaw.rotateAngleX = 0.20944F;
      }

   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float partialTick) {
      this.isJumping = par1EntityLiving.motionY > 0.0D;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.setRotationAngles(f, f1, f2, f3, f4, f5);
      super.bipedHead.render(f5);
      super.bipedBody.render(f5);
      super.bipedRightArm.render(f5);
      super.bipedLeftArm.render(f5);
      super.bipedRightLeg.render(f5);
      super.bipedLeftLeg.render(f5);
   }
}

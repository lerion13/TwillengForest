package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class ModelTFArcticArmor extends ModelBiped {

   public ModelTFArcticArmor(int part, float expand) {
      super(expand);
      ModelRenderer rightHood = new ModelRenderer(this, 0, 0);
      rightHood.addBox(-1.0F, -2.0F, -1.0F, 1, 4, 1, expand);
      rightHood.setRotationPoint(-2.5F, -3.0F, -5.0F);
      super.bipedHead.addChild(rightHood);
      ModelRenderer leftHood = new ModelRenderer(this, 0, 0);
      leftHood.addBox(0.0F, -2.0F, -1.0F, 1, 4, 1, expand);
      leftHood.setRotationPoint(2.5F, -3.0F, -5.0F);
      super.bipedHead.addChild(leftHood);
      ModelRenderer topHood = new ModelRenderer(this, 24, 0);
      topHood.addBox(-2.0F, -1.0F, -1.0F, 4, 1, 1, expand);
      topHood.setRotationPoint(0.0F, -5.5F, -5.0F);
      super.bipedHead.addChild(topHood);
      ModelRenderer bottomHood = new ModelRenderer(this, 24, 0);
      bottomHood.addBox(-2.0F, -1.0F, -1.0F, 4, 1, 1, expand);
      bottomHood.setRotationPoint(0.0F, 0.5F, -5.0F);
      super.bipedHead.addChild(bottomHood);
      switch(part) {
      case 0:
         super.bipedHead.showModel = true;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 1:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = true;
         super.bipedRightArm.showModel = true;
         super.bipedLeftArm.showModel = true;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 2:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = true;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
         break;
      case 3:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
      }

   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      if(par1Entity != null) {
         super.isSneak = par1Entity.isSneaking();
      }

      if(par1Entity != null && par1Entity instanceof EntityLivingBase) {
         super.heldItemRight = ((EntityLivingBase)par1Entity).getHeldItem() != null?1:0;
      }

      super.render(par1Entity, par2, par3, par4, par5, par6, par7);
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class ModelTFKnightlyArmor extends ModelBiped {

   public ModelRenderer righthorn1 = new ModelRenderer(this, 32, 0);
   public ModelRenderer righthorn2;
   public ModelRenderer lefthorn1;
   public ModelRenderer lefthorn2;
   public ModelRenderer shoulderSpike1;
   public ModelRenderer shoulderSpike2;
   public ModelRenderer shoeSpike1;
   public ModelRenderer shoeSpike2;


   public ModelTFKnightlyArmor(int part, float expand) {
      super(expand);
      this.righthorn1.addBox(-5.5F, -1.5F, -1.5F, 5, 3, 3);
      this.righthorn1.setRotationPoint(-4.0F, -6.5F, 0.0F);
      this.righthorn1.rotateAngleY = -0.2617994F;
      this.righthorn1.rotateAngleZ = 0.17453294F;
      this.righthorn2 = new ModelRenderer(this, 32, 6);
      this.righthorn2.addBox(-3.5F, -1.0F, -1.0F, 3, 2, 2);
      this.righthorn2.setRotationPoint(-4.5F, 0.0F, 0.0F);
      this.righthorn2.rotateAngleZ = 0.17453294F;
      this.righthorn1.addChild(this.righthorn2);
      this.lefthorn1 = new ModelRenderer(this, 32, 0);
      this.lefthorn1.mirror = true;
      this.lefthorn1.addBox(0.5F, -1.5F, -1.5F, 5, 3, 3);
      this.lefthorn1.setRotationPoint(4.0F, -6.5F, 0.0F);
      this.lefthorn1.rotateAngleY = 0.2617994F;
      this.lefthorn1.rotateAngleZ = -0.17453294F;
      this.lefthorn2 = new ModelRenderer(this, 32, 6);
      this.lefthorn2.addBox(0.5F, -1.0F, -1.0F, 3, 2, 2);
      this.lefthorn2.setRotationPoint(4.5F, 0.0F, 0.0F);
      this.lefthorn2.rotateAngleZ = -0.17453294F;
      this.lefthorn1.addChild(this.lefthorn2);
      super.bipedHead.addChild(this.righthorn1);
      super.bipedHead.addChild(this.lefthorn1);
      this.shoulderSpike1 = new ModelRenderer(this, 32, 10);
      this.shoulderSpike1.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.5F);
      this.shoulderSpike1.setRotationPoint(-3.75F, -2.5F, 0.0F);
      this.shoulderSpike1.rotateAngleX = 0.7853982F;
      this.shoulderSpike1.rotateAngleY = 0.17453294F;
      this.shoulderSpike1.rotateAngleZ = 0.6108653F;
      super.bipedRightArm.addChild(this.shoulderSpike1);
      this.shoulderSpike2 = new ModelRenderer(this, 32, 10);
      this.shoulderSpike2.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.5F);
      this.shoulderSpike2.setRotationPoint(3.75F, -2.5F, 0.0F);
      this.shoulderSpike2.rotateAngleX = -0.7853982F;
      this.shoulderSpike2.rotateAngleY = -0.17453294F;
      this.shoulderSpike2.rotateAngleZ = 0.95993114F;
      super.bipedLeftArm.addChild(this.shoulderSpike2);
      this.shoeSpike1 = new ModelRenderer(this, 32, 10);
      this.shoeSpike1.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.5F);
      this.shoeSpike1.setRotationPoint(-2.5F, 11.0F, 2.0F);
      this.shoeSpike1.rotateAngleY = -0.7853982F;
      super.bipedRightLeg.addChild(this.shoeSpike1);
      this.shoeSpike2 = new ModelRenderer(this, 32, 10);
      this.shoeSpike2.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.5F);
      this.shoeSpike2.setRotationPoint(2.5F, 11.0F, 2.0F);
      this.shoeSpike2.rotateAngleY = 0.7853982F;
      super.bipedLeftLeg.addChild(this.shoeSpike2);
      switch(part) {
      case 0:
         super.bipedHead.showModel = true;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 1:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = true;
         super.bipedRightArm.showModel = true;
         super.bipedLeftArm.showModel = true;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 2:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = true;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
         break;
      case 3:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
      }

   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      if(par1Entity != null) {
         super.isSneak = par1Entity.isSneaking();
      }

      if(par1Entity != null && par1Entity instanceof EntityLivingBase) {
         super.heldItemRight = ((EntityLivingBase)par1Entity).getHeldItem() != null?1:0;
      }

      super.render(par1Entity, par2, par3, par4, par5, par6, par7);
   }
}

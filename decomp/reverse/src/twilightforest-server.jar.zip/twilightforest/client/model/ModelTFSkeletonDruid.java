package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFSkeletonDruid extends ModelBiped {

   public ModelRenderer dress;


   public ModelTFSkeletonDruid() {
      float f = 0.0F;
      super.bipedBody = new ModelRenderer(this, 8, 16);
      super.bipedBody.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, f);
      super.bipedBody.setRotationPoint(0.0F, 0.0F + f, 0.0F);
      super.bipedRightArm = new ModelRenderer(this, 0, 16);
      super.bipedRightArm.addBox(-1.0F, -2.0F, -1.0F, 2, 12, 2, f);
      super.bipedRightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 0, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -1.0F, 2, 12, 2, f);
      super.bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 16);
      super.bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2);
      super.bipedRightLeg.setRotationPoint(-2.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 16);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2);
      super.bipedLeftLeg.setRotationPoint(2.0F, 12.0F, 0.0F);
      this.dress = new ModelRenderer(this, 32, 16);
      this.dress.addBox(-4.0F, 12.0F, -2.0F, 8, 12, 4, f);
      this.dress.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.dress.render(f5);
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelTFHelmetCrab extends ModelBase {

   ModelRenderer body;
   ModelRenderer helmetBase;
   ModelRenderer Leg8;
   ModelRenderer Leg6;
   ModelRenderer Leg4;
   ModelRenderer rightArm;
   ModelRenderer Leg5;
   ModelRenderer Leg3;
   ModelRenderer clawbase;
   ModelRenderer clawtop;
   ModelRenderer clawbottom;
   ModelRenderer righteye;
   ModelRenderer lefteye;
   public ModelRenderer helmet;
   public ModelRenderer righthorn1;
   public ModelRenderer righthorn2;
   public ModelRenderer lefthorn1;
   public ModelRenderer lefthorn2;


   public ModelTFHelmetCrab() {
      super.textureWidth = 64;
      super.textureHeight = 32;
      this.body = new ModelRenderer(this, 32, 4);
      this.body.addBox(-2.5F, -2.5F, -5.0F, 5, 5, 5);
      this.body.setRotationPoint(0.0F, 19.0F, 0.0F);
      this.helmetBase = new ModelRenderer(this, 0, 0);
      this.helmetBase.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      this.helmetBase.setRotationPoint(0.0F, 18.0F, 0.0F);
      this.helmetBase.rotateAngleX = -1.7453294F;
      this.helmetBase.rotateAngleY = -0.5235988F;
      this.helmet = new ModelRenderer(this, 0, 14);
      this.helmet.addBox(-3.5F, -11.0F, -3.5F, 7, 11, 7);
      this.helmet.rotateAngleY = 0.7853982F;
      this.righthorn1 = new ModelRenderer(this, 28, 14);
      this.righthorn1.addBox(-6.0F, -1.5F, -1.5F, 7, 3, 3);
      this.righthorn1.setRotationPoint(-3.5F, -9.0F, 0.0F);
      this.righthorn1.rotateAngleY = -0.2617994F;
      this.righthorn1.rotateAngleZ = 0.17453294F;
      this.righthorn2 = new ModelRenderer(this, 28, 20);
      this.righthorn2.addBox(-3.0F, -1.0F, -1.0F, 3, 2, 2);
      this.righthorn2.setRotationPoint(-5.5F, 0.0F, 0.0F);
      this.righthorn2.rotateAngleY = -0.2617994F;
      this.righthorn2.rotateAngleZ = 0.17453294F;
      this.righthorn1.addChild(this.righthorn2);
      this.lefthorn1 = new ModelRenderer(this, 28, 14);
      this.lefthorn1.mirror = true;
      this.lefthorn1.addBox(-1.0F, -1.5F, -1.5F, 7, 3, 3);
      this.lefthorn1.setRotationPoint(3.5F, -9.0F, 0.0F);
      this.lefthorn1.rotateAngleY = 0.2617994F;
      this.lefthorn1.rotateAngleZ = -0.17453294F;
      this.lefthorn2 = new ModelRenderer(this, 28, 20);
      this.lefthorn2.addBox(0.0F, -1.0F, -1.0F, 3, 2, 2);
      this.lefthorn2.setRotationPoint(5.5F, 0.0F, 0.0F);
      this.lefthorn2.rotateAngleY = 0.2617994F;
      this.lefthorn2.rotateAngleZ = -0.17453294F;
      this.lefthorn1.addChild(this.lefthorn2);
      this.helmetBase.addChild(this.helmet);
      this.helmetBase.addChild(this.righthorn1);
      this.helmetBase.addChild(this.lefthorn1);
      this.Leg8 = new ModelRenderer(this, 18, 0);
      this.Leg8.addBox(-1.0F, -1.0F, -1.0F, 8, 2, 2);
      this.Leg8.setRotationPoint(3.0F, 20.0F, -3.0F);
      this.setRotation(this.Leg8, 0.0F, 0.5759587F, 0.1919862F);
      this.Leg6 = new ModelRenderer(this, 18, 0);
      this.Leg6.addBox(-1.0F, -1.0F, -1.0F, 8, 2, 2);
      this.Leg6.setRotationPoint(3.0F, 20.0F, -2.0F);
      this.setRotation(this.Leg6, 0.0F, 0.2792527F, 0.1919862F);
      this.Leg4 = new ModelRenderer(this, 18, 0);
      this.Leg4.addBox(-1.0F, -1.0F, -1.0F, 8, 2, 2);
      this.Leg4.setRotationPoint(3.0F, 20.0F, -1.0F);
      this.setRotation(this.Leg4, 0.0F, -0.2792527F, 0.1919862F);
      this.rightArm = new ModelRenderer(this, 38, 0);
      this.rightArm.addBox(-7.0F, -1.0F, -1.0F, 8, 2, 2);
      this.rightArm.setRotationPoint(-3.0F, 20.0F, -3.0F);
      this.setRotation(this.rightArm, 0.0F, -1.319531F, -0.1919862F);
      this.Leg5 = new ModelRenderer(this, 18, 0);
      this.Leg5.addBox(-7.0F, -1.0F, -1.0F, 8, 2, 2);
      this.Leg5.setRotationPoint(-3.0F, 20.0F, -2.0F);
      this.setRotation(this.Leg5, 0.0F, -0.2792527F, -0.1919862F);
      this.Leg3 = new ModelRenderer(this, 18, 0);
      this.Leg3.addBox(-7.0F, -1.0F, -1.0F, 8, 2, 2);
      this.Leg3.setRotationPoint(-3.0F, 20.0F, -1.0F);
      this.setRotation(this.Leg3, 0.0F, 0.2792527F, -0.1919862F);
      this.clawbase = new ModelRenderer(this, 0, 0);
      this.clawbase.addBox(0.0F, -1.5F, -1.0F, 3, 3, 2);
      this.clawbase.setRotationPoint(-6.0F, 0.0F, -0.5F);
      this.setRotation(this.clawbase, 0.0F, 1.5707964F, 0.0F);
      this.clawtop = new ModelRenderer(this, 0, 5);
      this.clawtop.addBox(0.0F, -0.5F, -1.0F, 3, 1, 2);
      this.clawtop.setRotationPoint(3.0F, -1.0F, 0.0F);
      this.setRotation(this.clawtop, 0.0F, 0.0F, -0.1858931F);
      this.clawbottom = new ModelRenderer(this, 0, 8);
      this.clawbottom.addBox(0.0F, -0.5F, -1.0F, 3, 2, 2);
      this.clawbottom.setRotationPoint(3.0F, 0.0F, 0.0F);
      this.setRotation(this.clawbottom, 0.0F, 0.0F, 0.2602503F);
      this.clawbase.addChild(this.clawtop);
      this.clawbase.addChild(this.clawbottom);
      this.rightArm.addChild(this.clawbase);
      this.righteye = new ModelRenderer(this, 10, 0);
      this.righteye.addBox(-1.0F, -3.0F, -1.0F, 2, 3, 2);
      this.righteye.setRotationPoint(-1.0F, -1.0F, -4.0F);
      this.setRotation(this.righteye, 0.7853982F, 0.0F, -0.7853982F);
      this.lefteye = new ModelRenderer(this, 10, 0);
      this.lefteye.addBox(-1.0F, -3.0F, -1.0F, 2, 3, 2);
      this.lefteye.setRotationPoint(1.0F, -1.0F, -4.0F);
      this.setRotation(this.lefteye, 0.7853982F, 0.0F, 0.7853982F);
      this.body.addChild(this.righteye);
      this.body.addChild(this.lefteye);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      this.setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
      this.body.render(par7);
      this.helmetBase.render(par7);
      this.Leg8.render(par7);
      this.Leg6.render(par7);
      this.Leg4.render(par7);
      this.rightArm.render(par7);
      this.Leg5.render(par7);
      this.Leg3.render(par7);
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      super.setRotationAngles(par1, par2, par3, par4, par5, par6, par7Entity);
      this.body.rotateAngleY = par4 / 57.295776F;
      this.body.rotateAngleX = par5 / 57.295776F;
      float f6 = 0.7853982F;
      this.Leg3.rotateAngleZ = -f6 * 0.74F;
      this.Leg4.rotateAngleZ = f6 * 0.74F;
      this.Leg5.rotateAngleZ = -f6 * 0.74F;
      this.Leg6.rotateAngleZ = f6 * 0.74F;
      this.Leg8.rotateAngleZ = f6;
      float f7 = -0.0F;
      float f8 = 0.3926991F;
      this.Leg3.rotateAngleY = f8 * 1.0F + f7;
      this.Leg4.rotateAngleY = -f8 * 1.0F - f7;
      this.Leg5.rotateAngleY = -f8 * 1.0F + f7;
      this.Leg6.rotateAngleY = f8 * 1.0F - f7;
      this.Leg8.rotateAngleY = f8 * 2.0F - f7;
      float f10 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 3.1415927F) * 0.4F) * par2;
      float f11 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 1.5707964F) * 0.4F) * par2;
      float f12 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 4.712389F) * 0.4F) * par2;
      float f14 = Math.abs(MathHelper.sin(par1 * 0.6662F + 3.1415927F) * 0.4F) * par2;
      float f15 = Math.abs(MathHelper.sin(par1 * 0.6662F + 1.5707964F) * 0.4F) * par2;
      float f16 = Math.abs(MathHelper.sin(par1 * 0.6662F + 4.712389F) * 0.4F) * par2;
      this.Leg3.rotateAngleY += f10;
      this.Leg4.rotateAngleY += -f10;
      this.Leg5.rotateAngleY += f11;
      this.Leg6.rotateAngleY += -f11;
      this.Leg8.rotateAngleY += -f12;
      this.Leg3.rotateAngleZ += f14;
      this.Leg4.rotateAngleZ += -f14;
      this.Leg5.rotateAngleZ += f15;
      this.Leg6.rotateAngleZ += -f15;
      this.Leg8.rotateAngleZ += -f16;
      this.rightArm.rotateAngleY = -1.319531F;
      this.rightArm.rotateAngleY += MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFTroll;

public class ModelTFTroll extends ModelBiped {

   public ModelRenderer nose;


   public ModelTFTroll() {
      super.textureWidth = 128;
      super.textureHeight = 64;
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-5.0F, -8.0F, -3.0F, 10, 10, 10);
      super.bipedHead.setRotationPoint(0.0F, -9.0F, -6.0F);
      super.bipedHeadwear = new ModelRenderer(this, 32, 0);
      super.bipedHeadwear.addBox(-4.0F, -8.0F, -4.0F, 0, 0, 0);
      super.bipedBody = new ModelRenderer(this, 40, 0);
      super.bipedBody.addBox(-8.0F, 0.0F, -5.0F, 16, 26, 10);
      super.bipedBody.setRotationPoint(0.0F, -14.0F, 0.0F);
      this.nose = new ModelRenderer(this, 0, 21);
      this.nose.addBox(-2.0F, -2.0F, -2.0F, 4, 8, 4);
      this.nose.setRotationPoint(0.0F, -2.0F, -4.0F);
      super.bipedHead.addChild(this.nose);
      super.bipedRightArm = new ModelRenderer(this, 32, 36);
      super.bipedRightArm.addBox(-5.0F, -2.0F, -3.0F, 6, 22, 6);
      super.bipedRightArm.setRotationPoint(-9.0F, -9.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 32, 36);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -3.0F, 6, 22, 6);
      super.bipedLeftArm.setRotationPoint(9.0F, -9.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 44);
      super.bipedRightLeg.addBox(-3.0F, 0.0F, -4.0F, 6, 12, 8);
      super.bipedRightLeg.setRotationPoint(-5.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 44);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-3.0F, 0.0F, -4.0F, 6, 12, 8);
      super.bipedLeftLeg.setRotationPoint(5.0F, 12.0F, 0.0F);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      EntityTFTroll troll = (EntityTFTroll)par7Entity;
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      if(par7Entity.riddenByEntity != null) {
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      }

      if(super.heldItemLeft != 0 || super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      }

      if(super.onGround > 0.0F) {
         float swing = 1.0F - super.onGround;
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX - 3.141592653589793D * (double)swing);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX - 3.141592653589793D * (double)swing);
      }

      super.bipedRightArm.rotateAngleY = 0.0F;
      super.bipedLeftArm.rotateAngleY = 0.0F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
   }

   public void setLivingAnimations(EntityLivingBase par1EntityLivingBase, float par2, float par3, float par4) {
      EntityTFTroll troll = (EntityTFTroll)par1EntityLivingBase;
      if(troll.getAttackTarget() != null) {
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      }

   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFGoblinKnightLower;

public class ModelTFGoblinKnightLower extends ModelBiped {

   public ModelRenderer tunic;


   public ModelTFGoblinKnightLower() {
      super.heldItemLeft = 0;
      super.heldItemRight = 0;
      super.isSneak = false;
      super.aimedBow = false;
      super.textureWidth = 128;
      super.textureHeight = 64;
      super.bipedCloak = new ModelRenderer(this, 0, 0);
      super.bipedCloak.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1);
      super.bipedEars = new ModelRenderer(this, 24, 0);
      super.bipedEars.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1);
      super.bipedHead = new ModelRenderer(this, 0, 32);
      super.bipedHead.addBox(-2.5F, -5.0F, -3.5F, 5, 5, 5);
      super.bipedHead.setRotationPoint(0.0F, 10.0F, 1.0F);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
      super.bipedHeadwear.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedBody = new ModelRenderer(this, 16, 48);
      super.bipedBody.addBox(-3.5F, 0.0F, -2.0F, 7, 8, 4);
      super.bipedBody.setRotationPoint(0.0F, 8.0F, 0.0F);
      super.bipedRightArm = new ModelRenderer(this, 40, 48);
      super.bipedRightArm.addBox(-2.0F, -2.0F, -1.5F, 2, 8, 3);
      super.bipedRightArm.setRotationPoint(-3.5F, 10.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 40, 48);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(0.0F, -2.0F, -1.5F, 2, 8, 3);
      super.bipedLeftArm.setRotationPoint(3.5F, 10.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 48);
      super.bipedRightLeg.addBox(-3.0F, 0.0F, -2.0F, 4, 8, 4);
      super.bipedRightLeg.setRotationPoint(-2.5F, 16.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 48);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-1.0F, 0.0F, -2.0F, 4, 8, 4);
      super.bipedLeftLeg.setRotationPoint(2.5F, 16.0F, 0.0F);
      this.tunic = new ModelRenderer(this, 64, 19);
      this.tunic.addBox(-6.0F, 0.0F, -3.0F, 12, 9, 6);
      this.tunic.setRotationPoint(0.0F, 7.5F, 0.0F);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      super.render(par1Entity, par2, par3, par4, par5, par6, par7);
      if(((EntityTFGoblinKnightLower)par1Entity).hasArmor()) {
         this.renderTunic(par7);
      }

   }

   public void renderTunic(float par1) {
      this.tunic.render(par1);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      if(par7Entity.riddenByEntity != null) {
         super.bipedHead.rotateAngleY = 0.0F;
         super.bipedHead.rotateAngleX = 0.0F;
         super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
         super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      }

      if(super.heldItemLeft != 0) {
         super.bipedLeftArm.rotateAngleX = super.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemLeft;
      }

      if(super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = super.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemRight;
      }

      super.bipedRightArm.rotateAngleY = 0.0F;
      super.bipedLeftArm.rotateAngleY = 0.0F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
   }
}

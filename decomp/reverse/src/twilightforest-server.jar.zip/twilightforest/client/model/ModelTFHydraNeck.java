package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFHydraNeck extends ModelBase {

   ModelRenderer neck;


   public ModelTFHydraNeck() {
      super.textureWidth = 512;
      super.textureHeight = 256;
      this.setTextureOffset("neck.box", 128, 136);
      this.setTextureOffset("neck.fin", 128, 200);
      this.neck = new ModelRenderer(this, "neck");
      this.neck.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.neck.render(f5);
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
      this.neck.rotateAngleY = f3 / 57.29578F;
      this.neck.rotateAngleX = f4 / 57.29578F;
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelQuadruped;
import net.minecraft.client.model.ModelRenderer;

public class ModelTFDeer extends ModelQuadruped {

   public ModelRenderer neck;


   public ModelTFDeer() {
      super(12, 0.0F);
      super.field_78145_g = 10.0F;
      super.head = new ModelRenderer(this, 0, 5);
      super.head.addBox(-2.0F, -8.0F, -6.0F, 4, 6, 6, 0.0F);
      super.head.setRotationPoint(0.0F, 4.0F, -7.0F);
      super.body = new ModelRenderer(this, 36, 6);
      super.body.addBox(-4.0F, -10.0F, -7.0F, 6, 18, 8, 0.0F);
      super.body.setRotationPoint(1.0F, 5.0F, 2.0F);
      super.body.rotateAngleX = 1.570796F;
      super.leg1 = new ModelRenderer(this, 0, 17);
      super.leg1.addBox(-3.0F, 0.0F, -2.0F, 2, 12, 3, 0.0F);
      super.leg1.setRotationPoint(0.0F, 12.0F, 9.0F);
      super.leg2 = new ModelRenderer(this, 0, 17);
      super.leg2.addBox(-1.0F, 0.0F, -2.0F, 2, 12, 3, 0.0F);
      super.leg2.setRotationPoint(2.0F, 12.0F, 9.0F);
      super.leg3 = new ModelRenderer(this, 0, 17);
      super.leg3.addBox(-3.0F, 0.0F, -3.0F, 2, 12, 3, 0.0F);
      super.leg3.setRotationPoint(0.0F, 12.0F, -5.0F);
      super.leg4 = new ModelRenderer(this, 0, 17);
      super.leg4.addBox(-1.0F, 0.0F, -3.0F, 2, 12, 3, 0.0F);
      super.leg4.setRotationPoint(2.0F, 12.0F, -5.0F);
      this.neck = new ModelRenderer(this, 10, 19);
      this.neck.addBox(-2.5F, -8.0F, -11.0F, 3, 9, 4, 0.0F);
      this.neck.rotateAngleX = 4.974188F;
      super.body.addChild(this.neck);
      super.head.setTextureOffset(52, 0).addBox(-1.5F, -5.0F, -9.0F, 3, 3, 3, 0.0F);
      super.head.setTextureOffset(20, 0);
      super.head.addBox(-3.0F, -10.0F, -2.0F, 2, 2, 2, 0.0F);
      super.head.addBox(-3.0F, -10.0F, -2.0F, 2, 2, 2, 0.0F);
      super.head.addBox(-4.0F, -10.0F, -1.0F, 1, 1, 3, 0.0F);
      super.head.addBox(-5.0F, -11.0F, 1.0F, 1, 1, 5, 0.0F);
      super.head.addBox(-5.0F, -14.0F, 2.0F, 1, 4, 1, 0.0F);
      super.head.addBox(-6.0F, -17.0F, 3.0F, 1, 4, 1, 0.0F);
      super.head.addBox(-6.0F, -13.0F, 0.0F, 1, 1, 3, 0.0F);
      super.head.addBox(-6.0F, -14.0F, -3.0F, 1, 1, 4, 0.0F);
      super.head.addBox(-7.0F, -15.0F, -6.0F, 1, 1, 4, 0.0F);
      super.head.addBox(-6.0F, -16.0F, -9.0F, 1, 1, 4, 0.0F);
      super.head.addBox(-7.0F, -18.0F, -1.0F, 1, 5, 1, 0.0F);
      super.head.addBox(-6.0F, -19.0F, -6.0F, 1, 5, 1, 0.0F);
      super.head.addBox(1.0F, -10.0F, -2.0F, 2, 2, 2, 0.0F);
      super.head.addBox(3.0F, -10.0F, -1.0F, 1, 1, 3, 0.0F);
      super.head.addBox(4.0F, -11.0F, 1.0F, 1, 1, 5, 0.0F);
      super.head.addBox(4.0F, -14.0F, 2.0F, 1, 4, 1, 0.0F);
      super.head.addBox(5.0F, -17.0F, 3.0F, 1, 4, 1, 0.0F);
      super.head.addBox(5.0F, -13.0F, 0.0F, 1, 1, 3, 0.0F);
      super.head.addBox(5.0F, -14.0F, -3.0F, 1, 1, 4, 0.0F);
      super.head.addBox(6.0F, -15.0F, -6.0F, 1, 1, 4, 0.0F);
      super.head.addBox(5.0F, -16.0F, -9.0F, 1, 1, 4, 0.0F);
      super.head.addBox(6.0F, -18.0F, -1.0F, 1, 5, 1, 0.0F);
      super.head.addBox(5.0F, -19.0F, -6.0F, 1, 5, 1, 0.0F);
   }
}

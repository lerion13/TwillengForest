package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFRedcap extends ModelBiped {

   ModelRenderer goblinRightEar;
   ModelRenderer goblinLeftEar;


   public ModelTFRedcap() {
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-3.4F, 1.0F, -4.0F, 7, 7, 7, 0.0F);
      super.bipedHead.setRotationPoint(0.0F, 0.0F, 0.0F);
      super.bipedHeadwear = new ModelRenderer(this, 32, 0);
      super.bipedHeadwear.addBox(-2.0F, 0.0F, -3.0F, 4, 5, 7, 0.0F);
      super.bipedHeadwear.setRotationPoint(0.0F, 0.0F, 0.0F);
      super.bipedBody = new ModelRenderer(this, 12, 19);
      super.bipedBody.addBox(-4.0F, 6.0F, -2.0F, 8, 9, 4, 0.0F);
      super.bipedBody.setRotationPoint(0.0F, 0.0F, 0.0F);
      super.bipedRightArm = new ModelRenderer(this, 36, 17);
      super.bipedRightArm.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 3, 0.0F);
      super.bipedRightArm.setRotationPoint(-5.0F, 8.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 36, 17);
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 3, 0.0F);
      super.bipedLeftArm.setRotationPoint(5.0F, 8.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 20);
      super.bipedRightLeg.addBox(-2.0F, 2.0F, -1.0F, 3, 9, 3, 0.0F);
      super.bipedRightLeg.setRotationPoint(-2.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 20);
      super.bipedLeftLeg.addBox(-1.0F, 3.0F, -1.0F, 3, 9, 3, 0.0F);
      super.bipedLeftLeg.setRotationPoint(2.0F, 12.0F, 0.0F);
      this.goblinRightEar = new ModelRenderer(this, 48, 20);
      this.goblinRightEar.addBox(3.0F, -2.0F, -1.0F, 2, 3, 1, 0.0F);
      this.goblinRightEar.setRotationPoint(0.0F, 3.0F, 0.0F);
      this.goblinLeftEar = new ModelRenderer(this, 48, 24);
      this.goblinLeftEar.addBox(-5.0F, -2.0F, -1.0F, 2, 3, 1, 0.0F);
      this.goblinLeftEar.setRotationPoint(0.0F, 3.0F, 0.0F);
      this.goblinLeftEar.mirror = true;
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.goblinRightEar.rotateAngleX = super.bipedHead.rotateAngleX;
      this.goblinRightEar.rotateAngleY = super.bipedHead.rotateAngleY;
      this.goblinRightEar.rotateAngleZ = super.bipedHead.rotateAngleZ;
      this.goblinLeftEar.rotateAngleX = super.bipedHead.rotateAngleX;
      this.goblinLeftEar.rotateAngleY = super.bipedHead.rotateAngleY;
      this.goblinLeftEar.rotateAngleZ = super.bipedHead.rotateAngleZ;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.goblinRightEar.render(f5);
      this.goblinLeftEar.render(f5);
   }
}

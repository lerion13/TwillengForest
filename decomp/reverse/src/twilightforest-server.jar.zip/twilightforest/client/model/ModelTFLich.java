package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import twilightforest.entity.boss.EntityTFLich;

public class ModelTFLich extends ModelBiped {

   ModelRenderer collar;
   ModelRenderer cloak;
   ModelRenderer shieldBelt;
   boolean renderPass;


   public ModelTFLich() {
      this.renderPass = false;
      this.renderPass = false;
      super.textureWidth = 64;
      super.textureHeight = 64;
      super.bipedBody = new ModelRenderer(this, 8, 16);
      super.bipedBody.addBox(-4.0F, 0.0F, -2.0F, 8, 24, 4);
      super.bipedBody.setRotationPoint(0.0F, -4.0F, 0.0F);
      super.bipedBody.setTextureSize(64, 64);
      super.bipedRightArm = new ModelRenderer(this, 0, 16);
      super.bipedRightArm.addBox(-2.0F, -2.0F, -1.0F, 2, 12, 2);
      super.bipedRightArm.setTextureSize(64, 64);
      super.bipedRightArm.setRotationPoint(-5.0F, -2.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 0, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-2.0F, -2.0F, -1.0F, 2, 12, 2);
      super.bipedLeftArm.setRotationPoint(5.0F, -2.0F, 0.0F);
      super.bipedLeftArm.setTextureSize(64, 64);
      super.bipedHeadwear = new ModelRenderer(this, 32, 0);
      super.bipedHeadwear.addBox(-4.0F, -12.0F, -4.0F, 8, 8, 8, 0.5F);
      super.bipedHeadwear.setRotationPoint(0.0F, -4.0F, 0.0F);
      super.bipedHeadwear.setTextureSize(64, 64);
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8);
      super.bipedHead.setRotationPoint(0.0F, -4.0F, 0.0F);
      super.bipedHead.setTextureSize(64, 64);
      super.bipedRightLeg = new ModelRenderer(this, 0, 16);
      super.bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2);
      super.bipedRightLeg.setRotationPoint(-2.0F, 9.5F, 0.0F);
      super.bipedRightLeg.setTextureSize(64, 64);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 16);
      super.bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2);
      super.bipedLeftLeg.setRotationPoint(2.0F, 9.5F, 0.0F);
      super.bipedLeftLeg.setTextureSize(64, 64);
      super.bipedLeftLeg.mirror = true;
      this.collar = new ModelRenderer(this, 32, 16);
      this.collar.addBox(-6.0F, 0.0F, 0.0F, 12, 12, 1);
      this.collar.setRotationPoint(0.0F, -3.0F, -1.0F);
      this.collar.setTextureSize(64, 64);
      this.setRotation(this.collar, 2.164208F, 0.0F, 0.0F);
      this.cloak = new ModelRenderer(this, 0, 44);
      this.cloak.addBox(-6.0F, 0.0F, 0.0F, 12, 19, 1);
      this.cloak.setRotationPoint(0.0F, -4.0F, 2.5F);
      this.cloak.setTextureSize(64, 64);
      this.setRotation(this.cloak, 0.0F, 0.0F, 0.0F);
      this.shieldBelt = new ModelRenderer(this);
      this.shieldBelt.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public ModelTFLich(boolean specialRenderModel) {
      this();
      this.renderPass = specialRenderModel;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      EntityTFLich lich = (EntityTFLich)entity;
      if(!this.renderPass) {
         if(!lich.isShadowClone()) {
            super.render(entity, f, f1, f2, f3, f4, f5 * 1.125F);
            this.collar.render(f5 * 1.125F);
            this.cloak.render(f5 * 1.125F);
         }
      } else if(lich.isShadowClone()) {
         super.render(entity, f, f1, f2, f3, f4, f5 * 1.125F);
      } else if(lich.getShieldStrength() > 0) {
         this.shieldBelt.render(f5 * 1.125F);
      }

   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float time) {
      EntityTFLich lich = (EntityTFLich)par1EntityLiving;
      byte shields = lich.getShieldStrength();
      if(!lich.isShadowClone() && shields > 0) {
         if(this.shieldBelt.childModels == null || this.shieldBelt.childModels.size() != shields) {
            if(this.shieldBelt.childModels != null) {
               this.shieldBelt.childModels.clear();
            }

            for(int i = 0; i < shields; ++i) {
               Vec3 vec = Vec3.createVectorHelper(11.0D, 0.0D, 0.0D);
               float rotateY = (float)i * (360.0F / (float)shields) * 3.141593F / 180.0F;
               vec.rotateAroundY(rotateY);
               ModelRenderer shield = new ModelRenderer(this, 26, 40);
               shield.addBox(0.5F, -6.0F, -6.0F, 1, 12, 12);
               shield.setRotationPoint((float)vec.xCoord, (float)vec.yCoord, (float)vec.zCoord);
               shield.setTextureSize(64, 64);
               shield.rotateAngleY = rotateY;
               this.shieldBelt.addChild(shield);
            }
         }

         this.shieldBelt.rotateAngleY = ((float)lich.ticksExisted + time) / 5.0F;
         this.shieldBelt.rotateAngleX = MathHelper.sin(((float)lich.ticksExisted + time) / 5.0F) / 4.0F;
         this.shieldBelt.rotateAngleZ = MathHelper.cos(((float)lich.ticksExisted + time) / 5.0F) / 4.0F;
      }

   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
      super.aimedBow = false;
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      float ogSin = MathHelper.sin(super.onGround * 3.141593F);
      float otherSin = MathHelper.sin((1.0F - (1.0F - super.onGround) * (1.0F - super.onGround)) * 3.141593F);
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.5F;
      super.bipedRightArm.rotateAngleY = -(0.1F - ogSin * 0.6F);
      super.bipedLeftArm.rotateAngleY = 0.1F - ogSin * 0.6F;
      super.bipedRightArm.rotateAngleX = -1.570796F;
      super.bipedLeftArm.rotateAngleX = -3.141593F;
      super.bipedRightArm.rotateAngleX -= ogSin * 1.2F - otherSin * 0.4F;
      super.bipedLeftArm.rotateAngleX -= ogSin * 1.2F - otherSin * 0.4F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(f2 * 0.26F) * 0.15F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(f2 * 0.26F) * 0.15F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(f2 * 0.167F) * 0.15F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(f2 * 0.167F) * 0.15F;
      super.bipedHead.rotationPointY = -4.0F;
      super.bipedHeadwear.rotationPointY = -4.0F;
      super.bipedRightLeg.rotationPointY = 9.5F;
      super.bipedLeftLeg.rotationPointY = 9.5F;
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }
}

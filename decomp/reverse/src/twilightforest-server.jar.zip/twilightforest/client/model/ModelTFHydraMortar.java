package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;

public class ModelTFHydraMortar extends ModelBase {

   public ModelRenderer box;


   public ModelTFHydraMortar() {
      super.textureWidth = 32;
      super.textureHeight = 32;
      this.box = new ModelRenderer(this, 0, 0);
      this.box.addBox(-4.0F, 0.0F, -4.0F, 8, 8, 8, 0.0F);
      this.box.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public void render(float f5) {
      this.box.render(f5);
   }
}

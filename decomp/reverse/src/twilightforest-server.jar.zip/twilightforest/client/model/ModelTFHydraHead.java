package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import twilightforest.entity.boss.EntityTFHydraHead;
import twilightforest.entity.boss.EntityTFHydraPart;

public class ModelTFHydraHead extends ModelBase {

   ModelRenderer head;
   ModelRenderer jaw;
   ModelRenderer frill;


   public ModelTFHydraHead() {
      super.textureWidth = 512;
      super.textureHeight = 256;
      this.setTextureOffset("head.box", 272, 0);
      this.setTextureOffset("head.upperlip", 272, 56);
      this.setTextureOffset("head.rearjaw", 272, 132);
      this.setTextureOffset("head.fin", 128, 200);
      this.setTextureOffset("head.fang1", 272, 156);
      this.setTextureOffset("head.fang2", 272, 156);
      this.setTextureOffset("head.teeth", 280, 156);
      this.setTextureOffset("head.teeth2", 280, 160);
      this.setTextureOffset("head.teeth3", 280, 160);
      this.setTextureOffset("jaw.jaw", 272, 92);
      this.setTextureOffset("jaw.fang1", 272, 156);
      this.setTextureOffset("jaw.fang2", 272, 156);
      this.setTextureOffset("jaw.teeth", 280, 156);
      this.setTextureOffset("jaw.teeth2", 280, 160);
      this.setTextureOffset("jaw.teeth3", 280, 160);
      this.setTextureOffset("frill.frill", 272, 200);
      this.head = new ModelRenderer(this, "head");
      this.head.addBox("box", -16.0F, -14.0F, -32.0F, 32, 24, 32);
      this.head.addBox("upperlip", -15.0F, -2.0F, -56.0F, 30, 12, 24);
      this.head.addBox("rearjaw", -15.0F, 10.0F, -20.0F, 30, 8, 16);
      this.head.addBox("fin", -2.0F, -30.0F, -12.0F, 4, 24, 24);
      this.head.addBox("fang1", -12.0F, 10.0F, -49.0F, 2, 5, 2);
      this.head.addBox("fang2", 10.0F, 10.0F, -49.0F, 2, 5, 2);
      this.head.addBox("teeth", -8.0F, 9.0F, -49.0F, 16, 2, 2);
      this.head.addBox("teeth2", -10.0F, 9.0F, -45.0F, 2, 2, 16);
      this.head.addBox("teeth3", 8.0F, 9.0F, -45.0F, 2, 2, 16);
      this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.jaw = new ModelRenderer(this, "jaw");
      this.jaw.setRotationPoint(0.0F, 10.0F, -20.0F);
      this.jaw.addBox("jaw", -15.0F, 0.0F, -32.0F, 30, 8, 32);
      this.jaw.addBox("fang1", -10.0F, -5.0F, -29.0F, 2, 5, 2);
      this.jaw.addBox("fang2", 8.0F, -5.0F, -29.0F, 2, 5, 2);
      this.jaw.addBox("teeth", -8.0F, -1.0F, -29.0F, 16, 2, 2);
      this.jaw.addBox("teeth2", -10.0F, -1.0F, -25.0F, 2, 2, 16);
      this.jaw.addBox("teeth3", 8.0F, -1.0F, -25.0F, 2, 2, 16);
      this.setRotation(this.jaw, 0.0F, 0.0F, 0.0F);
      this.head.addChild(this.jaw);
      this.frill = new ModelRenderer(this, "frill");
      this.frill.setRotationPoint(0.0F, 0.0F, -14.0F);
      this.frill.addBox("frill", -24.0F, -40.0F, 0.0F, 48, 48, 4);
      this.setRotation(this.frill, -0.5235988F, 0.0F, 0.0F);
      this.head.addChild(this.frill);
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.head.render(f5);
   }

   public void render(float f5) {
      this.head.render(f5);
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity par7Entity) {}

   public void setLivingAnimations(EntityLivingBase entityliving, float f, float f1, float time) {
      EntityTFHydraHead whichHead = (EntityTFHydraHead)entityliving;
      this.head.rotateAngleY = this.getRotationY(whichHead, time);
      this.head.rotateAngleX = this.getRotationX(whichHead, time);
      float mouthOpen = whichHead.getMouthOpen();
      this.head.rotateAngleX -= (float)((double)mouthOpen * 0.2617993877991494D);
      this.jaw.rotateAngleX = (float)((double)mouthOpen * 1.0471975511965976D);
   }

   public void openMouthForTrophy(float mouthOpen) {
      this.head.rotateAngleY = 0.0F;
      this.head.rotateAngleX = 0.0F;
      this.head.rotateAngleX -= (float)((double)mouthOpen * 0.2617993877991494D);
      this.jaw.rotateAngleX = (float)((double)mouthOpen * 1.0471975511965976D);
   }

   public float getRotationY(EntityTFHydraPart whichHead, float time) {
      float yaw = whichHead.prevRotationYaw + (whichHead.rotationYaw - whichHead.prevRotationYaw) * time;
      return yaw / 57.29578F;
   }

   public float getRotationX(EntityTFHydraPart whichHead, float time) {
      return (whichHead.prevRotationPitch + (whichHead.rotationPitch - whichHead.prevRotationPitch) * time) / 57.29578F;
   }
}

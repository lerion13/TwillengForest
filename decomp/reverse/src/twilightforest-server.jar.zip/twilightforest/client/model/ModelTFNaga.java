package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import twilightforest.entity.boss.EntityTFNaga;
import twilightforest.entity.boss.EntityTFNagaSegment;

public class ModelTFNaga extends ModelBase {

   public ModelRenderer head = new ModelRenderer(this, 0, 0);
   public ModelRenderer body;


   public ModelTFNaga() {
      this.head.addBox(-8.0F, -12.0F, -8.0F, 16, 16, 16, 0.0F);
      this.head.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.body = new ModelRenderer(this, 0, 0);
      this.body.addBox(-8.0F, -16.0F, -8.0F, 16, 16, 16, 0.0F);
      this.body.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      if(entity instanceof EntityTFNaga) {
         this.head.render(f5 * 2.0F);
      } else if(entity instanceof EntityTFNagaSegment) {
         this.body.render(f5 * 2.0F);
      } else {
         this.head.render(f5 * 2.0F);
      }

   }
}

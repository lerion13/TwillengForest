package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;
import twilightforest.entity.passive.EntityTFQuestRam;

public class ModelTFQuestRam extends ModelBase {

   ModelRenderer frontbody;
   ModelRenderer rearbody;
   ModelRenderer leg1;
   ModelRenderer haunch1;
   ModelRenderer leg2;
   ModelRenderer haunch2;
   ModelRenderer leg3;
   ModelRenderer haunch3;
   ModelRenderer leg4;
   ModelRenderer haunch4;
   ModelRenderer neck;
   ModelRenderer nose;
   ModelRenderer head;
   ModelRenderer[] segments;
   boolean[] segmentEnabled;
   int[] colorOrder = new int[]{0, 8, 7, 15, 14, 1, 4, 5, 13, 3, 9, 11, 10, 2, 6, 12};


   public ModelTFQuestRam() {
      super.textureWidth = 128;
      super.textureHeight = 128;
      this.setTextureOffset("head.head", 0, 70);
      this.setTextureOffset("head.horn1a", 0, 94);
      this.setTextureOffset("head.horn1b", 20, 96);
      this.setTextureOffset("head.horn1c", 34, 95);
      this.setTextureOffset("head.horn1d", 46, 98);
      this.setTextureOffset("head.horn1e", 58, 95);
      this.setTextureOffset("head.horn1f", 76, 95);
      this.setTextureOffset("head.horn1g", 88, 97);
      this.setTextureOffset("head.horn1a", 0, 94);
      this.setTextureOffset("head.horn1b", 20, 96);
      this.setTextureOffset("head.horn1c", 34, 95);
      this.setTextureOffset("head.horn1d", 46, 98);
      this.setTextureOffset("head.horn1e", 58, 95);
      this.setTextureOffset("head.horn1f", 76, 95);
      this.setTextureOffset("head.horn1g", 88, 97);
      this.frontbody = new ModelRenderer(this, 0, 0);
      this.frontbody.addBox(-9.0F, -7.5F, -15.0F, 18, 15, 15);
      this.frontbody.setRotationPoint(0.0F, -1.0F, 2.0F);
      this.rearbody = new ModelRenderer(this, 0, 30);
      this.rearbody.addBox(-9.0F, -7.5F, 0.0F, 18, 15, 15);
      this.rearbody.setRotationPoint(0.0F, -1.0F, 4.0F);
      this.leg1 = new ModelRenderer(this, 66, 0);
      this.leg1.addBox(-3.0F, 10.0F, -3.0F, 6, 12, 6);
      this.leg1.setRotationPoint(-6.0F, 2.0F, 13.0F);
      this.haunch1 = new ModelRenderer(this, 90, 0);
      this.haunch1.addBox(-3.5F, 0.0F, -6.0F, 7, 10, 10);
      this.haunch1.setRotationPoint(-6.0F, 2.0F, 13.0F);
      this.leg2 = new ModelRenderer(this, 66, 0);
      this.leg2.addBox(-3.0F, 10.0F, -3.0F, 6, 12, 6);
      this.leg2.setRotationPoint(6.0F, 2.0F, 13.0F);
      this.haunch2 = new ModelRenderer(this, 90, 0);
      this.haunch2.addBox(-3.5F, 0.0F, -6.0F, 7, 10, 10);
      this.haunch2.setRotationPoint(6.0F, 2.0F, 13.0F);
      this.leg3 = new ModelRenderer(this, 66, 18);
      this.leg3.addBox(-3.0F, 10.0F, -3.0F, 6, 13, 6);
      this.leg3.setRotationPoint(-6.0F, 1.0F, -8.0F);
      this.haunch3 = new ModelRenderer(this, 90, 20);
      this.haunch3.addBox(-3.5F, 0.0F, -4.0F, 7, 10, 7);
      this.haunch3.setRotationPoint(-6.0F, 1.0F, -8.0F);
      this.leg4 = new ModelRenderer(this, 66, 18);
      this.leg4.addBox(-3.0F, 10.0F, -3.0F, 6, 13, 6);
      this.leg4.setRotationPoint(6.0F, 1.0F, -8.0F);
      this.haunch4 = new ModelRenderer(this, 90, 20);
      this.haunch4.addBox(-3.5F, 0.0F, -4.0F, 7, 10, 7);
      this.haunch4.setRotationPoint(6.0F, 1.0F, -8.0F);
      this.neck = new ModelRenderer(this, 66, 37);
      this.neck.addBox(-5.5F, -8.0F, -8.0F, 11, 14, 12);
      this.neck.setRotationPoint(0.0F, -8.0F, -7.0F);
      this.setRotation(this.neck, 0.2617994F, 0.0F, 0.0F);
      this.head = new ModelRenderer(this, "head");
      this.head.setRotationPoint(0.0F, -13.0F, -5.0F);
      this.head.addBox("head", -6.0F, -4.5F, -15.0F, 12, 9, 15);
      this.head.addBox("horn1a", 5.0F, -9.0F, -7.0F, 4, 4, 6);
      this.head.addBox("horn1b", 7.0F, -8.0F, -2.0F, 3, 4, 4);
      this.head.addBox("horn1c", 8.0F, -6.0F, 0.0F, 3, 6, 3);
      this.head.addBox("horn1d", 9.5F, -2.0F, -2.0F, 3, 3, 3);
      this.head.addBox("horn1e", 11.0F, 0.0F, -7.0F, 3, 3, 6);
      this.head.addBox("horn1f", 12.0F, -4.0F, -9.0F, 3, 6, 3);
      this.head.addBox("horn1g", 13.0F, -6.0F, -7.0F, 3, 3, 4);
      this.head.addBox("horn1a", -9.0F, -9.0F, -7.0F, 4, 4, 6);
      this.head.addBox("horn1b", -10.0F, -8.0F, -2.0F, 3, 4, 4);
      this.head.addBox("horn1c", -11.0F, -6.0F, 0.0F, 3, 6, 3);
      this.head.addBox("horn1d", -12.5F, -2.0F, -2.0F, 3, 3, 3);
      this.head.addBox("horn1e", -14.0F, 0.0F, -7.0F, 3, 3, 6);
      this.head.addBox("horn1f", -15.0F, -4.0F, -9.0F, 3, 6, 3);
      this.head.addBox("horn1g", -16.0F, -6.0F, -7.0F, 3, 3, 4);
      this.nose = new ModelRenderer(this, 54, 73);
      this.nose.addBox(-5.5F, -5.0F, -13.0F, 11, 9, 12);
      this.nose.setRotationPoint(0.0F, -7.0F, -1.0F);
      this.nose.setTextureSize(128, 128);
      this.setRotation(this.nose, 0.5235988F, 0.0F, 0.0F);
      this.head.addChild(this.nose);
      this.segments = new ModelRenderer[16];
      this.segmentEnabled = new boolean[16];

      for(int i = 0; i < 16; ++i) {
         this.segments[i] = new ModelRenderer(this, 0, 104);
         this.segments[i].addBox(-9.0F, -7.5F, 0.0F, 18, 15, 2);
         this.segments[i].setRotationPoint(0.0F, -1.0F, 2.0F);
         this.segmentEnabled[i] = false;
      }

   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5);
      this.frontbody.render(f5);
      this.rearbody.render(f5);
      this.leg1.render(f5);
      this.haunch1.render(f5);
      this.leg2.render(f5);
      this.haunch2.render(f5);
      this.leg3.render(f5);
      this.haunch3.render(f5);
      this.leg4.render(f5);
      this.haunch4.render(f5);
      this.neck.render(f5);
      this.head.render(f5);

      for(int i = 0; i < 16; ++i) {
         if(this.segmentEnabled[i]) {
            float var4 = 1.0F;
            GL11.glColor3f(var4 * EntitySheep.fleeceColorTable[i][0], var4 * EntitySheep.fleeceColorTable[i][1], var4 * EntitySheep.fleeceColorTable[i][2]);
            this.segments[i].render(f5);
         }
      }

      GL11.glColor3f(1.0F, 1.0F, 1.0F);
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6) {
      this.head.rotateAngleX = par5 / 57.295776F;
      this.head.rotateAngleY = par4 / 57.295776F;
      this.neck.rotateAngleY = this.head.rotateAngleY;
      this.leg1.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2 * 0.5F;
      this.leg2.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2 * 0.5F;
      this.leg3.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2 * 0.5F;
      this.leg4.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2 * 0.5F;
      this.haunch1.rotateAngleX = this.leg1.rotateAngleX;
      this.haunch2.rotateAngleX = this.leg2.rotateAngleX;
      this.haunch3.rotateAngleX = this.leg3.rotateAngleX;
      this.haunch4.rotateAngleX = this.leg4.rotateAngleX;
   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float partialTick) {
      EntityTFQuestRam ram = (EntityTFQuestRam)par1EntityLiving;
      int count = ram.countColorsSet();
      this.rearbody.rotationPointZ = (float)(2 + 2 * count);
      this.leg1.rotationPointZ = (float)(11 + 2 * count);
      this.leg2.rotationPointZ = (float)(11 + 2 * count);
      this.haunch1.rotationPointZ = (float)(11 + 2 * count);
      this.haunch2.rotationPointZ = (float)(11 + 2 * count);
      int segmentOffset = 2;
      int[] var8 = this.colorOrder;
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         int color = var8[var10];
         if(ram.isColorPresent(color)) {
            this.segmentEnabled[color] = true;
            this.segments[color].rotationPointZ = (float)segmentOffset;
            segmentOffset += 2;
         } else {
            this.segmentEnabled[color] = false;
         }
      }

   }
}

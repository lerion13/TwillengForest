package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFYeti;

public class ModelTFYeti extends ModelBiped {

   public ModelRenderer mouth;
   public ModelRenderer leftEye;
   public ModelRenderer rightEye;
   public ModelRenderer angryLeftEye;
   public ModelRenderer angryRightEye;


   public ModelTFYeti() {
      super.textureWidth = 128;
      super.textureHeight = 64;
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-4.0F, -8.0F, -4.0F, 0, 0, 0);
      super.bipedHeadwear = new ModelRenderer(this, 32, 0);
      super.bipedHeadwear.addBox(-4.0F, -8.0F, -4.0F, 0, 0, 0);
      super.bipedBody = new ModelRenderer(this, 32, 0);
      super.bipedBody.addBox(-10.0F, 0.0F, -6.0F, 20, 26, 12);
      super.bipedBody.setRotationPoint(0.0F, -14.0F, 0.0F);
      this.mouth = new ModelRenderer(this, 96, 6);
      this.mouth.addBox(-7.0F, -5.0F, -0.5F, 14, 10, 1);
      this.mouth.setRotationPoint(0.0F, 12.0F, -6.0F);
      super.bipedBody.addChild(this.mouth);
      this.rightEye = new ModelRenderer(this, 96, 0);
      this.rightEye.addBox(-2.5F, -2.5F, -0.5F, 5, 5, 1);
      this.rightEye.setRotationPoint(-5.5F, 4.5F, -6.0F);
      super.bipedBody.addChild(this.rightEye);
      this.leftEye = new ModelRenderer(this, 96, 0);
      this.leftEye.addBox(-2.5F, -2.5F, -0.5F, 5, 5, 1);
      this.leftEye.setRotationPoint(5.5F, 4.5F, -6.0F);
      super.bipedBody.addChild(this.leftEye);
      this.angryRightEye = new ModelRenderer(this, 109, 0);
      this.angryRightEye.addBox(-2.5F, -2.5F, -0.5F, 5, 5, 1);
      this.angryRightEye.setRotationPoint(5.5F, 4.5F, -6.0F);
      super.bipedBody.addChild(this.angryRightEye);
      this.angryLeftEye = new ModelRenderer(this, 109, 0);
      this.angryLeftEye.addBox(-2.5F, -2.5F, -0.5F, 5, 5, 1);
      this.angryLeftEye.setRotationPoint(-5.5F, 4.5F, -6.0F);
      super.bipedBody.addChild(this.angryLeftEye);
      super.bipedRightArm = new ModelRenderer(this, 0, 0);
      super.bipedRightArm.addBox(-5.0F, -2.0F, -3.0F, 6, 16, 6);
      super.bipedRightArm.setRotationPoint(-11.0F, -4.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 0, 0);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -3.0F, 6, 16, 6);
      super.bipedLeftArm.setRotationPoint(11.0F, -4.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 22);
      super.bipedRightLeg.addBox(-4.0F, 0.0F, -4.0F, 8, 12, 8);
      super.bipedRightLeg.setRotationPoint(-6.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 22);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-4.0F, 0.0F, -4.0F, 8, 12, 8);
      super.bipedLeftLeg.setRotationPoint(6.0F, 12.0F, 0.0F);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      EntityTFYeti yeti = (EntityTFYeti)par7Entity;
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      if(par7Entity.riddenByEntity != null) {
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      }

      if(super.heldItemLeft != 0) {
         super.bipedLeftArm.rotateAngleX = super.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemLeft;
      }

      if(super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = super.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemRight;
      }

      super.bipedRightArm.rotateAngleY = 0.0F;
      super.bipedLeftArm.rotateAngleY = 0.0F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      if(yeti.isAngry()) {
         float f6 = MathHelper.sin(super.onGround * 3.1415927F);
         float f7 = MathHelper.sin((1.0F - (1.0F - super.onGround) * (1.0F - super.onGround)) * 3.1415927F);
         super.bipedRightArm.rotateAngleZ = 0.0F;
         super.bipedLeftArm.rotateAngleZ = 0.0F;
         super.bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
         super.bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
         super.bipedRightArm.rotateAngleX = -1.5707964F;
         super.bipedLeftArm.rotateAngleX = -1.5707964F;
         super.bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
         super.bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
         super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
         super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
         super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
         super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      }

   }

   public void setLivingAnimations(EntityLivingBase par1EntityLivingBase, float par2, float par3, float par4) {
      EntityTFYeti yeti = (EntityTFYeti)par1EntityLivingBase;
      if(yeti.isAngry()) {
         this.rightEye.isHidden = true;
         this.leftEye.isHidden = true;
         this.angryRightEye.isHidden = false;
         this.angryLeftEye.isHidden = false;
      } else {
         this.rightEye.isHidden = false;
         this.leftEye.isHidden = false;
         this.angryRightEye.isHidden = true;
         this.angryLeftEye.isHidden = true;
      }

   }
}

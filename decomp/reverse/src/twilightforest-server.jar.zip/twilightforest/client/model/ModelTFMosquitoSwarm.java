package twilightforest.client.model;

import java.util.Random;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class ModelTFMosquitoSwarm extends ModelBase {

   ModelRenderer core;
   ModelRenderer node1;
   ModelRenderer node2;
   ModelRenderer node3;
   ModelRenderer node4;
   ModelRenderer node5;
   ModelRenderer node6;
   Random rand = new Random();


   public ModelTFMosquitoSwarm() {
      this.core = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.core.addBox(-4.0F, 0.0F, -2.0F, 1, 1, 1);
      this.core.setRotationPoint(0.0F, -4.0F, 0.0F);
      this.node1 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node1.addBox(-5.5F, -5.0F, -13.0F, 1, 1, 1);
      this.node1.setRotationPoint(2.0F, -1.0F, -6.0F);
      this.core.addChild(this.node1);
      this.node2 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node2.addBox(-5.5F, -13.0F, -5.0F, 1, 1, 1);
      this.node2.setRotationPoint(0.0F, -7.0F, -1.0F);
      this.core.addChild(this.node2);
      this.node3 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node3.addBox(-13.0F, -5.0F, -5.0F, 1, 1, 1);
      this.node3.setRotationPoint(5.0F, -2.0F, -1.0F);
      this.core.addChild(this.node3);
      this.node4 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node4.addBox(-5.5F, -5.0F, -13.0F, 1, 1, 1);
      this.node4.setRotationPoint(2.0F, -1.0F, -6.0F);
      this.core.addChild(this.node4);
      this.node5 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node5.addBox(-5.5F, -13.0F, -5.0F, 1, 1, 1);
      this.node5.setRotationPoint(0.0F, -7.0F, -1.0F);
      this.core.addChild(this.node5);
      this.node6 = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
      this.node6.addBox(-13.0F, -5.0F, -5.0F, 1, 1, 1);
      this.node6.setRotationPoint(5.0F, -2.0F, -1.0F);
      this.core.addChild(this.node6);
      this.addBugsToNodes(this.node1);
      this.addBugsToNodes(this.node2);
      this.addBugsToNodes(this.node3);
      this.addBugsToNodes(this.node4);
      this.addBugsToNodes(this.node5);
      this.addBugsToNodes(this.node6);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      this.core.render(par7 / 2.0F);
   }

   public void addBugsToNodes(ModelRenderer node) {
      byte bugs = 16;

      for(int i = 0; i < bugs; ++i) {
         Vec3 vec = Vec3.createVectorHelper(11.0D, 0.0D, 0.0D);
         float rotateY = (float)i * (360.0F / (float)bugs) * 3.141593F / 180.0F;
         vec.rotateAroundY(rotateY);
         ModelRenderer bug = new ModelRenderer(this, this.rand.nextInt(28), this.rand.nextInt(28));
         float bugX = (this.rand.nextFloat() - this.rand.nextFloat()) * 4.0F;
         float bugY = (this.rand.nextFloat() - this.rand.nextFloat()) * 4.0F;
         float bugZ = (this.rand.nextFloat() - this.rand.nextFloat()) * 4.0F;
         bug.addBox(bugX, bugY, bugZ, 1, 1, 1);
         bug.setRotationPoint((float)vec.xCoord, (float)vec.yCoord, (float)vec.zCoord);
         bug.rotateAngleY = rotateY;
         node.addChild(bug);
      }

   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float time) {
      this.core.rotateAngleY = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
      this.core.rotateAngleX = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.core.rotateAngleZ = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node1.rotateAngleY = ((float)par1EntityLiving.ticksExisted + time) / 2.0F;
      this.node1.rotateAngleX = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 6.0F) / 2.0F;
      this.node1.rotateAngleZ = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node2.rotateAngleY = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 2.0F) / 3.0F;
      this.node2.rotateAngleX = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
      this.node2.rotateAngleZ = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node3.rotateAngleY = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 7.0F) / 3.0F;
      this.node3.rotateAngleX = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 4.0F) / 2.0F;
      this.node3.rotateAngleZ = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
      this.node4.rotateAngleX = ((float)par1EntityLiving.ticksExisted + time) / 2.0F;
      this.node4.rotateAngleZ = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 6.0F) / 2.0F;
      this.node4.rotateAngleY = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node5.rotateAngleZ = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 2.0F) / 3.0F;
      this.node5.rotateAngleY = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node5.rotateAngleX = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
      this.node6.rotateAngleZ = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 7.0F) / 3.0F;
      this.node6.rotateAngleX = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 4.0F) / 2.0F;
      this.node6.rotateAngleY = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelTFMinoshroom extends ModelBiped {

   ModelRenderer body;
   ModelRenderer leg1;
   ModelRenderer leg2;
   ModelRenderer leg3;
   ModelRenderer leg4;
   ModelRenderer udders;
   ModelRenderer snout;
   public ModelRenderer righthorn1;
   public ModelRenderer righthorn2;
   public ModelRenderer lefthorn1;
   public ModelRenderer lefthorn2;


   public ModelTFMinoshroom() {
      super.textureWidth = 128;
      super.textureHeight = 32;
      super.bipedHead = new ModelRenderer(this, 96, 16);
      super.bipedHead.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8);
      super.bipedHead.setRotationPoint(0.0F, -6.0F, -9.0F);
      this.body = new ModelRenderer(this, 18, 4);
      this.body.addBox(-6.0F, -10.0F, -7.0F, 12, 18, 10);
      this.body.setRotationPoint(0.0F, 5.0F, 2.0F);
      this.setRotation(this.body, 1.570796F, 0.0F, 0.0F);
      this.leg1 = new ModelRenderer(this, 0, 16);
      this.leg1.addBox(-3.0F, 0.0F, -2.0F, 4, 12, 4);
      this.leg1.setRotationPoint(-3.0F, 12.0F, 7.0F);
      this.leg2 = new ModelRenderer(this, 0, 16);
      this.leg2.addBox(-1.0F, 0.0F, -2.0F, 4, 12, 4);
      this.leg2.setRotationPoint(3.0F, 12.0F, 7.0F);
      this.leg3 = new ModelRenderer(this, 0, 16);
      this.leg3.addBox(-3.0F, 0.0F, -3.0F, 4, 12, 4);
      this.leg3.setRotationPoint(-3.0F, 12.0F, -5.0F);
      this.leg4 = new ModelRenderer(this, 0, 16);
      this.leg4.addBox(-1.0F, 0.0F, -3.0F, 4, 12, 4);
      this.leg4.setRotationPoint(3.0F, 12.0F, -5.0F);
      this.udders = new ModelRenderer(this, 52, 0);
      this.udders.addBox(-2.0F, -3.0F, 0.0F, 4, 6, 2);
      this.udders.setRotationPoint(0.0F, 14.0F, 6.0F);
      this.setRotation(this.udders, 1.570796F, 0.0F, 0.0F);
      super.bipedBody = new ModelRenderer(this, 64, 0);
      super.bipedBody.addBox(-4.0F, 0.0F, -2.5F, 8, 12, 5);
      super.bipedBody.setRotationPoint(0.0F, -6.0F, -9.0F);
      super.bipedLeftArm = new ModelRenderer(this, 90, 0);
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4);
      super.bipedLeftArm.setRotationPoint(5.0F, -4.0F, -9.0F);
      super.bipedLeftArm.mirror = true;
      super.bipedRightArm = new ModelRenderer(this, 90, 0);
      super.bipedRightArm.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4);
      super.bipedRightArm.setRotationPoint(-5.0F, -4.0F, -9.0F);
      this.righthorn1 = new ModelRenderer(this, 0, 0);
      this.righthorn1.addBox(-5.5F, -1.5F, -1.5F, 5, 3, 3);
      this.righthorn1.setRotationPoint(-2.5F, -6.5F, 0.0F);
      this.righthorn1.rotateAngleY = -0.43633235F;
      this.righthorn1.rotateAngleZ = 0.17453294F;
      this.righthorn2 = new ModelRenderer(this, 16, 0);
      this.righthorn2.addBox(-3.5F, -1.0F, -1.0F, 3, 2, 2);
      this.righthorn2.setRotationPoint(-4.5F, 0.0F, 0.0F);
      this.righthorn2.rotateAngleY = -0.2617994F;
      this.righthorn2.rotateAngleZ = 0.7853982F;
      this.righthorn1.addChild(this.righthorn2);
      this.lefthorn1 = new ModelRenderer(this, 0, 0);
      this.lefthorn1.mirror = true;
      this.lefthorn1.addBox(0.5F, -1.5F, -1.5F, 5, 3, 3);
      this.lefthorn1.setRotationPoint(2.5F, -6.5F, 0.0F);
      this.lefthorn1.rotateAngleY = 0.43633235F;
      this.lefthorn1.rotateAngleZ = -0.17453294F;
      this.lefthorn2 = new ModelRenderer(this, 16, 0);
      this.lefthorn2.addBox(0.5F, -1.0F, -1.0F, 3, 2, 2);
      this.lefthorn2.setRotationPoint(4.5F, 0.0F, 0.0F);
      this.lefthorn2.rotateAngleY = 0.2617994F;
      this.lefthorn2.rotateAngleZ = -0.7853982F;
      this.lefthorn1.addChild(this.lefthorn2);
      super.bipedHead.addChild(this.righthorn1);
      super.bipedHead.addChild(this.lefthorn1);
      this.snout = new ModelRenderer(this, 105, 28);
      this.snout.addBox(-2.0F, -1.0F, -1.0F, 4, 3, 1);
      this.snout.setRotationPoint(0.0F, -2.0F, -4.0F);
      super.bipedHead.addChild(this.snout);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      super.bipedHead.render(f5);
      this.body.render(f5);
      this.leg1.render(f5);
      this.leg2.render(f5);
      this.leg3.render(f5);
      this.leg4.render(f5);
      this.udders.render(f5);
      super.bipedBody.render(f5);
      super.bipedLeftArm.render(f5);
      super.bipedRightArm.render(f5);
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity entity) {
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      if(super.heldItemLeft != 0) {
         super.bipedLeftArm.rotateAngleX = super.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemLeft;
      }

      if(super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = super.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemRight;
      }

      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      if(super.aimedBow) {
         float var7 = 0.0F;
         float var8 = 0.0F;
         super.bipedRightArm.rotateAngleZ = 0.0F;
         super.bipedLeftArm.rotateAngleZ = 0.0F;
         super.bipedRightArm.rotateAngleY = -(0.1F - var7 * 0.6F) + super.bipedHead.rotateAngleY;
         super.bipedLeftArm.rotateAngleY = 0.1F - var7 * 0.6F + super.bipedHead.rotateAngleY + 0.4F;
         super.bipedRightArm.rotateAngleX = -1.5707964F + super.bipedHead.rotateAngleX;
         super.bipedLeftArm.rotateAngleX = -1.5707964F + super.bipedHead.rotateAngleX;
         super.bipedRightArm.rotateAngleX -= var7 * 1.2F - var8 * 0.4F;
         super.bipedLeftArm.rotateAngleX -= var7 * 1.2F - var8 * 0.4F;
         super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
         super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
         super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
         super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      }

      this.body.rotateAngleX = 1.5707964F;
      this.leg1.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      this.leg2.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      this.leg3.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      this.leg4.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
   }
}

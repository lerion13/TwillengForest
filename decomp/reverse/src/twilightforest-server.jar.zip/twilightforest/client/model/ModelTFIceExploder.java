package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class ModelTFIceExploder extends ModelBiped {

   public ModelRenderer[] spikes = new ModelRenderer[16];


   public ModelTFIceExploder() {
      super.textureWidth = 32;
      super.textureHeight = 32;
      float par1 = 0.0F;
      float par2 = 0.0F;
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-4.0F, 0.0F, -4.0F, 8, 8, 8, par1);
      super.bipedHead.setRotationPoint(0.0F, 0.0F + par2, 0.0F);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
      super.bipedBody = new ModelRenderer(this, 0, 0);
      super.bipedRightArm = new ModelRenderer(this, 0, 0);
      super.bipedLeftArm = new ModelRenderer(this, 0, 0);
      super.bipedRightLeg = new ModelRenderer(this, 0, 0);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 0);

      for(int i = 0; i < this.spikes.length; ++i) {
         this.spikes[i] = new ModelRenderer(this, 0, 16);
         int spikeLength = i % 2 == 0?6:8;
         this.spikes[i].addBox(-1.0F, 6.0F, -1.0F, 2, spikeLength, 2, par1);
         this.spikes[i].setRotationPoint(0.0F, 4.0F + par2, 0.0F);
         ModelRenderer cube = new ModelRenderer(this, 8, 16);
         cube.addBox(-1.5F, -1.5F, -1.5F, 3, 3, 3);
         cube.setRotationPoint(0.0F, 8.0F, 0.0F);
         cube.rotateAngleZ = 0.7853982F;
         this.spikes[i].addChild(cube);
      }

   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      super.bipedHead.render(f5);

      for(int i = 0; i < this.spikes.length; ++i) {
         if(entity.isEntityAlive()) {
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.6F);
         }

         this.spikes[i].render(f5);
         GL11.glDisable(3042);
      }

   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float time) {
      for(int i = 0; i < this.spikes.length; ++i) {
         this.spikes[i].rotateAngleY = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
         this.spikes[i].rotateAngleX = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
         this.spikes[i].rotateAngleZ = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / 5.0F) / 4.0F;
         this.spikes[i].rotateAngleX += (float)(i * 5);
         this.spikes[i].rotateAngleY += (float)i * 2.5F;
         this.spikes[i].rotateAngleZ += (float)(i * 3);
         this.spikes[i].rotationPointX = MathHelper.cos(((float)par1EntityLiving.ticksExisted + time) / (float)i) * 3.0F;
         this.spikes[i].rotationPointY = 5.0F + MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / (float)i) * 3.0F;
         this.spikes[i].rotationPointZ = MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / (float)i) * 3.0F;
         ((ModelRenderer)this.spikes[i].childModels.get(0)).rotationPointY = 10.0F + MathHelper.sin(((float)(i + par1EntityLiving.ticksExisted) + time) / (float)i) * 3.0F;
      }

   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.entity.boss.EntityTFYetiAlpha;

public class ModelTFYetiAlpha extends ModelBiped {

   public ModelRenderer mouth;
   public ModelRenderer leftEye;
   public ModelRenderer rightEye;


   public ModelTFYetiAlpha() {
      super.textureWidth = 256;
      super.textureHeight = 128;
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-4.0F, -8.0F, -4.0F, 0, 0, 0);
      super.bipedHeadwear = new ModelRenderer(this, 32, 0);
      super.bipedHeadwear.addBox(-4.0F, -8.0F, -4.0F, 0, 0, 0);
      super.bipedBody = new ModelRenderer(this, 80, 0);
      super.bipedBody.addBox(-24.0F, -60.0F, -18.0F, 48, 72, 36);
      super.bipedBody.setRotationPoint(0.0F, -6.0F, 0.0F);
      this.mouth = new ModelRenderer(this, 121, 50);
      this.mouth.addBox(-17.0F, -7.0F, -1.5F, 34, 29, 2);
      this.mouth.setRotationPoint(0.0F, -37.0F, -18.0F);
      super.bipedBody.addChild(this.mouth);
      this.rightEye = new ModelRenderer(this, 64, 0);
      this.rightEye.addBox(-6.0F, -6.0F, -1.5F, 12, 12, 2);
      this.rightEye.setRotationPoint(-14.0F, -50.0F, -18.0F);
      super.bipedBody.addChild(this.rightEye);
      this.leftEye = new ModelRenderer(this, 64, 0);
      this.leftEye.addBox(-6.0F, -6.0F, -1.5F, 12, 12, 2);
      this.leftEye.setRotationPoint(14.0F, -50.0F, -18.0F);
      super.bipedBody.addChild(this.leftEye);
      super.bipedRightArm = new ModelRenderer(this, 0, 0);
      super.bipedRightArm.addBox(-15.0F, -6.0F, -8.0F, 16, 48, 16);
      super.bipedRightArm.setRotationPoint(-25.0F, -26.0F, 0.0F);
      super.bipedBody.addChild(super.bipedRightArm);
      super.bipedLeftArm = new ModelRenderer(this, 0, 0);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -6.0F, -8.0F, 16, 48, 16);
      super.bipedLeftArm.setRotationPoint(25.0F, -26.0F, 0.0F);
      super.bipedBody.addChild(super.bipedLeftArm);
      super.bipedRightLeg = new ModelRenderer(this, 0, 66);
      super.bipedRightLeg.addBox(-10.0F, 0.0F, -10.0F, 20, 20, 20);
      super.bipedRightLeg.setRotationPoint(-13.5F, 4.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 66);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-10.0F, 0.0F, -10.0F, 20, 20, 20);
      super.bipedLeftLeg.setRotationPoint(13.5F, 4.0F, 0.0F);
      this.addPairHorns(-58.0F, 35.0F);
      this.addPairHorns(-46.0F, 15.0F);
      this.addPairHorns(-36.0F, -5.0F);
   }

   private void addPairHorns(float height, float zangle) {
      ModelRenderer horn1a = new ModelRenderer(this, 0, 108);
      horn1a.addBox(-9.0F, -5.0F, -5.0F, 10, 10, 10);
      horn1a.setRotationPoint(-24.0F, height, -8.0F);
      horn1a.rotateAngleY = -0.5235988F;
      horn1a.rotateAngleZ = zangle / 57.295776F;
      super.bipedBody.addChild(horn1a);
      ModelRenderer horn1b = new ModelRenderer(this, 40, 108);
      horn1b.addBox(-14.0F, -4.0F, -4.0F, 18, 8, 8);
      horn1b.setRotationPoint(-8.0F, 0.0F, 0.0F);
      horn1b.rotateAngleY = -0.34906587F;
      horn1b.rotateAngleZ = zangle / 57.295776F;
      horn1a.addChild(horn1b);
      ModelRenderer horn2a = new ModelRenderer(this, 0, 108);
      horn2a.addBox(-1.0F, -5.0F, -5.0F, 10, 10, 10);
      horn2a.setRotationPoint(24.0F, height, 0.0F);
      horn2a.rotateAngleY = 0.5235988F;
      horn2a.rotateAngleZ = -zangle / 57.295776F;
      super.bipedBody.addChild(horn2a);
      ModelRenderer horn2b = new ModelRenderer(this, 40, 108);
      horn2b.addBox(-2.0F, -4.0F, -4.0F, 18, 8, 8);
      horn2b.setRotationPoint(8.0F, 0.0F, 0.0F);
      horn2b.rotateAngleY = 0.34906587F;
      horn2b.rotateAngleZ = -zangle / 57.295776F;
      horn2a.addChild(horn2b);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      this.setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
      super.bipedBody.render(par7);
      super.bipedRightLeg.render(par7);
      super.bipedLeftLeg.render(par7);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      EntityTFYetiAlpha yeti = (EntityTFYetiAlpha)par7Entity;
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedBody.rotateAngleX = par5 / 57.295776F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      float f6 = MathHelper.sin(super.onGround * 3.1415927F);
      float f7 = MathHelper.sin((1.0F - (1.0F - super.onGround) * (1.0F - super.onGround)) * 3.1415927F);
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightArm.rotateAngleY = -(0.1F - f6 * 0.6F);
      super.bipedLeftArm.rotateAngleY = 0.1F - f6 * 0.6F;
      super.bipedRightArm.rotateAngleX = -1.5707964F;
      super.bipedLeftArm.rotateAngleX = -1.5707964F;
      super.bipedRightArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
      super.bipedLeftArm.rotateAngleX -= f6 * 1.2F - f7 * 0.4F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedBody.rotationPointY = -6.0F;
      super.bipedRightLeg.rotationPointY = 4.0F;
      super.bipedLeftLeg.rotationPointY = 4.0F;
      if(yeti.isTired()) {
         super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
         super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
         super.bipedRightArm.rotateAngleZ = 0.0F;
         super.bipedLeftArm.rotateAngleZ = 0.0F;
         super.bipedRightArm.rotateAngleX += -0.62831855F;
         super.bipedLeftArm.rotateAngleX += -0.62831855F;
         super.bipedRightLeg.rotateAngleX = -1.2566371F;
         super.bipedLeftLeg.rotateAngleX = -1.2566371F;
         super.bipedRightLeg.rotateAngleY = 0.31415927F;
         super.bipedLeftLeg.rotateAngleY = -0.31415927F;
         super.bipedBody.rotationPointY = 6.0F;
         super.bipedRightLeg.rotationPointY = 12.0F;
         super.bipedLeftLeg.rotationPointY = 12.0F;
      }

      if(yeti.isRampaging()) {
         super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.66F + 3.1415927F) * 2.0F * par2 * 0.5F;
         super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.66F) * 2.0F * par2 * 0.5F;
         super.bipedRightArm.rotateAngleY += MathHelper.cos(par1 * 0.25F) * 0.5F + 0.5F;
         super.bipedLeftArm.rotateAngleY -= MathHelper.cos(par1 * 0.25F) * 0.5F + 0.5F;
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.9269908169872414D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.9269908169872414D);
         super.bipedRightArm.rotateAngleZ = 0.0F;
         super.bipedLeftArm.rotateAngleZ = 0.0F;
      }

      if(par7Entity.riddenByEntity != null) {
         super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
         super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      }

   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFGoblinKnightUpper;

public class ModelTFGoblinKnightUpper extends ModelBiped {

   public ModelRenderer breastplate;
   public ModelRenderer helmet;
   public ModelRenderer righthorn1;
   public ModelRenderer righthorn2;
   public ModelRenderer lefthorn1;
   public ModelRenderer lefthorn2;
   public ModelRenderer shield;
   public ModelRenderer spear;


   public ModelTFGoblinKnightUpper() {
      super.heldItemLeft = 0;
      super.heldItemRight = 0;
      super.isSneak = false;
      super.aimedBow = false;
      super.textureWidth = 128;
      super.textureHeight = 64;
      super.bipedCloak = new ModelRenderer(this, 0, 0);
      super.bipedCloak.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1);
      super.bipedEars = new ModelRenderer(this, 24, 0);
      super.bipedEars.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1);
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedHead.setRotationPoint(0.0F, 12.0F, 0.0F);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
      super.bipedHeadwear.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedHeadwear.setRotationPoint(0.0F, 12.0F, 0.0F);
      this.helmet = new ModelRenderer(this, 0, 0);
      this.helmet.addBox(-3.5F, -11.0F, -3.5F, 7, 11, 7);
      this.helmet.rotateAngleY = 0.7853982F;
      this.righthorn1 = new ModelRenderer(this, 28, 0);
      this.righthorn1.addBox(-6.0F, -1.5F, -1.5F, 7, 3, 3);
      this.righthorn1.setRotationPoint(-3.5F, -9.0F, 0.0F);
      this.righthorn1.rotateAngleY = 0.2617994F;
      this.righthorn1.rotateAngleZ = 0.17453294F;
      this.righthorn2 = new ModelRenderer(this, 28, 6);
      this.righthorn2.addBox(-3.0F, -1.0F, -1.0F, 3, 2, 2);
      this.righthorn2.setRotationPoint(-5.5F, 0.0F, 0.0F);
      this.righthorn2.rotateAngleZ = 0.17453294F;
      this.righthorn1.addChild(this.righthorn2);
      this.lefthorn1 = new ModelRenderer(this, 28, 0);
      this.lefthorn1.mirror = true;
      this.lefthorn1.addBox(-1.0F, -1.5F, -1.5F, 7, 3, 3);
      this.lefthorn1.setRotationPoint(3.5F, -9.0F, 0.0F);
      this.lefthorn1.rotateAngleY = -0.2617994F;
      this.lefthorn1.rotateAngleZ = -0.17453294F;
      this.lefthorn2 = new ModelRenderer(this, 28, 6);
      this.lefthorn2.addBox(0.0F, -1.0F, -1.0F, 3, 2, 2);
      this.lefthorn2.setRotationPoint(5.5F, 0.0F, 0.0F);
      this.lefthorn2.rotateAngleZ = -0.17453294F;
      this.lefthorn1.addChild(this.lefthorn2);
      super.bipedHeadwear.addChild(this.helmet);
      super.bipedHeadwear.addChild(this.righthorn1);
      super.bipedHeadwear.addChild(this.lefthorn1);
      super.bipedBody = new ModelRenderer(this, 0, 18);
      super.bipedBody.setRotationPoint(0.0F, 12.0F, 0.0F);
      super.bipedBody.addBox(-5.5F, 0.0F, -2.0F, 11, 8, 4);
      super.bipedBody.setTextureOffset(30, 24).addBox(-6.5F, 0.0F, -2.0F, 1, 4, 4);
      super.bipedBody.setTextureOffset(30, 24).addBox(5.5F, 0.0F, -2.0F, 1, 4, 4);
      super.bipedRightArm = new ModelRenderer(this, 44, 16);
      super.bipedRightArm.addBox(-4.0F, -2.0F, -2.0F, 4, 12, 4);
      super.bipedRightArm.setRotationPoint(-6.5F, 14.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 44, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(0.0F, -2.0F, -2.0F, 4, 12, 4);
      super.bipedLeftArm.setRotationPoint(6.5F, 14.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 30, 16);
      super.bipedRightLeg.addBox(-1.5F, 0.0F, -2.0F, 3, 4, 4);
      super.bipedRightLeg.setRotationPoint(-4.0F, 20.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 30, 16);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-1.5F, 0.0F, -2.0F, 3, 4, 4);
      super.bipedLeftLeg.setRotationPoint(4.0F, 20.0F, 0.0F);
      this.shield = new ModelRenderer(this, 63, 36);
      this.shield.addBox(-6.0F, -6.0F, -2.0F, 12, 20, 2);
      this.shield.setRotationPoint(0.0F, 12.0F, 0.0F);
      this.shield.rotateAngleX = 1.5707964F;
      super.bipedLeftArm.addChild(this.shield);
      this.spear = new ModelRenderer(this, 108, 0);
      this.spear.addBox(-1.0F, -19.0F, -1.0F, 2, 40, 2);
      this.spear.setRotationPoint(-2.0F, 8.5F, 0.0F);
      this.spear.rotateAngleX = 1.5707964F;
      super.bipedRightArm.addChild(this.spear);
      this.breastplate = new ModelRenderer(this, 64, 0);
      this.breastplate.addBox(-6.5F, 0.0F, -3.0F, 13, 12, 6);
      this.breastplate.setRotationPoint(0.0F, 11.5F, 0.0F);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      this.shield.isHidden = !((EntityTFGoblinKnightUpper)par1Entity).hasShield();
      super.render(par1Entity, par2, par3, par4, par5, par6, par7);
      if(((EntityTFGoblinKnightUpper)par1Entity).hasArmor()) {
         this.renderBreastplate(par7);
      }

   }

   public void renderBreastplate(float par1) {
      this.breastplate.render(par1);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      EntityTFGoblinKnightUpper upperKnight = (EntityTFGoblinKnightUpper)par7Entity;
      boolean hasShield = upperKnight.hasShield();
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHead.rotateAngleZ = 0.0F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedHeadwear.rotateAngleZ = super.bipedHead.rotateAngleZ;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      float leftConstraint = hasShield?0.2F:par2;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * leftConstraint * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
      super.bipedLeftLeg.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 1.4F * par2;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      if(super.isRiding) {
         super.bipedRightArm.rotateAngleX += -0.62831855F;
         super.bipedLeftArm.rotateAngleX += -0.62831855F;
         super.bipedRightLeg.rotateAngleX = 0.0F;
         super.bipedLeftLeg.rotateAngleX = 0.0F;
      }

      if(super.heldItemLeft != 0) {
         super.bipedLeftArm.rotateAngleX = super.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemLeft;
      }

      super.heldItemRight = 1;
      if(super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = super.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemRight;
      }

      super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX - 2.0734511513692637D);
      if(upperKnight.heavySpearTimer > 0) {
         super.bipedRightArm.rotateAngleX -= this.getArmRotationDuringSwing((float)(60 - upperKnight.heavySpearTimer) + par6) / 57.295776F;
      }

      super.bipedRightArm.rotateAngleY = 0.0F;
      super.bipedLeftArm.rotateAngleY = 0.0F;
      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleZ = -super.bipedLeftArm.rotateAngleZ;
      this.shield.rotateAngleX = (float)(6.283185307179586D - (double)super.bipedLeftArm.rotateAngleX);
   }

   private float getArmRotationDuringSwing(float attackTime) {
      return attackTime <= 10.0F?attackTime * 1.0F:(attackTime > 10.0F && attackTime <= 30.0F?10.0F:(attackTime > 30.0F && attackTime <= 33.0F?(attackTime - 30.0F) * -8.0F + 10.0F:(attackTime > 33.0F && attackTime <= 50.0F?-15.0F:(attackTime > 50.0F && attackTime <= 60.0F?(10.0F - (attackTime - 50.0F)) * -1.5F:0.0F))));
   }
}

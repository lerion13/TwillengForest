package twilightforest.client.model;

import net.minecraft.client.model.ModelQuadruped;
import net.minecraft.client.model.ModelRenderer;

public class ModelTFBoar extends ModelQuadruped {

   public ModelTFBoar() {
      super(6, 0.0F);
      super.field_78145_g = 4.0F;
      super.head = new ModelRenderer(this, 0, 0);
      super.head.addBox(-4.0F, -2.0F, -6.0F, 8, 7, 6, 0.0F);
      super.head.setRotationPoint(0.0F, 12.0F, -6.0F);
      super.body = new ModelRenderer(this, 28, 10);
      super.body.addBox(-5.0F, -8.0F, -7.0F, 10, 14, 8, 0.0F);
      super.body.setRotationPoint(0.0F, 11.0F, 2.0F);
      super.body.rotateAngleX = 1.570796F;
      super.leg1 = new ModelRenderer(this, 0, 16);
      super.leg1.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
      super.leg1.setRotationPoint(-3.0F, 18.0F, 7.0F);
      super.leg2 = new ModelRenderer(this, 0, 16);
      super.leg2.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
      super.leg2.setRotationPoint(3.0F, 18.0F, 7.0F);
      super.leg3 = new ModelRenderer(this, 0, 16);
      super.leg3.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
      super.leg3.setRotationPoint(-3.0F, 18.0F, -5.0F);
      super.leg4 = new ModelRenderer(this, 0, 16);
      super.leg4.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, 0.0F);
      super.leg4.setRotationPoint(3.0F, 18.0F, -5.0F);
      super.head.setTextureOffset(28, 0).addBox(-3.0F, 1.0F, -9.0F, 6, 4, 3, 0.0F);
      super.head.setTextureOffset(17, 17).addBox(3.0F, 2.0F, -9.0F, 1, 2, 1, 0.0F);
      super.head.setTextureOffset(17, 17).addBox(-4.0F, 2.0F, -9.0F, 1, 2, 1, 0.0F);
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFBlockGoblin extends ModelBiped {

   public ModelRenderer helmet;
   ModelRenderer block;
   ModelRenderer[] spikes = new ModelRenderer[27];


   public ModelTFBlockGoblin() {
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0, 0.0F);
      super.bipedHead.setRotationPoint(0.0F, 11.0F, 0.0F);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
      super.bipedHeadwear.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0, 0.5F);
      super.bipedHeadwear.setRotationPoint(0.0F, 11.0F, 0.0F);
      this.helmet = new ModelRenderer(this, 24, 0);
      this.helmet.addBox(-2.5F, -9.0F, -2.5F, 5, 9, 5);
      this.helmet.rotateAngleY = 0.7853982F;
      super.bipedHeadwear.addChild(this.helmet);
      super.bipedBody = new ModelRenderer(this, 0, 21);
      super.bipedBody.addBox(-3.5F, 0.0F, -2.0F, 7, 7, 4, 0.0F);
      super.bipedBody.setRotationPoint(0.0F, 11.0F, 0.0F);
      super.bipedRightArm = new ModelRenderer(this, 52, 0);
      super.bipedRightArm.addBox(-3.0F, -1.0F, -2.0F, 3, 12, 3, 0.0F);
      super.bipedRightArm.setRotationPoint(-3.5F, 12.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 52, 0);
      super.bipedLeftArm.addBox(0.0F, -1.0F, -1.5F, 3, 12, 3, 0.0F);
      super.bipedLeftArm.setRotationPoint(3.5F, 12.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 12);
      super.bipedRightLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 6, 3, 0.0F);
      super.bipedRightLeg.setRotationPoint(-2.0F, 18.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 12);
      super.bipedLeftLeg.addBox(-1.5F, 0.0F, -1.5F, 3, 6, 3, 0.0F);
      super.bipedLeftLeg.setRotationPoint(2.0F, 18.0F, 0.0F);
      this.block = new ModelRenderer(this, 32, 16);
      this.block.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
      this.block.setRotationPoint(6.0F, 0.0F, 0.0F);

      for(int fourtyFive = 0; fourtyFive < this.spikes.length; ++fourtyFive) {
         this.spikes[fourtyFive] = new ModelRenderer(this, 56, 16);
         this.spikes[fourtyFive].addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.0F);
         this.block.addChild(this.spikes[fourtyFive]);
      }

      this.spikes[2].rotationPointX = 4.0F;
      this.spikes[3].rotationPointX = 4.0F;
      this.spikes[4].rotationPointX = 4.0F;
      this.spikes[11].rotationPointX = 4.0F;
      this.spikes[12].rotationPointX = 5.0F;
      this.spikes[13].rotationPointX = 4.0F;
      this.spikes[20].rotationPointX = 4.0F;
      this.spikes[21].rotationPointX = 4.0F;
      this.spikes[22].rotationPointX = 4.0F;
      this.spikes[6].rotationPointX = -4.0F;
      this.spikes[7].rotationPointX = -4.0F;
      this.spikes[8].rotationPointX = -4.0F;
      this.spikes[15].rotationPointX = -4.0F;
      this.spikes[16].rotationPointX = -5.0F;
      this.spikes[17].rotationPointX = -4.0F;
      this.spikes[24].rotationPointX = -4.0F;
      this.spikes[25].rotationPointX = -4.0F;
      this.spikes[26].rotationPointX = -4.0F;
      this.spikes[0].rotationPointY = -9.0F;
      this.spikes[1].rotationPointY = -8.0F;
      this.spikes[2].rotationPointY = -8.0F;
      this.spikes[3].rotationPointY = -8.0F;
      this.spikes[4].rotationPointY = -8.0F;
      this.spikes[5].rotationPointY = -8.0F;
      this.spikes[6].rotationPointY = -8.0F;
      this.spikes[7].rotationPointY = -8.0F;
      this.spikes[8].rotationPointY = -8.0F;
      this.spikes[9].rotationPointY = -4.0F;
      this.spikes[10].rotationPointY = -4.0F;
      this.spikes[11].rotationPointY = -4.0F;
      this.spikes[12].rotationPointY = -4.0F;
      this.spikes[13].rotationPointY = -4.0F;
      this.spikes[14].rotationPointY = -4.0F;
      this.spikes[15].rotationPointY = -4.0F;
      this.spikes[16].rotationPointY = -4.0F;
      this.spikes[17].rotationPointY = -4.0F;
      this.spikes[18].rotationPointY = 1.0F;
      this.spikes[1].rotationPointZ = 4.0F;
      this.spikes[2].rotationPointZ = 4.0F;
      this.spikes[8].rotationPointZ = 4.0F;
      this.spikes[10].rotationPointZ = 4.0F;
      this.spikes[11].rotationPointZ = 5.0F;
      this.spikes[17].rotationPointZ = 4.0F;
      this.spikes[19].rotationPointZ = 4.0F;
      this.spikes[20].rotationPointZ = 4.0F;
      this.spikes[26].rotationPointZ = 4.0F;
      this.spikes[4].rotationPointZ = -4.0F;
      this.spikes[5].rotationPointZ = -4.0F;
      this.spikes[6].rotationPointZ = -4.0F;
      this.spikes[13].rotationPointZ = -4.0F;
      this.spikes[14].rotationPointZ = -5.0F;
      this.spikes[15].rotationPointZ = -4.0F;
      this.spikes[22].rotationPointZ = -4.0F;
      this.spikes[23].rotationPointZ = -4.0F;
      this.spikes[24].rotationPointZ = -4.0F;
      float var2 = 0.7853982F;
      this.spikes[1].rotateAngleX = var2;
      this.spikes[5].rotateAngleX = var2;
      this.spikes[19].rotateAngleX = var2;
      this.spikes[23].rotateAngleX = var2;
      this.spikes[11].rotateAngleY = var2;
      this.spikes[13].rotateAngleY = var2;
      this.spikes[15].rotateAngleY = var2;
      this.spikes[17].rotateAngleY = var2;
      this.spikes[3].rotateAngleZ = var2;
      this.spikes[7].rotateAngleZ = var2;
      this.spikes[21].rotateAngleZ = var2;
      this.spikes[25].rotateAngleZ = var2;
      this.spikes[2].rotateAngleX = -0.95993114F;
      this.spikes[2].rotateAngleY = var2;
      this.spikes[24].rotateAngleX = -0.95993114F;
      this.spikes[24].rotateAngleY = var2;
      this.spikes[4].rotateAngleX = -0.6108653F;
      this.spikes[4].rotateAngleY = -var2;
      this.spikes[26].rotateAngleX = -0.6108653F;
      this.spikes[26].rotateAngleY = -var2;
      this.spikes[6].rotateAngleY = var2;
      this.spikes[6].rotateAngleX = -0.6108653F;
      this.spikes[20].rotateAngleY = var2;
      this.spikes[20].rotateAngleX = -0.6108653F;
      this.spikes[8].rotateAngleX = -0.95993114F;
      this.spikes[8].rotateAngleY = -var2;
      this.spikes[22].rotateAngleX = -0.95993114F;
      this.spikes[22].rotateAngleY = -var2;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
   }

   public void setRotationAngles(float f, float f1, float f2, float yaw, float pitch, float time, Entity entity) {
      super.aimedBow = false;
      super.setRotationAngles(f, f1, f2, yaw, pitch, time, entity);
      super.bipedHead.rotationPointY = 11.0F;
      super.bipedHeadwear.rotationPointY = 11.0F;
      super.bipedBody.rotationPointY = 11.0F;
      super.bipedRightLeg.rotationPointY = 18.0F;
      super.bipedLeftLeg.rotationPointY = 18.0F;
      super.bipedRightArm.setRotationPoint(-3.5F, 12.0F, 0.0F);
      super.bipedRightArm.rotateAngleX = (float)((double)super.bipedRightArm.rotateAngleX + 3.141592653589793D);
      super.bipedLeftArm.setRotationPoint(3.5F, 12.0F, 0.0F);
      super.bipedLeftArm.rotateAngleX = (float)((double)super.bipedLeftArm.rotateAngleX + 3.141592653589793D);
      float angle = f2 / 4.0F;
      float length = 0.0F;
      this.block.rotationPointX = (float)Math.sin((double)angle) * length;
      this.block.rotationPointZ = (float)(-Math.cos((double)angle)) * length;
      this.block.rotateAngleY = -angle;
   }
}

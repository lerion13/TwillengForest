package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class ModelTFYetiArmor extends ModelBiped {

   private ModelRenderer bipedLegBody;
   private ModelRenderer rightRuff;
   private ModelRenderer leftRuff;
   private ModelRenderer rightToe;
   private ModelRenderer leftToe;


   public ModelTFYetiArmor(int part, float expand) {
      super(expand);
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(-4.5F, -7.5F, -4.0F, 9, 8, 8, expand);
      super.bipedHead.setRotationPoint(0.0F, 0.0F + expand, 0.0F);
      this.addPairHorns(-8.0F, 35.0F);
      this.addPairHorns(-6.0F, 15.0F);
      this.addPairHorns(-4.0F, -5.0F);
      super.bipedRightLeg = new ModelRenderer(this, 40, 0);
      super.bipedRightLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, expand);
      super.bipedRightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 40, 0);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, expand);
      super.bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
      this.rightRuff = new ModelRenderer(this, 40, 22);
      this.rightRuff.addBox(-2.5F, 0.0F, -2.5F, 5, 2, 5, expand);
      this.rightRuff.setRotationPoint(0.0F, 6.0F, 0.0F);
      super.bipedRightLeg.addChild(this.rightRuff);
      this.leftRuff = new ModelRenderer(this, 40, 22);
      this.leftRuff.addBox(-2.5F, 0.0F, -2.5F, 5, 2, 5, expand);
      this.leftRuff.setRotationPoint(0.0F, 6.0F, 0.0F);
      super.bipedLeftLeg.addChild(this.leftRuff);
      this.rightToe = new ModelRenderer(this, 40, 17);
      this.rightToe.addBox(-2.0F, 0.0F, -1.0F, 4, 2, 1, expand);
      this.rightToe.setRotationPoint(0.0F, 10.0F, -2.0F);
      super.bipedRightLeg.addChild(this.rightToe);
      this.leftToe = new ModelRenderer(this, 40, 17);
      this.leftToe.addBox(-2.0F, 0.0F, -1.0F, 4, 2, 1, expand);
      this.leftToe.setRotationPoint(0.0F, 10.0F, -2.0F);
      super.bipedLeftLeg.addChild(this.leftToe);
      super.bipedBody = new ModelRenderer(this, 0, 0);
      super.bipedBody.addBox(-4.0F, 0.0F, -2.0F, 8, 11, 4, expand);
      super.bipedBody.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.bipedLegBody = new ModelRenderer(this, 40, 16);
      this.bipedLegBody.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, expand);
      this.bipedLegBody.setRotationPoint(0.0F, 0.0F, 0.0F);
      super.bipedRightArm = new ModelRenderer(this, 0, 16);
      super.bipedRightArm.addBox(-3.0F, -2.0F, -2.0F, 4, 10, 4, expand);
      super.bipedRightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 0, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 4, 10, 4, expand);
      super.bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      switch(part) {
      case 0:
         super.bipedHead.showModel = true;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         this.bipedLegBody.showModel = false;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 1:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = true;
         super.bipedRightArm.showModel = true;
         super.bipedLeftArm.showModel = true;
         this.bipedLegBody.showModel = false;
         super.bipedRightLeg.showModel = false;
         super.bipedLeftLeg.showModel = false;
         break;
      case 2:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         this.bipedLegBody.showModel = true;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
         this.leftRuff.showModel = false;
         this.leftToe.showModel = false;
         this.rightRuff.showModel = false;
         this.rightToe.showModel = false;
         break;
      case 3:
         super.bipedHead.showModel = false;
         super.bipedHeadwear.showModel = false;
         super.bipedBody.showModel = false;
         super.bipedRightArm.showModel = false;
         super.bipedLeftArm.showModel = false;
         this.bipedLegBody.showModel = false;
         super.bipedRightLeg.showModel = true;
         super.bipedLeftLeg.showModel = true;
         this.leftRuff.showModel = true;
         this.leftToe.showModel = true;
         this.rightRuff.showModel = true;
         this.rightToe.showModel = true;
      }

   }

   private void addPairHorns(float height, float zangle) {
      ModelRenderer horn1a = new ModelRenderer(this, 0, 19);
      horn1a.addBox(-3.0F, -1.5F, -1.5F, 3, 3, 3);
      horn1a.setRotationPoint(-4.5F, height, -1.0F);
      horn1a.rotateAngleY = -0.5235988F;
      horn1a.rotateAngleZ = zangle / 57.295776F;
      super.bipedHead.addChild(horn1a);
      ModelRenderer horn1b = new ModelRenderer(this, 0, 26);
      horn1b.addBox(-4.0F, -1.0F, -1.0F, 5, 2, 2);
      horn1b.setRotationPoint(-3.0F, 0.0F, 0.0F);
      horn1b.rotateAngleY = -0.34906587F;
      horn1b.rotateAngleZ = zangle / 57.295776F;
      horn1a.addChild(horn1b);
      ModelRenderer horn2a = new ModelRenderer(this, 0, 19);
      horn2a.addBox(0.0F, -1.5F, -1.5F, 3, 3, 3);
      horn2a.setRotationPoint(4.5F, height, -1.0F);
      horn2a.rotateAngleY = 0.5235988F;
      horn2a.rotateAngleZ = -zangle / 57.295776F;
      super.bipedHead.addChild(horn2a);
      ModelRenderer horn2b = new ModelRenderer(this, 0, 26);
      horn2b.addBox(-1.0F, -1.0F, -1.0F, 5, 2, 2);
      horn2b.setRotationPoint(3.0F, 0.0F, 0.0F);
      horn2b.rotateAngleY = 0.34906587F;
      horn2b.rotateAngleZ = -zangle / 57.295776F;
      horn2a.addChild(horn2b);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      if(par1Entity != null) {
         super.isSneak = par1Entity.isSneaking();
      }

      if(par1Entity != null && par1Entity instanceof EntityLivingBase) {
         super.heldItemRight = ((EntityLivingBase)par1Entity).getHeldItem() != null?1:0;
      }

      super.render(par1Entity, par2, par3, par4, par5, par6, par7);
      this.bipedLegBody.render(par7);
   }
}

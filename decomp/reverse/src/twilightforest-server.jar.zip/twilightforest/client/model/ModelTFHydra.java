package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.entity.boss.EntityTFHydra;
import twilightforest.entity.boss.EntityTFHydraPart;

public class ModelTFHydra extends ModelBase {

   ModelRenderer body;
   ModelRenderer leg1;
   ModelRenderer leg2;
   ModelRenderer tail1;
   ModelRenderer tail2;
   ModelRenderer tail3;
   ModelRenderer tail4;
   ModelRenderer neck1a;
   ModelRenderer neck1b;
   ModelRenderer neck1c;
   ModelRenderer neck1d;
   ModelRenderer head1;
   ModelRenderer jaw1;
   ModelRenderer frill1;
   ModelRenderer neck2a;
   ModelRenderer neck2b;
   ModelRenderer neck2c;
   ModelRenderer neck2d;
   ModelRenderer head2;
   ModelRenderer jaw2;
   ModelRenderer frill2;
   ModelRenderer neck3a;
   ModelRenderer neck3b;
   ModelRenderer neck3c;
   ModelRenderer neck3d;
   ModelRenderer head3;
   ModelRenderer jaw3;
   ModelRenderer frill3;


   public ModelTFHydra() {
      super.textureWidth = 512;
      super.textureHeight = 256;
      this.setTextureOffset("body.body", 0, 0);
      this.setTextureOffset("leg.main", 0, 136);
      this.setTextureOffset("leg.toe", 184, 200);
      this.setTextureOffset("tail.box", 128, 136);
      this.setTextureOffset("tail.fin", 128, 200);
      this.setTextureOffset("neck.box", 128, 136);
      this.setTextureOffset("neck.fin", 128, 200);
      this.setTextureOffset("head.box", 272, 0);
      this.setTextureOffset("head.upperlip", 272, 56);
      this.setTextureOffset("head.fin", 128, 200);
      this.setTextureOffset("jaw.jaw", 272, 92);
      this.setTextureOffset("frill.frill", 272, 200);
      this.body = new ModelRenderer(this, "body");
      this.body.setRotationPoint(0.0F, -12.0F, 0.0F);
      this.body.addBox("body", -48.0F, 0.0F, 0.0F, 96, 96, 40);
      this.setRotation(this.body, 1.22173F, 0.0F, 0.0F);
      this.leg1 = new ModelRenderer(this, "leg");
      this.leg1.setRotationPoint(48.0F, -24.0F, 0.0F);
      this.leg1.addBox("main", -16.0F, 0.0F, -16.0F, 32, 48, 32);
      this.leg1.addBox("toe", -20.0F, 40.0F, -20.0F, 8, 8, 8);
      this.leg1.addBox("toe", -4.0F, 40.0F, -22.0F, 8, 8, 8);
      this.leg1.addBox("toe", 12.0F, 40.0F, -20.0F, 8, 8, 8);
      this.leg2 = new ModelRenderer(this, "leg");
      this.leg2.setRotationPoint(-48.0F, -24.0F, 0.0F);
      this.leg2.mirror = true;
      this.leg2.addBox("main", -16.0F, 0.0F, -16.0F, 32, 48, 32);
      this.leg2.addBox("toe", -20.0F, 40.0F, -20.0F, 8, 8, 8);
      this.leg2.addBox("toe", -4.0F, 40.0F, -22.0F, 8, 8, 8);
      this.leg2.addBox("toe", 12.0F, 40.0F, -20.0F, 8, 8, 8);
      this.tail1 = new ModelRenderer(this, "tail");
      this.tail1.setRotationPoint(0.0F, 6.0F, 108.0F);
      this.tail1.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.tail1.addBox("fin", -2.0F, -28.0F, -11.0F, 4, 24, 24);
      this.tail2 = new ModelRenderer(this, "tail");
      this.tail2.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.tail2.addBox("fin", -2.0F, -28.0F, -11.0F, 4, 24, 24);
      this.tail2.setRotationPoint(0.0F, 7.0F, 142.0F);
      this.tail3 = new ModelRenderer(this, "tail");
      this.tail3.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.tail3.addBox("fin", -2.0F, -28.0F, -11.0F, 4, 24, 24);
      this.tail3.setRotationPoint(0.0F, 8.0F, 176.0F);
      this.tail4 = new ModelRenderer(this, "tail");
      this.tail4.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.tail4.addBox("fin", -2.0F, -28.0F, -11.0F, 4, 24, 24);
      this.tail4.setRotationPoint(0.0F, 8.0F, 210.0F);
      this.neck1a = new ModelRenderer(this, "neck");
      this.neck1a.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck1a.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck1a.setRotationPoint(0.0F, -48.0F, 16.0F);
      this.neck1b = new ModelRenderer(this, "neck");
      this.neck1b.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck1b.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck1b.setRotationPoint(0.0F, -68.0F, 0.0F);
      this.neck1c = new ModelRenderer(this, "neck");
      this.neck1c.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck1c.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck1c.setRotationPoint(0.0F, -93.0F, -14.0F);
      this.neck1d = new ModelRenderer(this, "neck");
      this.neck1d.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck1d.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck1d.setRotationPoint(0.0F, -116.0F, -37.0F);
      this.head1 = new ModelRenderer(this, "head");
      this.head1.addBox("box", -16.0F, -14.0F, -32.0F, 32, 24, 32);
      this.head1.addBox("upperlip", -15.0F, -2.0F, -56.0F, 30, 12, 24);
      this.head1.addBox("fin", -2.0F, -30.0F, -12.0F, 4, 24, 24);
      this.head1.setRotationPoint(0.0F, -128.0F, -53.0F);
      this.jaw1 = new ModelRenderer(this, "jaw");
      this.jaw1.setRotationPoint(0.0F, 10.0F, -4.0F);
      this.jaw1.addBox("jaw", -15.0F, 0.0F, -48.0F, 30, 8, 48);
      this.setRotation(this.jaw1, 0.0F, 0.0F, 0.0F);
      this.head1.addChild(this.jaw1);
      this.frill1 = new ModelRenderer(this, "frill");
      this.frill1.setRotationPoint(0.0F, 0.0F, -10.0F);
      this.frill1.addBox("frill", -24.0F, -40.0F, 0.0F, 48, 48, 4);
      this.setRotation(this.frill1, -0.5235988F, 0.0F, 0.0F);
      this.head1.addChild(this.frill1);
      this.neck2a = new ModelRenderer(this, "neck");
      this.neck2a.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck2a.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck2a.setRotationPoint(48.0F, -48.0F, 16.0F);
      this.neck2b = new ModelRenderer(this, "neck");
      this.neck2b.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck2b.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck2b.setRotationPoint(71.0F, -68.0F, 0.0F);
      this.neck2c = new ModelRenderer(this, "neck");
      this.neck2c.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck2c.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck2c.setRotationPoint(96.0F, -93.0F, -14.0F);
      this.neck2d = new ModelRenderer(this, "neck");
      this.neck2d.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck2d.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck2d.setRotationPoint(108.0F, -116.0F, -37.0F);
      this.head2 = new ModelRenderer(this, "head");
      this.head2.addBox("box", -16.0F, -14.0F, -32.0F, 32, 24, 32);
      this.head2.addBox("upperlip", -15.0F, -2.0F, -56.0F, 30, 12, 24);
      this.head2.addBox("fin", -2.0F, -30.0F, -12.0F, 4, 24, 24);
      this.head2.setRotationPoint(108.0F, -128.0F, -53.0F);
      this.jaw2 = new ModelRenderer(this, "jaw");
      this.jaw2.setRotationPoint(0.0F, 10.0F, -4.0F);
      this.jaw2.addBox("jaw", -15.0F, 0.0F, -48.0F, 30, 8, 48);
      this.setRotation(this.jaw2, 0.0F, 0.0F, 0.0F);
      this.head2.addChild(this.jaw2);
      this.frill2 = new ModelRenderer(this, "frill");
      this.frill2.setRotationPoint(0.0F, 0.0F, -10.0F);
      this.frill2.addBox("frill", -24.0F, -40.0F, 0.0F, 48, 48, 4);
      this.setRotation(this.frill2, -0.5235988F, 0.0F, 0.0F);
      this.head2.addChild(this.frill2);
      this.neck3a = new ModelRenderer(this, "neck");
      this.neck3a.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 31);
      this.neck3a.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck3a.setRotationPoint(-48.0F, -48.0F, 16.0F);
      this.neck3b = new ModelRenderer(this, "neck");
      this.neck3b.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck3b.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck3b.setRotationPoint(-71.0F, -43.0F, 0.0F);
      this.neck3c = new ModelRenderer(this, "neck");
      this.neck3c.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck3c.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck3c.setRotationPoint(-96.0F, -33.0F, -14.0F);
      this.neck3d = new ModelRenderer(this, "neck");
      this.neck3d.addBox("box", -16.0F, -16.0F, -16.0F, 32, 32, 32);
      this.neck3d.addBox("fin", -2.0F, -23.0F, 0.0F, 4, 24, 24);
      this.neck3d.setRotationPoint(-108.0F, -24.0F, -37.0F);
      this.head3 = new ModelRenderer(this, "head");
      this.head3.addBox("box", -16.0F, -14.0F, -32.0F, 32, 24, 32);
      this.head3.addBox("upperlip", -15.0F, -2.0F, -56.0F, 30, 12, 24);
      this.head3.addBox("fin", -2.0F, -30.0F, -12.0F, 4, 24, 24);
      this.head3.setRotationPoint(-108.0F, -24.0F, -53.0F);
      this.jaw3 = new ModelRenderer(this, "jaw");
      this.jaw3.setRotationPoint(0.0F, 10.0F, -4.0F);
      this.jaw3.addBox("jaw", -15.0F, 0.0F, -48.0F, 30, 8, 48);
      this.setRotation(this.jaw3, 0.125F, 0.0F, 0.0F);
      this.head3.addChild(this.jaw3);
      this.frill3 = new ModelRenderer(this, "frill");
      this.frill3.setRotationPoint(0.0F, 0.0F, -10.0F);
      this.frill3.addBox("frill", -24.0F, -40.0F, 0.0F, 48, 48, 4);
      this.setRotation(this.frill3, -0.5235988F, 0.0F, 0.0F);
      this.head3.addChild(this.frill3);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.body.render(f5);
      this.leg1.render(f5);
      this.leg2.render(f5);
      this.tail1.render(f5);
      this.tail2.render(f5);
      this.tail3.render(f5);
      this.tail4.render(f5);
   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.leg1.rotateAngleX = MathHelper.cos(f * 0.6662F) * 1.4F * f1;
      this.leg2.rotateAngleX = MathHelper.cos(f * 0.6662F + 3.141593F) * 1.4F * f1;
      this.leg1.rotateAngleY = 0.0F;
      this.leg2.rotateAngleY = 0.0F;
   }

   public float getRotationY(EntityTFHydra hydra, EntityTFHydraPart whichHead, float time) {
      float yawOffset = hydra.prevRenderYawOffset + (hydra.renderYawOffset - hydra.prevRenderYawOffset) * time;
      float yaw = whichHead.prevRotationYaw + (whichHead.rotationYaw - whichHead.prevRotationYaw) * time;
      return (yaw - yawOffset) / 57.29578F;
   }

   public float getRotationX(EntityTFHydra hydra, EntityTFHydraPart whichHead, float time) {
      return (whichHead.prevRotationPitch + (whichHead.rotationPitch - whichHead.prevRotationPitch) * time) / 57.29578F;
   }
}

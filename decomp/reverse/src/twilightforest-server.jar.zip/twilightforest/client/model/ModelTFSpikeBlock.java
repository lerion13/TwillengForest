package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFSpikeBlock extends ModelBase {

   ModelRenderer block = new ModelRenderer(this, 32, 16);
   ModelRenderer[] spikes = new ModelRenderer[27];


   public ModelTFSpikeBlock() {
      this.block.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
      this.block.setRotationPoint(0.0F, 0.0F, 0.0F);

      for(int fourtyFive = 0; fourtyFive < this.spikes.length; ++fourtyFive) {
         this.spikes[fourtyFive] = new ModelRenderer(this, 56, 16);
         this.spikes[fourtyFive].addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2, 0.0F);
         this.block.addChild(this.spikes[fourtyFive]);
      }

      this.spikes[2].rotationPointX = 4.0F;
      this.spikes[3].rotationPointX = 4.0F;
      this.spikes[4].rotationPointX = 4.0F;
      this.spikes[11].rotationPointX = 4.0F;
      this.spikes[12].rotationPointX = 5.0F;
      this.spikes[13].rotationPointX = 4.0F;
      this.spikes[20].rotationPointX = 4.0F;
      this.spikes[21].rotationPointX = 4.0F;
      this.spikes[22].rotationPointX = 4.0F;
      this.spikes[6].rotationPointX = -4.0F;
      this.spikes[7].rotationPointX = -4.0F;
      this.spikes[8].rotationPointX = -4.0F;
      this.spikes[15].rotationPointX = -4.0F;
      this.spikes[16].rotationPointX = -5.0F;
      this.spikes[17].rotationPointX = -4.0F;
      this.spikes[24].rotationPointX = -4.0F;
      this.spikes[25].rotationPointX = -4.0F;
      this.spikes[26].rotationPointX = -4.0F;
      this.spikes[0].rotationPointY = -9.0F;
      this.spikes[1].rotationPointY = -8.0F;
      this.spikes[2].rotationPointY = -8.0F;
      this.spikes[3].rotationPointY = -8.0F;
      this.spikes[4].rotationPointY = -8.0F;
      this.spikes[5].rotationPointY = -8.0F;
      this.spikes[6].rotationPointY = -8.0F;
      this.spikes[7].rotationPointY = -8.0F;
      this.spikes[8].rotationPointY = -8.0F;
      this.spikes[9].rotationPointY = -4.0F;
      this.spikes[10].rotationPointY = -4.0F;
      this.spikes[11].rotationPointY = -4.0F;
      this.spikes[12].rotationPointY = -4.0F;
      this.spikes[13].rotationPointY = -4.0F;
      this.spikes[14].rotationPointY = -4.0F;
      this.spikes[15].rotationPointY = -4.0F;
      this.spikes[16].rotationPointY = -4.0F;
      this.spikes[17].rotationPointY = -4.0F;
      this.spikes[18].rotationPointY = 1.0F;
      this.spikes[1].rotationPointZ = 4.0F;
      this.spikes[2].rotationPointZ = 4.0F;
      this.spikes[8].rotationPointZ = 4.0F;
      this.spikes[10].rotationPointZ = 4.0F;
      this.spikes[11].rotationPointZ = 5.0F;
      this.spikes[17].rotationPointZ = 4.0F;
      this.spikes[19].rotationPointZ = 4.0F;
      this.spikes[20].rotationPointZ = 4.0F;
      this.spikes[26].rotationPointZ = 4.0F;
      this.spikes[4].rotationPointZ = -4.0F;
      this.spikes[5].rotationPointZ = -4.0F;
      this.spikes[6].rotationPointZ = -4.0F;
      this.spikes[13].rotationPointZ = -4.0F;
      this.spikes[14].rotationPointZ = -5.0F;
      this.spikes[15].rotationPointZ = -4.0F;
      this.spikes[22].rotationPointZ = -4.0F;
      this.spikes[23].rotationPointZ = -4.0F;
      this.spikes[24].rotationPointZ = -4.0F;
      float var2 = 0.7853982F;
      this.spikes[1].rotateAngleX = var2;
      this.spikes[5].rotateAngleX = var2;
      this.spikes[19].rotateAngleX = var2;
      this.spikes[23].rotateAngleX = var2;
      this.spikes[11].rotateAngleY = var2;
      this.spikes[13].rotateAngleY = var2;
      this.spikes[15].rotateAngleY = var2;
      this.spikes[17].rotateAngleY = var2;
      this.spikes[3].rotateAngleZ = var2;
      this.spikes[7].rotateAngleZ = var2;
      this.spikes[21].rotateAngleZ = var2;
      this.spikes[25].rotateAngleZ = var2;
      this.spikes[2].rotateAngleX = -0.95993114F;
      this.spikes[2].rotateAngleY = var2;
      this.spikes[24].rotateAngleX = -0.95993114F;
      this.spikes[24].rotateAngleY = var2;
      this.spikes[4].rotateAngleX = -0.6108653F;
      this.spikes[4].rotateAngleY = -var2;
      this.spikes[26].rotateAngleX = -0.6108653F;
      this.spikes[26].rotateAngleY = -var2;
      this.spikes[6].rotateAngleY = var2;
      this.spikes[6].rotateAngleX = -0.6108653F;
      this.spikes[20].rotateAngleY = var2;
      this.spikes[20].rotateAngleX = -0.6108653F;
      this.spikes[8].rotateAngleX = -0.95993114F;
      this.spikes[8].rotateAngleY = -var2;
      this.spikes[22].rotateAngleX = -0.95993114F;
      this.spikes[22].rotateAngleY = -var2;
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.block.render(f5);
   }
}

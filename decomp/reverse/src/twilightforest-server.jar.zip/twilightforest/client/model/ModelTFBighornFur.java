package twilightforest.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSheep2;

public class ModelTFBighornFur extends ModelSheep2 {

   public ModelTFBighornFur() {
      super.head = new ModelRenderer(this, 0, 0);
      super.head.addBox(-3.0F, -4.0F, -4.0F, 6, 6, 6, 0.6F);
      super.head.setRotationPoint(0.0F, 6.0F, -8.0F);
      super.body = new ModelRenderer(this, 28, 8);
      super.body.addBox(-4.0F, -9.0F, -7.0F, 8, 15, 6, 0.5F);
      super.body.setRotationPoint(0.0F, 5.0F, 2.0F);
      float f = 0.4F;
      super.leg1 = new ModelRenderer(this, 0, 16);
      super.leg1.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, f);
      super.leg1.setRotationPoint(-3.0F, 12.0F, 7.0F);
      super.leg2 = new ModelRenderer(this, 0, 16);
      super.leg2.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, f);
      super.leg2.setRotationPoint(3.0F, 12.0F, 7.0F);
      super.leg3 = new ModelRenderer(this, 0, 16);
      super.leg3.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, f);
      super.leg3.setRotationPoint(-3.0F, 12.0F, -5.0F);
      super.leg4 = new ModelRenderer(this, 0, 16);
      super.leg4.addBox(-2.0F, 0.0F, -2.0F, 4, 6, 4, f);
      super.leg4.setRotationPoint(3.0F, 12.0F, -5.0F);
   }
}

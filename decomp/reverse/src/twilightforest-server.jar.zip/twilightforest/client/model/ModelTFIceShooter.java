package twilightforest.client.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import twilightforest.client.model.ModelTFIceExploder;

public class ModelTFIceShooter extends ModelTFIceExploder {

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float time) {
      for(int i = 0; i < super.spikes.length; ++i) {
         super.spikes[i].rotateAngleY = 1.570795F + MathHelper.sin(((float)par1EntityLiving.ticksExisted + time) / 5.0F) * 0.5F;
         super.spikes[i].rotateAngleX = ((float)par1EntityLiving.ticksExisted + time) / 5.0F;
         super.spikes[i].rotateAngleZ = MathHelper.cos((float)i / 5.0F) / 4.0F;
         super.spikes[i].rotateAngleX = (float)((double)super.spikes[i].rotateAngleX + (double)i * 0.39269908169872414D);
         ((ModelRenderer)super.spikes[i].childModels.get(0)).rotationPointY = 9.5F + MathHelper.sin(((float)(i + par1EntityLiving.ticksExisted) + time) / 3.0F) * 3.0F;
      }

   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.tileentity.TileEntityTFMoonworm;

public class ModelTFMoonworm extends ModelBase {

   ModelRenderer Shape1;
   ModelRenderer Shape2;
   ModelRenderer Shape3;
   ModelRenderer head;


   public ModelTFMoonworm() {
      super.textureWidth = 32;
      super.textureHeight = 32;
      this.Shape1 = new ModelRenderer(this, 0, 4);
      this.Shape1.addBox(-1.0F, -1.0F, -1.0F, 4, 2, 2);
      this.Shape1.setRotationPoint(-1.0F, 7.0F, 3.0F);
      this.Shape2 = new ModelRenderer(this, 0, 8);
      this.Shape2.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 4);
      this.Shape2.setRotationPoint(3.0F, 7.0F, 0.0F);
      this.Shape3 = new ModelRenderer(this, 0, 14);
      this.Shape3.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2);
      this.Shape3.setRotationPoint(2.0F, 7.0F, -2.0F);
      this.head = new ModelRenderer(this, 0, 0);
      this.head.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 2);
      this.head.setRotationPoint(-3.0F, 7.0F, 2.0F);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      super.render(entity, f, f1, f2, f3, f4, f5);
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.Shape1.render(f5);
      this.Shape2.render(f5);
      this.Shape3.render(f5);
      this.head.render(f5);
   }

   public void render(float f5) {
      this.Shape1.render(f5);
      this.Shape2.render(f5);
      this.Shape3.render(f5);
      this.head.render(f5);
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity entity) {
      super.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
   }

   public void setLivingAnimations(TileEntityTFMoonworm moonworm, float partialTime) {
      this.head.rotationPointY = 7.0F;
      this.Shape1.rotationPointY = 7.0F;
      this.Shape2.rotationPointY = 7.0F;
      this.Shape3.rotationPointY = 7.0F;
      if(moonworm.yawDelay == 0) {
         float time = (float)(moonworm.desiredYaw - moonworm.currentYaw) - partialTime;
         this.head.rotationPointY += Math.min(0.0F, MathHelper.sin(time / 2.0F));
         this.Shape1.rotationPointY += Math.min(0.0F, MathHelper.sin(time / 2.0F + 1.0F));
         this.Shape2.rotationPointY += Math.min(0.0F, MathHelper.sin(time / 2.0F + 2.0F));
         this.Shape3.rotationPointY += Math.min(0.0F, MathHelper.sin(time / 2.0F + 3.0F));
      }

   }
}

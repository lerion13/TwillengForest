package twilightforest.client.model;

import twilightforest.client.model.ModelTFKnightlyArmor;

public class ModelTFPhantomArmor extends ModelTFKnightlyArmor {

   public ModelTFPhantomArmor(int part, float expand) {
      super(part, expand);
      super.righthorn1.rotateAngleY = -0.43633235F;
      super.righthorn1.rotateAngleZ = 0.7853982F;
      super.righthorn2.rotateAngleY = -0.2617994F;
      super.righthorn2.rotateAngleZ = 0.7853982F;
      super.lefthorn1.rotateAngleY = 0.43633235F;
      super.lefthorn1.rotateAngleZ = -0.7853982F;
      super.lefthorn2.rotateAngleY = 0.2617994F;
      super.lefthorn2.rotateAngleZ = -0.7853982F;
   }
}

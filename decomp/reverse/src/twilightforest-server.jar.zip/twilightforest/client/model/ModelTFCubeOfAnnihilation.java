package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTFCubeOfAnnihilation extends ModelBase {

   public ModelRenderer box;
   public ModelRenderer boxX;
   public ModelRenderer boxY;
   public ModelRenderer boxZ;


   public ModelTFCubeOfAnnihilation() {
      super.textureWidth = 64;
      super.textureHeight = 64;
      this.box = new ModelRenderer(this, 0, 0);
      this.box.addBox(-8.0F, -8.0F, -8.0F, 16, 16, 16, 0.0F);
      this.box.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.boxX = new ModelRenderer(this, 0, 32);
      this.boxX.addBox(-8.0F, -8.0F, -8.0F, 16, 16, 16, 0.0F);
      this.boxX.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.boxY = new ModelRenderer(this, 0, 32);
      this.boxY.addBox(-8.0F, -8.0F, -8.0F, 16, 16, 16, 0.0F);
      this.boxY.setRotationPoint(0.0F, 0.0F, 0.0F);
      this.boxZ = new ModelRenderer(this, 0, 32);
      this.boxZ.addBox(-8.0F, -8.0F, -8.0F, 16, 16, 16, 0.0F);
      this.boxZ.setRotationPoint(0.0F, 0.0F, 0.0F);
   }

   public void render(Entity p_78088_1_, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_, float p_78088_6_, float p_78088_7_) {
      this.setRotationAngles(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, p_78088_7_, p_78088_1_);
      this.box.render(p_78088_7_);
      this.boxX.render(p_78088_7_);
      this.boxY.render(p_78088_7_);
      this.boxZ.render(p_78088_7_);
   }

   public void setRotationAngles(float f, float f1, float f2, float f3, float time, float f5, Entity entity) {
      this.boxX.rotateAngleX = (float)Math.sin((double)((float)entity.ticksExisted + time)) / 5.0F;
      this.boxY.rotateAngleY = (float)Math.sin((double)((float)entity.ticksExisted + time)) / 5.0F;
      this.boxZ.rotateAngleZ = (float)Math.sin((double)((float)entity.ticksExisted + time)) / 5.0F;
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFTowerGolem;

public class ModelTFTowerGolem extends ModelBase {

   ModelRenderer head;
   ModelRenderer jaw;
   ModelRenderer body;
   ModelRenderer rightarm;
   ModelRenderer leftarm;
   ModelRenderer leftleg;
   ModelRenderer leftfoot;
   ModelRenderer ribs;
   ModelRenderer hips;
   ModelRenderer rightfoot;
   ModelRenderer rightleg;
   ModelRenderer spine;


   public ModelTFTowerGolem() {
      super.textureWidth = 128;
      super.textureHeight = 64;
      this.head = new ModelRenderer(this, 0, 0);
      this.head.setRotationPoint(0.0F, -11.0F, -2.0F);
      this.head.setTextureOffset(0, 0).addBox(-3.5F, -10.0F, -3.0F, 7, 8, 6);
      this.head.setTextureOffset(0, 14).addBox(-4.0F, -6.0F, -3.5F, 8, 4, 6);
      this.body = new ModelRenderer(this, 0, 26);
      this.body.addBox(-8.0F, 0.0F, -5.0F, 16, 10, 10);
      this.body.setRotationPoint(0.0F, -13.0F, 0.0F);
      this.ribs = new ModelRenderer(this, 0, 46);
      this.ribs.addBox(-5.0F, 0.0F, -3.0F, 10, 6, 6);
      this.ribs.setRotationPoint(0.0F, -3.0F, 0.0F);
      this.rightarm = new ModelRenderer(this, 52, 0);
      this.rightarm.setRotationPoint(-8.0F, -12.0F, 0.0F);
      this.rightarm.setTextureOffset(52, 0).addBox(-5.0F, -2.0F, -1.5F, 3, 14, 3);
      this.rightarm.setTextureOffset(52, 17).addBox(-7.0F, 12.0F, -3.0F, 6, 12, 6);
      this.rightarm.setTextureOffset(52, 36).addBox(-7.0F, -3.0F, -3.5F, 7, 2, 7);
      this.rightarm.setTextureOffset(52, 45).addBox(-7.0F, -1.0F, -3.5F, 7, 5, 2);
      this.rightarm.setTextureOffset(52, 45).addBox(-7.0F, -1.0F, 1.5F, 7, 5, 2);
      this.rightarm.setTextureOffset(52, 54).addBox(-2.0F, -1.0F, -2.0F, 2, 5, 3);
      this.leftarm = new ModelRenderer(this, 52, 0);
      this.leftarm.mirror = true;
      this.leftarm.setRotationPoint(8.0F, -12.0F, 0.0F);
      this.leftarm.setTextureOffset(52, 0).addBox(2.0F, -2.0F, -1.5F, 3, 14, 3);
      this.leftarm.setTextureOffset(52, 17).addBox(1.0F, 12.0F, -3.0F, 6, 12, 6);
      this.leftarm.setTextureOffset(52, 36).addBox(0.0F, -3.0F, -3.5F, 7, 2, 7);
      this.leftarm.setTextureOffset(52, 45).addBox(0.0F, -1.0F, -3.5F, 7, 5, 2);
      this.leftarm.setTextureOffset(52, 45).addBox(0.0F, -1.0F, 1.5F, 7, 5, 2);
      this.leftarm.setTextureOffset(52, 54).addBox(0.0F, -1.0F, -2.0F, 2, 5, 3);
      this.hips = new ModelRenderer(this, 84, 25);
      this.hips.addBox(-5.0F, 0.0F, -2.0F, 10, 3, 4);
      this.hips.setRotationPoint(0.0F, 1.0F, 0.0F);
      this.spine = new ModelRenderer(this, 84, 18);
      this.spine.addBox(-1.5F, 0.0F, -1.5F, 3, 4, 3);
      this.spine.setRotationPoint(0.0F, -3.0F, 0.0F);
      this.leftleg = new ModelRenderer(this, 84, 32);
      this.leftleg.mirror = true;
      this.leftleg.setRotationPoint(1.0F, 2.0F, 0.0F);
      this.leftleg.setTextureOffset(84, 32).addBox(0.0F, 0.0F, -1.5F, 3, 8, 3);
      this.leftleg.setTextureOffset(84, 43).addBox(-0.5F, 8.0F, -4.0F, 6, 14, 7);
      this.rightleg = new ModelRenderer(this, 84, 32);
      this.rightleg.setRotationPoint(-1.0F, 2.0F, 0.0F);
      this.rightleg.setTextureOffset(84, 32).addBox(-3.0F, 0.0F, -1.5F, 3, 8, 3);
      this.rightleg.setTextureOffset(84, 43).addBox(-5.5F, 8.0F, -4.0F, 6, 14, 7);
   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.head.render(f5);
      this.body.render(f5);
      this.rightarm.render(f5);
      this.leftarm.render(f5);
      this.rightleg.render(f5);
      this.leftleg.render(f5);
      this.ribs.render(f5);
      this.hips.render(f5);
      this.spine.render(f5);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      this.head.rotateAngleY = par4 / 57.295776F;
      this.head.rotateAngleX = par5 / 57.295776F;
      this.leftleg.rotateAngleX = -1.5F * this.func_78172_a(par1, 13.0F) * par2;
      this.rightleg.rotateAngleX = 1.5F * this.func_78172_a(par1, 13.0F) * par2;
      this.leftleg.rotateAngleY = 0.0F;
      this.rightleg.rotateAngleY = 0.0F;
      this.rightarm.rotateAngleZ = MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      this.leftarm.rotateAngleZ = -MathHelper.cos(par3 * 0.09F) * 0.05F - 0.05F;
   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float par4) {
      EntityTFTowerGolem var5 = (EntityTFTowerGolem)par1EntityLiving;
      int var6 = var5.getAttackTimer();
      if(var6 > 0) {
         this.rightarm.rotateAngleX = -2.0F + 1.5F * this.func_78172_a((float)var6 - par4, 10.0F);
         this.leftarm.rotateAngleX = -2.0F + 1.5F * this.func_78172_a((float)var6 - par4, 10.0F);
      } else {
         this.rightarm.rotateAngleX = (-0.2F + 1.5F * this.func_78172_a(par2, 25.0F)) * par3;
         this.leftarm.rotateAngleX = (-0.2F - 1.5F * this.func_78172_a(par2, 25.0F)) * par3;
      }

   }

   private float func_78172_a(float par1, float par2) {
      return (Math.abs(par1 % par2 - par2 * 0.5F) - par2 * 0.25F) / (par2 * 0.25F);
   }
}

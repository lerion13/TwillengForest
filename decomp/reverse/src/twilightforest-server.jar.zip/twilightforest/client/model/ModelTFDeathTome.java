package twilightforest.client.model;

import net.minecraft.client.model.ModelBook;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class ModelTFDeathTome extends ModelBook {

   ModelRenderer everything = (new ModelRenderer(this)).setTextureOffset(0, 0).addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
   ModelRenderer book = (new ModelRenderer(this)).setTextureOffset(0, 0).addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
   ModelRenderer loosePage1;
   ModelRenderer loosePage2;
   ModelRenderer loosePage3;
   ModelRenderer loosePage4;


   public ModelTFDeathTome() {
      this.book.addChild(super.coverRight);
      this.book.addChild(super.coverLeft);
      this.book.addChild(super.bookSpine);
      this.book.addChild(super.pagesRight);
      this.book.addChild(super.pagesLeft);
      this.book.addChild(super.flippingPageRight);
      this.book.addChild(super.flippingPageLeft);
      this.loosePage1 = (new ModelRenderer(this)).setTextureOffset(24, 10).addBox(0.0F, -4.0F, -8.0F, 5, 8, 0);
      this.loosePage2 = (new ModelRenderer(this)).setTextureOffset(24, 10).addBox(0.0F, -4.0F, 9.0F, 5, 8, 0);
      this.loosePage3 = (new ModelRenderer(this)).setTextureOffset(24, 10).addBox(0.0F, -4.0F, 11.0F, 5, 8, 0);
      this.loosePage4 = (new ModelRenderer(this)).setTextureOffset(24, 10).addBox(0.0F, -4.0F, 7.0F, 5, 8, 0);
      this.everything.addChild(this.book);
      this.everything.addChild(this.loosePage1);
      this.everything.addChild(this.loosePage2);
      this.everything.addChild(this.loosePage3);
      this.everything.addChild(this.loosePage4);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float scale) {
      GL11.glEnable(2884);
      this.setRotationAngles((float)par1Entity.ticksExisted, 0.4F, 0.6F, 0.9F, par6, 0.0625F);
      this.everything.render(scale);
      GL11.glDisable(2884);
   }

   public void setRotationAngles(float bounce, float flipRight, float flipLeft, float open, float rotate, float scale) {
      this.book.rotateAngleZ = -0.87266463F;
      this.everything.rotateAngleY = rotate / 57.295776F + 1.5707964F;
   }

   public void setLivingAnimations(EntityLivingBase par1EntityLiving, float par2, float par3, float partialTick) {
      float bounce = (float)par1EntityLiving.ticksExisted + partialTick;
      float open = 0.9F;
      float flipRight = 0.4F;
      float flipLeft = 0.6F;
      this.book.setRotationPoint(0.0F, 4.0F + MathHelper.sin(bounce * 0.3F) * 2.0F, 0.0F);
      float openAngle = (MathHelper.sin(bounce * 0.4F) * 0.3F + 1.25F) * open;
      super.coverRight.rotateAngleY = 3.1415927F + openAngle;
      super.coverLeft.rotateAngleY = -openAngle;
      super.pagesRight.rotateAngleY = openAngle;
      super.pagesLeft.rotateAngleY = -openAngle;
      super.flippingPageRight.rotateAngleY = openAngle - openAngle * 2.0F * flipRight;
      super.flippingPageLeft.rotateAngleY = openAngle - openAngle * 2.0F * flipLeft;
      super.pagesRight.rotationPointX = MathHelper.sin(openAngle);
      super.pagesLeft.rotationPointX = MathHelper.sin(openAngle);
      super.flippingPageRight.rotationPointX = MathHelper.sin(openAngle);
      super.flippingPageLeft.rotationPointX = MathHelper.sin(openAngle);
      this.loosePage1.rotateAngleY = bounce / 4.0F;
      this.loosePage1.rotateAngleX = MathHelper.sin(bounce / 5.0F) / 3.0F;
      this.loosePage1.rotateAngleZ = MathHelper.cos(bounce / 5.0F) / 5.0F;
      this.loosePage2.rotateAngleY = bounce / 3.0F;
      this.loosePage2.rotateAngleX = MathHelper.sin(bounce / 5.0F) / 3.0F;
      this.loosePage2.rotateAngleZ = MathHelper.cos(bounce / 5.0F) / 4.0F + 2.0F;
      this.loosePage3.rotateAngleY = bounce / 4.0F;
      this.loosePage3.rotateAngleX = -MathHelper.sin(bounce / 5.0F) / 3.0F;
      this.loosePage3.rotateAngleZ = MathHelper.cos(bounce / 5.0F) / 5.0F - 1.0F;
      this.loosePage4.rotateAngleY = bounce / 4.0F;
      this.loosePage4.rotateAngleX = -MathHelper.sin(bounce / 2.0F) / 4.0F;
      this.loosePage4.rotateAngleZ = MathHelper.cos(bounce / 7.0F) / 5.0F;
   }
}

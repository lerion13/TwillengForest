package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import twilightforest.entity.boss.EntityTFKnightPhantom;

public class ModelTFKnightPhantom2 extends ModelBiped {

   public ModelTFKnightPhantom2() {
      this(0.0F);
   }

   public ModelTFKnightPhantom2(float par1) {
      super(par1, 0.0F, 64, 32);
      super.bipedRightArm = new ModelRenderer(this, 40, 16);
      super.bipedRightArm.addBox(-1.0F, -2.0F, -1.0F, 2, 12, 2, par1);
      super.bipedRightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 40, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -1.0F, 2, 12, 2, par1);
      super.bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 16);
      super.bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2, par1);
      super.bipedRightLeg.setRotationPoint(-2.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 16);
      super.bipedLeftLeg.mirror = true;
      super.bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, 2, 12, 2, par1);
      super.bipedLeftLeg.setRotationPoint(2.0F, 12.0F, 0.0F);
   }

   public void render(Entity par1Entity, float par2, float par3, float par4, float par5, float par6, float par7) {
      this.setRotationAngles(par2, par3, par4, par5, par6, par7, par1Entity);
      if(((EntityTFKnightPhantom)par1Entity).isChargingAtPlayer()) {
         super.render(par1Entity, par2, par3, par4, par5, par6, par7);
      }

   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      super.setRotationAngles(par1, par2, par3, par4, par5, par6, par7Entity);
      super.bipedLeftLeg.rotateAngleX = 0.0F;
      super.bipedLeftLeg.rotateAngleY = 0.0F;
      super.bipedLeftLeg.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = 0.0F;
      super.bipedRightLeg.rotateAngleY = 0.0F;
      super.bipedRightLeg.rotateAngleZ = 0.0F;
      super.bipedRightLeg.rotateAngleX = 0.2F * MathHelper.sin(par3 * 0.3F) + 0.4F;
      super.bipedLeftLeg.rotateAngleX = 0.2F * MathHelper.sin(par3 * 0.3F) + 0.4F;
   }
}

package twilightforest.client.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelTFSlimeBeetle extends ModelBase {

   ModelRenderer head;
   ModelRenderer RearEnd;
   ModelRenderer Leg6;
   ModelRenderer Leg4;
   ModelRenderer Leg2;
   ModelRenderer Leg5;
   ModelRenderer Leg3;
   ModelRenderer Leg1;
   ModelRenderer connector1;
   ModelRenderer antenna1;
   ModelRenderer antenna2;
   ModelRenderer eye1;
   ModelRenderer eye2;
   ModelRenderer slimeCube;
   ModelRenderer tail1;
   ModelRenderer tail2;
   ModelRenderer mouth;
   ModelRenderer slimeCenter;
   boolean renderPassModel;


   public ModelTFSlimeBeetle() {
      this(false);
   }

   public ModelTFSlimeBeetle(boolean renderpass) {
      this.renderPassModel = false;
      this.renderPassModel = renderpass;
      super.textureWidth = 64;
      super.textureHeight = 64;
      this.connector1 = new ModelRenderer(this, 0, 12);
      this.connector1.addBox(-3.0F, -3.0F, -1.0F, 6, 6, 1);
      this.connector1.setRotationPoint(0.0F, 19.0F, -4.0F);
      this.RearEnd = new ModelRenderer(this, 31, 6);
      this.RearEnd.addBox(-4.0F, -11.0F, -4.0F, 8, 10, 8);
      this.RearEnd.setRotationPoint(0.0F, 18.0F, 7.0F);
      this.setRotation(this.RearEnd, 1.570796F, 0.0F, 0.0F);
      this.Leg6 = new ModelRenderer(this, 40, 0);
      this.Leg6.addBox(-1.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg6.setRotationPoint(2.0F, 21.0F, -4.0F);
      this.setRotation(this.Leg6, 0.0F, 0.2792527F, 0.3490659F);
      this.Leg5 = new ModelRenderer(this, 40, 0);
      this.Leg5.mirror = true;
      this.Leg5.addBox(-9.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg5.setRotationPoint(-2.0F, 21.0F, -4.0F);
      this.setRotation(this.Leg5, 0.0F, -0.2792527F, -0.3490659F);
      this.Leg4 = new ModelRenderer(this, 40, 0);
      this.Leg4.addBox(-1.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg4.setRotationPoint(2.0F, 21.0F, -1.0F);
      this.setRotation(this.Leg4, 0.0F, -0.2792527F, 0.3490659F);
      this.Leg2 = new ModelRenderer(this, 40, 0);
      this.Leg2.addBox(-1.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg2.setRotationPoint(2.0F, 21.0F, 4.0F);
      this.setRotation(this.Leg2, 0.0F, -0.6981317F, 0.3490659F);
      this.Leg3 = new ModelRenderer(this, 40, 0);
      this.Leg3.mirror = true;
      this.Leg3.addBox(-9.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg3.setRotationPoint(-2.0F, 21.0F, -1.0F);
      this.setRotation(this.Leg3, 0.0F, 0.2792527F, -0.3490659F);
      this.Leg1 = new ModelRenderer(this, 40, 0);
      this.Leg1.mirror = true;
      this.Leg1.addBox(-9.0F, -1.0F, -1.0F, 10, 2, 2);
      this.Leg1.setRotationPoint(-2.0F, 21.0F, 4.0F);
      this.Leg1.setTextureSize(64, 32);
      this.setRotation(this.Leg1, 0.0F, 0.6981317F, -0.3490659F);
      this.head = new ModelRenderer(this, 0, 0);
      this.head.addBox(-4.0F, -4.0F, -6.0F, 8, 6, 6);
      this.head.setRotationPoint(0.0F, 19.0F, -5.0F);
      this.antenna1 = new ModelRenderer(this, 38, 4);
      this.antenna1.addBox(0.0F, -0.5F, -0.5F, 12, 1, 1);
      this.antenna1.setRotationPoint(1.0F, -3.0F, -5.0F);
      this.setRotation(this.antenna1, 0.0F, 1.047198F, -0.296706F);
      this.antenna2 = new ModelRenderer(this, 38, 4);
      this.antenna2.addBox(0.0F, -0.5F, -0.5F, 12, 1, 1);
      this.antenna2.setRotationPoint(-1.0F, -3.0F, -5.0F);
      this.setRotation(this.antenna2, 0.0F, 2.094395F, 0.296706F);
      this.eye1 = new ModelRenderer(this, 15, 12);
      this.eye1.addBox(-1.5F, -1.5F, -1.5F, 3, 3, 3);
      this.eye1.setRotationPoint(-3.0F, -2.0F, -5.0F);
      this.eye2 = new ModelRenderer(this, 15, 12);
      this.eye2.addBox(-1.5F, -1.5F, -1.5F, 3, 3, 3);
      this.eye2.setRotationPoint(3.0F, -2.0F, -5.0F);
      this.mouth = new ModelRenderer(this, 17, 12);
      this.mouth.addBox(-1.0F, -1.0F, -1.0F, 2, 2, 1);
      this.mouth.setRotationPoint(0.0F, 1.0F, -6.0F);
      this.head.addChild(this.antenna1);
      this.head.addChild(this.antenna2);
      this.head.addChild(this.eye1);
      this.head.addChild(this.eye2);
      this.head.addChild(this.mouth);
      this.tail1 = new ModelRenderer(this, 0, 20);
      this.tail1.addBox(-3.0F, -3.0F, -3.0F, 6, 6, 6);
      this.tail1.setRotationPoint(0.0F, 19.0F, 9.0F);
      this.tail2 = new ModelRenderer(this, 0, 20);
      this.tail2.addBox(-3.0F, -6.0F, -3.0F, 6, 6, 6);
      this.tail2.setRotationPoint(0.0F, -3.0F, 2.0F);
      this.slimeCube = new ModelRenderer(this, 0, 40);
      this.slimeCube.addBox(-6.0F, -12.0F, -9.0F, 12, 12, 12);
      this.slimeCube.setRotationPoint(0.0F, -6.0F, 0.0F);
      this.slimeCenter = new ModelRenderer(this, 32, 24);
      this.slimeCenter.addBox(-4.0F, -10.0F, -7.0F, 8, 8, 8);
      this.slimeCenter.setRotationPoint(0.0F, -6.0F, 0.0F);
      this.tail1.addChild(this.tail2);
      if(this.renderPassModel) {
         this.tail2.addChild(this.slimeCube);
      } else {
         this.tail2.addChild(this.slimeCenter);
      }

   }

   public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
      this.setRotationAngles(f, f1, f2, f3, f4, f5, entity);
      this.tail1.render(f5);
      if(!this.renderPassModel) {
         this.head.render(f5);
         this.RearEnd.render(f5);
         this.Leg6.render(f5);
         this.Leg4.render(f5);
         this.Leg2.render(f5);
         this.Leg5.render(f5);
         this.Leg3.render(f5);
         this.Leg1.render(f5);
         this.connector1.render(f5);
      }

   }

   private void setRotation(ModelRenderer model, float x, float y, float z) {
      model.rotateAngleX = x;
      model.rotateAngleY = y;
      model.rotateAngleZ = z;
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      this.head.rotateAngleY = par4 / 57.295776F;
      this.head.rotateAngleX = par5 / 57.295776F;
      float legZ = 0.28559935F;
      this.Leg1.rotateAngleZ = -legZ;
      this.Leg2.rotateAngleZ = legZ;
      this.Leg3.rotateAngleZ = -legZ * 0.74F;
      this.Leg4.rotateAngleZ = legZ * 0.74F;
      this.Leg5.rotateAngleZ = -legZ;
      this.Leg6.rotateAngleZ = legZ;
      float var9 = -0.0F;
      float var10 = 0.3926991F;
      this.Leg1.rotateAngleY = var10 * 2.0F + var9;
      this.Leg2.rotateAngleY = -var10 * 2.0F - var9;
      this.Leg3.rotateAngleY = var10 * 1.0F + var9;
      this.Leg4.rotateAngleY = -var10 * 1.0F - var9;
      this.Leg5.rotateAngleY = -var10 * 2.0F + var9;
      this.Leg6.rotateAngleY = var10 * 2.0F - var9;
      float var11 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 0.0F) * 0.4F) * par2;
      float var12 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 3.1415927F) * 0.4F) * par2;
      float var14 = -(MathHelper.cos(par1 * 0.6662F * 2.0F + 4.712389F) * 0.4F) * par2;
      float var15 = Math.abs(MathHelper.sin(par1 * 0.6662F + 0.0F) * 0.4F) * par2;
      float var16 = Math.abs(MathHelper.sin(par1 * 0.6662F + 3.1415927F) * 0.4F) * par2;
      float var18 = Math.abs(MathHelper.sin(par1 * 0.6662F + 4.712389F) * 0.4F) * par2;
      this.Leg1.rotateAngleY += var11;
      this.Leg2.rotateAngleY += -var11;
      this.Leg3.rotateAngleY += var12;
      this.Leg4.rotateAngleY += -var12;
      this.Leg5.rotateAngleY += var14;
      this.Leg6.rotateAngleY += -var14;
      this.Leg1.rotateAngleZ += var15;
      this.Leg2.rotateAngleZ += -var15;
      this.Leg3.rotateAngleZ += var16;
      this.Leg4.rotateAngleZ += -var16;
      this.Leg5.rotateAngleZ += var18;
      this.Leg6.rotateAngleZ += -var18;
      this.tail1.rotateAngleX = MathHelper.cos(par3 * 0.3335F) * 0.15F;
      this.tail2.rotateAngleX = MathHelper.cos(par3 * 0.4445F) * 0.2F;
      this.slimeCube.rotateAngleX = MathHelper.cos(par3 * 0.5555F) * 0.25F;
      this.slimeCenter.rotateAngleX = MathHelper.cos(par3 * 0.5555F + 0.25F) * 0.25F;
   }
}

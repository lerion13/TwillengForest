package twilightforest.client.model;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelTFKnightPhantom extends ModelBiped {

   public ModelRenderer helmet;
   public ModelRenderer righthorn1;
   public ModelRenderer righthorn2;
   public ModelRenderer lefthorn1;
   public ModelRenderer lefthorn2;


   public ModelTFKnightPhantom() {
      super.heldItemLeft = 0;
      super.heldItemRight = 0;
      super.isSneak = false;
      super.aimedBow = false;
      super.textureWidth = 128;
      super.textureHeight = 64;
      super.bipedCloak = new ModelRenderer(this, 0, 0);
      super.bipedCloak.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1);
      super.bipedEars = new ModelRenderer(this, 24, 0);
      super.bipedEars.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1);
      super.bipedHead = new ModelRenderer(this, 0, 0);
      super.bipedHead.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedHead.setRotationPoint(0.0F, -10.0F, 0.0F);
      super.bipedHeadwear = new ModelRenderer(this, 0, 0);
      super.bipedHeadwear.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedHeadwear.setRotationPoint(0.0F, -10.0F, 0.0F);
      this.helmet = new ModelRenderer(this, 0, 0);
      this.helmet.addBox(-4.0F, -11.0F, -4.0F, 8, 11, 8);
      this.helmet.rotateAngleY = 0.7853982F;
      this.righthorn1 = new ModelRenderer(this, 28, 0);
      this.righthorn1.addBox(-6.0F, -1.5F, -1.5F, 7, 3, 3);
      this.righthorn1.setRotationPoint(-3.5F, -9.0F, 0.0F);
      this.righthorn1.rotateAngleY = 0.2617994F;
      this.righthorn1.rotateAngleZ = 0.17453294F;
      this.righthorn2 = new ModelRenderer(this, 28, 6);
      this.righthorn2.addBox(-3.0F, -1.0F, -1.0F, 3, 2, 2);
      this.righthorn2.setRotationPoint(-5.5F, 0.0F, 0.0F);
      this.righthorn2.rotateAngleZ = 0.17453294F;
      this.righthorn1.addChild(this.righthorn2);
      this.lefthorn1 = new ModelRenderer(this, 28, 0);
      this.lefthorn1.mirror = true;
      this.lefthorn1.addBox(-1.0F, -1.5F, -1.5F, 7, 3, 3);
      this.lefthorn1.setRotationPoint(3.5F, -9.0F, 0.0F);
      this.lefthorn1.rotateAngleY = -0.2617994F;
      this.lefthorn1.rotateAngleZ = -0.17453294F;
      this.lefthorn2 = new ModelRenderer(this, 28, 6);
      this.lefthorn2.addBox(0.0F, -1.0F, -1.0F, 3, 2, 2);
      this.lefthorn2.setRotationPoint(5.5F, 0.0F, 0.0F);
      this.lefthorn2.rotateAngleZ = -0.17453294F;
      this.lefthorn1.addChild(this.lefthorn2);
      super.bipedHeadwear.addChild(this.helmet);
      super.bipedHeadwear.addChild(this.righthorn1);
      super.bipedHeadwear.addChild(this.lefthorn1);
      super.bipedBody = new ModelRenderer(this, 0, 18);
      super.bipedBody.setRotationPoint(0.0F, 2.0F, 0.0F);
      super.bipedBody.addBox(-7.0F, -12.0F, -3.5F, 14, 12, 7);
      super.bipedBody.setTextureOffset(30, 24).addBox(-6.0F, 0.0F, -3.0F, 12, 8, 6);
      super.bipedRightArm = new ModelRenderer(this, 44, 16);
      super.bipedRightArm.addBox(-5.0F, -2.0F, -3.0F, 6, 7, 6);
      super.bipedRightArm.setRotationPoint(-8.0F, -8.0F, 0.0F);
      super.bipedLeftArm = new ModelRenderer(this, 44, 16);
      super.bipedLeftArm.mirror = true;
      super.bipedLeftArm.addBox(-1.0F, -2.0F, -3.0F, 6, 7, 6);
      super.bipedLeftArm.setRotationPoint(8.0F, -8.0F, 0.0F);
      super.bipedRightLeg = new ModelRenderer(this, 0, 0);
      super.bipedRightLeg.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedRightLeg.setRotationPoint(0.0F, 12.0F, 0.0F);
      super.bipedLeftLeg = new ModelRenderer(this, 0, 0);
      super.bipedLeftLeg.addBox(0.0F, 0.0F, 0.0F, 0, 0, 0);
      super.bipedLeftLeg.setRotationPoint(0.0F, 12.0F, 0.0F);
   }

   public void setRotationAngles(float par1, float par2, float par3, float par4, float par5, float par6, Entity par7Entity) {
      super.bipedHead.rotateAngleY = par4 / 57.295776F;
      super.bipedHead.rotateAngleX = par5 / 57.295776F;
      super.bipedHead.rotateAngleZ = 0.0F;
      super.bipedHeadwear.rotateAngleY = super.bipedHead.rotateAngleY;
      super.bipedHeadwear.rotateAngleX = super.bipedHead.rotateAngleX;
      super.bipedHeadwear.rotateAngleZ = super.bipedHead.rotateAngleZ;
      super.bipedRightArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F + 3.1415927F) * 2.0F * par2 * 0.5F;
      super.bipedLeftArm.rotateAngleX = MathHelper.cos(par1 * 0.6662F) * 2.0F * par2 * 0.5F;
      super.bipedRightArm.rotateAngleZ = 0.0F;
      super.bipedLeftArm.rotateAngleZ = 0.0F;
      if(super.heldItemLeft != 0) {
         super.bipedLeftArm.rotateAngleX = super.bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemLeft;
      }

      super.heldItemRight = 1;
      if(super.heldItemRight != 0) {
         super.bipedRightArm.rotateAngleX = super.bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * (float)super.heldItemRight;
      }

      super.bipedRightArm.rotateAngleZ += MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedLeftArm.rotateAngleZ -= MathHelper.cos(par3 * 0.09F) * 0.05F + 0.05F;
      super.bipedRightArm.rotateAngleX += MathHelper.sin(par3 * 0.067F) * 0.05F;
      super.bipedLeftArm.rotateAngleX -= MathHelper.sin(par3 * 0.067F) * 0.05F;
   }
}

package twilightforest.client;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import twilightforest.world.WorldProviderTwilightForest;

public class TFClientTicker {

   @SubscribeEvent
   public void clientTick(ClientTickEvent event) {
      Minecraft mc = Minecraft.getMinecraft();
      WorldClient world = mc.theWorld;
      if(world != null && world.provider instanceof WorldProviderTwilightForest && mc.ingameGUI != null) {
         mc.ingameGUI.prevVignetteBrightness = 0.0F;
      }

   }
}

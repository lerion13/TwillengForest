package twilightforest.client;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;
import twilightforest.uncrafting.ContainerTFUncrafting;

public class GuiTFGoblinCrafting extends GuiContainer {

   private static final ResourceLocation textureLoc = new ResourceLocation("twilightforest:textures/gui/guigoblintinkering.png");


   public GuiTFGoblinCrafting(InventoryPlayer inventory, World world, int x, int y, int z) {
      super(new ContainerTFUncrafting(inventory, world, x, y, z));
   }

   protected void drawGuiContainerForegroundLayer(int var1, int var2) {
      super.fontRendererObj.drawString("Uncrafting Table", 8, 6, 4210752);
      super.fontRendererObj.drawString(StatCollector.translateToLocal("container.inventory"), 8, super.ySize - 96 + 2, 4210752);
   }

   protected void drawGuiContainerBackgroundLayer(float var1, int var2, int var3) {
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      super.mc.getTextureManager().bindTexture(textureLoc);
      int frameX = (super.width - super.xSize) / 2;
      int frameY = (super.height - super.ySize) / 2;
      this.drawTexturedModalRect(frameX, frameY, 0, 0, super.xSize, super.ySize);
      ContainerTFUncrafting tfContainer = (ContainerTFUncrafting)super.inventorySlots;
      RenderHelper.enableGUIStandardItemLighting();
      GL11.glPushMatrix();
      GL11.glTranslatef((float)super.guiLeft, (float)super.guiTop, 0.0F);

      for(int fontRendererObj = 0; fontRendererObj < 9; ++fontRendererObj) {
         Slot costVal = tfContainer.getSlot(2 + fontRendererObj);
         Slot color = tfContainer.getSlot(11 + fontRendererObj);
         if(costVal.getStack() != null) {
            this.drawSlotAsBackground(costVal, color);
         }
      }

      GL11.glPopMatrix();
      FontRenderer var11 = super.mc.fontRenderer;
      RenderHelper.disableStandardItemLighting();
      int var12 = tfContainer.getUncraftingCost();
      String cost;
      int var13;
      if(var12 > 0) {
         if(super.mc.thePlayer.experienceLevel < var12 && !super.mc.thePlayer.capabilities.isCreativeMode) {
            var13 = 10485760;
            cost = "" + var12;
            var11.drawStringWithShadow(cost, frameX + 48 - var11.getStringWidth(cost), frameY + 38, var13);
         } else {
            var13 = 8453920;
            cost = "" + var12;
            var11.drawStringWithShadow(cost, frameX + 48 - var11.getStringWidth(cost), frameY + 38, var13);
         }
      }

      var12 = tfContainer.getRecraftingCost();
      if(var12 > 0) {
         if(super.mc.thePlayer.experienceLevel < var12 && !super.mc.thePlayer.capabilities.isCreativeMode) {
            var13 = 10485760;
            cost = "" + var12;
            var11.drawStringWithShadow(cost, frameX + 130 - var11.getStringWidth(cost), frameY + 38, var13);
         } else {
            var13 = 8453920;
            cost = "" + var12;
            var11.drawStringWithShadow(cost, frameX + 130 - var11.getStringWidth(cost), frameY + 38, var13);
         }
      }

   }

   private void drawSlotAsBackground(Slot backgroundSlot, Slot appearSlot) {
      int screenX = appearSlot.xDisplayPosition;
      int screenY = appearSlot.yDisplayPosition;
      ItemStack itemStackToRender = backgroundSlot.getStack();
      super.zLevel = 50.0F;
      GuiScreen.itemRender.zLevel = 50.0F;
      GuiScreen.itemRender.renderItemIntoGUI(super.fontRendererObj, super.mc.renderEngine, itemStackToRender, screenX, screenY);
      GuiScreen.itemRender.renderItemOverlayIntoGUI(super.fontRendererObj, super.mc.renderEngine, itemStackToRender, screenX, screenY);
      boolean itemBroken = false;
      if(backgroundSlot.getHasStack() && backgroundSlot.getStack().stackSize == 0) {
         itemBroken = true;
      }

      GL11.glDisable(2896);
      GL11.glDisable(2929);
      Gui.drawRect(screenX, screenY, screenX + 16, screenY + 16, itemBroken?-2130736245:-1618244725);
      GL11.glEnable(2896);
      GL11.glEnable(2929);
      GuiScreen.itemRender.zLevel = 0.0F;
      super.zLevel = 0.0F;
   }

}

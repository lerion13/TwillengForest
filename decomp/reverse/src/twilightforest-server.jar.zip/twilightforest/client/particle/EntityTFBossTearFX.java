package twilightforest.client.particle;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;

@SideOnly(Side.CLIENT)
public class EntityTFBossTearFX extends EntityFX {

   public EntityTFBossTearFX(World par1World, double par2, double par4, double par6, Item par8Item) {
      super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
      this.setParticleIcon(par8Item.getIconFromDamage(0));
      super.particleRed = super.particleGreen = super.particleBlue = 1.0F;
      super.particleGravity = Blocks.snow.blockParticleGravity * 2.0F;
      super.particleScale = 16.0F;
      super.particleMaxAge = 20 + super.rand.nextInt(40);
   }

   public EntityTFBossTearFX(World par1World, double par2, double par4, double par6, double par8, double par10, double par12, Item par14Item) {
      this(par1World, par2, par4, par6, par14Item);
      super.motionX *= 0.10000000149011612D;
      super.motionY *= 0.10000000149011612D;
      super.motionZ *= 0.10000000149011612D;
      super.motionX += par8;
      super.motionY += par10;
      super.motionZ += par12;
   }

   public int getFXLayer() {
      return 2;
   }

   public void onUpdate() {
      super.onUpdate();
      if(super.onGround && super.rand.nextBoolean()) {
         super.worldObj.playSound(super.posX, super.posY + 1.0D, super.posZ, "random.glass", 0.5F, 1.0F, false);

         for(int var1 = 0; var1 < 50; ++var1) {
            double gaussX = super.rand.nextGaussian() * 0.1D;
            double gaussY = super.rand.nextGaussian() * 0.2D;
            double gaussZ = super.rand.nextGaussian() * 0.1D;
            Item popItem = Items.ghast_tear;
            super.worldObj.spawnParticle("iconcrack_" + Item.getIdFromItem(popItem), super.posX + (double)super.rand.nextFloat() - (double)super.rand.nextFloat(), super.posY + 0.5D, super.posZ + (double)super.rand.nextFloat(), gaussX, gaussY, gaussZ);
         }

         this.setDead();
      }

   }

   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
      float f6 = (float)super.particleTextureIndexX / 16.0F;
      float f7 = f6 + 0.0624375F;
      float f8 = (float)super.particleTextureIndexY / 16.0F;
      float f9 = f8 + 0.0624375F;
      float f10 = 0.1F * super.particleScale;
      if(super.particleIcon != null) {
         f6 = super.particleIcon.getInterpolatedU(0.0D);
         f7 = super.particleIcon.getInterpolatedU(16.0D);
         f8 = super.particleIcon.getInterpolatedV(0.0D);
         f9 = super.particleIcon.getInterpolatedV(16.0D);
      }

      float f11 = (float)(super.prevPosX + (super.posX - super.prevPosX) * (double)par2 - EntityFX.interpPosX);
      float f12 = (float)(super.prevPosY + (super.posY - super.prevPosY) * (double)par2 - EntityFX.interpPosY);
      float f13 = (float)(super.prevPosZ + (super.posZ - super.prevPosZ) * (double)par2 - EntityFX.interpPosZ);
      float f14 = 1.0F;
      par1Tessellator.setColorOpaque_F(f14 * super.particleRed, f14 * super.particleGreen, f14 * super.particleBlue);
      par1Tessellator.addVertexWithUV((double)(f11 - par3 * f10 - par6 * f10), (double)(f12 - par4 * f10), (double)(f13 - par5 * f10 - par7 * f10), (double)f6, (double)f9);
      par1Tessellator.addVertexWithUV((double)(f11 - par3 * f10 + par6 * f10), (double)(f12 + par4 * f10), (double)(f13 - par5 * f10 + par7 * f10), (double)f6, (double)f8);
      par1Tessellator.addVertexWithUV((double)(f11 + par3 * f10 + par6 * f10), (double)(f12 + par4 * f10), (double)(f13 + par5 * f10 + par7 * f10), (double)f7, (double)f8);
      par1Tessellator.addVertexWithUV((double)(f11 + par3 * f10 - par6 * f10), (double)(f12 - par4 * f10), (double)(f13 + par5 * f10 - par7 * f10), (double)f7, (double)f9);
   }
}

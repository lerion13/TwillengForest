package twilightforest.client.particle;

import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

public class EntityTFFireflyFX extends EntityFX {

   float fireflyParticleScale;
   int fireflyHalfLife;


   public EntityTFFireflyFX(World world, double d, double d1, double d2, float f, float f1, float f2) {
      this(world, d, d1, d2, 1.0F, f, f1, f2);
   }

   public EntityTFFireflyFX(World world, double d, double d1, double d2, float f, float f1, float f2, float f3) {
      super(world, d, d1, d2, 0.0D, 0.0D, 0.0D);
      super.motionX *= 2.100000001490116D;
      super.motionY *= 2.100000001490116D;
      super.motionZ *= 2.100000001490116D;
      if(f1 == 0.0F) {
         f1 = 1.0F;
      }

      super.particleRed = super.particleGreen = 1.0F * f;
      super.particleRed *= 0.9F;
      super.particleBlue = 0.0F;
      super.particleScale *= 1.0F;
      super.particleScale *= f;
      this.fireflyParticleScale = super.particleScale;
      super.particleMaxAge = (int)(32.0D / (Math.random() * 0.8D + 0.2D));
      super.particleMaxAge = (int)((float)super.particleMaxAge * f);
      this.fireflyHalfLife = super.particleMaxAge / 2;
      super.noClip = false;
   }

   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
      float f6 = (float)super.particleTextureIndexX / 16.0F;
      float f7 = f6 + 0.0624375F;
      float f8 = (float)super.particleTextureIndexY / 16.0F;
      float f9 = f8 + 0.0624375F;
      float f10 = 0.1F * super.particleScale;
      super.particleScale = this.fireflyParticleScale;
      GL11.glDisable(3008);
      GL11.glEnable(3042);
      GL11.glColorMask(true, true, true, true);
      GL11.glBlendFunc(770, 1);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
      float f11 = (float)(super.prevPosX + (super.posX - super.prevPosX) * (double)par2 - EntityFX.interpPosX);
      float f12 = (float)(super.prevPosY + (super.posY - super.prevPosY) * (double)par2 - EntityFX.interpPosY);
      float f13 = (float)(super.prevPosZ + (super.posZ - super.prevPosZ) * (double)par2 - EntityFX.interpPosZ);
      float f14 = 1.0F;
      par1Tessellator.setColorRGBA_F(super.particleRed * f14, super.particleGreen * f14, super.particleBlue * f14, super.particleAlpha);
      par1Tessellator.addVertexWithUV((double)(f11 - par3 * f10 - par6 * f10), (double)(f12 - par4 * f10), (double)(f13 - par5 * f10 - par7 * f10), (double)f7, (double)f9);
      par1Tessellator.addVertexWithUV((double)(f11 - par3 * f10 + par6 * f10), (double)(f12 + par4 * f10), (double)(f13 - par5 * f10 + par7 * f10), (double)f7, (double)f8);
      par1Tessellator.addVertexWithUV((double)(f11 + par3 * f10 + par6 * f10), (double)(f12 + par4 * f10), (double)(f13 + par5 * f10 + par7 * f10), (double)f6, (double)f8);
      par1Tessellator.addVertexWithUV((double)(f11 + par3 * f10 - par6 * f10), (double)(f12 - par4 * f10), (double)(f13 + par5 * f10 - par7 * f10), (double)f6, (double)f9);
      GL11.glDisable(3042);
      GL11.glEnable(3008);
   }

   public void onUpdate() {
      super.prevPosX = super.posX;
      super.prevPosY = super.posY;
      super.prevPosZ = super.posZ;
      if(super.particleAge++ >= super.particleMaxAge) {
         this.setDead();
      }

      if(super.particleAge < this.fireflyHalfLife) {
         this.setParticleTextureIndex(super.particleAge * 8 / this.fireflyHalfLife);
      } else {
         this.setParticleTextureIndex(7 - (super.particleAge - this.fireflyHalfLife) * 8 / super.particleMaxAge);
      }

      this.moveEntity(super.motionX, super.motionY, super.motionZ);
      if(super.posY == super.prevPosY) {
         super.motionX *= 1.1D;
         super.motionZ *= 1.1D;
      }

      super.motionX *= 0.9599999785423279D;
      super.motionY *= 0.9599999785423279D;
      super.motionZ *= 0.9599999785423279D;
      if(super.onGround) {
         super.motionX *= 0.699999988079071D;
         super.motionZ *= 0.699999988079071D;
      }

   }
}

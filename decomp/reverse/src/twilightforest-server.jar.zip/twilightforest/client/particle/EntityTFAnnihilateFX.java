package twilightforest.client.particle;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.world.World;
import twilightforest.item.ItemTFCubeOfAnnihilation;
import twilightforest.item.TFItems;

@SideOnly(Side.CLIENT)
public class EntityTFAnnihilateFX extends EntityFX {

   float initialParticleScale;


   public EntityTFAnnihilateFX(World par1World, double par2, double par4, double par6, double par8, double par10, double par12) {
      this(par1World, par2, par4, par6, par8, par10, par12, 1.0F);
   }

   public EntityTFAnnihilateFX(World par1World, double par2, double par4, double par6, double par8, double par10, double par12, float par14) {
      super(par1World, par2, par4, par6, 0.0D, 0.0D, 0.0D);
      super.motionX *= 0.10000000149011612D;
      super.motionY *= 0.10000000149011612D;
      super.motionZ *= 0.10000000149011612D;
      super.motionX += par8 * 0.4D;
      super.motionY += par10 * 0.4D;
      super.motionZ += par12 * 0.4D;
      super.particleRed = super.particleGreen = super.particleBlue = 1.0F;
      super.particleScale *= 0.75F;
      super.particleScale *= par14;
      this.initialParticleScale = super.particleScale;
      super.particleMaxAge = (int)(60.0D / (Math.random() * 0.8D + 0.6D));
      super.particleMaxAge = (int)((float)super.particleMaxAge * par14);
      super.noClip = false;
      this.setParticleIcon(((ItemTFCubeOfAnnihilation)TFItems.cubeOfAnnihilation).getAnnihilateIcon());
      this.onUpdate();
   }

   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
      super.renderParticle(par1Tessellator, par2, par3, par4, par5, par6, par7);
   }

   public void onUpdate() {
      super.prevPosX = super.posX;
      super.prevPosY = super.posY;
      super.prevPosZ = super.posZ;
      if(super.particleAge++ >= super.particleMaxAge) {
         this.setDead();
      }

      this.moveEntity(super.motionX, super.motionY, super.motionZ);
      super.motionX *= 0.9599999785423279D;
      super.motionY *= 0.9599999785423279D;
      super.motionZ *= 0.9599999785423279D;
      if(super.onGround) {
         super.motionX *= 0.699999988079071D;
         super.motionZ *= 0.699999988079071D;
      }

      super.particleScale = (float)((double)super.particleScale * 0.97D);
      if((double)super.particleScale < 0.4D) {
         this.setDead();
      }

      float blacken = 0.985F;
      super.particleRed *= blacken;
      super.particleGreen *= blacken;
      super.particleBlue *= blacken;
   }

   public int getBrightnessForRender(float par1) {
      return 15728880;
   }

   public int getFXLayer() {
      return 2;
   }
}

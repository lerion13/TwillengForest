package twilightforest.client.particle;

import net.minecraft.client.particle.EntityEnchantmentTableParticleFX;
import net.minecraft.world.World;

public class EntityTFLeafRuneFX extends EntityEnchantmentTableParticleFX {

   public EntityTFLeafRuneFX(World world, double x, double y, double z, double velX, double velY, double velZ) {
      super(world, x, y, z, velX, velY, velZ);
      super.particleScale = super.rand.nextFloat() + 1.0F;
      super.particleMaxAge += 10;
      super.particleGravity = 0.003F + super.rand.nextFloat() * 0.006F;
      super.noClip = false;
   }

   public void onUpdate() {
      super.prevPosX = super.posX;
      super.prevPosY = super.posY;
      super.prevPosZ = super.posZ;
      this.moveEntity(super.motionX, super.motionY, super.motionZ);
      super.motionY -= (double)super.particleGravity;
      if(super.particleAge++ >= super.particleMaxAge) {
         this.setDead();
      }

   }
}

package twilightforest.client.particle;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.particle.EntityFX;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.world.World;

@SideOnly(Side.CLIENT)
public class EntityTFGhastTrapFX extends EntityFX {

   float reddustParticleScale;
   private double originX;
   private double originY;
   private double originZ;


   public EntityTFGhastTrapFX(World par1World, double par2, double par4, double par6, double par8, double par9, double par10) {
      this(par1World, par2, par4, par6, 3.0F, par8, par9, par10);
   }

   public EntityTFGhastTrapFX(World par1World, double x, double y, double z, float scale, double mx, double my, double mz) {
      super(par1World, x + mx, y + my, z + mz, mx, my, mz);
      super.motionX = mx;
      super.motionY = my;
      super.motionZ = mz;
      this.originX = x;
      this.originY = y;
      this.originZ = z;
      float f4 = (float)Math.random() * 0.4F;
      super.particleGreen = ((float)(Math.random() * 0.20000000298023224D) + 0.8F) * f4;
      super.particleBlue = ((float)(Math.random() * 0.20000000298023224D) + 0.8F) * f4;
      super.particleRed = 1.0F;
      super.particleScale *= 0.75F;
      super.particleScale *= scale;
      this.reddustParticleScale = super.particleScale;
      super.particleMaxAge = (int)(10.0D / (Math.random() * 0.8D + 0.2D));
      super.noClip = false;
   }

   public void renderParticle(Tessellator par1Tessellator, float par2, float par3, float par4, float par5, float par6, float par7) {
      float f6 = ((float)super.particleAge + par2) / (float)super.particleMaxAge * 32.0F;
      if(f6 < 0.0F) {
         f6 = 0.0F;
      }

      if(f6 > 1.0F) {
         f6 = 1.0F;
      }

      super.particleScale = this.reddustParticleScale * f6;
      super.renderParticle(par1Tessellator, par2, par3, par4, par5, par6, par7);
   }

   public void onUpdate() {
      this.setParticleTextureIndex(7 - super.particleAge * 8 / super.particleMaxAge);
      super.prevPosX = super.posX;
      super.prevPosY = super.posY;
      super.prevPosZ = super.posZ;
      float proportion = (float)super.particleAge / (float)super.particleMaxAge;
      proportion = 1.0F - proportion;
      super.posX = this.originX + super.motionX * (double)proportion;
      super.posY = this.originY + super.motionY * (double)proportion;
      super.posZ = this.originZ + super.motionZ * (double)proportion;
      if(super.particleAge++ >= super.particleMaxAge) {
         this.setDead();
      }

   }
}

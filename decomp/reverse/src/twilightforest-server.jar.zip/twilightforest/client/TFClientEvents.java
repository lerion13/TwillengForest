package twilightforest.client;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import java.util.Random;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderLivingEvent.Post;
import org.lwjgl.opengl.GL11;
import twilightforest.item.ItemTFBowBase;

public class TFClientEvents {

   private Random random = new Random();


   @SubscribeEvent
   public void renderLivingPost(Post event) {
      if(event.entity.getDataWatcher().getWatchableObjectInt(7) == Potion.potionTypes[Potion.moveSlowdown.getId()].getLiquidColor() && event.entity.getDataWatcher().getWatchableObjectByte(8) > 0) {
         this.renderIcedEntity(event.entity, event.renderer, event.x, event.y, event.z);
      }

   }

   @SubscribeEvent
   public void fovUpdate(FOVUpdateEvent event) {
      if(event.entity.isUsingItem() && event.entity.getItemInUse().getItem() instanceof ItemTFBowBase) {
         int i = event.entity.getItemInUseDuration();
         float f1 = (float)i / 20.0F;
         if(f1 > 1.0F) {
            f1 = 1.0F;
         } else {
            f1 *= f1;
         }

         event.newfov *= 1.0F - f1 * 0.15F;
      }

   }

   private void renderIcedEntity(EntityLivingBase entity, RendererLivingEntity renderer, double x, double y, double z) {
      GL11.glEnable(3042);
      GL11.glBlendFunc(770, 771);
      RenderManager.instance.renderEngine.bindTexture(TextureMap.locationBlocksTexture);
      this.random.setSeed((long)(entity.getEntityId() * entity.getEntityId() * 3121 + entity.getEntityId() * 45238971));
      int numCubes = (int)(entity.height / 0.4F);

      for(int i = 0; i < numCubes; ++i) {
         GL11.glPushMatrix();
         float dx = (float)(x + this.random.nextGaussian() * 0.20000000298023224D * (double)entity.width);
         float dy = (float)(y + this.random.nextGaussian() * 0.20000000298023224D * (double)entity.height) + entity.height / 2.0F;
         float dz = (float)(z + this.random.nextGaussian() * 0.20000000298023224D * (double)entity.width);
         GL11.glTranslatef(dx, dy, dz);
         GL11.glScalef(0.5F, 0.5F, 0.5F);
         GL11.glRotatef(this.random.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
         GL11.glRotatef(this.random.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
         GL11.glRotatef(this.random.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
         RenderBlocks.getInstance().renderBlockAsItem(Blocks.ice, 0, 1.0F);
         GL11.glPopMatrix();
      }

      GL11.glDisable(3042);
   }
}

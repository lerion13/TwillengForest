package twilightforest.client.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import org.lwjgl.opengl.GL11;
import twilightforest.TFMazeMapData;
import twilightforest.item.ItemTFMazeMap;
import twilightforest.item.TFItems;

public class TFMazeMapRenderer implements IItemRenderer {

   private static final ResourceLocation mapBackgroundTextures = new ResourceLocation("textures/map/map_background.png");


   public TFMazeMapRenderer(GameSettings gameSettings, TextureManager textureManager) {}

   public boolean handleRenderType(ItemStack item, ItemRenderType type) {
      return (item.getItem() == TFItems.mazeMap || item.getItem() == TFItems.oreMap) && RenderItem.renderInFrame && type == ItemRenderType.ENTITY;
   }

   public boolean shouldUseRenderHelper(ItemRenderType type, ItemStack item, ItemRendererHelper helper) {
      return false;
   }

   public void renderItem(ItemRenderType type, ItemStack item, Object ... data) {
      if(RenderItem.renderInFrame) {
         EntityItem entity = (EntityItem)data[1];
         TFMazeMapData mapData = ((ItemTFMazeMap)TFItems.mazeMap).getMapData(item, entity.worldObj);
         if(mapData != null) {
            this.renderMapInFrame(item, RenderManager.instance, mapData);
         }
      }

   }

   private void renderMapInFrame(ItemStack item, RenderManager renderManager, TFMazeMapData mapData) {
      GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
      GL11.glScalef(0.0078125F, 0.0078125F, 0.0078125F);
      GL11.glTranslatef(-65.0F, -111.0F, -3.0F);
      GL11.glNormal3f(0.0F, 0.0F, -1.0F);
      renderManager.renderEngine.bindTexture(mapBackgroundTextures);
      Tessellator tessellator = Tessellator.instance;
      tessellator.startDrawingQuads();
      byte b0 = 7;
      tessellator.addVertexWithUV((double)(0 - b0), (double)(128 + b0), 0.0D, 0.0D, 1.0D);
      tessellator.addVertexWithUV((double)(128 + b0), (double)(128 + b0), 0.0D, 1.0D, 1.0D);
      tessellator.addVertexWithUV((double)(128 + b0), (double)(0 - b0), 0.0D, 1.0D, 0.0D);
      tessellator.addVertexWithUV((double)(0 - b0), (double)(0 - b0), 0.0D, 0.0D, 0.0D);
      tessellator.draw();
      GL11.glTranslatef(0.0F, 0.0F, -1.0F);
      Minecraft.getMinecraft().entityRenderer.getMapItemRenderer().func_148250_a(mapData, false);
   }

}

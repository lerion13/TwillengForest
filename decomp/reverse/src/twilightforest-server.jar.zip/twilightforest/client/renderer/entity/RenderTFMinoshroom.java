package twilightforest.client.renderer.entity;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderTFMinoshroom extends RenderBiped {

   private static final ResourceLocation textureLoc = new ResourceLocation("twilightforest:textures/model/minoshroomtaur.png");


   public RenderTFMinoshroom(ModelBiped par1ModelBase, float par2) {
      super(par1ModelBase, par2);
   }

   protected void renderMooshroomEquippedItems(EntityLivingBase par1EntityLiving, float par2) {
      super.renderEquippedItems(par1EntityLiving, par2);
      this.bindTexture(TextureMap.locationBlocksTexture);
      GL11.glEnable(2884);
      GL11.glPushMatrix();
      GL11.glScalef(1.0F, -1.0F, 1.0F);
      GL11.glTranslatef(0.2F, 0.375F, 0.5F);
      GL11.glRotatef(42.0F, 0.0F, 1.0F, 0.0F);
      super.field_147909_c.renderBlockAsItem(Blocks.red_mushroom, 0, 1.0F);
      GL11.glTranslatef(0.1F, 0.0F, -0.6F);
      GL11.glRotatef(42.0F, 0.0F, 1.0F, 0.0F);
      super.field_147909_c.renderBlockAsItem(Blocks.red_mushroom, 0, 1.0F);
      GL11.glPopMatrix();
      GL11.glPushMatrix();
      ((ModelBiped)super.mainModel).bipedHead.postRender(0.0625F);
      GL11.glScalef(1.0F, -1.0F, 1.0F);
      GL11.glTranslatef(0.0F, 1.0F, 0.0F);
      GL11.glRotatef(12.0F, 0.0F, 1.0F, 0.0F);
      super.field_147909_c.renderBlockAsItem(Blocks.red_mushroom, 0, 1.0F);
      GL11.glPopMatrix();
      GL11.glDisable(2884);
   }

   protected void renderEquippedItems(EntityLivingBase par1EntityLiving, float par2) {
      this.renderMooshroomEquippedItems(par1EntityLiving, par2);
   }

   protected ResourceLocation getEntityTexture(Entity par1Entity) {
      return textureLoc;
   }

}

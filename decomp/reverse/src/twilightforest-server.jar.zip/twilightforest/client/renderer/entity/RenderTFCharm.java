package twilightforest.client.renderer.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.util.IIcon;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import twilightforest.entity.EntityTFCharmEffect;
import twilightforest.item.TFItems;

@SideOnly(Side.CLIENT)
public class RenderTFCharm extends Render {

   private IIcon itemIcon;


   public RenderTFCharm(IIcon par1) {
      this.itemIcon = par1;
   }

   public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9) {
      if(par1Entity instanceof EntityTFCharmEffect) {
         EntityTFCharmEffect var10 = (EntityTFCharmEffect)par1Entity;
         if(var10.getItemID() > 0) {
            this.itemIcon = TFItems.charmOfKeeping1.getIconFromDamage(0);
         }
      }

      GL11.glPushMatrix();
      GL11.glTranslatef((float)par2, (float)par4, (float)par6);
      GL11.glEnable('\u803a');
      GL11.glScalef(0.5F, 0.5F, 0.5F);
      this.bindEntityTexture(par1Entity);
      Tessellator var101 = Tessellator.instance;
      this.func_77026_a(var101, this.itemIcon);
      GL11.glDisable('\u803a');
      GL11.glPopMatrix();
   }

   private void func_77026_a(Tessellator par1Tessellator, IIcon par2Icon) {
      float f = par2Icon.getMinU();
      float f1 = par2Icon.getMaxU();
      float f2 = par2Icon.getMinV();
      float f3 = par2Icon.getMaxV();
      float f4 = 1.0F;
      float f5 = 0.5F;
      float f6 = 0.25F;
      GL11.glRotatef(180.0F - super.renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(-super.renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
      par1Tessellator.startDrawingQuads();
      par1Tessellator.setNormal(0.0F, 1.0F, 0.0F);
      par1Tessellator.addVertexWithUV((double)(0.0F - f5), (double)(0.0F - f6), 0.0D, (double)f, (double)f3);
      par1Tessellator.addVertexWithUV((double)(f4 - f5), (double)(0.0F - f6), 0.0D, (double)f1, (double)f3);
      par1Tessellator.addVertexWithUV((double)(f4 - f5), (double)(f4 - f6), 0.0D, (double)f1, (double)f2);
      par1Tessellator.addVertexWithUV((double)(0.0F - f5), (double)(f4 - f6), 0.0D, (double)f, (double)f2);
      par1Tessellator.draw();
   }

   protected ResourceLocation getEntityTexture(Entity par1Entity) {
      return TextureMap.locationItemsTexture;
   }
}

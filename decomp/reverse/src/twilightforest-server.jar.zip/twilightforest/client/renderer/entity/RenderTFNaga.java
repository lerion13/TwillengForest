package twilightforest.client.renderer.entity;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.util.ResourceLocation;
import twilightforest.entity.boss.EntityTFNaga;

public class RenderTFNaga extends RenderLiving {

   private static final ResourceLocation textureLoc = new ResourceLocation("twilightforest:textures/model/nagahead.png");


   public RenderTFNaga(ModelBase modelbase, float f) {
      super(modelbase, f);
   }

   public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
      super.doRender(entity, d, d1, d2, f, f1);
      if(entity instanceof EntityTFNaga && ((EntityTFNaga)entity).getParts() != null) {
         EntityTFNaga naga = (EntityTFNaga)entity;

         for(int i = 0; i < naga.getParts().length; ++i) {
            if(!naga.getParts()[i].isDead) {
               RenderManager.instance.renderEntitySimple(naga.getParts()[i], f1);
            }
         }

         BossStatus.setBossStatus(naga, false);
      }

   }

   protected ResourceLocation getEntityTexture(Entity par1Entity) {
      return textureLoc;
   }

}

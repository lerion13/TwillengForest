package twilightforest.client.renderer.entity;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;
import twilightforest.entity.boss.EntityTFSnowQueenIceShield;

public class RenderTFSnowQueenIceShield extends Render {

   private final RenderBlocks renderBlocks = new RenderBlocks();


   public void doRender(Entity var1, double var2, double var4, double var6, float var8, float var9) {
      this.doRender((EntityTFSnowQueenIceShield)var1, var2, var4, var6, var8, var9);
   }

   public void doRender(EntityTFSnowQueenIceShield entity, double x, double y, double z, float p_147918_8_, float p_147918_9_) {
      World world = entity.worldObj;
      Block block = Blocks.packed_ice;
      int i = MathHelper.floor_double(entity.posX);
      int j = MathHelper.floor_double(entity.posY);
      int k = MathHelper.floor_double(entity.posZ);
      if(block != null && block != world.getBlock(i, j, k)) {
         GL11.glPushMatrix();
         GL11.glTranslatef((float)x, (float)y, (float)z);
         this.bindEntityTexture(entity);
         GL11.glDisable(2896);
         this.renderBlocks.setRenderBoundsFromBlock(block);
         this.renderBlocks.renderBlockSandFalling(block, world, i, j, k, 0);
         GL11.glEnable(2896);
         GL11.glPopMatrix();
      }

   }

   protected ResourceLocation getEntityTexture(Entity var1) {
      return TextureMap.locationBlocksTexture;
   }
}

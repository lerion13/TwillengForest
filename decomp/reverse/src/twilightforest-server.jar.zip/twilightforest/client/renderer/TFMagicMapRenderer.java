package twilightforest.client.renderer;

import java.util.Iterator;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.storage.MapData;
import net.minecraft.world.storage.MapData.MapCoord;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.IItemRenderer.ItemRenderType;
import net.minecraftforge.client.IItemRenderer.ItemRendererHelper;
import org.lwjgl.opengl.GL11;
import twilightforest.TFMagicMapData;
import twilightforest.item.ItemTFMagicMap;
import twilightforest.item.TFItems;

public class TFMagicMapRenderer implements IItemRenderer {

   private static final ResourceLocation vanillaMapIcons = new ResourceLocation("textures/map/map_icons.png");
   private static final ResourceLocation twilightMapIcons = new ResourceLocation("twilightforest:textures/gui/mapicons.png");
   private static final ResourceLocation mapBackgroundTextures = new ResourceLocation("textures/map/map_background.png");
   private int[] intArray = new int[16384];
   private DynamicTexture bufferedImage = new DynamicTexture(128, 128);
   private final ResourceLocation textureLoc;


   public TFMagicMapRenderer(GameSettings par1GameSettings, TextureManager par2TextureManager) {
      this.textureLoc = par2TextureManager.getDynamicTextureLocation("map", this.bufferedImage);
      this.intArray = this.bufferedImage.getTextureData();

      for(int i = 0; i < this.intArray.length; ++i) {
         this.intArray[i] = 0;
      }

   }

   public boolean handleRenderType(ItemStack item, ItemRenderType type) {
      return item.getItem() == TFItems.magicMap && (type == ItemRenderType.FIRST_PERSON_MAP || RenderItem.renderInFrame && type == ItemRenderType.ENTITY);
   }

   public boolean shouldUseRenderHelper(ItemRenderType type, ItemStack item, ItemRendererHelper helper) {
      return false;
   }

   public void renderItem(ItemRenderType type, ItemStack item, Object ... data) {
      if(type == ItemRenderType.FIRST_PERSON_MAP) {
         EntityPlayer entity = (EntityPlayer)data[0];
         TextureManager mapData = (TextureManager)data[1];
         MapData mapData1 = (MapData)data[2];
         if(mapData1 != null && mapData1 instanceof TFMagicMapData) {
            this.renderMap(entity, mapData, (TFMagicMapData)mapData1);
         }
      } else if(RenderItem.renderInFrame) {
         EntityItem entity1 = (EntityItem)data[1];
         TFMagicMapData mapData2 = ((ItemTFMagicMap)TFItems.magicMap).getMapData(item, entity1.worldObj);
         if(mapData2 != null) {
            this.renderMapInFrame(item, RenderManager.instance, mapData2);
         }
      }

   }

   public void renderMap(EntityPlayer par1EntityPlayer, TextureManager par2TextureManager, TFMagicMapData par3MapData) {
      for(int var15 = 0; var15 < 16384; ++var15) {
         int var16 = par3MapData.colors[var15] & 255;
         if(var16 == 0) {
            this.intArray[var15] = (var15 + var15 / 128 & 1) * 8 + 16 << 24;
         } else {
            int tesselator = var16 - 1;
            BiomeGenBase var18 = BiomeGenBase.getBiomeGenArray()[tesselator];
            if(var18 != null) {
               this.intArray[var15] = -16777216 | var18.color;
            }
         }
      }

      this.bufferedImage.updateDynamicTexture();
      byte var151 = 0;
      byte var161 = 0;
      Tessellator var17 = Tessellator.instance;
      float var181 = 0.0F;
      par2TextureManager.bindTexture(this.textureLoc);
      GL11.glEnable(3042);
      GL11.glBlendFunc(1, 771);
      GL11.glDisable(3008);
      var17.startDrawingQuads();
      var17.addVertexWithUV((double)((float)(var151 + 0) + var181), (double)((float)(var161 + 128) - var181), -0.009999999776482582D, 0.0D, 1.0D);
      var17.addVertexWithUV((double)((float)(var151 + 128) - var181), (double)((float)(var161 + 128) - var181), -0.009999999776482582D, 1.0D, 1.0D);
      var17.addVertexWithUV((double)((float)(var151 + 128) - var181), (double)((float)(var161 + 0) + var181), -0.009999999776482582D, 1.0D, 0.0D);
      var17.addVertexWithUV((double)((float)(var151 + 0) + var181), (double)((float)(var161 + 0) + var181), -0.009999999776482582D, 0.0D, 0.0D);
      var17.draw();
      GL11.glEnable(3008);
      GL11.glDisable(3042);
      par2TextureManager.bindTexture(vanillaMapIcons);
      Iterator var9 = par3MapData.playersVisibleOnMap.values().iterator();

      MapCoord mapCoord;
      float var21;
      float var23;
      float var22;
      float var24;
      while(var9.hasNext()) {
         mapCoord = (MapCoord)var9.next();
         GL11.glPushMatrix();
         GL11.glTranslatef((float)var151 + (float)mapCoord.centerX / 2.0F + 64.0F, (float)var161 + (float)mapCoord.centerZ / 2.0F + 64.0F, -0.04F);
         GL11.glRotatef((float)(mapCoord.iconRotation * 360) / 16.0F, 0.0F, 0.0F, 1.0F);
         GL11.glScalef(4.0F, 4.0F, 3.0F);
         GL11.glTranslatef(-0.125F, 0.125F, 0.0F);
         var21 = (float)(mapCoord.iconSize % 4 + 0) / 4.0F;
         var23 = (float)(mapCoord.iconSize / 4 + 0) / 4.0F;
         var22 = (float)(mapCoord.iconSize % 4 + 1) / 4.0F;
         var24 = (float)(mapCoord.iconSize / 4 + 1) / 4.0F;
         var17.startDrawingQuads();
         var17.addVertexWithUV(-1.0D, 1.0D, 0.0D, (double)var21, (double)var23);
         var17.addVertexWithUV(1.0D, 1.0D, 0.0D, (double)var22, (double)var23);
         var17.addVertexWithUV(1.0D, -1.0D, 0.0D, (double)var22, (double)var24);
         var17.addVertexWithUV(-1.0D, -1.0D, 0.0D, (double)var21, (double)var24);
         var17.draw();
         GL11.glPopMatrix();
      }

      par2TextureManager.bindTexture(twilightMapIcons);
      var9 = par3MapData.featuresVisibleOnMap.iterator();

      while(var9.hasNext()) {
         mapCoord = (MapCoord)var9.next();
         GL11.glPushMatrix();
         GL11.glTranslatef((float)var151 + (float)mapCoord.centerX / 2.0F + 64.0F, (float)var161 + (float)mapCoord.centerZ / 2.0F + 64.0F, -0.02F);
         GL11.glRotatef((float)(mapCoord.iconRotation * 360) / 16.0F, 0.0F, 0.0F, 1.0F);
         GL11.glScalef(4.0F, 4.0F, 3.0F);
         GL11.glTranslatef(-0.125F, 0.125F, 0.0F);
         var21 = (float)(mapCoord.iconSize % 8 + 0) / 8.0F;
         var23 = (float)(mapCoord.iconSize / 8 + 0) / 8.0F;
         var22 = (float)(mapCoord.iconSize % 8 + 1) / 8.0F;
         var24 = (float)(mapCoord.iconSize / 8 + 1) / 8.0F;
         var17.startDrawingQuads();
         var17.addVertexWithUV(-1.0D, 1.0D, 0.0D, (double)var21, (double)var23);
         var17.addVertexWithUV(1.0D, 1.0D, 0.0D, (double)var22, (double)var23);
         var17.addVertexWithUV(1.0D, -1.0D, 0.0D, (double)var22, (double)var24);
         var17.addVertexWithUV(-1.0D, -1.0D, 0.0D, (double)var21, (double)var24);
         var17.draw();
         GL11.glPopMatrix();
      }

   }

   private void renderMapInFrame(ItemStack item, RenderManager renderManager, TFMagicMapData mapData) {
      GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);
      GL11.glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
      GL11.glScalef(0.0078125F, 0.0078125F, 0.0078125F);
      GL11.glTranslatef(-65.0F, -111.0F, -3.0F);
      GL11.glNormal3f(0.0F, 0.0F, -1.0F);
      renderManager.renderEngine.bindTexture(mapBackgroundTextures);
      Tessellator tessellator = Tessellator.instance;
      tessellator.startDrawingQuads();
      byte b0 = 7;
      tessellator.addVertexWithUV((double)(0 - b0), (double)(128 + b0), 0.0D, 0.0D, 1.0D);
      tessellator.addVertexWithUV((double)(128 + b0), (double)(128 + b0), 0.0D, 1.0D, 1.0D);
      tessellator.addVertexWithUV((double)(128 + b0), (double)(0 - b0), 0.0D, 1.0D, 0.0D);
      tessellator.addVertexWithUV((double)(0 - b0), (double)(0 - b0), 0.0D, 0.0D, 0.0D);
      tessellator.draw();
      GL11.glTranslatef(0.0F, 0.0F, -1.0F);
      this.renderMap((EntityPlayer)null, renderManager.renderEngine, mapData);
   }

}

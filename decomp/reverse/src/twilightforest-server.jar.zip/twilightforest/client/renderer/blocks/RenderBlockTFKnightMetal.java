package twilightforest.client.renderer.blocks;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.world.IBlockAccess;
import org.lwjgl.opengl.GL11;

public class RenderBlockTFKnightMetal implements ISimpleBlockRenderingHandler {

   final int renderID;


   public RenderBlockTFKnightMetal(int blockComplexRenderID) {
      this.renderID = blockComplexRenderID;
   }

   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {
      renderInvJar(renderer, block, metadata);
   }

   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
      return renderSpikeBlock(renderer, world, x, y, z, block);
   }

   public boolean shouldRender3DInInventory(int modelId) {
      return true;
   }

   public int getRenderId() {
      return this.renderID;
   }

   public static boolean renderSpikeBlock(RenderBlocks renderblocks, IBlockAccess world, int x, int y, int z, Block block) {
      float p = 0.0625F;
      float a = 9.765625E-4F;
      float p4 = 0.25F - a;

      for(int rx = 0; rx < 3; ++rx) {
         for(int ry = 0; ry < 3; ++ry) {
            for(int rz = 0; rz < 3; ++rz) {
               renderblocks.setRenderBounds((double)((float)rx * 6.0F * p + a), (double)((float)ry * 6.0F * p + a), (double)((float)rz * 6.0F * p + a), (double)((float)rx * 6.0F * p + p4), (double)((float)ry * 6.0F * p + p4), (double)((float)rz * 6.0F * p + p4));
               renderblocks.renderStandardBlock(block, x, y, z);
            }
         }
      }

      renderblocks.setRenderBounds((double)p, (double)p, (double)p, (double)(15.0F * p), (double)(15.0F * p), (double)(15.0F * p));
      renderblocks.renderStandardBlock(block, x, y, z);
      block.setBlockBoundsForItemRender();
      return true;
   }

   public static void renderInvJar(RenderBlocks renderblocks, Block par1Block, int meta) {
      Tessellator tessellator = Tessellator.instance;
      GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
      GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
      float p = 0.0625F;
      float a = 9.765625E-4F;
      float p4 = 0.25F - a;

      for(int rx = 0; rx < 3; ++rx) {
         for(int ry = 0; ry < 3; ++ry) {
            for(int rz = 0; rz < 3; ++rz) {
               renderblocks.setRenderBounds((double)((float)rx * 6.0F * p + a), (double)((float)ry * 6.0F * p + a), (double)((float)rz * 6.0F * p + a), (double)((float)rx * 6.0F * p + p4), (double)((float)ry * 6.0F * p + p4), (double)((float)rz * 6.0F * p + p4));
               renderInvBlock(renderblocks, par1Block, meta, tessellator);
            }
         }
      }

      renderblocks.setRenderBounds((double)p, (double)p, (double)p, (double)(15.0F * p), (double)(15.0F * p), (double)(15.0F * p));
      renderInvBlock(renderblocks, par1Block, meta, tessellator);
      GL11.glTranslatef(0.5F, 0.5F, 0.5F);
      par1Block.setBlockBoundsForItemRender();
   }

   protected static void renderInvBlock(RenderBlocks renderblocks, Block par1Block, int meta, Tessellator tessellator) {
      tessellator.startDrawingQuads();
      tessellator.setNormal(0.0F, -1.0F, 0.0F);
      renderblocks.renderFaceYNeg(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(0, meta));
      tessellator.draw();
      tessellator.startDrawingQuads();
      tessellator.setNormal(0.0F, 1.0F, 0.0F);
      renderblocks.renderFaceYPos(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(1, meta));
      tessellator.draw();
      tessellator.startDrawingQuads();
      tessellator.setNormal(0.0F, 0.0F, -1.0F);
      renderblocks.renderFaceXPos(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(2, meta));
      tessellator.draw();
      tessellator.startDrawingQuads();
      tessellator.setNormal(0.0F, 0.0F, 1.0F);
      renderblocks.renderFaceXNeg(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(3, meta));
      tessellator.draw();
      tessellator.startDrawingQuads();
      tessellator.setNormal(-1.0F, 0.0F, 0.0F);
      renderblocks.renderFaceZNeg(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(4, meta));
      tessellator.draw();
      tessellator.startDrawingQuads();
      tessellator.setNormal(1.0F, 0.0F, 0.0F);
      renderblocks.renderFaceZPos(par1Block, 0.0D, 0.0D, 0.0D, par1Block.getIcon(5, meta));
      tessellator.draw();
   }
}

package twilightforest.client.renderer.blocks;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.world.IBlockAccess;

public class RenderBlockTFHugeLilyPad implements ISimpleBlockRenderingHandler {

   final int renderID;


   public RenderBlockTFHugeLilyPad(int blockComplexRenderID) {
      this.renderID = blockComplexRenderID;
   }

   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}

   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
      int meta = world.getBlockMetadata(x, y, z);
      this.setRenderRotate(renderer, meta);
      boolean didRender = renderer.renderStandardBlock(block, x, y, z);
      this.restoreRendererRotate(renderer);
      return didRender;
   }

   private void restoreRendererRotate(RenderBlocks renderer) {
      renderer.uvRotateSouth = 0;
      renderer.uvRotateEast = 0;
      renderer.uvRotateWest = 0;
      renderer.uvRotateNorth = 0;
      renderer.uvRotateTop = 0;
      renderer.uvRotateBottom = 0;
   }

   private void setRenderRotate(RenderBlocks renderer, int meta) {
      int orient = meta >> 2;
      if(orient == 2) {
         orient = 3;
      } else if(orient == 3) {
         orient = 2;
      }

      renderer.uvRotateTop = orient;
      renderer.uvRotateBottom = orient;
   }

   public boolean shouldRender3DInInventory(int modelId) {
      return false;
   }

   public int getRenderId() {
      return this.renderID;
   }
}

package twilightforest.client.renderer.blocks;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.world.IBlockAccess;
import twilightforest.block.BlockTFPlant;

public class RenderBlockTFPlants implements ISimpleBlockRenderingHandler {

   final int renderID;


   public RenderBlockTFPlants(int blockRenderID) {
      this.renderID = blockRenderID;
   }

   public void renderInventoryBlock(Block block, int metadata, int modelID, RenderBlocks renderer) {}

   public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {
      int meta = world.getBlockMetadata(x, y, z);
      if(meta == 3) {
         this.renderMossPatch(x, y, z, block, renderer);
      } else if(meta == 5) {
         this.renderCloverPatch(x, y, z, block, renderer);
      } else if(meta == 4) {
         this.renderMayapple(x, y, z, block, renderer);
      } else if(meta == 14) {
         renderer.renderBlockCrops(block, x, y, z);
      } else {
         renderer.renderCrossedSquares(block, x, y, z);
      }

      return true;
   }

   private void renderMayapple(int x, int y, int z, Block block, RenderBlocks renderer) {
      renderer.clearOverrideBlockTexture();
      renderer.setRenderBounds(0.25D, 0.375D, 0.25D, 0.8125D, 0.375D, 0.8125D);
      renderer.renderStandardBlock(block, x, y, z);
      renderer.overrideBlockTexture = BlockTFPlant.mayappleSide;
      renderer.setRenderBounds(0.5D, 0.0D, 0.5D, 0.5625D, 0.37437498569488525D, 0.5625D);
      renderer.renderStandardBlock(block, x, y, z);
      renderer.clearOverrideBlockTexture();
   }

   private void renderCloverPatch(int x, int y, int z, Block block, RenderBlocks renderer) {
      renderer.renderMinY = renderer.renderMaxY;
      renderer.renderStandardBlock(block, x, y, z);
      renderer.renderMinY = 0.0D;
      renderer.renderMaxY -= 0.009999999776482582D;
      renderer.renderMinX += 0.0625D;
      renderer.renderMinZ += 0.0625D;
      renderer.renderMaxX -= 0.0625D;
      renderer.renderMaxZ -= 0.0625D;
      renderer.renderStandardBlock(block, x, y, z);
   }

   private void renderMossPatch(int x, int y, int z, Block block, RenderBlocks renderer) {
      renderer.renderStandardBlock(block, x, y, z);
      double originalMaxX;
      long seed;
      int num0;
      int num1;
      int num2;
      int num3;
      if(renderer.renderMinX > 0.0D) {
         originalMaxX = renderer.renderMaxZ;
         seed = (long)(x * 3129871) ^ (long)y * 116129781L ^ (long)z;
         seed = seed * seed * 42317861L + seed * 7L;
         num0 = (int)(seed >> 12 & 3L) + 1;
         num1 = (int)(seed >> 15 & 3L) + 1;
         num2 = (int)(seed >> 18 & 3L) + 1;
         num3 = (int)(seed >> 21 & 3L) + 1;
         renderer.renderMaxX = renderer.renderMinX;
         renderer.renderMinX -= 0.0625D;
         renderer.renderMinZ += (double)((float)num0 / 16.0F);
         if(renderer.renderMaxZ - (double)((float)(num1 + num2 + num3) / 16.0F) > renderer.renderMinZ) {
            renderer.renderMaxZ = renderer.renderMinZ + (double)((float)num1 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
            renderer.renderMaxZ = originalMaxX - (double)((float)num2 / 16.0F);
            renderer.renderMinZ = renderer.renderMaxZ - (double)((float)num3 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
         } else {
            renderer.renderMaxZ -= (double)((float)num2 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
         }

         renderer.setRenderBoundsFromBlock(block);
      }

      if(renderer.renderMaxX < 1.0D) {
         originalMaxX = renderer.renderMaxZ;
         seed = (long)(x * 3129871) ^ (long)y * 116129781L ^ (long)z;
         seed = seed * seed * 42317861L + seed * 17L;
         num0 = (int)(seed >> 12 & 3L) + 1;
         num1 = (int)(seed >> 15 & 3L) + 1;
         num2 = (int)(seed >> 18 & 3L) + 1;
         num3 = (int)(seed >> 21 & 3L) + 1;
         renderer.renderMinX = renderer.renderMaxX;
         renderer.renderMaxX += 0.0625D;
         renderer.renderMinZ += (double)((float)num0 / 16.0F);
         if(renderer.renderMaxZ - (double)((float)(num1 + num2 + num3) / 16.0F) > renderer.renderMinZ) {
            renderer.renderMaxZ = renderer.renderMinZ + (double)((float)num1 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
            renderer.renderMaxZ = originalMaxX - (double)((float)num2 / 16.0F);
            renderer.renderMinZ = renderer.renderMaxZ - (double)((float)num3 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
         } else {
            renderer.renderMaxZ -= (double)((float)num2 / 16.0F);
            renderer.renderStandardBlock(block, x, y, z);
         }

         renderer.setRenderBoundsFromBlock(block);
      }

      if(renderer.renderMinZ > 0.0D) {
         originalMaxX = renderer.renderMaxX;
         seed = (long)(x * 3129871) ^ (long)y * 116129781L ^ (long)z;
         seed = seed * seed * 42317861L + seed * 23L;
         num0 = (int)(seed >> 12 & 3L) + 1;
         num1 = (int)(seed >> 15 & 3L) + 1;
         num2 = (int)(seed >> 18 & 3L) + 1;
         num3 = (int)(seed >> 21 & 3L) + 1;
         renderer.renderMaxZ = renderer.renderMinZ;
         renderer.renderMinZ -= 0.0625D;
         renderer.renderMinX += (double)((float)num0 / 16.0F);
         renderer.renderMaxX = renderer.renderMinX + (double)((float)num1 / 16.0F);
         renderer.renderStandardBlock(block, x, y, z);
         renderer.renderMaxX = originalMaxX - (double)((float)num2 / 16.0F);
         renderer.renderMinX = renderer.renderMaxX - (double)((float)num3 / 16.0F);
         renderer.renderStandardBlock(block, x, y, z);
         renderer.setRenderBoundsFromBlock(block);
      }

      if(renderer.renderMaxZ < 1.0D) {
         originalMaxX = renderer.renderMaxX;
         seed = (long)(x * 3129871) ^ (long)y * 116129781L ^ (long)z;
         seed = seed * seed * 42317861L + seed * 11L;
         num0 = (int)(seed >> 12 & 3L) + 1;
         num1 = (int)(seed >> 15 & 3L) + 1;
         num2 = (int)(seed >> 18 & 3L) + 1;
         num3 = (int)(seed >> 21 & 3L) + 1;
         renderer.renderMinZ = renderer.renderMaxZ;
         renderer.renderMaxZ += 0.0625D;
         renderer.renderMinX += (double)((float)num0 / 16.0F);
         renderer.renderMaxX = renderer.renderMinX + (double)((float)num1 / 16.0F);
         renderer.renderStandardBlock(block, x, y, z);
         renderer.renderMaxX = originalMaxX - (double)((float)num2 / 16.0F);
         renderer.renderMinX = renderer.renderMaxX - (double)((float)num3 / 16.0F);
         renderer.renderStandardBlock(block, x, y, z);
         renderer.setRenderBoundsFromBlock(block);
      }

   }

   public boolean shouldRender3DInInventory(int modelId) {
      return false;
   }

   public int getRenderId() {
      return this.renderID;
   }
}

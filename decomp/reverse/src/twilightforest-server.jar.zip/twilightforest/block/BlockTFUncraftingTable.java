package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.item.TFItems;

public class BlockTFUncraftingTable extends Block {

   public static IIcon tinkerTop;
   public static IIcon tinkerSide;


   protected BlockTFUncraftingTable() {
      super(Material.wood);
      this.setHardness(2.5F);
      this.setStepSound(Block.soundTypeWood);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public IIcon getIcon(int side, int meta) {
      return side == 1?tinkerTop:tinkerSide;
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      tinkerTop = par1IconRegister.registerIcon("TwilightForest:uncrafting_top");
      tinkerSide = par1IconRegister.registerIcon("TwilightForest:uncrafting_side");
   }

   public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int par6, float par7, float par8, float par9) {
      player.openGui(TwilightForestMod.instance, 1, world, x, y, z);
      return true;
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
   }
}

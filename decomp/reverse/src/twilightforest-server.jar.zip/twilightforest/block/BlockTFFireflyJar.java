package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.entity.passive.EntityTFTinyFirefly;
import twilightforest.item.TFItems;

public class BlockTFFireflyJar extends Block {

   public static IIcon jarTop;
   public static IIcon jarSide;
   public static IIcon jarCork;


   protected BlockTFFireflyJar() {
      super(Material.glass);
      this.setBlockBounds(0.1875F, 0.0F, 0.1875F, 0.8125F, 1.0F, 0.8125F);
      this.setHardness(0.3F);
      this.setStepSound(Block.soundTypeWood);
      this.setCreativeTab(TFItems.creativeTab);
      this.setLightLevel(1.0F);
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public int getRenderType() {
      return TwilightForestMod.proxy.getComplexBlockRenderID();
   }

   public IIcon getIcon(int side, int meta) {
      return side != 1 && side != 0?jarSide:jarTop;
   }

   public int getLightValue(IBlockAccess world, int x, int y, int z) {
      return 15;
   }

   public boolean isBlockNormalCube(World world, int x, int y, int z) {
      return false;
   }

   public void setBlockBoundsBasedOnState(IBlockAccess world, int x, int y, int z) {
      this.setBlockBounds(0.1875F, 0.0F, 0.1875F, 0.8125F, 1.0F, 0.8125F);
   }

   public void setBlockBoundsForItemRender() {
      this.setBlockBounds(0.1875F, 0.0F, 0.1875F, 0.8125F, 1.0F, 0.8125F);
   }

   @SideOnly(Side.CLIENT)
   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {
      double dx = (double)((float)x + (rand.nextFloat() - rand.nextFloat()) * 0.3F + 0.5F);
      double dy = (double)((float)y - 0.1F + (rand.nextFloat() - rand.nextFloat()) * 0.4F);
      double dz = (double)((float)z + (rand.nextFloat() - rand.nextFloat()) * 0.3F + 0.5F);
      EntityTFTinyFirefly tinyfly = new EntityTFTinyFirefly(world, dx, dy, dz);
      world.addWeatherEffect(tinyfly);
      dx = (double)((float)x + (rand.nextFloat() - rand.nextFloat()) * 0.3F + 0.5F);
      dy = (double)((float)y - 0.1F + (rand.nextFloat() - rand.nextFloat()) * 0.4F);
      dz = (double)((float)z + (rand.nextFloat() - rand.nextFloat()) * 0.3F + 0.5F);
      tinyfly = new EntityTFTinyFirefly(world, dx, dy, dz);
      world.addWeatherEffect(tinyfly);
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      jarTop = par1IconRegister.registerIcon("TwilightForest:fireflyjar_top");
      jarSide = par1IconRegister.registerIcon("TwilightForest:fireflyjar_side");
      jarCork = par1IconRegister.registerIcon("TwilightForest:fireflyjar_cork");
   }
}

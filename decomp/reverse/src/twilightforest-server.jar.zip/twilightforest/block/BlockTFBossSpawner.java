package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.item.TFItems;
import twilightforest.tileentity.TileEntityTFHydraSpawner;
import twilightforest.tileentity.TileEntityTFKnightPhantomsSpawner;
import twilightforest.tileentity.TileEntityTFLichSpawner;
import twilightforest.tileentity.TileEntityTFNagaSpawner;
import twilightforest.tileentity.TileEntityTFSnowQueenSpawner;
import twilightforest.tileentity.TileEntityTFTowerBossSpawner;

public class BlockTFBossSpawner extends BlockContainer {

   protected BlockTFBossSpawner() {
      super(Material.rock);
      this.setHardness(20.0F);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public boolean hasTileEntity(int metadata) {
      return true;
   }

   public TileEntity createTileEntity(World world, int metadata) {
      return (TileEntity)(metadata == 0?new TileEntityTFNagaSpawner():(metadata == 1?new TileEntityTFLichSpawner():(metadata == 2?new TileEntityTFHydraSpawner():(metadata == 3?new TileEntityTFTowerBossSpawner():(metadata == 4?new TileEntityTFKnightPhantomsSpawner():(metadata == 5?new TileEntityTFSnowQueenSpawner():null))))));
   }

   public TileEntity createNewTileEntity(World var1, int var2) {
      return this.createTileEntity(var1, var2);
   }

   public Item getItemDropped(int par1, Random par2Random, int par3) {
      return null;
   }

   public int quantityDropped(Random random) {
      return 0;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {}

   public IIcon getIcon(int side, int metadata) {
      return Blocks.mob_spawner.getIcon(side, metadata);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {}
}

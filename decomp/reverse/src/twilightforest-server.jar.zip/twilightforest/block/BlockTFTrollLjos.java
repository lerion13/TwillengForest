package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.init.Blocks;
import twilightforest.item.TFItems;

public class BlockTFTrollLjos extends Block {

   protected BlockTFTrollLjos() {
      super(Material.rock);
      this.setHardness(2.0F);
      this.setResistance(15.0F);
      this.setStepSound(Block.soundTypeStone);
      this.setCreativeTab(TFItems.creativeTab);
      this.setLightLevel(1.0F);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      super.blockIcon = Blocks.lit_redstone_lamp.getIcon(0, 0);
   }
}

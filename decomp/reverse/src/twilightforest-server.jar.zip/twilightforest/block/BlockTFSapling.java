package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockSapling;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class BlockTFSapling extends BlockSapling {

   private IIcon[] icons;
   private String[] iconNames = new String[]{"sapling_oak", "sapling_canopy", "sapling_mangrove", "sapling_darkwood", "sapling_hollow_oak", "sapling_time", "sapling_transformation", "sapling_mining", "sapling_sorting", "sapling_rainboak"};


   protected BlockTFSapling() {
      float var3 = 0.4F;
      this.setBlockBounds(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var3 * 2.0F, 0.5F + var3);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public void updateTick(World par1World, int x, int y, int z, Random par5Random) {
      if(!par1World.isRemote && par1World.getBlockLightValue(x, y + 1, z) >= 9 && par5Random.nextInt(7) == 0) {
         this.func_149878_d(par1World, x, y, z, par5Random);
      }

   }

   public void func_149878_d(World world, int x, int y, int z, Random rand) {
      int meta = world.getBlockMetadata(x, y, z);
      Object treeGenerator = null;
      byte var8 = 0;
      byte var9 = 0;
      boolean largeTree = false;
      if(meta != 1 && meta != 2 && meta != 3 && meta != 4 && meta != 5 && meta != 6 && meta != 7 && meta != 8 && meta == 9) {
         ;
      }

      if(largeTree) {
         world.setBlock(x + var8, y, z + var9, Blocks.air, 0, 4);
         world.setBlock(x + var8 + 1, y, z + var9, Blocks.air, 0, 4);
         world.setBlock(x + var8, y, z + var9 + 1, Blocks.air, 0, 4);
         world.setBlock(x + var8 + 1, y, z + var9 + 1, Blocks.air, 0, 4);
      } else {
         world.setBlock(x, y, z, Blocks.air, 0, 4);
      }

   }

   public IIcon getIcon(int side, int metadata) {
      return metadata < this.icons.length?this.icons[metadata]:null;
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      this.icons = new IIcon[this.iconNames.length];

      for(int i = 0; i < this.icons.length; ++i) {
         this.icons[i] = par1IconRegister.registerIcon("TwilightForest:" + this.iconNames[i]);
      }

   }

   public int damageDropped(int par1) {
      return par1;
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
      par3List.add(new ItemStack(par1, 1, 2));
      par3List.add(new ItemStack(par1, 1, 3));
      par3List.add(new ItemStack(par1, 1, 4));
      par3List.add(new ItemStack(par1, 1, 5));
      par3List.add(new ItemStack(par1, 1, 6));
      par3List.add(new ItemStack(par1, 1, 7));
      par3List.add(new ItemStack(par1, 1, 8));
      par3List.add(new ItemStack(par1, 1, 9));
   }
}

package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBreakable;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import twilightforest.item.TFItems;

public class BlockTFWispyCloud extends BlockBreakable {

   protected BlockTFWispyCloud() {
      super("", Material.craftedSnow, false);
      this.setStepSound(Block.soundTypeCloth);
      this.setCreativeTab(TFItems.creativeTab);
      this.setHardness(0.3F);
      this.setBlockTextureName("TwilightForest:wispy_cloud");
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister p_149651_1_) {
      super.blockIcon = p_149651_1_.registerIcon(this.getTextureName());
   }

   @SideOnly(Side.CLIENT)
   public int getRenderBlockPass() {
      return 1;
   }

   protected boolean canSilkHarvest() {
      return true;
   }

   public int quantityDropped(Random p_149745_1_) {
      return 0;
   }

   public boolean renderAsNormalBlock() {
      return false;
   }
}

package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class BlockTFHugeStalk extends Block {

   private IIcon topIcon;


   protected BlockTFHugeStalk() {
      super(Material.wood);
      this.setHardness(1.25F);
      this.setResistance(7.0F);
      this.setBlockTextureName("TwilightForest:huge_stalk");
      this.setStepSound(Block.soundTypeGrass);
      this.setCreativeTab(TFItems.creativeTab);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      super.registerBlockIcons(par1IconRegister);
      this.topIcon = par1IconRegister.registerIcon(this.getTextureName() + "_top");
   }

   @SideOnly(Side.CLIENT)
   public IIcon getIcon(int side, int meta) {
      return side != 0 && side != 1?super.blockIcon:this.topIcon;
   }

   public boolean canSustainLeaves(IBlockAccess world, int x, int y, int z) {
      return true;
   }

   public void breakBlock(World world, int x, int y, int z, Block myBlock, int meta) {
      byte radius = 4;
      int rad1 = radius + 1;
      if(world.checkChunksExist(x - rad1, y - rad1, z - rad1, x + rad1, y + rad1, z + rad1)) {
         for(int dx = -radius; dx <= radius; ++dx) {
            for(int dy = -radius; dy <= radius; ++dy) {
               for(int dz = -radius; dz <= radius; ++dz) {
                  Block block = world.getBlock(x + dx, y + dy, z + dz);
                  if(block.isLeaves(world, x + dx, y + dy, z + dz)) {
                     block.beginLeavesDecay(world, x + dx, y + dy, z + dz);
                  }
               }
            }
         }
      }

   }
}

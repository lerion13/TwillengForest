package twilightforest.block;

import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class BlockTFLeaves extends BlockLeaves {

   int oakColor = 4764952;
   int canopyColor = 6330464;
   int mangroveColor = 8431445;
   public static final String[] unlocalizedNameArray = new String[]{"twilightoak", "canopy", "mangrove", "rainboak"};


   protected BlockTFLeaves() {
      this.setHardness(0.2F);
      this.setLightOpacity(2);
      this.setStepSound(Block.soundTypeGrass);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public int getBlockColor() {
      double var1 = 0.5D;
      double var3 = 1.0D;
      return ColorizerFoliage.getFoliageColor(var1, var3);
   }

   public int getRenderColor(int par1) {
      return (par1 & 3) == 1?this.canopyColor:((par1 & 3) == 2?this.mangroveColor:this.oakColor);
   }

   public int colorMultiplier(IBlockAccess par1IBlockAccess, int x, int y, int z) {
      int meta = par1IBlockAccess.getBlockMetadata(x, y, z);
      int red = 0;
      int green = 0;
      int blue = 0;

      int normalColor;
      for(normalColor = -1; normalColor <= 1; ++normalColor) {
         for(int var10 = -1; var10 <= 1; ++var10) {
            int var11 = par1IBlockAccess.getBiomeGenForCoords(x + var10, z + normalColor).getBiomeFoliageColor(x, y, z);
            red += (var11 & 16711680) >> 16;
            green += (var11 & '\uff00') >> 8;
            blue += var11 & 255;
         }
      }

      normalColor = (red / 9 & 255) << 16 | (green / 9 & 255) << 8 | blue / 9 & 255;
      if((meta & 3) == 1) {
         return ((normalColor & 16711422) + 4627046) / 2;
      } else if((meta & 3) == 2) {
         return ((normalColor & 16711422) + 12641940) / 2;
      } else if((meta & 3) == 3) {
         red = x * 32 + y * 16;
         if((red & 256) != 0) {
            red = 255 - (red & 255);
         }

         red &= 255;
         blue = y * 32 + z * 16;
         if((blue & 256) != 0) {
            blue = 255 - (blue & 255);
         }

         blue ^= 255;
         green = x * 16 + z * 32;
         if((green & 256) != 0) {
            green = 255 - (green & 255);
         }

         green &= 255;
         return red << 16 | blue << 8 | green;
      } else {
         return normalColor;
      }
   }

   public boolean isOpaqueCube() {
      return Blocks.leaves.isOpaqueCube();
   }

   public IIcon getIcon(int i, int j) {
      return Blocks.leaves.getIcon(i, (j & 3) == 3?0:j);
   }

   public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l) {
      return Blocks.leaves.shouldSideBeRendered(iblockaccess, i, j, k, l);
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
      par3List.add(new ItemStack(this, 1, 2));
      par3List.add(new ItemStack(this, 1, 3));
   }

   public int quantityDropped(Random par1Random) {
      return par1Random.nextInt(40) == 0?1:0;
   }

   public Item getItemDropped(int par1, Random par2Random, int par3) {
      return Item.getItemFromBlock(TFBlocks.sapling);
   }

   public int damageDropped(int par1) {
      int leafType = par1 & 3;
      return leafType;
   }

   public void dropBlockAsItemWithChance(World par1World, int par2, int par3, int par4, int meta, float par6, int par7) {
      if(!par1World.isRemote) {
         byte chance = 40;
         if((meta & 3) == 2) {
            chance = 20;
         }

         if(par1World.rand.nextInt(chance) == 0) {
            Item item = this.getItemDropped(meta, par1World.rand, par7);
            this.dropBlockAsItem(par1World, par2, par3, par4, new ItemStack(item, 1, this.getSaplingMeta(meta)));
         }
      }

   }

   public int getSaplingMeta(int leafMeta) {
      int leafType = leafMeta & 3;
      return leafType == 3?9:leafType;
   }

   public String[] func_150125_e() {
      return unlocalizedNameArray;
   }

}

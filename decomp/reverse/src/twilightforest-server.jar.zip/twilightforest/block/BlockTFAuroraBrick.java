package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class BlockTFAuroraBrick extends Block {

   private static IIcon[] icons;


   public BlockTFAuroraBrick() {
      super(Material.packedIce);
      this.setCreativeTab(TFItems.creativeTab);
      this.setHardness(2.0F);
      this.setResistance(10.0F);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      icons = new IIcon[8];
      icons[0] = par1IconRegister.registerIcon("TwilightForest:aurorabrick0");
      icons[1] = par1IconRegister.registerIcon("TwilightForest:aurorabrick1");
      icons[2] = par1IconRegister.registerIcon("TwilightForest:aurorabrick2");
      icons[3] = par1IconRegister.registerIcon("TwilightForest:aurorabrick3");
      icons[4] = par1IconRegister.registerIcon("TwilightForest:aurorabrick4");
      icons[5] = par1IconRegister.registerIcon("TwilightForest:aurorabrick5");
      icons[6] = par1IconRegister.registerIcon("TwilightForest:aurorabrick6");
      icons[7] = par1IconRegister.registerIcon("TwilightForest:aurorabrick7");
   }

   public IIcon getIcon(int side, int meta) {
      return meta < 8?icons[meta]:icons[15 - meta];
   }

   public int colorMultiplier(IBlockAccess par1IBlockAccess, int x, int y, int z) {
      boolean red = false;
      boolean green = false;
      boolean blue = false;
      byte red1 = 16;
      int blue1 = x * 12 + z * 6;
      if((blue1 & 256) != 0) {
         blue1 = 255 - (blue1 & 255);
      }

      blue1 ^= 255;
      blue1 &= 255;
      int green1 = x * 4 + z * 8;
      if((green1 & 256) != 0) {
         green1 = 255 - (green1 & 255);
      }

      green1 &= 255;
      if(green1 + blue1 < 128) {
         green1 = 128 - blue1;
      }

      return red1 << 16 | blue1 << 8 | green1;
   }

   @SideOnly(Side.CLIENT)
   public int getBlockColor() {
      return this.colorMultiplier((IBlockAccess)null, 16, 0, 16);
   }

   @SideOnly(Side.CLIENT)
   public int getRenderColor(int meta) {
      return this.getBlockColor();
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
   }

   public int damageDropped(int meta) {
      return 0;
   }

   public int onBlockPlaced(World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int meta) {
      return Math.abs(x + z) % 16;
   }

   public void onBlockAdded(World world, int x, int y, int z) {
      world.setBlockMetadataWithNotify(x, y, z, Math.abs(x + z) % 16, 2);
   }
}

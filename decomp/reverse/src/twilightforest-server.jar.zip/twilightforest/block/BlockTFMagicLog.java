package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class BlockTFMagicLog extends BlockLog {

   public static final int META_TIME = 0;
   public static final int META_TRANS = 1;
   public static final int META_MINE = 2;
   public static final int META_SORT = 3;
   public static IIcon SPR_TIMESIDE;
   public static IIcon SPR_TIMETOP;
   public static IIcon SPR_TIMECLOCK;
   public static IIcon SPR_TIMECLOCKOFF;
   public static IIcon SPR_TRANSSIDE;
   public static IIcon SPR_TRANSTOP;
   public static IIcon SPR_TRANSHEART;
   public static IIcon SPR_TRANSHEARTOFF;
   public static IIcon SPR_MINESIDE;
   public static IIcon SPR_MINETOP;
   public static IIcon SPR_MINEGEM;
   public static IIcon SPR_MINEGEMOFF;
   public static IIcon SPR_SORTSIDE;
   public static IIcon SPR_SORTTOP;
   public static IIcon SPR_SORTEYE;
   public static IIcon SPR_SORTEYEOFF;


   protected BlockTFMagicLog() {
      this.setHardness(2.0F);
      this.setStepSound(Block.soundTypeWood);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public IIcon getIcon(int side, int meta) {
      int orient = meta & 12;
      int woodType = meta & 3;
      switch(woodType) {
      case 0:
      default:
         return orient == 0 && (side == 1 || side == 0)?SPR_TIMETOP:(orient == 4 && (side == 5 || side == 4)?SPR_TIMETOP:(orient == 8 && (side == 2 || side == 3)?SPR_TIMETOP:SPR_TIMESIDE));
      case 1:
         return orient == 0 && (side == 1 || side == 0)?SPR_TRANSTOP:(orient == 4 && (side == 5 || side == 4)?SPR_TRANSTOP:(orient == 8 && (side == 2 || side == 3)?SPR_TRANSTOP:SPR_TRANSSIDE));
      case 2:
         return orient == 0 && (side == 1 || side == 0)?SPR_MINETOP:(orient == 4 && (side == 5 || side == 4)?SPR_MINETOP:(orient == 8 && (side == 2 || side == 3)?SPR_MINETOP:SPR_MINESIDE));
      case 3:
         return orient == 0 && (side == 1 || side == 0)?SPR_SORTTOP:(orient == 4 && (side == 5 || side == 4)?SPR_SORTTOP:(orient == 8 && (side == 2 || side == 3)?SPR_SORTTOP:SPR_SORTSIDE));
      }
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      SPR_TIMESIDE = par1IconRegister.registerIcon("TwilightForest:time_side");
      SPR_TIMETOP = par1IconRegister.registerIcon("TwilightForest:time_section");
      SPR_TIMECLOCK = par1IconRegister.registerIcon("TwilightForest:time_clock");
      SPR_TIMECLOCKOFF = par1IconRegister.registerIcon("TwilightForest:time_clock_off");
      SPR_TRANSSIDE = par1IconRegister.registerIcon("TwilightForest:trans_side");
      SPR_TRANSTOP = par1IconRegister.registerIcon("TwilightForest:trans_section");
      SPR_TRANSHEART = par1IconRegister.registerIcon("TwilightForest:trans_heart");
      SPR_TRANSHEARTOFF = par1IconRegister.registerIcon("TwilightForest:trans_heart_off");
      SPR_MINESIDE = par1IconRegister.registerIcon("TwilightForest:mine_side");
      SPR_MINETOP = par1IconRegister.registerIcon("TwilightForest:mine_section");
      SPR_MINEGEM = par1IconRegister.registerIcon("TwilightForest:mine_gem");
      SPR_MINEGEMOFF = par1IconRegister.registerIcon("TwilightForest:mine_gem_off");
      SPR_SORTSIDE = par1IconRegister.registerIcon("TwilightForest:sort_side");
      SPR_SORTTOP = par1IconRegister.registerIcon("TwilightForest:sort_section");
      SPR_SORTEYE = par1IconRegister.registerIcon("TwilightForest:sort_eye");
      SPR_SORTEYEOFF = par1IconRegister.registerIcon("TwilightForest:sort_eye_off");
   }

   public Item getItemDropped(int par1, Random par2Random, int par3) {
      return Item.getItemFromBlock(this);
   }

   @SideOnly(Side.CLIENT)
   public void randomDisplayTick(World world, int x, int y, int z, Random rand) {}

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
      par3List.add(new ItemStack(par1, 1, 2));
      par3List.add(new ItemStack(par1, 1, 3));
   }
}

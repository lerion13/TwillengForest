package twilightforest.block;

import net.minecraft.init.Blocks;
import twilightforest.block.BlockTFGiantBlock;
import twilightforest.item.TFItems;

public class BlockTFGiantCobble extends BlockTFGiantBlock {

   protected BlockTFGiantCobble() {
      super(Blocks.cobblestone);
      this.setHardness(128.0F);
      this.setResistance(10.0F);
      this.setCreativeTab(TFItems.creativeTab);
   }
}

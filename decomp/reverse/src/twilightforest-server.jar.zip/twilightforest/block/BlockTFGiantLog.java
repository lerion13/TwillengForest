package twilightforest.block;

import net.minecraft.init.Blocks;
import twilightforest.block.BlockTFGiantBlock;
import twilightforest.item.TFItems;

public class BlockTFGiantLog extends BlockTFGiantBlock {

   protected BlockTFGiantLog() {
      super(Blocks.log);
      this.setHardness(128.0F);
      this.setCreativeTab(TFItems.creativeTab);
   }
}

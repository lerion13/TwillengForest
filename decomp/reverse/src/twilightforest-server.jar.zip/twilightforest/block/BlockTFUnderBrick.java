package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import twilightforest.item.TFItems;

public class BlockTFUnderBrick extends Block {

   private static IIcon[] iconSide = new IIcon[4];


   public BlockTFUnderBrick() {
      super(Material.rock);
      this.setHardness(1.5F);
      this.setResistance(10.0F);
      this.setStepSound(Block.soundTypeStone);
      this.setCreativeTab(TFItems.creativeTab);
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      iconSide[0] = par1IconRegister.registerIcon("TwilightForest:knightbrick");
      iconSide[1] = par1IconRegister.registerIcon("TwilightForest:knightbrick_mossy");
      iconSide[2] = par1IconRegister.registerIcon("TwilightForest:knightbrick_cracked");
   }

   public IIcon getIcon(int side, int meta) {
      return meta < iconSide.length?(side != 0 && side != 1?iconSide[meta]:iconSide[meta]):(side != 0 && side != 1?iconSide[0]:iconSide[0]);
   }

   public int colorMultiplier(IBlockAccess par1IBlockAccess, int x, int y, int z) {
      par1IBlockAccess.getBlockMetadata(x, y, z);
      return 16777215;
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
      par3List.add(new ItemStack(par1, 1, 2));
   }

   public int damageDropped(int meta) {
      return meta;
   }

}

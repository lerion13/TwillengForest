package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.awt.Color;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class BlockTFAuroraPillar extends BlockRotatedPillar {

   private IIcon sideIcon;
   private IIcon topIcon;


   protected BlockTFAuroraPillar() {
      super(Material.packedIce);
      this.setCreativeTab(TFItems.creativeTab);
      this.setHardness(2.0F);
      this.setResistance(10.0F);
   }

   public int colorMultiplier(IBlockAccess world, int x, int y, int z) {
      boolean red = false;
      boolean green = false;
      boolean blue = false;
      int normalColor = TFBlocks.auroraBlock.colorMultiplier(world, x, y, z);
      int red1 = normalColor >> 16 & 255;
      int blue1 = normalColor & 255;
      int green1 = normalColor >> 8 & 255;
      float[] hsb = Color.RGBtoHSB(red1, blue1, green1, (float[])null);
      return Color.HSBtoRGB(hsb[0], hsb[1] * 0.5F, Math.min(hsb[2] + 0.4F, 0.9F));
   }

   @SideOnly(Side.CLIENT)
   public int getBlockColor() {
      return this.colorMultiplier((IBlockAccess)null, 16, 0, 16);
   }

   @SideOnly(Side.CLIENT)
   public int getRenderColor(int meta) {
      return this.getBlockColor();
   }

   @SideOnly(Side.CLIENT)
   protected IIcon getSideIcon(int meta) {
      return this.sideIcon;
   }

   @SideOnly(Side.CLIENT)
   protected IIcon getTopIcon(int p_150161_1_) {
      return this.topIcon;
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      this.sideIcon = par1IconRegister.registerIcon("TwilightForest:aurora_pillar_side");
      this.topIcon = par1IconRegister.registerIcon("TwilightForest:aurora_pillar_top");
   }
}

package twilightforest.block;

import java.util.Random;
import net.minecraft.world.World;
import twilightforest.block.BlockTFTrollRoot;
import twilightforest.block.TFBlocks;

public class BlockTFUnripeTorchCluster extends BlockTFTrollRoot {

   private static final int RIPEN_THRESHHOLD = 6;


   protected BlockTFUnripeTorchCluster() {
      this.setBlockTextureName("TwilightForest:unripe_torch_cluster");
   }

   public void updateTick(World world, int x, int y, int z, Random rand) {
      super.updateTick(world, x, y, z, rand);
      if(world.getBlockLightValue(x, y, z) >= 6) {
         world.setBlock(x, y, z, TFBlocks.trollBer);
      }

   }
}

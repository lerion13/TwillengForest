package twilightforest.block;

import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import twilightforest.block.BlockTFTrollRoot;
import twilightforest.item.TFItems;

public class BlockTFRipeTorchCluster extends BlockTFTrollRoot {

   protected BlockTFRipeTorchCluster() {
      this.setBlockTextureName("TwilightForest:ripe_torch_cluster");
      this.setLightLevel(1.0F);
   }

   public Item getItemDropped(int meta, Random rand, int fortune) {
      return TFItems.torchberries;
   }

   public int quantityDropped(int meta, int fortune, Random random) {
      return this.quantityDroppedWithBonus(fortune, random);
   }

   public int quantityDropped(Random rand) {
      return 4 + rand.nextInt(5);
   }

   public int quantityDroppedWithBonus(int bonus, Random rand) {
      if(bonus > 0 && Item.getItemFromBlock(this) != this.getItemDropped(0, rand, bonus)) {
         int j = rand.nextInt(bonus + 2) - 1;
         if(j < 0) {
            j = 0;
         }

         return this.quantityDropped(rand) * (j + 1);
      } else {
         return this.quantityDropped(rand);
      }
   }

   public void harvestBlock(World world, EntityPlayer player, int x, int y, int z, int meta) {
      if(world.isRemote || player.getCurrentEquippedItem() == null || player.getCurrentEquippedItem().getItem() != Items.shears) {
         super.harvestBlock(world, player, x, y, z, meta);
      }

   }
}

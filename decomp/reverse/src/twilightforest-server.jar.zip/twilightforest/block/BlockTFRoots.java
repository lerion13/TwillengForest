package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import twilightforest.item.TFItems;

public class BlockTFRoots extends Block {

   public static IIcon spRootSide;
   public static IIcon spOreRootSide;
   public static final int ROOT_META = 0;
   public static final int OREROOT_META = 1;


   public BlockTFRoots() {
      super(Material.wood);
      this.setCreativeTab(TFItems.creativeTab);
      this.setHardness(2.0F);
      this.setStepSound(Block.soundTypeWood);
   }

   public IIcon getIcon(int side, int meta) {
      return meta == 1?spOreRootSide:spRootSide;
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      spRootSide = par1IconRegister.registerIcon("TwilightForest:rootblock");
      spOreRootSide = par1IconRegister.registerIcon("TwilightForest:oreroots");
   }

   public Item getItemDropped(int meta, Random random, int j) {
      switch(meta) {
      case 0:
         return Items.stick;
      case 1:
         return TFItems.liveRoot;
      default:
         return Item.getItemFromBlock(this);
      }
   }

   public int damageDropped(int meta) {
      switch(meta) {
      case 0:
         return 0;
      case 1:
         return 0;
      default:
         return meta | 8;
      }
   }

   public int quantityDropped(int meta, int fortune, Random random) {
      switch(meta) {
      case 0:
         return 3 + random.nextInt(2);
      default:
         return super.quantityDropped(meta, fortune, random);
      }
   }

   @SideOnly(Side.CLIENT)
   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
   }
}

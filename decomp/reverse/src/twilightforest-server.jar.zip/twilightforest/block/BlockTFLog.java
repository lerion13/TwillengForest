package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class BlockTFLog extends BlockLog {

   public static IIcon sprOakSide;
   public static IIcon sprOakTop;
   public static IIcon sprCanopySide;
   public static IIcon sprCanopyTop;
   public static IIcon sprMangroveSide;
   public static IIcon sprMangroveTop;
   public static IIcon sprDarkwoodSide;
   public static IIcon sprDarkwoodTop;


   protected BlockTFLog() {
      this.setHardness(2.0F);
      this.setStepSound(Block.soundTypeWood);
      this.setCreativeTab(TFItems.creativeTab);
   }

   public IIcon getIcon(int side, int meta) {
      int orient = meta & 12;
      int woodType = meta & 3;
      switch(woodType) {
      case 0:
      default:
         return orient == 0 && (side == 1 || side == 0)?sprOakTop:(orient == 4 && (side == 5 || side == 4)?sprOakTop:(orient == 8 && (side == 2 || side == 3)?sprOakTop:sprOakSide));
      case 1:
         return orient == 0 && (side == 1 || side == 0)?sprCanopyTop:(orient == 4 && (side == 5 || side == 4)?sprCanopyTop:(orient == 8 && (side == 2 || side == 3)?sprCanopyTop:sprCanopySide));
      case 2:
         return orient == 0 && (side == 1 || side == 0)?sprMangroveTop:(orient == 4 && (side == 5 || side == 4)?sprMangroveTop:(orient == 8 && (side == 2 || side == 3)?sprMangroveTop:sprMangroveSide));
      case 3:
         return orient == 0 && (side == 1 || side == 0)?sprDarkwoodTop:(orient == 4 && (side == 5 || side == 4)?sprDarkwoodTop:(orient == 8 && (side == 2 || side == 3)?sprDarkwoodTop:sprDarkwoodSide));
      }
   }

   @SideOnly(Side.CLIENT)
   public void registerBlockIcons(IIconRegister par1IconRegister) {
      sprOakSide = par1IconRegister.registerIcon("TwilightForest:oak_side");
      sprOakTop = par1IconRegister.registerIcon("TwilightForest:oak_top");
      sprCanopySide = par1IconRegister.registerIcon("TwilightForest:canopy_side");
      sprCanopyTop = par1IconRegister.registerIcon("TwilightForest:canopy_top");
      sprMangroveSide = par1IconRegister.registerIcon("TwilightForest:mangrove_side");
      sprMangroveTop = par1IconRegister.registerIcon("TwilightForest:mangrove_top");
      sprDarkwoodSide = par1IconRegister.registerIcon("TwilightForest:darkwood_side");
      sprDarkwoodTop = par1IconRegister.registerIcon("TwilightForest:darkwood_top");
   }

   public Item getItemDropped(int par1, Random par2Random, int par3) {
      return Item.getItemFromBlock(TFBlocks.log);
   }

   public void getSubBlocks(Item par1, CreativeTabs par2CreativeTabs, List par3List) {
      par3List.add(new ItemStack(par1, 1, 0));
      par3List.add(new ItemStack(par1, 1, 1));
      par3List.add(new ItemStack(par1, 1, 2));
      par3List.add(new ItemStack(par1, 1, 3));
   }
}

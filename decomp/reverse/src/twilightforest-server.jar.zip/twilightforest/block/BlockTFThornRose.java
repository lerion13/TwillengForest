package twilightforest.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;
import twilightforest.item.TFItems;

public class BlockTFThornRose extends Block {

   protected BlockTFThornRose() {
      super(Material.plants);
      this.setHardness(10.0F);
      this.setStepSound(Block.soundTypeGrass);
      this.setCreativeTab(TFItems.creativeTab);
      float radius = 0.4F;
      this.setBlockBounds(0.5F - radius, 0.5F - radius, 0.5F - radius, 0.5F + radius, 0.5F + radius, 0.5F + radius);
   }

   public int getRenderType() {
      return 1;
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public boolean canPlaceBlockAt(World world, int x, int y, int z) {
      return this.canBlockStay(world, x, y, z);
   }

   public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) {
      return null;
   }

   public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {
      if(!this.canBlockStay(world, x, y, z)) {
         this.dropBlockAsItem(world, x, y, z, world.getBlockMetadata(x, y, z), 0);
         world.setBlockToAir(x, y, z);
      }

   }

   public boolean canBlockStay(World world, int x, int y, int z) {
      boolean supported = false;
      ForgeDirection[] var6 = ForgeDirection.VALID_DIRECTIONS;
      int var7 = var6.length;

      for(int var8 = 0; var8 < var7; ++var8) {
         ForgeDirection dir = var6[var8];
         int dx = x + dir.offsetX;
         int dy = y + dir.offsetY;
         int dz = z + dir.offsetZ;
         if(world.getBlock(dx, dy, dz).canSustainLeaves(world, dx, dy, dz)) {
            supported = true;
         }
      }

      return supported;
   }
}

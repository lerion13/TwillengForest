package twilightforest.block;

import java.util.Random;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.block.BlockTFCritter;
import twilightforest.tileentity.TileEntityTFMoonworm;

public class BlockTFMoonworm extends BlockTFCritter {

   public static int sprMoonworm = 52;


   public int tickRate() {
      return 50;
   }

   public void setBlockBoundsBasedOnState(IBlockAccess world, int x, int y, int z) {
      int facing = world.getBlockMetadata(x, y, z) & 7;
      float wide = 0.25F;
      if(facing == 1) {
         this.setBlockBounds(0.0F, 0.25F, 0.5F - wide, wide, 0.75F, 0.5F + wide);
      } else if(facing == 2) {
         this.setBlockBounds(1.0F - wide, 0.25F, 0.5F - wide, 1.0F, 0.75F, 0.5F + wide);
      } else if(facing == 3) {
         this.setBlockBounds(0.5F - wide, 0.25F, 0.0F, 0.5F + wide, 0.75F, wide);
      } else if(facing == 4) {
         this.setBlockBounds(0.5F - wide, 0.25F, 1.0F - wide, 0.5F + wide, 0.75F, 1.0F);
      } else if(facing == 5) {
         this.setBlockBounds(0.5F - wide, 0.0F, 0.25F, 0.5F + wide, wide, 0.75F);
      } else if(facing == 6) {
         this.setBlockBounds(0.5F - wide, 1.0F - wide, 0.25F, 0.5F + wide, 1.0F, 0.75F);
      } else {
         float f1 = 0.1F;
         this.setBlockBounds(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, 0.6F, 0.5F + f1);
      }

   }

   public int getLightValue(IBlockAccess world, int x, int y, int z) {
      return 14;
   }

   public TileEntity createTileEntity(World world, int metadata) {
      return new TileEntityTFMoonworm();
   }

   public void onBlockAdded(World world, int x, int y, int z) {
      super.onBlockAdded(world, x, y, z);
      world.scheduleBlockUpdate(x, y, z, this, this.tickRate());
   }

   public void updateTick(World world, int x, int y, int z, Random random) {
      if(world.getBlockLightValue(x, y, z) < 12) {
         world.scheduleBlockUpdate(x, y, z, this, this.tickRate());
      }

   }

   public boolean dropCritterIfCantStay(World world, int x, int y, int z) {
      if(!this.canPlaceBlockAt(world, x, y, z)) {
         world.setBlockToAir(x, y, z);
         return false;
      } else {
         return true;
      }
   }

   public int quantityDropped(int meta, int fortune, Random random) {
      return 0;
   }

}

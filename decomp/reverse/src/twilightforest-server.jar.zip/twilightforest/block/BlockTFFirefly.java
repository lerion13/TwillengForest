package twilightforest.block;

import java.util.Random;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.block.BlockTFCritter;
import twilightforest.tileentity.TileEntityTFFirefly;

public class BlockTFFirefly extends BlockTFCritter {

   public static int sprFirefly = 4;
   public static Random rand = new Random();


   protected BlockTFFirefly() {
      this.setLightLevel(0.9375F);
   }

   public int tickRate() {
      return 50 + rand.nextInt(50);
   }

   public int getLightValue(IBlockAccess world, int x, int y, int z) {
      return 15;
   }

   public TileEntity createTileEntity(World world, int metadata) {
      return new TileEntityTFFirefly();
   }

   public void onBlockAdded(World world, int x, int y, int z) {
      super.onBlockAdded(world, x, y, z);
   }

   public void updateTick(World world, int x, int y, int z, Random random) {
      if(!world.isRemote && world.getBlockLightValue(x, y, z) < 12) {
         world.markBlockForUpdate(x, y, z);
         world.scheduleBlockUpdate(x, y, z, this, this.tickRate());
      }

   }

}

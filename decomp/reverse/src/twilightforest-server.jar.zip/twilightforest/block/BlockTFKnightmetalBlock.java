package twilightforest.block;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCompressed;
import net.minecraft.block.material.MapColor;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.item.TFItems;

public class BlockTFKnightmetalBlock extends BlockCompressed {

   private static final float BLOCK_DAMAGE = 4.0F;


   public BlockTFKnightmetalBlock() {
      super(MapColor.ironColor);
      this.setHardness(5.0F);
      this.setResistance(41.0F);
      this.setStepSound(Block.soundTypeMetal);
      this.setBlockTextureName("TwilightForest:knightmetal_block");
      this.setCreativeTab(TFItems.creativeTab);
   }

   public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) {
      float f = 0.0625F;
      return AxisAlignedBB.getBoundingBox((double)((float)x + f), (double)((float)y + f), (double)((float)z + f), (double)((float)(x + 1) - f), (double)((float)(y + 1) - f), (double)((float)(z + 1) - f));
   }

   public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
      entity.attackEntityFrom(DamageSource.cactus, 4.0F);
   }

   public boolean renderAsNormalBlock() {
      return false;
   }

   public boolean isOpaqueCube() {
      return false;
   }

   public int getRenderType() {
      return TwilightForestMod.proxy.getKnightmetalBlockRenderID();
   }

   @SideOnly(Side.CLIENT)
   public boolean shouldSideBeRendered(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5) {
      return true;
   }
}

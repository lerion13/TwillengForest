package twilightforest.block;

import net.minecraft.init.Blocks;
import twilightforest.block.BlockTFGiantBlock;
import twilightforest.item.TFItems;

public class BlockTFGiantObsidian extends BlockTFGiantBlock {

   protected BlockTFGiantObsidian() {
      super(Blocks.obsidian);
      this.setHardness(204800.0F);
      this.setResistance(8192000.0F);
      this.setCreativeTab(TFItems.creativeTab);
   }
}

package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.entity.ai.EntityAITFThrowRider;
import twilightforest.item.TFItems;

public class EntityTFYeti extends EntityMob {

   private static final int ANGER_FLAG = 16;


   public EntityTFYeti(World par1World) {
      super(par1World);
      this.setSize(1.4F, 2.4F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAITFThrowRider(this, 1.0F));
      super.tasks.addTask(2, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(3, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(4, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(4, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true, false));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.38D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(0.0D);
      this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(4.0D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(16, Byte.valueOf((byte)0));
   }

   public void onLivingUpdate() {
      if(super.riddenByEntity != null) {
         this.setSize(1.4F, 2.4F);
         if(super.riddenByEntity.isSneaking()) {
            super.riddenByEntity.setSneaking(false);
         }
      } else {
         this.setSize(1.4F, 2.4F);
      }

      super.onLivingUpdate();
      if(super.riddenByEntity != null) {
         this.getLookHelper().setLookPositionWithEntity(super.riddenByEntity, 100.0F, 100.0F);
         Vec3 riderPos = this.getRiderPosition();
         this.func_145771_j(riderPos.xCoord, riderPos.yCoord, riderPos.zCoord);
      }

   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      return super.interact(par1EntityPlayer);
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      if(super.riddenByEntity == null && par1Entity.ridingEntity == null) {
         par1Entity.mountEntity(this);
      }

      return super.attackEntityAsMob(par1Entity);
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      if(par1DamageSource.getSourceOfDamage() != null) {
         this.setAngry(true);
      }

      return super.attackEntityFrom(par1DamageSource, par2);
   }

   public boolean isAngry() {
      return (super.dataWatcher.getWatchableObjectByte(16) & 2) != 0;
   }

   public void setAngry(boolean anger) {
      byte b0 = super.dataWatcher.getWatchableObjectByte(16);
      if(anger) {
         this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 | 2)));
      } else {
         super.dataWatcher.updateObject(16, Byte.valueOf((byte)(b0 & -3)));
      }

   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("Angry", this.isAngry());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setAngry(par1NBTTagCompound.getBoolean("Angry"));
   }

   public void updateRiderPosition() {
      if(super.riddenByEntity != null) {
         Vec3 riderPos = this.getRiderPosition();
         super.riddenByEntity.setPosition(riderPos.xCoord, riderPos.yCoord, riderPos.zCoord);
      }

   }

   public double getMountedYOffset() {
      return 2.25D;
   }

   public Vec3 getRiderPosition() {
      if(super.riddenByEntity != null) {
         float distance = 0.4F;
         double var1 = Math.cos((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         double var3 = Math.sin((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         return Vec3.createVectorHelper(super.posX + var1, super.posY + this.getMountedYOffset() + super.riddenByEntity.getYOffset(), super.posZ + var3);
      } else {
         return Vec3.createVectorHelper(super.posX, super.posY, super.posZ);
      }
   }

   public boolean canRiderInteract() {
      return true;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public boolean getCanSpawnHere() {
      return super.worldObj.getBiomeGenForCoords(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posZ)) != TFBiomeBase.tfSnow?super.getCanSpawnHere():super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).size() == 0;
   }

   protected boolean isValidLightLevel() {
      int x = MathHelper.floor_double(super.posX);
      int z = MathHelper.floor_double(super.posZ);
      return super.worldObj.getBiomeGenForCoords(x, z) == TFBiomeBase.tfSnow?true:super.isValidLightLevel();
   }

   protected Item getDropItem() {
      return TFItems.arcticFur;
   }
}

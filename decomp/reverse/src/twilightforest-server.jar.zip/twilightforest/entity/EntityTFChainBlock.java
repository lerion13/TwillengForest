package twilightforest.entity;

import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFGoblinChain;
import twilightforest.item.ItemTFChainBlock;

public class EntityTFChainBlock extends EntityThrowable implements IEntityMultiPart {

   private static final int MAX_SMASH = 12;
   private static final int MAX_CHAIN = 16;
   private boolean isReturning = false;
   private int blocksSmashed = 0;
   private double velX;
   private double velY;
   private double velZ;
   private boolean isAttached;
   private EntityLivingBase attachedTo;
   public EntityTFGoblinChain chain1;
   public EntityTFGoblinChain chain2;
   public EntityTFGoblinChain chain3;
   public EntityTFGoblinChain chain4;
   public EntityTFGoblinChain chain5;
   public Entity[] partsArray;


   public EntityTFChainBlock(World par1World) {
      super(par1World);
      this.setSize(0.6F, 0.6F);
      this.partsArray = new Entity[]{this.chain1 = new EntityTFGoblinChain(this), this.chain2 = new EntityTFGoblinChain(this), this.chain3 = new EntityTFGoblinChain(this), this.chain4 = new EntityTFGoblinChain(this), this.chain5 = new EntityTFGoblinChain(this)};
   }

   public EntityTFChainBlock(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public EntityTFChainBlock(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
      this.setSize(0.6F, 0.6F);
      this.isReturning = false;
   }

   public void setThrowableHeading(double x, double y, double z, float speed, float accuracy) {
      super.setThrowableHeading(x, y, z, speed, accuracy);
      this.velX = super.motionX;
      this.velY = super.motionY;
      this.velZ = super.motionZ;
   }

   protected float getGravityVelocity() {
      return 0.05F;
   }

   protected void onImpact(MovingObjectPosition mop) {
      if(mop.entityHit != null && mop.entityHit instanceof EntityLivingBase && mop.entityHit != this.getThrower() && mop.entityHit.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)this.getThrower()), 10.0F)) {
         super.ticksExisted += 60;
      }

      if(!super.worldObj.isAirBlock(mop.blockX, mop.blockY, mop.blockZ)) {
         if(!this.isReturning) {
            super.worldObj.playSoundAtEntity(this, "random.anvil_land", 0.125F, super.rand.nextFloat());
         }

         if(!super.worldObj.isRemote && this.blocksSmashed < 12) {
            if(super.worldObj.getBlock(mop.blockX, mop.blockY, mop.blockZ).getBlockHardness(super.worldObj, mop.blockX, mop.blockY, mop.blockZ) > 0.3F) {
               double bounce = 0.6D;
               this.velX *= bounce;
               this.velY *= bounce;
               this.velZ *= bounce;
               switch(mop.sideHit) {
               case 0:
                  if(this.velY > 0.0D) {
                     this.velY *= -bounce;
                  }
                  break;
               case 1:
                  if(this.velY < 0.0D) {
                     this.velY *= -bounce;
                  }
                  break;
               case 2:
                  if(this.velZ > 0.0D) {
                     this.velZ *= -bounce;
                  }
                  break;
               case 3:
                  if(this.velZ < 0.0D) {
                     this.velZ *= -bounce;
                  }
                  break;
               case 4:
                  if(this.velX > 0.0D) {
                     this.velX *= -bounce;
                  }
                  break;
               case 5:
                  if(this.velX < 0.0D) {
                     this.velX *= -bounce;
                  }
               }
            }

            this.affectBlocksInAABB(super.boundingBox, this.getThrower());
         }

         if(!super.worldObj.isRemote) {
            this.isReturning = true;
         }

         if(this.blocksSmashed > 12 && super.ticksExisted < 60) {
            super.ticksExisted += 60;
         }
      }

   }

   private boolean affectBlocksInAABB(AxisAlignedBB par1AxisAlignedBB, EntityLivingBase entity) {
      int minX = MathHelper.floor_double(par1AxisAlignedBB.minX);
      int minY = MathHelper.floor_double(par1AxisAlignedBB.minY);
      int minZ = MathHelper.floor_double(par1AxisAlignedBB.minZ);
      int maxX = MathHelper.floor_double(par1AxisAlignedBB.maxX);
      int maxY = MathHelper.floor_double(par1AxisAlignedBB.maxY);
      int maxZ = MathHelper.floor_double(par1AxisAlignedBB.maxZ);
      boolean hitBlock = false;

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dy = minY; dy <= maxY; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               Block block = super.worldObj.getBlock(dx, dy, dz);
               super.worldObj.getBlockMetadata(dx, dy, dz);
               if(block != Blocks.air && block.getExplosionResistance(this) < 7.0F && block.getBlockHardness(super.worldObj, dx, dy, dz) >= 0.0F) {
                  ++this.blocksSmashed;
                  hitBlock = true;
               }
            }
         }
      }

      return hitBlock;
   }

   public void onUpdate() {
      super.onUpdate();
      if(this.chain1 != null) {
         this.chain1.onUpdate();
         this.chain2.onUpdate();
         this.chain3.onUpdate();
         this.chain4.onUpdate();
         this.chain5.onUpdate();
      }

      if(this.getThrower() == null && !super.worldObj.isRemote) {
         this.setDead();
      }

      if(this.getThrower() != null) {
         float var16 = this.getDistanceToEntity(this.getThrower());
         if(!this.isReturning && var16 > 16.0F) {
            this.isReturning = true;
         }

         if(this.isReturning && var16 < 1.0F) {
            if(this.getThrower() instanceof EntityPlayer) {
               ItemTFChainBlock.setChainAsReturned((EntityPlayer)this.getThrower());
            }

            this.setDead();
         }
      }

      if(this.isReturning && !super.worldObj.isRemote && this.getThrower() != null) {
         EntityLivingBase var14 = this.getThrower();
         Vec3 var18 = Vec3.createVectorHelper(var14.posX - super.posX, var14.posY + (double)var14.getEyeHeight() - 1.200000023841858D - super.posY, var14.posZ - super.posZ).normalize();
         float var19 = Math.min((float)super.ticksExisted * 0.03F, 1.0F);
         super.motionX = this.velX * (1.0D - (double)var19) + var18.xCoord * 2.0D * (double)var19;
         super.motionY = this.velY * (1.0D - (double)var19) + var18.yCoord * 2.0D * (double)var19 - (double)this.getGravityVelocity();
         super.motionZ = this.velZ * (1.0D - (double)var19) + var18.zCoord * 2.0D * (double)var19;
      }

      if(super.worldObj.isRemote && !this.isAttached) {
         List var15 = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.addCoord(-super.motionX, -super.motionY, -super.motionZ).expand(2.0D, 2.0D, 2.0D));

         for(int var17 = 0; var17 < var15.size(); ++var17) {
            Entity var191 = (Entity)var15.get(var17);
            if(var191 instanceof EntityPlayer) {
               this.attachedTo = (EntityPlayer)var191;
            }
         }

         this.isAttached = true;
      }

      if(this.attachedTo != null) {
         Vec3 var161 = this.attachedTo.getLookVec();
         var161.rotateAroundY(-0.4F);
         double var181 = this.attachedTo.posX + var161.xCoord;
         double sy = this.attachedTo.posY + var161.yCoord - 0.6000000238418579D;
         double sz = this.attachedTo.posZ + var161.zCoord;
         double ox = var181 - super.posX;
         double oy = sy - super.posY - 0.25D;
         double oz = sz - super.posZ;
         this.chain1.setPosition(var181 - ox * 0.05D, sy - oy * 0.05D, sz - oz * 0.05D);
         this.chain2.setPosition(var181 - ox * 0.25D, sy - oy * 0.25D, sz - oz * 0.25D);
         this.chain3.setPosition(var181 - ox * 0.45D, sy - oy * 0.45D, sz - oz * 0.45D);
         this.chain4.setPosition(var181 - ox * 0.65D, sy - oy * 0.65D, sz - oz * 0.65D);
         this.chain5.setPosition(var181 - ox * 0.85D, sy - oy * 0.85D, sz - oz * 0.85D);
      }

   }

   protected float func_70182_d() {
      return 1.5F;
   }

   public World func_82194_d() {
      return super.worldObj;
   }

   public boolean attackEntityFromPart(EntityDragonPart p_70965_1_, DamageSource p_70965_2_, float p_70965_3_) {
      return false;
   }

   public Entity[] getParts() {
      return this.partsArray;
   }
}

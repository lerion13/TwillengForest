package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;

public class EntityTFHedgeSpider extends EntitySpider {

   public EntityTFHedgeSpider(World world) {
      super(world);
   }

   public EntityTFHedgeSpider(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected Entity findPlayerToAttack() {
      double var2 = 16.0D;
      return super.worldObj.getClosestVulnerablePlayerToEntity(this, var2);
   }

   protected boolean isValidLightLevel() {
      int chunkX = MathHelper.floor_double(super.posX) >> 4;
      int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
      return TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hedgeMaze?true:super.isValidLightLevel();
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         if(TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hedgeMaze) {
            ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHedge);
         }
      }

   }
}

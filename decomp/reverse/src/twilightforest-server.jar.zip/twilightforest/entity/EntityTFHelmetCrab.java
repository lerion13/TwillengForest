package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.item.TFItems;

public class EntityTFHelmetCrab extends EntityMob {

   public EntityTFHelmetCrab(World world) {
      super(world);
      this.setSize(0.8F, 1.1F);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAILeapAtTarget(this, 0.28F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   public EntityTFHelmetCrab(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void entityInit() {
      super.entityInit();
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(13.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
   }

   protected String getLivingSound() {
      return null;
   }

   protected String getHurtSound() {
      return "mob.spider.say";
   }

   protected String getDeathSound() {
      return "mob.spider.death";
   }

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {
      this.playSound("mob.spider.step", 0.15F, 1.0F);
   }

   protected Item getDropItem() {
      return TFItems.armorShard;
   }

   protected void dropFewItems(boolean flag, int i) {
      super.dropFewItems(flag, i);
      if(super.rand.nextInt(2) == 0) {
         this.dropItem(Items.fish, 1 + i);
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.ARTHROPOD;
   }

   public int getTotalArmorValue() {
      int i = super.getTotalArmorValue() + 6;
      if(i > 20) {
         i = 20;
      }

      return i;
   }
}

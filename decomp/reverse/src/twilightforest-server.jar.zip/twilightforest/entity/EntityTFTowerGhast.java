package twilightforest.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFFeature;

public class EntityTFTowerGhast extends EntityGhast {

   private static final int AGGRO_STATUS = 16;
   protected EntityLivingBase field_70792_g;
   protected boolean isAggressive;
   protected int field_70798_h;
   protected int explosionPower;
   protected int aggroCounter;
   protected float aggroRange;
   protected float stareRange;
   protected float wanderFactor;
   protected int inTrapCounter;
   private ChunkCoordinates homePosition = new ChunkCoordinates(0, 0, 0);
   private float maximumHomeDistance = -1.0F;


   public EntityTFTowerGhast(World par1World) {
      super(par1World);
      this.setSize(4.0F, 6.0F);
      this.aggroRange = 64.0F;
      this.stareRange = 32.0F;
      this.wanderFactor = 16.0F;
      this.inTrapCounter = 0;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
   }

   protected float getSoundVolume() {
      return 0.5F;
   }

   public int getTalkInterval() {
      return 160;
   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }

   public void onUpdate() {
      super.onUpdate();
   }

   public int getAttackStatus() {
      return super.dataWatcher.getWatchableObjectByte(16);
   }

   public void onLivingUpdate() {
      float var1 = this.getBrightness(1.0F);
      if(var1 > 0.5F) {
         super.entityAge += 2;
      }

      if(super.rand.nextBoolean()) {
         super.worldObj.spawnParticle("reddust", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width, super.posY + super.rand.nextDouble() * (double)super.height - 0.25D, super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width, 0.0D, 0.0D, 0.0D);
      }

      super.onLivingUpdate();
   }

   protected void updateEntityActionState() {
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.setDead();
      }

      this.despawnEntity();
      this.checkForTowerHome();
      if(this.inTrapCounter > 0) {
         --this.inTrapCounter;
         this.field_70792_g = null;
      } else {
         super.prevAttackCounter = super.attackCounter;
         if(this.field_70792_g != null && this.field_70792_g.isDead) {
            this.field_70792_g = null;
         }

         if(this.field_70792_g == null) {
            this.field_70792_g = this.findPlayerInRange();
         } else if(!this.isAggressive && this.field_70792_g instanceof EntityPlayer) {
            this.checkToIncreaseAggro((EntityPlayer)this.field_70792_g);
         }

         double offsetX = super.waypointX - super.posX;
         double offsetY = super.waypointY - super.posY;
         double offsetZ = super.waypointZ - super.posZ;
         double distanceDesired = offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ;
         if((distanceDesired < 1.0D || distanceDesired > 3600.0D) && this.wanderFactor > 0.0F) {
            super.waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * this.wanderFactor);
            super.waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * this.wanderFactor);
            super.waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * this.wanderFactor);
         }

         if(this.field_70792_g == null && this.wanderFactor > 0.0F) {
            if(super.courseChangeCooldown-- <= 0) {
               super.courseChangeCooldown += super.rand.nextInt(20) + 20;
               distanceDesired = (double)MathHelper.sqrt_double(distanceDesired);
               if(!this.isWithinHomeDistance(MathHelper.floor_double(super.waypointX), MathHelper.floor_double(super.waypointY), MathHelper.floor_double(super.waypointZ))) {
                  ChunkCoordinates targetRange = TFFeature.getNearestCenterXYZ(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posZ), super.worldObj);
                  Vec3 homeVector = Vec3.createVectorHelper((double)targetRange.posX - super.posX, (double)(targetRange.posY + 128) - super.posY, (double)targetRange.posZ - super.posZ);
                  homeVector = homeVector.normalize();
                  super.waypointX = super.posX + homeVector.xCoord * 16.0D + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
                  super.waypointY = super.posY + homeVector.yCoord * 16.0D + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
                  super.waypointZ = super.posZ + homeVector.zCoord * 16.0D + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
               }

               if(this.isCourseTraversable(super.waypointX, super.waypointY, super.waypointZ, distanceDesired)) {
                  super.motionX += offsetX / distanceDesired * 0.1D;
                  super.motionY += offsetY / distanceDesired * 0.1D;
                  super.motionZ += offsetZ / distanceDesired * 0.1D;
               } else {
                  super.waypointX = super.posX;
                  super.waypointY = super.posY;
                  super.waypointZ = super.posZ;
               }
            }
         } else {
            super.motionX *= 0.75D;
            super.motionY *= 0.75D;
            super.motionZ *= 0.75D;
         }

         double var13 = this.aggroCounter <= 0 && !this.isAggressive?(double)this.stareRange:(double)this.aggroRange;
         if(this.field_70792_g != null && this.field_70792_g.getDistanceSqToEntity(this) < var13 * var13 && this.canEntityBeSeen(this.field_70792_g)) {
            this.faceEntity(this.field_70792_g, 10.0F, (float)this.getVerticalFaceSpeed());
            if(this.isAggressive) {
               if(super.attackCounter == 10) {
                  super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1007, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
               }

               ++super.attackCounter;
               if(super.attackCounter == 20) {
                  this.spitFireball();
                  super.attackCounter = -40;
               }
            }
         } else {
            this.isAggressive = false;
            this.field_70792_g = null;
            super.renderYawOffset = super.rotationYaw = -((float)Math.atan2(super.motionX, super.motionZ)) * 180.0F / 3.1415927F;
            super.rotationPitch = 0.0F;
         }

         if(super.attackCounter > 0 && !this.isAggressive) {
            --super.attackCounter;
         }

         byte currentAggroStatus = super.dataWatcher.getWatchableObjectByte(16);
         byte newAggroStatus = (byte)(super.attackCounter > 10?2:(this.aggroCounter <= 0 && !this.isAggressive?0:1));
         if(currentAggroStatus != newAggroStatus) {
            super.dataWatcher.updateObject(16, Byte.valueOf(newAggroStatus));
         }

      }
   }

   public int getVerticalFaceSpeed() {
      return 500;
   }

   protected void spitFireball() {
      double offsetX = this.field_70792_g.posX - super.posX;
      double offsetY = this.field_70792_g.boundingBox.minY + (double)(this.field_70792_g.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
      double offsetZ = this.field_70792_g.posZ - super.posZ;
      super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1008, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
      EntityLargeFireball entityFireball = new EntityLargeFireball(super.worldObj, this, offsetX, offsetY, offsetZ);
      double shotSpawnDistance = 0.5D;
      Vec3 lookVec = this.getLook(1.0F);
      entityFireball.posX = super.posX + lookVec.xCoord * shotSpawnDistance;
      entityFireball.posY = super.posY + (double)(super.height / 2.0F) + lookVec.yCoord * shotSpawnDistance;
      entityFireball.posZ = super.posZ + lookVec.zCoord * shotSpawnDistance;
      super.worldObj.spawnEntityInWorld(entityFireball);
      if(super.rand.nextInt(6) == 0) {
         this.isAggressive = false;
      }

   }

   protected EntityLivingBase findPlayerInRange() {
      EntityPlayer closest = super.worldObj.getClosestVulnerablePlayerToEntity(this, (double)this.aggroRange);
      if(closest != null) {
         float range = this.getDistanceToEntity(closest);
         if(range < this.stareRange || this.shouldAttackPlayer(closest)) {
            return closest;
         }
      }

      return null;
   }

   protected void checkToIncreaseAggro(EntityPlayer par1EntityPlayer) {
      if(this.shouldAttackPlayer(par1EntityPlayer)) {
         if(this.aggroCounter == 0) {
            super.worldObj.playSoundAtEntity(this, "mob.ghast.moan", 1.0F, 1.0F);
         }

         if(this.aggroCounter++ >= 20) {
            this.aggroCounter = 0;
            this.isAggressive = true;
         }
      } else {
         this.aggroCounter = 0;
      }

   }

   protected boolean shouldAttackPlayer(EntityPlayer par1EntityPlayer) {
      int dx = MathHelper.floor_double(par1EntityPlayer.posX);
      int dy = MathHelper.floor_double(par1EntityPlayer.posY);
      int dz = MathHelper.floor_double(par1EntityPlayer.posZ);
      return super.worldObj.canBlockSeeTheSky(dx, dy, dz) && par1EntityPlayer.canEntityBeSeen(this);
   }

   protected boolean isCourseTraversable(double par1, double par3, double par5, double par7) {
      double var9 = (super.waypointX - super.posX) / par7;
      double var11 = (super.waypointY - super.posY) / par7;
      double var13 = (super.waypointZ - super.posZ) / par7;
      AxisAlignedBB var15 = super.boundingBox.copy();

      for(int var16 = 1; (double)var16 < par7; ++var16) {
         var15.offset(var9, var11, var13);
         if(!super.worldObj.getCollidingBoundingBoxes(this, var15).isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      boolean wasAttacked = super.attackEntityFrom(par1DamageSource, par2);
      if(wasAttacked && par1DamageSource.getSourceOfDamage() instanceof EntityLivingBase) {
         this.field_70792_g = (EntityLivingBase)par1DamageSource.getSourceOfDamage();
         this.isAggressive = true;
         return true;
      } else {
         return wasAttacked;
      }
   }

   public boolean getCanSpawnHere() {
      return super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).isEmpty() && !super.worldObj.isAnyLiquid(super.boundingBox) && super.worldObj.difficultySetting != EnumDifficulty.PEACEFUL && this.isValidLightLevel();
   }

   protected boolean isValidLightLevel() {
      return true;
   }

   protected void checkForTowerHome() {
      if(!this.hasHome()) {
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         TFFeature nearFeature = TFFeature.getFeatureForRegion(chunkX, chunkZ, super.worldObj);
         if(nearFeature != TFFeature.darkTower) {
            this.detachHome();
            super.entityAge += 5;
         } else {
            ChunkCoordinates cc = TFFeature.getNearestCenterXYZ(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posZ), super.worldObj);
            this.setHomeArea(cc.posX, cc.posY + 128, cc.posZ, 64);
         }
      }

   }

   public boolean isWithinHomeDistance(int x, int y, int z) {
      if(this.getMaximumHomeDistance() == -1.0F) {
         return true;
      } else {
         ChunkCoordinates home = this.getHomePosition();
         return y > 64 && y < 210 && home.getDistanceSquared(x, home.posY, z) < this.getMaximumHomeDistance() * this.getMaximumHomeDistance();
      }
   }

   public void setInTrap() {
      this.inTrapCounter = 10;
   }

   public void setHomeArea(int par1, int par2, int par3, int par4) {
      this.homePosition.set(par1, par2, par3);
      this.maximumHomeDistance = (float)par4;
   }

   public ChunkCoordinates getHomePosition() {
      return this.homePosition;
   }

   public float getMaximumHomeDistance() {
      return this.maximumHomeDistance;
   }

   public void detachHome() {
      this.maximumHomeDistance = -1.0F;
   }

   public boolean hasHome() {
      return this.maximumHomeDistance != -1.0F;
   }
}

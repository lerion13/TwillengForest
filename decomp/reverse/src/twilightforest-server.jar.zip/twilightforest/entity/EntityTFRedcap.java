package twilightforest.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.entity.ai.EntityAITFRedcapLightTNT;
import twilightforest.entity.ai.EntityAITFRedcapShy;

public class EntityTFRedcap extends EntityMob {

   public static ItemStack heldPick = new ItemStack(Items.iron_pickaxe, 1);
   public static ItemStack heldTNT = new ItemStack(Blocks.tnt, 1);
   public static ItemStack heldFlint = new ItemStack(Items.flint_and_steel, 1);
   private boolean shy;
   private int tntLeft;


   public EntityTFRedcap(World world) {
      super(world);
      this.tntLeft = 0;
      this.setSize(0.9F, 1.4F);
      this.shy = true;
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityTNTPrimed.class, 2.0F, 1.0D, 2.0D));
      super.tasks.addTask(2, new EntityAITFRedcapShy(this, 1.0F));
      super.tasks.addTask(3, new EntityAITFRedcapLightTNT(this, 1.0F));
      super.tasks.addTask(5, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.setCurrentItemOrArmor(0, heldPick);
      this.setCurrentItemOrArmor(1, new ItemStack(Items.iron_boots));
      super.equipmentDropChances[0] = 0.2F;
      super.equipmentDropChances[1] = 0.2F;
   }

   public EntityTFRedcap(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.redcap.redcap";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.redcap.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.redcap.die";
   }

   protected Item getDropItem() {
      return Items.coal;
   }

   public boolean isShy() {
      return this.shy && super.recentlyHit <= 0;
   }

   public int getTntLeft() {
      return this.tntLeft;
   }

   public void setTntLeft(int tntLeft) {
      this.tntLeft = tntLeft;
   }

   public ItemStack getPick() {
      return heldPick;
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("TNTLeft", this.getTntLeft());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setTntLeft(par1NBTTagCompound.getInteger("TNTLeft"));
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         if(TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hill1) {
            ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHill1);
         }
      }

   }

}

package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.biomes.TFBiomeBase;

public class EntityTFMosquitoSwarm extends EntityMob {

   public EntityTFMosquitoSwarm(World par1World) {
      super(par1World);
      this.setSize(0.7F, 1.9F);
      super.stepHeight = 2.1F;
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(12.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.mosquito.mosquito";
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      if(super.attackEntityAsMob(par1Entity)) {
         if(par1Entity instanceof EntityLivingBase) {
            byte duration = 7;
            if(super.worldObj.difficultySetting != EnumDifficulty.EASY) {
               if(super.worldObj.difficultySetting == EnumDifficulty.NORMAL) {
                  duration = 15;
               } else if(super.worldObj.difficultySetting == EnumDifficulty.HARD) {
                  duration = 30;
               }
            }

            if(duration > 0) {
               ((EntityLivingBase)par1Entity).addPotionEffect(new PotionEffect(Potion.hunger.id, duration * 20, 0));
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean getCanSpawnHere() {
      return super.worldObj.getBiomeGenForCoords(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posZ)) != TFBiomeBase.tfSwamp?super.getCanSpawnHere():super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).size() == 0;
   }

   public int getMaxSpawnedInChunk() {
      return 1;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }
}

package twilightforest.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

public class EntityTFProtectionBox extends Entity {

   public int lifeTime;
   public int sizeX;
   public int sizeY;
   public int sizeZ;


   public EntityTFProtectionBox(World worldObj, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
      super(worldObj);
      this.setLocationAndAngles((double)minX, (double)minY, (double)minZ, 0.0F, 0.0F);
      this.sizeX = Math.abs(maxX - minX) + 1;
      this.sizeY = Math.abs(maxY - minY) + 1;
      this.sizeZ = Math.abs(maxZ - minZ) + 1;
      this.setSize((float)Math.max(this.sizeX, this.sizeZ), (float)this.sizeY);
      this.lifeTime = 60;
   }

   public void onUpdate() {
      super.onUpdate();
      if(this.lifeTime <= 1) {
         this.setDead();
      } else {
         --this.lifeTime;
      }

   }

   public float getBrightness(float par1) {
      return 1.0F;
   }

   @SideOnly(Side.CLIENT)
   public int getBrightnessForRender(float par1) {
      return 15728880;
   }

   protected void entityInit() {}

   protected void readEntityFromNBT(NBTTagCompound var1) {}

   protected void writeEntityToNBT(NBTTagCompound var1) {}

   @SideOnly(Side.CLIENT)
   public boolean canRenderOnFire() {
      return false;
   }
}

package twilightforest.entity.boss;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFLich;
import twilightforest.entity.boss.EntityTFLichBomb;

public class EntityTFLichBolt extends EntityThrowable {

   public EntityLivingBase playerReflects = null;


   public EntityTFLichBolt(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public EntityTFLichBolt(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
   }

   public EntityTFLichBolt(World par1World) {
      super(par1World);
   }

   protected float func_70182_d() {
      return 0.5F;
   }

   public void onUpdate() {
      super.onUpdate();
      this.makeTrail();
   }

   public void makeTrail() {
      for(int i = 0; i < 5; ++i) {
         double dx = super.posX + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dy = super.posY + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dz = super.posZ + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double s1 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.17F);
         double s2 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.8F);
         double s3 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.69F);
         super.worldObj.spawnParticle("mobSpell", dx, dy, dz, s1, s2, s3);
      }

   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public float getCollisionBorderSize() {
      return 1.0F;
   }

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      this.setBeenAttacked();
      if(damagesource.getEntity() != null) {
         Vec3 vec3d = damagesource.getEntity().getLookVec();
         if(vec3d != null) {
            this.setThrowableHeading(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord, 1.5F, 0.1F);
         }

         if(damagesource.getEntity() instanceof EntityLivingBase) {
            this.playerReflects = (EntityLivingBase)damagesource.getEntity();
         }

         return true;
      } else {
         return false;
      }
   }

   public EntityLivingBase getThrower() {
      return this.playerReflects != null?this.playerReflects:super.getThrower();
   }

   protected float getGravityVelocity() {
      return 0.001F;
   }

   protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
      boolean passThrough = false;
      if(par1MovingObjectPosition.entityHit != null && (par1MovingObjectPosition.entityHit instanceof EntityTFLichBolt || par1MovingObjectPosition.entityHit instanceof EntityTFLichBomb)) {
         passThrough = true;
      }

      if(par1MovingObjectPosition.entityHit != null && par1MovingObjectPosition.entityHit instanceof EntityLivingBase) {
         if(par1MovingObjectPosition.entityHit instanceof EntityTFLich) {
            EntityTFLich i = (EntityTFLich)par1MovingObjectPosition.entityHit;
            if(i.isShadowClone()) {
               passThrough = true;
            }
         }

         if(!passThrough && par1MovingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, this.getThrower()), 6.0F)) {
            ;
         }
      }

      if(!passThrough) {
         for(int var4 = 0; var4 < 8; ++var4) {
            super.worldObj.spawnParticle("iconcrack_" + Item.getIdFromItem(Items.ender_pearl), super.posX, super.posY, super.posZ, super.rand.nextGaussian() * 0.05D, super.rand.nextDouble() * 0.2D, super.rand.nextGaussian() * 0.05D);
         }

         if(!super.worldObj.isRemote) {
            this.setDead();
         }
      }

   }
}

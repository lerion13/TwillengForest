package twilightforest.entity.boss;

import cpw.mods.fml.common.FMLLog;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.TFTreasure;
import twilightforest.TwilightForestMod;
import twilightforest.block.TFBlocks;
import twilightforest.entity.EntityTFMiniGhast;
import twilightforest.entity.EntityTFTowerGhast;
import twilightforest.entity.boss.EntityTFUrGhastFireball;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFUrGhast extends EntityTFTowerGhast implements IBossDisplayData {

   private static final int DATA_TANTRUM = 18;
   private static final int HOVER_ALTITUDE = 20;
   public double courseX;
   public double courseY;
   public double courseZ;
   ArrayList trapLocations;
   ArrayList travelCoords;
   int currentTravelCoordIndex;
   int travelPathRepetitions;
   int desiredRepetitions;
   int nextTantrumCry;
   float damageUntilNextPhase;
   boolean noTrapMode;


   public EntityTFUrGhast(World par1World) {
      super(par1World);
      this.setSize(14.0F, 18.0F);
      super.aggroRange = 128.0F;
      super.wanderFactor = 32.0F;
      super.noClip = true;
      this.trapLocations = new ArrayList();
      this.travelCoords = new ArrayList();
      this.setInTantrum(false);
      this.damageUntilNextPhase = 45.0F;
      super.experienceValue = 317;
      this.noTrapMode = false;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(250.0D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(18, Byte.valueOf((byte)0));
   }

   protected boolean canDespawn() {
      return false;
   }

   public void onUpdate() {
      super.onUpdate();
      if(super.deathTime > 0) {
         for(int k = 0; k < 5; ++k) {
            double d = super.rand.nextGaussian() * 0.02D;
            double d1 = super.rand.nextGaussian() * 0.02D;
            double d2 = super.rand.nextGaussian() * 0.02D;
            String explosionType = super.rand.nextBoolean()?"hugeexplosion":"explode";
            super.worldObj.spawnParticle(explosionType, super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, d, d1, d2);
         }
      }

   }

   public boolean attackEntityFrom(DamageSource source, float damage) {
      if(source == DamageSource.inWall) {
         return false;
      } else {
         boolean attackSuccessful = false;
         if(this.isInTantrum()) {
            damage /= 4.0F;
         }

         if("fireball".equals(source.getDamageType()) && source.getEntity() instanceof EntityPlayer) {
            attackSuccessful = super.attackEntityFrom(DamageSource.causeThrownDamage(source.getSourceOfDamage(), source.getEntity()), damage);
         } else {
            attackSuccessful = super.attackEntityFrom(source, damage);
         }

         if(!super.worldObj.isRemote) {
            if(super.hurtTime == super.maxHurtTime) {
               this.damageUntilNextPhase -= this.getLastDamage();
               FMLLog.info("[Urghast] Attack successful, %f damage until phase switch.", new Object[]{Float.valueOf(this.damageUntilNextPhase)});
               if(this.damageUntilNextPhase <= 0.0F) {
                  this.switchPhase();
               }
            } else {
               FMLLog.info("[Urghast] Attack fail with %s type attack for %f damage", new Object[]{source.damageType, Float.valueOf(damage)});
            }
         }

         return attackSuccessful;
      }
   }

   private float getLastDamage() {
      return super.prevHealth - this.getHealth();
   }

   private void switchPhase() {
      if(this.isInTantrum()) {
         this.stopTantrum();
      } else {
         this.startTantrum();
      }

      this.damageUntilNextPhase = 48.0F;
   }

   protected void startTantrum() {
      this.setInTantrum(true);
      short rainTime = 6000;
      WorldInfo worldInfo = MinecraftServer.getServer().worldServers[0].getWorldInfo();
      worldInfo.setRaining(true);
      worldInfo.setThundering(true);
      worldInfo.setRainTime(rainTime);
      worldInfo.setThunderTime(rainTime);
      this.spawnGhastsAtTraps();
   }

   protected void spawnGhastsAtTraps() {
      ArrayList ghastSpawns = new ArrayList(this.trapLocations);
      int numSpawns = Math.min(2, ghastSpawns.size());

      for(int i = 0; i < numSpawns; ++i) {
         int index = super.rand.nextInt(ghastSpawns.size());
         ChunkCoordinates spawnCoord = (ChunkCoordinates)ghastSpawns.get(index);
         ghastSpawns.remove(index);
         this.spawnMinionGhastsAt(spawnCoord.posX, spawnCoord.posY, spawnCoord.posZ);
      }

   }

   public void stopTantrum() {
      this.setInTantrum(false);
   }

   private void spawnMinionGhastsAt(int x, int y, int z) {
      byte tries = 24;
      int spawns = 0;
      byte maxSpawns = 6;
      byte rangeXZ = 4;
      byte rangeY = 8;
      super.worldObj.addWeatherEffect(new EntityLightningBolt(super.worldObj, (double)x, (double)(y + 4), (double)z));

      for(int i = 0; i < tries; ++i) {
         EntityTFMiniGhast minion = new EntityTFMiniGhast(super.worldObj);
         double sx = (double)x + (super.rand.nextDouble() - super.rand.nextDouble()) * (double)rangeXZ;
         double sy = (double)y + super.rand.nextDouble() * (double)rangeY;
         double sz = (double)z + (super.rand.nextDouble() - super.rand.nextDouble()) * (double)rangeXZ;
         minion.setLocationAndAngles(sx, sy, sz, super.worldObj.rand.nextFloat() * 360.0F, 0.0F);
         minion.makeBossMinion();
         if(minion.getCanSpawnHere()) {
            super.worldObj.spawnEntityInWorld(minion);
            minion.spawnExplosionParticle();
         }

         ++spawns;
         if(spawns >= maxSpawns) {
            break;
         }
      }

   }

   protected void updateEntityActionState() {
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.setDead();
      }

      this.despawnEntity();
      List nearbyGhasts = super.worldObj.getEntitiesWithinAABB(EntityTFMiniGhast.class, super.boundingBox.expand(1.0D, 1.0D, 1.0D));
      Iterator offsetX = nearbyGhasts.iterator();

      while(offsetX.hasNext()) {
         EntityTFMiniGhast ghast = (EntityTFMiniGhast)offsetX.next();
         ghast.setDead();
         this.heal(2.0F);
      }

      if(this.trapLocations.isEmpty() && !this.noTrapMode) {
         this.scanForTrapsTwice();
      }

      if(this.trapLocations.isEmpty() && !this.noTrapMode) {
         FMLLog.info("[TwilightForest] Ur-ghast cannot find traps nearby, entering trap-less mode", new Object[0]);
         this.noTrapMode = true;
      }

      if(super.inTrapCounter > 0) {
         --super.inTrapCounter;
         super.field_70792_g = null;
      } else {
         super.prevAttackCounter = super.attackCounter;
         if(super.field_70792_g != null && super.field_70792_g.isDead) {
            super.field_70792_g = null;
         }

         if(super.field_70792_g == null) {
            super.field_70792_g = this.findPlayerInRange();
         } else if(!super.isAggressive && super.field_70792_g instanceof EntityPlayer) {
            this.checkToIncreaseAggro((EntityPlayer)super.field_70792_g);
         }

         if(this.isInTantrum()) {
            this.shedTear();
            super.field_70792_g = null;
            if(--this.nextTantrumCry <= 0) {
               this.playSound(this.getHurtSound(), this.getSoundVolume(), this.getSoundPitch());
               this.nextTantrumCry = 20 + super.rand.nextInt(30);
            }

            if(super.ticksExisted % 10 == 0) {
               this.doTantrumDamageEffects();
            }
         }

         this.checkAndChangeCourse();
         double var14 = super.waypointX - super.posX;
         double offsetY = super.waypointY - super.posY;
         double offsetZ = super.waypointZ - super.posZ;
         double distanceToWaypoint = var14 * var14 + offsetY * offsetY + offsetZ * offsetZ;
         if(distanceToWaypoint < 1.0D || distanceToWaypoint > 3600.0D) {
            this.makeNewWaypoint();
         }

         double targetRange;
         if(super.courseChangeCooldown-- <= 0) {
            super.courseChangeCooldown += super.rand.nextInt(5) + 0;
            distanceToWaypoint = (double)MathHelper.sqrt_double(distanceToWaypoint);
            targetRange = 0.05D;
            super.motionX += var14 / distanceToWaypoint * targetRange;
            super.motionY += offsetY / distanceToWaypoint * targetRange;
            super.motionZ += offsetZ / distanceToWaypoint * targetRange;
         }

         targetRange = super.aggroCounter <= 0 && !super.isAggressive?(double)super.stareRange:(double)super.aggroRange;
         if(super.field_70792_g != null && super.field_70792_g.getDistanceSqToEntity(this) < targetRange * targetRange && this.canEntityBeSeen(super.field_70792_g)) {
            this.faceEntity(super.field_70792_g, 10.0F, (float)this.getVerticalFaceSpeed());
            if(super.isAggressive) {
               if(super.attackCounter == 10) {
                  this.playSound("mob.ghast.charge", this.getSoundVolume(), this.getSoundPitch());
               }

               ++super.attackCounter;
               if(super.attackCounter == 20) {
                  this.spitFireball();
                  super.attackCounter = -40;
               }
            }
         } else {
            super.isAggressive = false;
            super.field_70792_g = null;
            super.rotationYaw = -((float)Math.atan2(super.motionX, super.motionZ)) * 180.0F / 3.1415927F;
            super.rotationPitch = 0.0F;
         }

         if(super.attackCounter > 0 && !super.isAggressive) {
            --super.attackCounter;
         }

         byte currentAggroStatus = super.dataWatcher.getWatchableObjectByte(16);
         byte newAggroStatus = (byte)(super.attackCounter > 10?2:(super.aggroCounter <= 0 && !super.isAggressive?0:1));
         if(currentAggroStatus != newAggroStatus) {
            super.dataWatcher.updateObject(16, Byte.valueOf(newAggroStatus));
         }

      }
   }

   private void doTantrumDamageEffects() {
      AxisAlignedBB below = super.boundingBox.getOffsetBoundingBox(0.0D, -16.0D, 0.0D).expand(0.0D, 16.0D, 0.0D);
      List playersBelow = super.worldObj.getEntitiesWithinAABB(EntityPlayer.class, below);
      Iterator ghastsBelow = playersBelow.iterator();

      while(ghastsBelow.hasNext()) {
         EntityPlayer player = (EntityPlayer)ghastsBelow.next();
         int ghast = MathHelper.floor_double(player.posX);
         int dy = MathHelper.floor_double(player.posY);
         int dz = MathHelper.floor_double(player.posZ);
         if(super.worldObj.canBlockSeeTheSky(ghast, dy, dz)) {
            player.attackEntityFrom(DamageSource.anvil, 3.0F);
         }
      }

      List var8 = super.worldObj.getEntitiesWithinAABB(EntityTFMiniGhast.class, below);

      EntityTFMiniGhast var10;
      for(Iterator var9 = var8.iterator(); var9.hasNext(); ++var10.motionY) {
         var10 = (EntityTFMiniGhast)var9.next();
      }

   }

   private void shedTear() {
      TwilightForestMod.proxy.spawnParticle(super.worldObj, "bosstear", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width, super.posY + super.rand.nextDouble() * (double)super.height - 0.25D, super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width, 0.0D, 0.0D, 0.0D);
   }

   protected void makeNewWaypoint() {
      double closestDistance = this.getDistanceSq(this.courseX, this.courseY, this.courseZ);

      for(int i = 0; i < 50; ++i) {
         double potentialX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * super.wanderFactor);
         double potentialY = this.courseY + (double)(super.rand.nextFloat() * 8.0F) - 4.0D;
         double potentialZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * super.wanderFactor);
         double offsetX = this.courseX - potentialX;
         double offsetY = this.courseY - potentialY;
         double offsetZ = this.courseZ - potentialZ;
         double potentialDistanceToCourse = offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ;
         if(potentialDistanceToCourse < closestDistance) {
            super.waypointX = potentialX;
            super.waypointY = potentialY;
            super.waypointZ = potentialZ;
            closestDistance = potentialDistanceToCourse;
         }
      }

   }

   protected void checkAndChangeCourse() {
      if(this.courseX == 0.0D && this.courseY == 0.0D && this.courseZ == 0.0D) {
         this.changeCourse();
      }

      double offsetX = this.courseX - super.posX;
      double offsetY = this.courseY - super.posY;
      double offsetZ = this.courseZ - super.posZ;
      double distanceToCourse = offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ;
      if(distanceToCourse < 100.0D) {
         this.changeCourse();
      }

   }

   private void changeCourse() {
      if(this.travelCoords.isEmpty()) {
         this.makeTravelPath();
      }

      if(!this.travelCoords.isEmpty()) {
         if(this.currentTravelCoordIndex >= this.travelCoords.size()) {
            this.currentTravelCoordIndex = 0;
            ++this.travelPathRepetitions;
            if(!this.checkGhastsAtTraps()) {
               this.spawnGhastsAtTraps();
            }
         }

         this.courseX = (double)((ChunkCoordinates)this.travelCoords.get(this.currentTravelCoordIndex)).posX;
         this.courseY = (double)(((ChunkCoordinates)this.travelCoords.get(this.currentTravelCoordIndex)).posY + 20);
         this.courseZ = (double)((ChunkCoordinates)this.travelCoords.get(this.currentTravelCoordIndex)).posZ;
         ++this.currentTravelCoordIndex;
      }

   }

   private boolean checkGhastsAtTraps() {
      int trapsWithEnoughGhasts = 0;
      Iterator var2 = this.trapLocations.iterator();

      while(var2.hasNext()) {
         ChunkCoordinates trap = (ChunkCoordinates)var2.next();
         AxisAlignedBB aabb = AxisAlignedBB.getBoundingBox((double)trap.posX, (double)trap.posY, (double)trap.posZ, (double)(trap.posX + 1), (double)(trap.posY + 1), (double)(trap.posZ + 1)).expand(8.0D, 16.0D, 8.0D);
         List nearbyGhasts = super.worldObj.getEntitiesWithinAABB(EntityTFMiniGhast.class, aabb);
         if(nearbyGhasts.size() >= 4) {
            ++trapsWithEnoughGhasts;
         }
      }

      return trapsWithEnoughGhasts >= 1;
   }

   private void makeTravelPath() {
      int px = MathHelper.floor_double(super.posX);
      int py = MathHelper.floor_double(super.posY);
      int pz = MathHelper.floor_double(super.posZ);
      ArrayList potentialPoints;
      if(!this.noTrapMode) {
         potentialPoints = new ArrayList(this.trapLocations);
      } else {
         potentialPoints = new ArrayList();
         potentialPoints.add(new ChunkCoordinates(px + 20, py - 20, pz));
         potentialPoints.add(new ChunkCoordinates(px, py - 20, pz - 20));
         potentialPoints.add(new ChunkCoordinates(px - 20, py - 20, pz));
         potentialPoints.add(new ChunkCoordinates(px, py - 20, pz + 20));
      }

      this.travelCoords.clear();

      while(!potentialPoints.isEmpty()) {
         int index = super.rand.nextInt(potentialPoints.size());
         this.travelCoords.add(potentialPoints.get(index));
         potentialPoints.remove(index);
      }

      if(this.noTrapMode) {
         this.travelCoords.add(new ChunkCoordinates(px, py - 20, pz));
      }

   }

   protected void spitFireball() {
      double offsetX = super.field_70792_g.posX - super.posX;
      double offsetY = super.field_70792_g.boundingBox.minY + (double)(super.field_70792_g.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
      double offsetZ = super.field_70792_g.posZ - super.posZ;
      super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1008, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
      EntityTFUrGhastFireball entityFireball = new EntityTFUrGhastFireball(super.worldObj, this, offsetX, offsetY, offsetZ);
      entityFireball.field_92057_e = 1;
      double shotSpawnDistance = 8.5D;
      Vec3 lookVec = this.getLook(1.0F);
      entityFireball.posX = super.posX + lookVec.xCoord * shotSpawnDistance;
      entityFireball.posY = super.posY + (double)(super.height / 2.0F) + lookVec.yCoord * shotSpawnDistance;
      entityFireball.posZ = super.posZ + lookVec.zCoord * shotSpawnDistance;
      super.worldObj.spawnEntityInWorld(entityFireball);

      for(int i = 0; i < 2; ++i) {
         entityFireball = new EntityTFUrGhastFireball(super.worldObj, this, offsetX + (double)((super.rand.nextFloat() - super.rand.nextFloat()) * 8.0F), offsetY, offsetZ + (double)((super.rand.nextFloat() - super.rand.nextFloat()) * 8.0F));
         entityFireball.field_92057_e = 1;
         entityFireball.posX = super.posX + lookVec.xCoord * shotSpawnDistance;
         entityFireball.posY = super.posY + (double)(super.height / 2.0F) + lookVec.yCoord * shotSpawnDistance;
         entityFireball.posZ = super.posZ + lookVec.zCoord * shotSpawnDistance;
         super.worldObj.spawnEntityInWorld(entityFireball);
      }

   }

   private void scanForTrapsTwice() {
      byte scanRangeXZ = 48;
      byte scanRangeY = 32;
      int px = MathHelper.floor_double(super.posX);
      int py = MathHelper.floor_double(super.posY);
      int pz = MathHelper.floor_double(super.posZ);
      this.scanForTraps(scanRangeXZ, scanRangeY, px, py, pz);
      if(this.trapLocations.size() > 0) {
         int ax = 0;
         int ay = 0;
         int az = 0;

         ChunkCoordinates trapCoords;
         for(Iterator var9 = this.trapLocations.iterator(); var9.hasNext(); az += trapCoords.posZ) {
            trapCoords = (ChunkCoordinates)var9.next();
            ax += trapCoords.posX;
            ay += trapCoords.posY;
         }

         ax /= this.trapLocations.size();
         ay /= this.trapLocations.size();
         az /= this.trapLocations.size();
         this.scanForTraps(scanRangeXZ, scanRangeY, ax, ay, az);
      }

   }

   protected void scanForTraps(int scanRangeXZ, int scanRangeY, int px, int py, int pz) {
      for(int sx = -scanRangeXZ; sx <= scanRangeXZ; ++sx) {
         for(int sz = -scanRangeXZ; sz <= scanRangeXZ; ++sz) {
            for(int sy = -scanRangeY; sy <= scanRangeY; ++sy) {
               if(this.isTrapAt(px + sx, py + sy, pz + sz)) {
                  ChunkCoordinates trapCoords = new ChunkCoordinates(px + sx, py + sy, pz + sz);
                  if(!this.trapLocations.contains(trapCoords)) {
                     this.trapLocations.add(trapCoords);
                  }
               }
            }
         }
      }

   }

   private boolean isTrapAt(int x, int y, int z) {
      return super.worldObj.blockExists(x, y, z) && super.worldObj.getBlock(x, y, z) == TFBlocks.towerDevice && (super.worldObj.getBlockMetadata(x, y, z) == 10 || super.worldObj.getBlockMetadata(x, y, z) == 11);
   }

   public boolean isBurning() {
      return false;
   }

   public boolean canBePushed() {
      return false;
   }

   public boolean isInTantrum() {
      return super.dataWatcher.getWatchableObjectByte(18) != 0;
   }

   public void setInTantrum(boolean par1) {
      super.dataWatcher.updateObject(18, par1?Byte.valueOf((byte)-1):Byte.valueOf((byte)0));
      this.damageUntilNextPhase = 48.0F;
   }

   protected float getSoundVolume() {
      return 16.0F;
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.5F;
   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      nbttagcompound.setBoolean("inTantrum", this.isInTantrum());
      super.writeEntityToNBT(nbttagcompound);
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      this.setInTantrum(nbttagcompound.getBoolean("inTantrum"));
   }

   protected void onDeathUpdate() {
      super.onDeathUpdate();
      if(super.deathTime == 20 && !super.worldObj.isRemote) {
         ChunkCoordinates chestCoords = this.findChestCoords();
         TFTreasure.darktower_boss.generate(super.worldObj, (Random)null, chestCoords.posX, chestCoords.posY, chestCoords.posZ);
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightProgressUrghast);
      }

      if(!super.worldObj.isRemote && super.worldObj.provider instanceof WorldProviderTwilightForest) {
         ChunkCoordinates chestCoords = this.findChestCoords();
         int dx = chestCoords.posX;
         int dy = chestCoords.posY;
         int dz = chestCoords.posZ;
         ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
         TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(dx, dz, super.worldObj);
         if(nearbyFeature == TFFeature.darkTower) {
            chunkProvider.setStructureConquered(dx, dy, dz, true);
         }
      }

   }

   private ChunkCoordinates findChestCoords() {
      if(this.trapLocations.size() <= 0) {
         return new ChunkCoordinates(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posY), MathHelper.floor_double(super.posZ));
      } else {
         int ax = 0;
         int ay = 0;
         int az = 0;

         ChunkCoordinates trapCoords;
         for(Iterator var4 = this.trapLocations.iterator(); var4.hasNext(); az += trapCoords.posZ) {
            trapCoords = (ChunkCoordinates)var4.next();
            ax += trapCoords.posX;
            ay += trapCoords.posY;
         }

         ax /= this.trapLocations.size();
         ay /= this.trapLocations.size();
         az /= this.trapLocations.size();
         return new ChunkCoordinates(ax, ay + 2, az);
      }
   }
}

package twilightforest.entity.boss;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.entity.boss.EntityTFHydraHead;
import twilightforest.entity.boss.EntityTFHydraPart;
import twilightforest.entity.boss.HydraHeadContainer;
import twilightforest.item.TFItems;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFHydra extends EntityLiving implements IBossDisplayData, IEntityMultiPart, IMob {

   private static int TICKS_BEFORE_HEALING = 1000;
   private static int HEAD_RESPAWN_TICKS = 100;
   private static int HEAD_MAX_DAMAGE = 120;
   private static float ARMOR_MULTIPLIER = 8.0F;
   private static int MAX_HEALTH = 360;
   private static float HEADS_ACTIVITY_FACTOR = 0.3F;
   private static int SECONDARY_FLAME_CHANCE = 10;
   private static int SECONDARY_MORTAR_CHANCE = 16;
   private static final int DATA_SPAWNHEADS = 17;
   private static final int DATA_BOSSHEALTH = 18;
   public Entity[] partArray;
   public EntityDragonPart body;
   public HydraHeadContainer[] hc;
   public int numHeads;
   public EntityDragonPart leftLeg;
   public EntityDragonPart rightLeg;
   public EntityDragonPart tail;
   Entity field_70776_bF;
   public int ticksSinceDamaged;


   public EntityTFHydra(World world) {
      super(world);
      this.numHeads = 7;
      this.field_70776_bF = null;
      this.ticksSinceDamaged = 0;
      this.partArray = new Entity[]{this.body = new EntityDragonPart(this, "body", 4.0F, 4.0F), this.leftLeg = new EntityDragonPart(this, "leg", 2.0F, 3.0F), this.rightLeg = new EntityDragonPart(this, "leg", 2.0F, 3.0F), this.tail = new EntityDragonPart(this, "tail", 4.0F, 4.0F)};
      this.hc = new HydraHeadContainer[this.numHeads];

      for(int partList = 0; partList < this.numHeads; ++partList) {
         this.hc[partList] = new HydraHeadContainer(this, partList, partList < 3);
      }

      ArrayList var4 = new ArrayList();
      Collections.addAll(var4, this.partArray);

      for(int i = 0; i < this.numHeads; ++i) {
         Collections.addAll(var4, this.hc[i].getNeckArray());
      }

      this.partArray = (Entity[])var4.toArray(this.partArray);
      this.setSize(16.0F, 12.0F);
      super.ignoreFrustumCheck = true;
      super.isImmuneToFire = true;
      super.experienceValue = 511;
      this.setSpawnHeads(true);
   }

   public EntityTFHydra(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)MAX_HEALTH);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
   }

   public void onLivingUpdate() {
      int angle;
      if((this.hc[0].headEntity == null || this.hc[1].headEntity == null || this.hc[2].headEntity == null) && this.shouldSpawnHeads() && !super.worldObj.isRemote) {
         for(angle = 0; angle < this.numHeads; ++angle) {
            this.hc[angle].headEntity = new EntityTFHydraHead(this, "head" + angle, 3.0F, 3.0F);
            this.hc[angle].headEntity.setPosition(super.posX, super.posY, super.posZ);
            super.worldObj.spawnEntityInWorld(this.hc[angle].headEntity);
         }

         this.setSpawnHeads(false);
      }

      this.body.onUpdate();

      for(angle = 0; angle < this.numHeads; ++angle) {
         this.hc[angle].onUpdate();
      }

      if(!super.worldObj.isRemote) {
         super.dataWatcher.updateObject(18, Integer.valueOf((int)this.getHealth()));
      } else if(this.getHealth() > 0.0F) {
         super.deathTime = 0;
      }

      if(super.hurtTime > 0) {
         for(angle = 0; angle < this.numHeads; ++angle) {
            this.hc[angle].setHurtTime(super.hurtTime);
         }
      }

      ++this.ticksSinceDamaged;
      if(!super.worldObj.isRemote && this.ticksSinceDamaged > TICKS_BEFORE_HEALING && this.ticksSinceDamaged % 5 == 0) {
         this.heal(1.0F);
      }

      this.setDifficultyVariables();
      if(super.newPosRotationIncrements > 0) {
         double var9 = super.posX + (super.newPosX - super.posX) / (double)super.newPosRotationIncrements;
         double var3 = super.posY + (super.newPosY - super.posY) / (double)super.newPosRotationIncrements;
         double var5 = super.posZ + (super.newPosZ - super.posZ) / (double)super.newPosRotationIncrements;
         double var7 = MathHelper.wrapAngleTo180_double(super.newRotationYaw - (double)super.rotationYaw);
         super.rotationYaw = (float)((double)super.rotationYaw + var7 / (double)super.newPosRotationIncrements);
         super.rotationPitch = (float)((double)super.rotationPitch + (super.newRotationPitch - (double)super.rotationPitch) / (double)super.newPosRotationIncrements);
         --super.newPosRotationIncrements;
         this.setPosition(var9, var3, var5);
         this.setRotation(super.rotationYaw, super.rotationPitch);
      }

      if(Math.abs(super.motionX) < 0.005D) {
         super.motionX = 0.0D;
      }

      if(Math.abs(super.motionY) < 0.005D) {
         super.motionY = 0.0D;
      }

      if(Math.abs(super.motionZ) < 0.005D) {
         super.motionZ = 0.0D;
      }

      super.worldObj.theProfiler.startSection("ai");
      if(this.isMovementBlocked()) {
         super.isJumping = false;
         super.moveStrafing = 0.0F;
         super.moveForward = 0.0F;
         super.randomYawVelocity = 0.0F;
      } else if(this.isClientWorld()) {
         super.worldObj.theProfiler.startSection("oldAi");
         this.updateEntityActionState();
         super.worldObj.theProfiler.endSection();
         super.rotationYawHead = super.rotationYaw;
      }

      super.worldObj.theProfiler.endSection();
      super.worldObj.theProfiler.startSection("jump");
      if(super.isJumping) {
         if(!this.isInWater() && !this.handleLavaMovement()) {
            if(super.onGround) {
               this.jump();
            }
         } else {
            super.motionY += 0.03999999910593033D;
         }
      }

      super.worldObj.theProfiler.endSection();
      super.worldObj.theProfiler.startSection("travel");
      super.moveStrafing *= 0.98F;
      super.moveForward *= 0.98F;
      super.randomYawVelocity *= 0.9F;
      this.moveEntityWithHeading(super.moveStrafing, super.moveForward);
      super.worldObj.theProfiler.endSection();
      this.body.width = this.body.height = 6.0F;
      this.tail.width = 6.0F;
      this.tail.height = 2.0F;
      float var10 = (super.renderYawOffset + 180.0F) * 3.141593F / 180.0F;
      double dx = super.posX - (double)MathHelper.sin(var10) * 3.0D;
      double dy = super.posY + 0.1D;
      double dz = super.posZ + (double)MathHelper.cos(var10) * 3.0D;
      this.body.setPosition(dx, dy, dz);
      dx = super.posX - (double)MathHelper.sin(var10) * 10.5D;
      dy = super.posY + 0.1D;
      dz = super.posZ + (double)MathHelper.cos(var10) * 10.5D;
      this.tail.setPosition(dx, dy, dz);
      super.worldObj.theProfiler.startSection("push");
      if(!super.worldObj.isRemote && super.hurtTime == 0) {
         this.collideWithEntities(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.body.boundingBox), this.body);
         this.collideWithEntities(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.tail.boundingBox), this.tail);
      }

      super.worldObj.theProfiler.endSection();
      if(!super.worldObj.isRemote) {
         this.destroyBlocksInAABB(this.body.boundingBox);
         this.destroyBlocksInAABB(this.tail.boundingBox);

         for(int i = 0; i < this.numHeads; ++i) {
            if(this.hc[i].headEntity != null && this.hc[i].isActive()) {
               this.destroyBlocksInAABB(this.hc[i].headEntity.boundingBox);
            }
         }

         if(super.ticksExisted % 20 == 0 && this.isUnsteadySurfaceBeneath()) {
            this.destroyBlocksInAABB(super.boundingBox.offset(0.0D, -1.0D, 0.0D));
         }
      }

   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(18, new Integer(MAX_HEALTH));
   }

   public boolean shouldSpawnHeads() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setSpawnHeads(boolean flag) {
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)127));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)0));
      }

   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      super.writeEntityToNBT(nbttagcompound);
      nbttagcompound.setBoolean("SpawnHeads", this.shouldSpawnHeads());
      nbttagcompound.setByte("NumHeads", (byte)this.countActiveHeads());
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      this.setSpawnHeads(nbttagcompound.getBoolean("SpawnHeads"));
      this.activateNumberOfHeads(nbttagcompound.getByte("NumHeads"));
   }

   protected void updateEntityActionState() {
      ++super.entityAge;
      this.despawnEntity();
      super.moveStrafing = 0.0F;
      super.moveForward = 0.0F;
      float f = 48.0F;

      int flag;
      for(flag = 0; flag < this.numHeads; ++flag) {
         if(this.hc[flag].isActive() && this.hc[flag].getDamageTaken() > HEAD_MAX_DAMAGE) {
            this.hc[flag].setNextState(11);
            this.hc[flag].endCurrentAction();
            this.hc[flag].setRespawnCounter(HEAD_RESPAWN_TICKS);
            int flag1 = this.getRandomDeadHead();
            if(flag1 != -1) {
               this.hc[flag1].setRespawnCounter(HEAD_RESPAWN_TICKS);
            }
         }
      }

      if(super.rand.nextFloat() < 0.7F) {
         EntityPlayer var4 = super.worldObj.getClosestVulnerablePlayerToEntity(this, (double)f);
         if(var4 != null) {
            this.field_70776_bF = var4;
            super.numTicksToChaseTarget = 100 + super.rand.nextInt(20);
         } else {
            super.randomYawVelocity = (super.rand.nextFloat() - 0.5F) * 20.0F;
         }
      }

      if(this.field_70776_bF != null) {
         this.faceEntity(this.field_70776_bF, 10.0F, (float)this.getVerticalFaceSpeed());

         for(flag = 0; flag < this.numHeads; ++flag) {
            if(!this.isHeadAttacking(this.hc[flag]) && !this.hc[flag].isSecondaryAttacking) {
               this.hc[flag].setTargetEntity(this.field_70776_bF);
            }
         }

         if(this.field_70776_bF.isEntityAlive()) {
            float var6 = this.field_70776_bF.getDistanceToEntity(this);
            if(this.canEntityBeSeen(this.field_70776_bF)) {
               this.attackEntity(this.field_70776_bF, var6);
            }
         }

         if(super.numTicksToChaseTarget-- <= 0 || this.field_70776_bF.isDead || this.field_70776_bF.getDistanceSqToEntity(this) > (double)(f * f)) {
            this.field_70776_bF = null;
         }
      } else {
         if(super.rand.nextFloat() < 0.05F) {
            super.randomYawVelocity = (super.rand.nextFloat() - 0.5F) * 20.0F;
         }

         super.rotationYaw += super.randomYawVelocity;
         super.rotationPitch = super.defaultPitch;

         for(flag = 0; flag < this.numHeads; ++flag) {
            if(this.hc[flag].currentState == 0) {
               this.hc[flag].setTargetEntity((Entity)null);
            }
         }
      }

      this.secondaryAttacks();
      boolean var7 = this.isInWater();
      boolean var5 = this.handleLavaMovement();
      if(var7 || var5) {
         super.isJumping = super.rand.nextFloat() < 0.8F;
      }

   }

   private void setDifficultyVariables() {
      if(super.worldObj.difficultySetting != EnumDifficulty.HARD) {
         HEADS_ACTIVITY_FACTOR = 0.3F;
      } else {
         HEADS_ACTIVITY_FACTOR = 0.5F;
      }

   }

   private int getRandomDeadHead() {
      for(int i = 0; i < this.numHeads; ++i) {
         if(this.hc[i].currentState == 12 && this.hc[i].respawnCounter == -1) {
            return i;
         }
      }

      return -1;
   }

   private void activateNumberOfHeads(int howMany) {
      int moreHeads = howMany - this.countActiveHeads();

      for(int i = 0; i < moreHeads; ++i) {
         int otherHead = this.getRandomDeadHead();
         if(otherHead != -1) {
            this.hc[otherHead].currentState = 0;
            this.hc[otherHead].setNextState(0);
            this.hc[otherHead].endCurrentAction();
         }
      }

   }

   private void attackEntity(Entity target, float distance) {
      byte BITE_CHANCE = 10;
      byte FLAME_CHANCE = 100;
      short MORTAR_CHANCE = 160;
      boolean targetAbove = target.boundingBox.minY > super.boundingBox.maxY;

      int i;
      for(i = 0; i < 3; ++i) {
         if(this.hc[i].currentState == 0 && !this.areTooManyHeadsAttacking(target, i)) {
            if(distance > 4.0F && distance < 10.0F && super.rand.nextInt(BITE_CHANCE) == 0 && this.countActiveHeads() > 2 && !this.areOtherHeadsBiting(target, i)) {
               this.hc[i].setNextState(1);
            } else if(distance > 0.0F && distance < 20.0F && super.rand.nextInt(FLAME_CHANCE) == 0) {
               this.hc[i].setNextState(5);
            } else if(distance > 8.0F && distance < 32.0F && !targetAbove && super.rand.nextInt(MORTAR_CHANCE) == 0) {
               this.hc[i].setNextState(8);
            }
         }
      }

      for(i = 3; i < this.numHeads; ++i) {
         if(this.hc[i].currentState == 0 && !this.areTooManyHeadsAttacking(target, i)) {
            if(distance > 0.0F && distance < 20.0F && super.rand.nextInt(FLAME_CHANCE) == 0) {
               this.hc[i].setNextState(5);
            } else if(distance > 8.0F && distance < 32.0F && !targetAbove && super.rand.nextInt(MORTAR_CHANCE) == 0) {
               this.hc[i].setNextState(8);
            }
         }
      }

   }

   protected boolean areTooManyHeadsAttacking(Entity target, int testHead) {
      int otherAttacks = 0;

      for(int i = 0; i < this.numHeads; ++i) {
         if(i != testHead && this.isHeadAttacking(this.hc[i])) {
            ++otherAttacks;
            if(this.isHeadBiting(this.hc[i])) {
               otherAttacks += 2;
            }
         }
      }

      return (float)otherAttacks >= 1.0F + (float)this.countActiveHeads() * HEADS_ACTIVITY_FACTOR;
   }

   public int countActiveHeads() {
      int count = 0;

      for(int i = 0; i < this.numHeads; ++i) {
         if(this.hc[i].isActive()) {
            ++count;
         }
      }

      return count;
   }

   private boolean isHeadAttacking(HydraHeadContainer head) {
      return head.currentState == 1 || head.currentState == 2 || head.currentState == 3 || head.currentState == 5 || head.currentState == 6 || head.currentState == 8 || head.currentState == 9;
   }

   protected boolean areOtherHeadsBiting(Entity target, int testHead) {
      for(int i = 0; i < this.numHeads; ++i) {
         if(i != testHead && this.isHeadBiting(this.hc[i])) {
            return true;
         }
      }

      return false;
   }

   protected boolean isHeadBiting(HydraHeadContainer head) {
      return head.currentState == 1 || head.currentState == 2 || head.currentState == 3 || head.nextState == 1;
   }

   private void secondaryAttacks() {
      for(int secondaryTarget = 0; secondaryTarget < this.numHeads; ++secondaryTarget) {
         if(this.hc[secondaryTarget].headEntity == null) {
            return;
         }
      }

      EntityLivingBase var4 = this.findSecondaryTarget(20.0D);
      if(var4 != null) {
         float distance = var4.getDistanceToEntity(this);

         for(int i = 1; i < this.numHeads; ++i) {
            if(this.hc[i].isActive() && this.hc[i].currentState == 0 && this.isTargetOnThisSide(i, var4)) {
               if(distance > 0.0F && distance < 20.0F && super.rand.nextInt(SECONDARY_FLAME_CHANCE) == 0) {
                  this.hc[i].setTargetEntity(var4);
                  this.hc[i].isSecondaryAttacking = true;
                  this.hc[i].setNextState(5);
               } else if(distance > 8.0F && distance < 32.0F && super.rand.nextInt(SECONDARY_MORTAR_CHANCE) == 0) {
                  this.hc[i].setTargetEntity(var4);
                  this.hc[i].isSecondaryAttacking = true;
                  this.hc[i].setNextState(8);
               }
            }
         }
      }

   }

   public boolean isTargetOnThisSide(int headNum, Entity target) {
      double headDist = this.distanceSqXZ(this.hc[headNum].headEntity, target);
      double middleDist = this.distanceSqXZ(this, target);
      return headDist < middleDist;
   }

   private double distanceSqXZ(Entity headEntity, Entity target) {
      double distX = headEntity.posX - target.posX;
      double distZ = headEntity.posZ - target.posZ;
      return distX * distX + distZ * distZ;
   }

   public EntityLivingBase findSecondaryTarget(double range) {
      double closestRange = -1.0D;
      EntityLivingBase closestEntity = null;
      List nearbyEntities = super.worldObj.getEntitiesWithinAABB(EntityLivingBase.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(range, range, range));
      Iterator var7 = nearbyEntities.iterator();

      while(var7.hasNext()) {
         EntityLivingBase nearbyLiving = (EntityLivingBase)var7.next();
         if(!(nearbyLiving instanceof EntityTFHydra) && !(nearbyLiving instanceof EntityTFHydraPart) && nearbyLiving != this.field_70776_bF && !this.isAnyHeadTargeting(nearbyLiving) && this.canEntityBeSeen(nearbyLiving)) {
            double curDist = nearbyLiving.getDistanceSq(super.posX, super.posY, super.posZ);
            if((range < 0.0D || curDist < range * range) && (closestRange == -1.0D || curDist < closestRange)) {
               closestRange = curDist;
               closestEntity = nearbyLiving;
            }
         }
      }

      return closestEntity;
   }

   boolean isAnyHeadTargeting(Entity targetEntity) {
      for(int i = 0; i < this.numHeads; ++i) {
         if(this.hc[i].targetEntity != null && this.hc[i].targetEntity.equals(targetEntity)) {
            return true;
         }
      }

      return false;
   }

   private void collideWithEntities(List par1List, Entity part) {
      double pushPower = 4.0D;
      double centerX = (part.boundingBox.minX + part.boundingBox.maxX) / 2.0D;
      double centerY = (part.boundingBox.minZ + part.boundingBox.maxZ) / 2.0D;
      Iterator var9 = par1List.iterator();

      while(var9.hasNext()) {
         Entity entity = (Entity)var9.next();
         if(entity instanceof EntityLivingBase) {
            double distX = entity.posX - centerX;
            double distZ = entity.posZ - centerY;
            double sqDist = distX * distX + distZ * distZ;
            entity.addVelocity(distX / sqDist * pushPower, 0.20000000298023224D, distZ / sqDist * pushPower);
         }
      }

   }

   private boolean isUnsteadySurfaceBeneath() {
      int minX = MathHelper.floor_double(super.boundingBox.minX);
      int minZ = MathHelper.floor_double(super.boundingBox.minZ);
      int maxX = MathHelper.floor_double(super.boundingBox.maxX);
      int maxZ = MathHelper.floor_double(super.boundingBox.maxZ);
      int minY = MathHelper.floor_double(super.boundingBox.minY);
      int solid = 0;
      int total = 0;
      int dy = minY - 1;

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dz = minZ; dz <= maxZ; ++dz) {
            ++total;
            if(super.worldObj.getBlock(dx, dy, dz).getMaterial().isSolid()) {
               ++solid;
            }
         }
      }

      return (float)solid / (float)total < 0.6F;
   }

   private boolean destroyBlocksInAABB(AxisAlignedBB par1AxisAlignedBB) {
      int minX = MathHelper.floor_double(par1AxisAlignedBB.minX);
      int minY = MathHelper.floor_double(par1AxisAlignedBB.minY);
      int minZ = MathHelper.floor_double(par1AxisAlignedBB.minZ);
      int maxX = MathHelper.floor_double(par1AxisAlignedBB.maxX);
      int maxY = MathHelper.floor_double(par1AxisAlignedBB.maxY);
      int maxZ = MathHelper.floor_double(par1AxisAlignedBB.maxZ);
      boolean wasBlocked = false;

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dy = minY; dy <= maxY; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               Block currentID = super.worldObj.getBlock(dx, dy, dz);
               if(currentID != Blocks.air) {
                  int currentMeta = super.worldObj.getBlockMetadata(dx, dy, dz);
                  if(currentID != Blocks.obsidian && currentID != Blocks.end_stone && currentID != Blocks.bedrock) {
                     super.worldObj.setBlock(dx, dy, dz, Blocks.air, 0, 2);
                     super.worldObj.playAuxSFX(2001, dx, dy, dz, Block.getIdFromBlock(currentID) + (currentMeta << 12));
                  } else {
                     wasBlocked = true;
                  }
               }
            }
         }
      }

      return wasBlocked;
   }

   public int getVerticalFaceSpeed() {
      return 500;
   }

   public boolean attackEntityFromPart(EntityDragonPart dragonpart, DamageSource damagesource, float i) {
      double range = this.calculateRange(damagesource);
      return range > 400.0D?false:this.superAttackFrom(damagesource, (float)Math.round(i / 8.0F));
   }

   protected boolean superAttackFrom(DamageSource par1DamageSource, float par2) {
      return super.attackEntityFrom(par1DamageSource, par2);
   }

   public boolean attackEntityFromPart(EntityTFHydraPart part, DamageSource damagesource, float damageAmount) {
      if(!super.worldObj.isRemote && damagesource == DamageSource.inWall && part.getBoundingBox() != null) {
         this.destroyBlocksInAABB(part.getBoundingBox());
      }

      HydraHeadContainer headCon = null;

      for(int range = 0; range < this.numHeads; ++range) {
         if(this.hc[range].headEntity == part) {
            headCon = this.hc[range];
         }
      }

      double var9 = this.calculateRange(damagesource);
      if(var9 > 400.0D) {
         return false;
      } else if(headCon != null && !headCon.isActive()) {
         return false;
      } else {
         boolean tookDamage;
         if(headCon != null && (double)headCon.getCurrentMouthOpen() > 0.5D) {
            tookDamage = this.superAttackFrom(damagesource, damageAmount);
            headCon.addDamage(damageAmount);
         } else {
            int armoredDamage = Math.round(damageAmount / ARMOR_MULTIPLIER);
            tookDamage = this.superAttackFrom(damagesource, (float)armoredDamage);
            if(headCon != null) {
               headCon.addDamage((float)armoredDamage);
            }
         }

         if(tookDamage) {
            this.ticksSinceDamaged = 0;
         }

         return tookDamage;
      }
   }

   protected double calculateRange(DamageSource damagesource) {
      double range = -1.0D;
      if(damagesource.getSourceOfDamage() != null) {
         range = this.getDistanceSqToEntity(damagesource.getSourceOfDamage());
      }

      if(damagesource.getEntity() != null) {
         range = this.getDistanceSqToEntity(damagesource.getEntity());
      }

      return range;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      return false;
   }

   public Entity[] getParts() {
      return this.partArray;
   }

   public boolean canBeCollidedWith() {
      return false;
   }

   public boolean canBePushed() {
      return false;
   }

   public void knockBack(Entity entity, float i, double d, double d1) {}

   protected String getLivingSound() {
      return "TwilightForest:mob.hydra.growl";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.hydra.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.hydra.death";
   }

   protected float getSoundVolume() {
      return 2.0F;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightKillHydra);
      }

      if(!super.worldObj.isRemote && super.worldObj.provider instanceof WorldProviderTwilightForest) {
         int dx = MathHelper.floor_double(super.posX);
         int dy = MathHelper.floor_double(super.posY);
         int dz = MathHelper.floor_double(super.posZ);
         ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
         TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(dx, dz, super.worldObj);
         if(nearbyFeature == TFFeature.hydraLair) {
            chunkProvider.setStructureConquered(dx, dy, dz, true);
         }
      }

   }

   protected void dropFewItems(boolean par1, int par2) {
      int totalDrops = super.rand.nextInt(3 + par2) + 5;

      int i;
      for(i = 0; i < totalDrops; ++i) {
         this.dropItem(TFItems.hydraChop, 5);
      }

      totalDrops = super.rand.nextInt(4 + par2) + 7;

      for(i = 0; i < totalDrops; ++i) {
         this.dropItem(TFItems.fieryBlood, 1);
      }

      this.dropItem(TFItems.trophy, 1);
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean isBurning() {
      return false;
   }

   protected void onDeathUpdate() {
      ++super.deathTime;
      int var1;
      if(super.deathTime == 1) {
         for(var1 = 0; var1 < this.numHeads; ++var1) {
            this.hc[var1].setRespawnCounter(-1);
            if(this.hc[var1].isActive()) {
               this.hc[var1].setNextState(0);
               this.hc[var1].endCurrentAction();
               this.hc[var1].setHurtTime(200);
            }
         }
      }

      if(super.deathTime <= 140 && super.deathTime % 20 == 0) {
         var1 = super.deathTime / 20 - 1;
         if(this.hc[var1].isActive()) {
            this.hc[var1].setNextState(11);
            this.hc[var1].endCurrentAction();
         }
      }

      if(super.deathTime == 200) {
         if(!super.worldObj.isRemote && (super.recentlyHit > 0 || this.isPlayer()) && !this.isChild()) {
            var1 = this.getExperiencePoints(super.attackingPlayer);

            while(var1 > 0) {
               int var8 = EntityXPOrb.getXPSplit(var1);
               var1 -= var8;
               super.worldObj.spawnEntityInWorld(new EntityXPOrb(super.worldObj, super.posX, super.posY, super.posZ, var8));
            }
         }

         this.setDead();
      }

      for(var1 = 0; var1 < 20; ++var1) {
         double var9 = super.rand.nextGaussian() * 0.02D;
         double var4 = super.rand.nextGaussian() * 0.02D;
         double var6 = super.rand.nextGaussian() * 0.02D;
         String particle = super.rand.nextInt(2) == 0?"largeexplode":"explode";
         super.worldObj.spawnParticle(particle, super.posX + (double)(super.rand.nextFloat() * this.body.width * 2.0F) - (double)this.body.width, super.posY + (double)(super.rand.nextFloat() * this.body.height), super.posZ + (double)(super.rand.nextFloat() * this.body.width * 2.0F) - (double)this.body.width, var9, var4, var6);
      }

   }

   public World func_82194_d() {
      return super.worldObj;
   }

}

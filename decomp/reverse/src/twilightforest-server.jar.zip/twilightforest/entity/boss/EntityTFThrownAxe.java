package twilightforest.entity.boss;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFKnightPhantom;

public class EntityTFThrownAxe extends EntityThrowable {

   private static final float PROJECTILE_DAMAGE = 6.0F;


   public EntityTFThrownAxe(World par1World, EntityLivingBase par2EntityLivingBase) {
      super(par1World, par2EntityLivingBase);
      this.setSize(0.5F, 0.5F);
   }

   public EntityTFThrownAxe(World par1World) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
   }

   protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
      boolean passThru = false;
      if(par1MovingObjectPosition.entityHit != null) {
         if(par1MovingObjectPosition.entityHit instanceof EntityTFKnightPhantom) {
            passThru = true;
         }

         if(!passThru) {
            par1MovingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.getThrower()), 6.0F);
         }
      }

      for(int i = 0; i < 8; ++i) {
         super.worldObj.spawnParticle("largesmoke", super.posX, super.posY, super.posZ, 0.0D, 0.0D, 0.0D);
      }

      if(!passThru && !super.worldObj.isRemote) {
         this.setDead();
      }

   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public float getCollisionBorderSize() {
      return 1.0F;
   }

   protected float func_70182_d() {
      return 0.1F;
   }

   protected float getGravityVelocity() {
      return 0.001F;
   }
}

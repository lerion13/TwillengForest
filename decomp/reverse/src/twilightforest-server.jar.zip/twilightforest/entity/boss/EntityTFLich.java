package twilightforest.entity.boss;

import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.entity.EntityTFSwarmSpider;
import twilightforest.entity.boss.EntityTFLichBolt;
import twilightforest.entity.boss.EntityTFLichBomb;
import twilightforest.entity.boss.EntityTFLichMinion;
import twilightforest.item.TFItems;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFLich extends EntityMob implements IBossDisplayData {

   private static final int DATA_ISCLONE = 21;
   private static final int DATA_SHIELDSTRENGTH = 17;
   private static final int DATA_MINIONSLEFT = 18;
   private static final int DATA_BOSSHEALTH = 19;
   private static final int DATA_ATTACKTYPE = 20;
   EntityTFLich masterLich;
   private static final ItemStack[] heldItems = new ItemStack[]{new ItemStack(TFItems.scepterTwilight, 1), new ItemStack(TFItems.scepterZombie, 1), new ItemStack(Items.golden_sword, 1)};
   public static final int MAX_SHADOW_CLONES = 2;
   public static final int INITIAL_SHIELD_STRENGTH = 5;
   public static final int MAX_ACTIVE_MINIONS = 3;
   public static final int INITIAL_MINIONS_TO_SUMMON = 9;
   public static final int MAX_HEALTH = 100;


   public EntityTFLich(World world) {
      super(world);
      this.setSize(1.1F, 2.5F);
      this.setShadowClone(false);
      this.masterLich = null;
      super.isImmuneToFire = true;
      this.setShieldStrength(5);
      this.setMinionsToSummon(9);
      super.experienceValue = 217;
   }

   public EntityTFLich(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   public EntityTFLich(World world, EntityTFLich otherLich) {
      this(world);
      this.setShadowClone(true);
      this.masterLich = otherLich;
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(21, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(18, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(19, new Integer(100));
      super.dataWatcher.addObject(20, Byte.valueOf((byte)0));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(100.0D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(6.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.800000011920929D);
   }

   public ItemStack getHeldItem() {
      return heldItems[this.getPhase() - 1];
   }

   protected void dropFewItems(boolean par1, int par2) {
      this.dropScepter();
      int totalDrops = super.rand.nextInt(3 + par2) + 2;

      int i;
      for(i = 0; i < totalDrops; ++i) {
         this.dropGoldThing();
      }

      totalDrops = super.rand.nextInt(4 + par2) + 1;

      for(i = 0; i < totalDrops; ++i) {
         this.dropItem(Items.ender_pearl, 1);
      }

      totalDrops = super.rand.nextInt(5 + par2) + 5;

      for(i = 0; i < totalDrops; ++i) {
         this.dropItem(Items.bone, 1);
      }

      this.entityDropItem(new ItemStack(TFItems.trophy, 1, 2), 0.0F);
   }

   private void dropScepter() {
      int scepterType = super.rand.nextInt(3);
      if(scepterType == 0) {
         this.entityDropItem(new ItemStack(TFItems.scepterZombie), 0.0F);
      } else if(scepterType == 1) {
         this.entityDropItem(new ItemStack(TFItems.scepterLifeDrain), 0.0F);
      } else {
         this.entityDropItem(new ItemStack(TFItems.scepterTwilight), 0.0F);
      }

   }

   private void dropGoldThing() {
      int thingType = super.rand.nextInt(5);
      ItemStack goldThing;
      if(thingType == 0) {
         goldThing = new ItemStack(Items.golden_sword);
      } else if(thingType == 1) {
         goldThing = new ItemStack(Items.golden_helmet);
      } else if(thingType == 2) {
         goldThing = new ItemStack(Items.golden_chestplate);
      } else if(thingType == 3) {
         goldThing = new ItemStack(Items.golden_leggings);
      } else {
         goldThing = new ItemStack(Items.golden_boots);
      }

      EnchantmentHelper.addRandomEnchantment(super.rand, goldThing, 10 + super.rand.nextInt(30));
      this.entityDropItem(goldThing, 0.0F);
   }

   public void setInWeb() {}

   protected boolean canDespawn() {
      return false;
   }

   public boolean handleLavaMovement() {
      return false;
   }

   public boolean isInWater() {
      return false;
   }

   public int getPhase() {
      return !this.isShadowClone() && this.getShieldStrength() <= 0?(this.getMinionsToSummon() > 0?2:3):1;
   }

   public void onLivingUpdate() {
      float angle = super.renderYawOffset * 3.141593F / 180.0F;
      double dx = super.posX + (double)MathHelper.cos(angle) * 0.65D;
      double dy = super.posY + (double)super.height * 0.94D;
      double dz = super.posZ + (double)MathHelper.sin(angle) * 0.65D;
      int factor = (80 - super.attackTime) / 10;
      int particles = factor > 0?super.rand.nextInt(factor):1;

      for(int j1 = 0; j1 < particles; ++j1) {
         float sparkle = 1.0F - ((float)super.attackTime + 1.0F) / 60.0F;
         sparkle *= sparkle;
         float red = 0.37F * sparkle;
         float grn = 0.99F * sparkle;
         float blu = 0.89F * sparkle;
         if(this.getNextAttackType() != 0) {
            red = 0.99F * sparkle;
            grn = 0.47F * sparkle;
            blu = 0.0F * sparkle;
         }

         super.worldObj.spawnParticle("mobSpell", dx + super.rand.nextGaussian() * 0.025D, dy + super.rand.nextGaussian() * 0.025D, dz + super.rand.nextGaussian() * 0.025D, (double)red, (double)grn, (double)blu);
      }

      if(this.isShadowClone()) {
         this.checkForMaster();
      }

      if(!super.worldObj.isRemote) {
         super.dataWatcher.updateObject(19, Integer.valueOf((int)this.getHealth()));
      }

      super.onLivingUpdate();
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float damage) {
      if(par1DamageSource.getDamageType() == "inWall" && super.entityToAttack != null) {
         this.teleportToSightOfEntity(super.entityToAttack);
      }

      if(this.isShadowClone()) {
         super.worldObj.playSoundAtEntity(this, "random.fizz", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
         return false;
      } else {
         Entity prevTarget = super.entityToAttack;
         if(par1DamageSource.getEntity() instanceof EntityTFLich) {
            return false;
         } else if(this.getShieldStrength() > 0) {
            if(par1DamageSource.isUnblockable() && damage > 2.0F) {
               if(this.getShieldStrength() > 0) {
                  this.setShieldStrength(this.getShieldStrength() - 1);
                  super.worldObj.playSoundAtEntity(this, "random.break", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
               }
            } else {
               super.worldObj.playSoundAtEntity(this, "random.break", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
               if(par1DamageSource.getEntity() instanceof EntityPlayer) {
                  super.entityToAttack = par1DamageSource.getEntity();
               }
            }

            return false;
         } else if(super.attackEntityFrom(par1DamageSource, damage)) {
            if(super.entityToAttack instanceof EntityTFLich) {
               super.entityToAttack = prevTarget;
            }

            if(this.getPhase() < 3 || super.rand.nextInt(4) == 0) {
               this.teleportToSightOfEntity(super.entityToAttack);
            }

            return true;
         } else {
            return false;
         }
      }
   }

   protected void attackEntity(Entity targetedEntity, float f) {
      if(!this.isShadowClone() && super.attackTime % 15 == 0) {
         this.popNearbyMob();
      }

      if(this.getPhase() == 1) {
         if(super.attackTime == 60 && !super.worldObj.isRemote) {
            this.teleportToSightOfEntity(targetedEntity);
            if(!this.isShadowClone()) {
               this.checkAndSpawnClones(targetedEntity);
            }
         }

         if(this.canEntityBeSeen(targetedEntity) && super.attackTime == 0 && f < 20.0F) {
            if(this.getNextAttackType() == 0) {
               this.launchBoltAt(targetedEntity);
            } else {
               this.launchBombAt(targetedEntity);
            }

            if(super.rand.nextInt(3) > 0) {
               this.setNextAttackType(0);
            } else {
               this.setNextAttackType(1);
            }

            super.attackTime = 100;
         }

         super.hasAttacked = true;
      }

      if(this.getPhase() == 2 && !this.isShadowClone()) {
         this.despawnClones();
         if(super.attackTime % 15 == 0) {
            this.checkAndSpawnMinions(targetedEntity);
         }

         if(super.attackTime == 0) {
            if(f < 2.0F) {
               this.attackEntityAsMob(targetedEntity);
               super.attackTime = 20;
            } else if(f < 20.0F && this.canEntityBeSeen(targetedEntity)) {
               if(this.getNextAttackType() == 0) {
                  this.launchBoltAt(targetedEntity);
               } else {
                  this.launchBombAt(targetedEntity);
               }

               if(super.rand.nextInt(2) > 0) {
                  this.setNextAttackType(0);
               } else {
                  this.setNextAttackType(1);
               }

               super.attackTime = 60;
            } else {
               this.teleportToSightOfEntity(targetedEntity);
               super.attackTime = 20;
            }
         }

         super.hasAttacked = true;
      }

      if(this.getPhase() == 3 && super.attackTime <= 0 && f < 2.0F && targetedEntity.boundingBox.maxY > super.boundingBox.minY && targetedEntity.boundingBox.minY < super.boundingBox.maxY) {
         super.attackTime = 20;
         this.attackEntityAsMob(targetedEntity);
         super.hasAttacked = true;
      }

   }

   protected void launchBoltAt(Entity targetedEntity) {
      float bodyFacingAngle = super.renderYawOffset * 3.141593F / 180.0F;
      double sx = super.posX + (double)MathHelper.cos(bodyFacingAngle) * 0.65D;
      double sy = super.posY + (double)super.height * 0.82D;
      double sz = super.posZ + (double)MathHelper.sin(bodyFacingAngle) * 0.65D;
      double tx = targetedEntity.posX - sx;
      double ty = targetedEntity.boundingBox.minY + (double)(targetedEntity.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
      double tz = targetedEntity.posZ - sz;
      super.worldObj.playSoundAtEntity(this, "mob.ghast.fireball", this.getSoundVolume(), (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 1.0F);
      EntityTFLichBolt projectile = new EntityTFLichBolt(super.worldObj, this);
      projectile.setThrowableHeading(tx, ty, tz, projectile.func_70182_d(), 1.0F);
      projectile.setLocationAndAngles(sx, sy, sz, super.rotationYaw, super.rotationPitch);
      super.worldObj.spawnEntityInWorld(projectile);
   }

   protected void launchBombAt(Entity targetedEntity) {
      float bodyFacingAngle = super.renderYawOffset * 3.141593F / 180.0F;
      double sx = super.posX + (double)MathHelper.cos(bodyFacingAngle) * 0.65D;
      double sy = super.posY + (double)super.height * 0.82D;
      double sz = super.posZ + (double)MathHelper.sin(bodyFacingAngle) * 0.65D;
      double tx = targetedEntity.posX - sx;
      double ty = targetedEntity.boundingBox.minY + (double)(targetedEntity.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
      double tz = targetedEntity.posZ - sz;
      super.worldObj.playSoundAtEntity(this, "mob.ghast.fireball", this.getSoundVolume(), (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 1.0F);
      EntityTFLichBomb projectile = new EntityTFLichBomb(super.worldObj, this);
      projectile.setThrowableHeading(tx, ty, tz, projectile.func_40077_c(), 1.0F);
      projectile.setLocationAndAngles(sx, sy, sz, super.rotationYaw, super.rotationPitch);
      super.worldObj.spawnEntityInWorld(projectile);
   }

   protected void popNearbyMob() {
      List nearbyMobs = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      Iterator var2 = nearbyMobs.iterator();

      while(var2.hasNext()) {
         Entity entity = (Entity)var2.next();
         if(entity instanceof EntityLiving && this.canPop(entity) && this.canEntityBeSeen(entity)) {
            EntityLiving mob = (EntityLiving)entity;
            if(!super.worldObj.isRemote) {
               mob.setDead();
               mob.spawnExplosionParticle();
            }

            this.makeRedMagicTrail(mob.posX, mob.posY + (double)mob.height / 2.0D, mob.posZ, super.posX, super.posY + (double)super.height / 2.0D, super.posZ);
            break;
         }
      }

   }

   protected boolean canPop(Entity nearby) {
      Class[] poppable = new Class[]{EntitySkeleton.class, EntityZombie.class, EntityEnderman.class, EntitySpider.class, EntityCreeper.class, EntityTFSwarmSpider.class};
      Class[] var3 = poppable;
      int var4 = poppable.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Class pop = var3[var5];
         if(nearby.getClass() == pop) {
            return true;
         }
      }

      return false;
   }

   protected void checkAndSpawnClones(Entity targetedEntity) {
      if(this.countMyClones() < 2) {
         this.spawnShadowClone(targetedEntity);
      }

   }

   protected int countMyClones() {
      List nearbyLiches = super.worldObj.getEntitiesWithinAABB(EntityTFLich.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      int count = 0;
      Iterator var3 = nearbyLiches.iterator();

      while(var3.hasNext()) {
         EntityTFLich nearbyLich = (EntityTFLich)var3.next();
         if(nearbyLich.isShadowClone() && nearbyLich.masterLich == this) {
            ++count;
         }
      }

      return count;
   }

   public boolean wantsNewClone(EntityTFLich clone) {
      return clone.isShadowClone() && this.countMyClones() < 2;
   }

   protected void spawnShadowClone(Entity targetedEntity) {
      Vec3 cloneSpot = this.findVecInLOSOf(targetedEntity);
      EntityTFLich newClone = new EntityTFLich(super.worldObj, this);
      newClone.setPosition(cloneSpot.xCoord, cloneSpot.yCoord, cloneSpot.zCoord);
      super.worldObj.spawnEntityInWorld(newClone);
      newClone.entityToAttack = targetedEntity;
      newClone.attackTime = 60 + super.rand.nextInt(3) - super.rand.nextInt(3);
      this.makeTeleportTrail(super.posX, super.posY, super.posZ, cloneSpot.xCoord, cloneSpot.yCoord, cloneSpot.zCoord);
   }

   protected void despawnClones() {
      List nearbyLiches = super.worldObj.getEntitiesWithinAABB(this.getClass(), AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      Iterator var2 = nearbyLiches.iterator();

      while(var2.hasNext()) {
         EntityTFLich nearbyLich = (EntityTFLich)var2.next();
         if(nearbyLich.isShadowClone()) {
            nearbyLich.isDead = true;
         }
      }

   }

   protected void checkAndSpawnMinions(Entity targetedEntity) {
      if(!super.worldObj.isRemote && this.getMinionsToSummon() > 0) {
         int minions = this.countMyMinions();
         if(minions < 3) {
            this.spawnMinionAt((EntityLivingBase)targetedEntity);
            this.setMinionsToSummon(this.getMinionsToSummon() - 1);
         }
      }

   }

   protected int countMyMinions() {
      List nearbyMinons = super.worldObj.getEntitiesWithinAABB(EntityTFLichMinion.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      int count = 0;
      Iterator var3 = nearbyMinons.iterator();

      while(var3.hasNext()) {
         EntityTFLichMinion nearbyMinon = (EntityTFLichMinion)var3.next();
         if(nearbyMinon.master == this) {
            ++count;
         }
      }

      return count;
   }

   protected void spawnMinionAt(EntityLivingBase targetedEntity) {
      Vec3 minionSpot = this.findVecInLOSOf(targetedEntity);
      EntityTFLichMinion minion = new EntityTFLichMinion(super.worldObj, this);
      minion.setPosition(minionSpot.xCoord, minionSpot.yCoord, minionSpot.zCoord);
      super.worldObj.spawnEntityInWorld(minion);
      minion.setAttackTarget(targetedEntity);
      minion.spawnExplosionParticle();
      super.worldObj.playSoundAtEntity(minion, "random.pop", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      this.makeBlackMagicTrail(super.posX, super.posY + (double)this.getEyeHeight(), super.posZ, minionSpot.xCoord, minionSpot.yCoord + (double)minion.height / 2.0D, minionSpot.zCoord);
   }

   public boolean wantsNewMinion(EntityTFLichMinion minion) {
      return this.countMyMinions() < 3;
   }

   protected void checkForMaster() {
      if(this.masterLich == null) {
         this.findNewMaster();
      }

      if(!super.worldObj.isRemote && (this.masterLich == null || this.masterLich.isDead)) {
         super.isDead = true;
      }

   }

   private void findNewMaster() {
      List nearbyLiches = super.worldObj.getEntitiesWithinAABB(EntityTFLich.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      Iterator var2 = nearbyLiches.iterator();

      while(var2.hasNext()) {
         EntityTFLich nearbyLich = (EntityTFLich)var2.next();
         if(!nearbyLich.isShadowClone() && nearbyLich.wantsNewClone(this)) {
            this.masterLich = nearbyLich;
            this.makeTeleportTrail(super.posX, super.posY, super.posZ, nearbyLich.posX, nearbyLich.posY, nearbyLich.posZ);
            this.setAttackTarget(this.masterLich.getAttackTarget());
            break;
         }
      }

   }

   protected void teleportToSightOfEntity(Entity entity) {
      Vec3 dest = this.findVecInLOSOf(entity);
      double srcX = super.posX;
      double srcY = super.posY;
      double srcZ = super.posZ;
      if(dest != null) {
         this.teleportToNoChecks(dest.xCoord, dest.yCoord, dest.zCoord);
         this.faceEntity(entity, 100.0F, 100.0F);
         super.renderYawOffset = super.rotationYaw;
         if(!this.canEntityBeSeen(entity)) {
            this.teleportToNoChecks(srcX, srcY, srcZ);
         }
      }

   }

   protected Vec3 findVecInLOSOf(Entity targetEntity) {
      if(targetEntity == null) {
         return null;
      } else {
         double tx = 0.0D;
         double ty = 0.0D;
         double tz = 0.0D;
         byte tries = 100;

         for(int i = 0; i < tries; ++i) {
            tx = targetEntity.posX + super.rand.nextGaussian() * 16.0D;
            ty = targetEntity.posY + super.rand.nextGaussian() * 8.0D;
            tz = targetEntity.posZ + super.rand.nextGaussian() * 16.0D;
            boolean groundFlag = false;
            int bx = MathHelper.floor_double(tx);
            int by = MathHelper.floor_double(ty);
            int bz = MathHelper.floor_double(tz);

            while(!groundFlag && ty > 0.0D) {
               Block halfWidth = super.worldObj.getBlock(bx, by - 1, bz);
               if(halfWidth != Blocks.air && halfWidth.getMaterial().isSolid()) {
                  groundFlag = true;
               } else {
                  --ty;
                  --by;
               }
            }

            if(by != 0 && this.canEntitySee(targetEntity, tx, ty, tz)) {
               float var16 = super.width / 2.0F;
               AxisAlignedBB destBox = AxisAlignedBB.getBoundingBox(tx - (double)var16, ty - (double)super.yOffset + (double)super.ySize, tz - (double)var16, tx + (double)var16, ty - (double)super.yOffset + (double)super.ySize + (double)super.height, tz + (double)var16);
               if(super.worldObj.getCollidingBoundingBoxes(this, destBox).size() <= 0 && !super.worldObj.isAnyLiquid(destBox)) {
                  break;
               }
            }
         }

         return tries == 99?null:Vec3.createVectorHelper(tx, ty, tz);
      }
   }

   protected boolean canEntitySee(Entity entity, double dx, double dy, double dz) {
      return super.worldObj.rayTraceBlocks(Vec3.createVectorHelper(entity.posX, entity.posY + (double)entity.getEyeHeight(), entity.posZ), Vec3.createVectorHelper(dx, dy, dz)) == null;
   }

   protected boolean teleportToNoChecks(double destX, double destY, double destZ) {
      double srcX = super.posX;
      double srcY = super.posY;
      double srcZ = super.posZ;
      this.setPosition(destX, destY, destZ);
      this.makeTeleportTrail(srcX, srcY, srcZ, destX, destY, destZ);
      super.worldObj.playSoundEffect(srcX, srcY, srcZ, "mob.endermen.portal", 1.0F, 1.0F);
      super.worldObj.playSoundAtEntity(this, "mob.endermen.portal", 1.0F, 1.0F);
      super.isJumping = false;
      return true;
   }

   protected void makeTeleportTrail(double srcX, double srcY, double srcZ, double destX, double destY, double destZ) {
      short particles = 128;

      for(int i = 0; i < particles; ++i) {
         double trailFactor = (double)i / ((double)particles - 1.0D);
         float f = (super.rand.nextFloat() - 0.5F) * 0.2F;
         float f1 = (super.rand.nextFloat() - 0.5F) * 0.2F;
         float f2 = (super.rand.nextFloat() - 0.5F) * 0.2F;
         double tx = srcX + (destX - srcX) * trailFactor + (super.rand.nextDouble() - 0.5D) * (double)super.width * 2.0D;
         double ty = srcY + (destY - srcY) * trailFactor + super.rand.nextDouble() * (double)super.height;
         double tz = srcZ + (destZ - srcZ) * trailFactor + (super.rand.nextDouble() - 0.5D) * (double)super.width * 2.0D;
         super.worldObj.spawnParticle("spell", tx, ty, tz, (double)f, (double)f1, (double)f2);
      }

   }

   protected void makeRedMagicTrail(double srcX, double srcY, double srcZ, double destX, double destY, double destZ) {
      byte particles = 32;

      for(int i = 0; i < particles; ++i) {
         double trailFactor = (double)i / ((double)particles - 1.0D);
         float f = 1.0F;
         float f1 = 0.5F;
         float f2 = 0.5F;
         double tx = srcX + (destX - srcX) * trailFactor + super.rand.nextGaussian() * 0.005D;
         double ty = srcY + (destY - srcY) * trailFactor + super.rand.nextGaussian() * 0.005D;
         double tz = srcZ + (destZ - srcZ) * trailFactor + super.rand.nextGaussian() * 0.005D;
         super.worldObj.spawnParticle("mobSpell", tx, ty, tz, (double)f, (double)f1, (double)f2);
      }

   }

   protected void makeBlackMagicTrail(double srcX, double srcY, double srcZ, double destX, double destY, double destZ) {
      byte particles = 32;

      for(int i = 0; i < particles; ++i) {
         double trailFactor = (double)i / ((double)particles - 1.0D);
         float f = 0.2F;
         float f1 = 0.2F;
         float f2 = 0.2F;
         double tx = srcX + (destX - srcX) * trailFactor + super.rand.nextGaussian() * 0.005D;
         double ty = srcY + (destY - srcY) * trailFactor + super.rand.nextGaussian() * 0.005D;
         double tz = srcZ + (destZ - srcZ) * trailFactor + super.rand.nextGaussian() * 0.005D;
         super.worldObj.spawnParticle("mobSpell", tx, ty, tz, (double)f, (double)f1, (double)f2);
      }

   }

   public boolean isShadowClone() {
      return (super.dataWatcher.getWatchableObjectByte(21) & 2) != 0;
   }

   public void setShadowClone(boolean par1) {
      byte var2 = super.dataWatcher.getWatchableObjectByte(21);
      if(par1) {
         super.dataWatcher.updateObject(21, Byte.valueOf((byte)(var2 | 2)));
      } else {
         super.dataWatcher.updateObject(21, Byte.valueOf((byte)(var2 & -3)));
      }

   }

   public byte getShieldStrength() {
      return super.dataWatcher.getWatchableObjectByte(17);
   }

   public void setShieldStrength(int shieldStrength) {
      super.dataWatcher.updateObject(17, Byte.valueOf((byte)shieldStrength));
   }

   public byte getMinionsToSummon() {
      return super.dataWatcher.getWatchableObjectByte(18);
   }

   public void setMinionsToSummon(int minionsToSummon) {
      super.dataWatcher.updateObject(18, Byte.valueOf((byte)minionsToSummon));
   }

   public byte getNextAttackType() {
      return super.dataWatcher.getWatchableObjectByte(20);
   }

   public void setNextAttackType(int attackType) {
      super.dataWatcher.updateObject(20, Byte.valueOf((byte)attackType));
   }

   protected String getLivingSound() {
      return "mob.blaze.breathe";
   }

   protected String getHurtSound() {
      return "mob.blaze.hit";
   }

   protected String getDeathSound() {
      return "mob.blaze.death";
   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      super.writeEntityToNBT(nbttagcompound);
      nbttagcompound.setBoolean("ShadowClone", this.isShadowClone());
      nbttagcompound.setByte("ShieldStrength", this.getShieldStrength());
      nbttagcompound.setByte("MinionsToSummon", this.getMinionsToSummon());
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      this.setShadowClone(nbttagcompound.getBoolean("ShadowClone"));
      this.setShieldStrength(nbttagcompound.getByte("ShieldStrength"));
      this.setMinionsToSummon(nbttagcompound.getByte("MinionsToSummon"));
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightKillLich);
      }

      if(!super.worldObj.isRemote && !this.isShadowClone()) {
         int dx = MathHelper.floor_double(super.posX);
         int dy = MathHelper.floor_double(super.posY);
         int dz = MathHelper.floor_double(super.posZ);
         if(super.worldObj.provider instanceof WorldProviderTwilightForest) {
            ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
            TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(dx, dz, super.worldObj);
            if(nearbyFeature == TFFeature.lichTower) {
               chunkProvider.setStructureConquered(dx, dy, dz, true);
            }
         }
      }

   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.UNDEAD;
   }

}

package twilightforest.entity.boss;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class EntityTFHydraMortar extends EntityThrowable {

   private static final int BURN_FACTOR = 5;
   private static final int DIRECT_DAMAGE = 18;
   public EntityLivingBase playerReflects = null;
   public int fuse = 80;
   public boolean megaBlast = false;


   public EntityTFHydraMortar(World par1World) {
      super(par1World);
      this.setSize(0.75F, 0.75F);
   }

   public EntityTFHydraMortar(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
      this.setSize(0.75F, 0.75F);
   }

   public void onUpdate() {
      super.onUpdate();
      this.func_145771_j(super.posX, (super.boundingBox.minY + super.boundingBox.maxY) / 2.0D, super.posZ);
      if(super.onGround) {
         if(!super.worldObj.isRemote) {
            super.motionX *= 0.9D;
            super.motionY *= 0.9D;
            super.motionZ *= 0.9D;
         }

         if(this.fuse-- <= 0) {
            this.detonate();
         }
      }

   }

   public void setToBlasting() {
      this.megaBlast = true;
   }

   protected void onImpact(MovingObjectPosition mop) {
      if(mop.entityHit == null && !this.megaBlast) {
         super.motionY = 0.0D;
         super.onGround = true;
      } else {
         this.detonate();
      }

   }

   public float func_145772_a(Explosion par1Explosion, World par2World, int par3, int par4, int par5, Block par6Block) {
      float var6 = super.func_145772_a(par1Explosion, par2World, par3, par4, par5, par6Block);
      if(this.megaBlast && par6Block != Blocks.bedrock && par6Block != Blocks.end_portal && par6Block != Blocks.end_portal_frame) {
         var6 = Math.min(0.8F, var6);
      }

      return var6;
   }

   protected void detonate() {
      float explosionPower = this.megaBlast?4.0F:0.1F;
      super.worldObj.newExplosion(this, super.posX, super.posY, super.posZ, explosionPower, true, true);
      if(!super.worldObj.isRemote) {
         ArrayList nearbyList = new ArrayList(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.expand(1.0D, 1.0D, 1.0D)));
         Iterator var3 = nearbyList.iterator();

         while(var3.hasNext()) {
            Entity nearby = (Entity)var3.next();
            if(nearby.attackEntityFrom(DamageSource.causeFireballDamage((EntityFireball)null, this.getThrower()), 18.0F) && !nearby.isImmuneToFire()) {
               nearby.setFire(5);
            }
         }
      }

      this.setDead();
   }

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      this.setBeenAttacked();
      if(damagesource.getEntity() != null && !super.worldObj.isRemote) {
         Vec3 vec3d = damagesource.getEntity().getLookVec();
         if(vec3d != null) {
            this.setThrowableHeading(vec3d.xCoord, vec3d.yCoord + 1.0D, vec3d.zCoord, 1.5F, 0.1F);
            super.onGround = false;
            this.fuse += 20;
         }

         if(damagesource.getEntity() instanceof EntityLivingBase) {
            this.playerReflects = (EntityLivingBase)damagesource.getEntity();
         }

         return true;
      } else {
         return false;
      }
   }

   public EntityLivingBase getThrower() {
      return this.playerReflects != null?this.playerReflects:super.getThrower();
   }

   public boolean isBurning() {
      return true;
   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public float getCollisionBorderSize() {
      return 1.5F;
   }

   protected float getGravityVelocity() {
      return 0.05F;
   }

   protected float func_70182_d() {
      return 0.75F;
   }

   protected float func_70183_g() {
      return -20.0F;
   }
}

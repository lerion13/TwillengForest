package twilightforest.entity.boss;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public class EntityTFIceCrystal extends EntityMob {

   private int crystalAge;


   public EntityTFIceCrystal(World par1World) {
      super(par1World);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(3, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.setSize(0.6F, 1.8F);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23000000417232513D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected Item getDropItem() {
      return Items.snowball;
   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.ice.noise";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.ice.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.ice.death";
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      ++this.crystalAge;
      if(this.crystalAge >= 600 && !super.worldObj.isRemote) {
         this.setDead();
      }

   }
}

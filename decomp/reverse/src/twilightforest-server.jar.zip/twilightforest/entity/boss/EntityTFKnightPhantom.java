package twilightforest.entity.boss;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.TFTreasure;
import twilightforest.entity.boss.EntityTFThrownAxe;
import twilightforest.entity.boss.EntityTFThrownPick;
import twilightforest.item.TFItems;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFKnightPhantom extends EntityFlying implements IMob {

   private static final float CIRCLE_SMALL_RADIUS = 2.5F;
   private static final float CIRCLE_LARGE_RADIUS = 8.5F;
   private static final int FLAG_CHARGING = 17;
   int number;
   int ticksProgress;
   EntityTFKnightPhantom.Formation currentFormation;
   private ChunkCoordinates homePosition = new ChunkCoordinates(0, 0, 0);
   private float maximumHomeDistance = -1.0F;
   private int chargePosX;
   private int chargePosY;
   private int chargePosZ;


   public EntityTFKnightPhantom(World par1World) {
      super(par1World);
      this.setSize(1.5F, 3.0F);
      super.noClip = true;
      super.isImmuneToFire = true;
      this.currentFormation = EntityTFKnightPhantom.Formation.HOVER;
      super.experienceValue = 93;
      this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlySword));
      this.setCurrentItemOrArmor(3, new ItemStack(TFItems.phantomPlate));
      this.setCurrentItemOrArmor(4, new ItemStack(TFItems.phantomHelm));
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(35.0D);
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0D);
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      return this.isEntityInvulnerable()?false:(par1DamageSource == DamageSource.inWall?false:super.attackEntityFrom(par1DamageSource, par2));
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.isChargingAtPlayer()) {
         for(int i = 0; i < 4; ++i) {
            Item particleID = super.rand.nextBoolean()?TFItems.phantomHelm:TFItems.knightlySword;
            super.worldObj.spawnParticle("iconcrack_" + Item.getIdFromItem(particleID), super.posX + ((double)(super.rand.nextFloat() * super.rand.nextFloat()) - 0.5D) * (double)super.width, super.posY + (double)super.rand.nextFloat() * ((double)super.height - 0.75D) + 0.5D, super.posZ + ((double)(super.rand.nextFloat() * super.rand.nextFloat()) - 0.5D) * (double)super.width, 0.0D, -0.1D, 0.0D);
            super.worldObj.spawnParticle("smoke", super.posX + ((double)(super.rand.nextFloat() * super.rand.nextFloat()) - 0.5D) * (double)super.width, super.posY + (double)super.rand.nextFloat() * ((double)super.height - 0.75D) + 0.5D, super.posZ + ((double)(super.rand.nextFloat() * super.rand.nextFloat()) - 0.5D) * (double)super.width, 0.0D, 0.1D, 0.0D);
         }
      }

   }

   protected void onDeathUpdate() {
      super.onDeathUpdate();

      for(int i = 0; i < 20; ++i) {
         double d0 = super.rand.nextGaussian() * 0.02D;
         double d1 = super.rand.nextGaussian() * 0.02D;
         double d2 = super.rand.nextGaussian() * 0.02D;
         super.worldObj.spawnParticle("explode", super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, d0, d1, d2);
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightProgressKnights);
      }

      if(!super.worldObj.isRemote && super.worldObj.provider instanceof WorldProviderTwilightForest) {
         int nearbyKnights = this.getHomePosition().posX;
         int dy = this.getHomePosition().posY;
         int dz = this.getHomePosition().posZ;
         ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
         TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(nearbyKnights, dz, super.worldObj);
         if(nearbyFeature == TFFeature.tfStronghold) {
            chunkProvider.setStructureConquered(nearbyKnights, dy, dz, true);
         }
      }

      if(!super.worldObj.isRemote) {
         List nearbyKnights1 = this.getNearbyKnights();
         if(nearbyKnights1.size() <= 1) {
            this.makeATreasure();
         }
      }

   }

   private void makeATreasure() {
      if(this.getHomePosition().posX != 0) {
         TFTreasure.stronghold_boss.generate(super.worldObj, (Random)null, this.getHomePosition().posX, this.getHomePosition().posY - 1, this.getHomePosition().posZ);
      } else {
         int px = MathHelper.floor_double(super.lastTickPosX);
         int py = MathHelper.floor_double(super.lastTickPosY);
         int pz = MathHelper.floor_double(super.lastTickPosZ);
         TFTreasure.stronghold_boss.generate(super.worldObj, (Random)null, px, py, pz);
      }

   }

   protected void updateEntityActionState() {
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.setDead();
      }

      this.despawnEntity();
      super.noClip = this.ticksProgress % 20 != 0;
      ++this.ticksProgress;
      if(this.ticksProgress >= this.getMaxTicksForFormation()) {
         this.switchToNextFormation();
      }

      float seekRange = this.isChargingAtPlayer()?24.0F:9.0F;
      EntityPlayer target = super.worldObj.getClosestVulnerablePlayerToEntity(this, (double)seekRange);
      if(target != null && this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START) {
         int dest = MathHelper.floor_double(target.lastTickPosX);
         int moveX = MathHelper.floor_double(target.lastTickPosY);
         int targetZ = MathHelper.floor_double(target.lastTickPosZ);
         if(this.isWithinHomeArea(dest, moveX, targetZ)) {
            this.chargePosX = dest;
            this.chargePosY = moveX;
            this.chargePosZ = targetZ;
         } else {
            this.chargePosX = this.getHomePosition().posX;
            this.chargePosY = this.getHomePosition().posY;
            this.chargePosZ = this.getHomePosition().posZ;
         }
      }

      Vec3 dest1 = this.getDestination();
      double moveX1 = dest1.xCoord - super.posX;
      double moveY = dest1.yCoord - super.posY;
      double moveZ = dest1.zCoord - super.posZ;
      double factor = moveX1 * moveX1 + moveY * moveY + moveZ * moveZ;
      factor = (double)MathHelper.sqrt_double(factor);
      double speed = 0.1D;
      super.motionX += moveX1 / factor * speed;
      super.motionY += moveY / factor * speed;
      super.motionZ += moveZ / factor * speed;
      if(target != null) {
         this.faceEntity(target, 10.0F, 500.0F);
         if(target.isEntityAlive()) {
            float f1 = target.getDistanceToEntity(this);
            if(this.canEntityBeSeen(target)) {
               this.attackEntity(target, f1);
            }
         }

         if(this.isAxeKnight() && this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK && this.ticksProgress % 4 == 0) {
            this.launchAxeAt(target);
         }

         if(this.isPickKnight() && this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK && this.ticksProgress % 4 == 0) {
            this.launchPicks();
         }
      }

   }

   protected void attackEntity(Entity par1Entity, float par2) {
      if(super.attackTime <= 0 && par2 < 2.0F && par1Entity.boundingBox.maxY > super.boundingBox.minY && par1Entity.boundingBox.minY < super.boundingBox.maxY) {
         super.attackTime = 20;
         this.attackEntityAsMob(par1Entity);
      }

   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      float f = this.getAttackDamage();
      int i = 0;
      if(par1Entity instanceof EntityLivingBase) {
         f += EnchantmentHelper.getEnchantmentModifierLiving(this, (EntityLivingBase)par1Entity);
         i += EnchantmentHelper.getKnockbackModifier(this, (EntityLivingBase)par1Entity);
      }

      boolean flag = par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), f);
      if(flag) {
         if(i > 0) {
            par1Entity.addVelocity((double)(-MathHelper.sin(super.rotationYaw * 3.1415927F / 180.0F) * (float)i * 0.5F), 0.1D, (double)(MathHelper.cos(super.rotationYaw * 3.1415927F / 180.0F) * (float)i * 0.5F));
            super.motionX *= 0.6D;
            super.motionZ *= 0.6D;
         }

         int j = EnchantmentHelper.getFireAspectModifier(this);
         if(j > 0) {
            par1Entity.setFire(j * 4);
         }

         if(par1Entity instanceof EntityLivingBase) {
            ;
         }
      }

      return flag;
   }

   private float getAttackDamage() {
      float damage = (float)this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
      if(this.isChargingAtPlayer()) {
         damage += 7.0F;
      }

      return damage;
   }

   protected void launchAxeAt(Entity targetedEntity) {
      float bodyFacingAngle = super.renderYawOffset * 3.141593F / 180.0F;
      double sx = super.posX + (double)(MathHelper.cos(bodyFacingAngle) * 1.0F);
      double sy = super.posY + (double)super.height * 0.82D;
      double sz = super.posZ + (double)(MathHelper.sin(bodyFacingAngle) * 1.0F);
      double tx = targetedEntity.posX - sx;
      double ty = targetedEntity.boundingBox.minY + (double)(targetedEntity.height / 2.0F) - (super.posY + (double)(super.height / 2.0F));
      double tz = targetedEntity.posZ - sz;
      super.worldObj.playSoundAtEntity(this, "random.bow", this.getSoundVolume(), (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.4F);
      EntityTFThrownAxe projectile = new EntityTFThrownAxe(super.worldObj, this);
      float speed = 0.75F;
      projectile.setThrowableHeading(tx, ty, tz, speed, 1.0F);
      projectile.setLocationAndAngles(sx, sy, sz, super.rotationYaw, super.rotationPitch);
      super.worldObj.spawnEntityInWorld(projectile);
   }

   protected void launchPicks() {
      super.worldObj.playSoundAtEntity(this, "random.bow", this.getSoundVolume(), (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.4F);

      for(int i = 0; i < 8; ++i) {
         float throwAngle = (float)i * 3.1415915F / 4.0F;
         double sx = super.posX + (double)(MathHelper.cos(throwAngle) * 1.0F);
         double sy = super.posY + (double)super.height * 0.82D;
         double sz = super.posZ + (double)(MathHelper.sin(throwAngle) * 1.0F);
         double vx = (double)MathHelper.cos(throwAngle);
         double vy = 0.0D;
         double vz = (double)MathHelper.sin(throwAngle);
         EntityTFThrownPick projectile = new EntityTFThrownPick(super.worldObj, this);
         projectile.setLocationAndAngles(sx, sy, sz, (float)i * 45.0F, super.rotationPitch);
         float speed = 0.5F;
         projectile.setThrowableHeading(vx, vy, vz, speed, 1.0F);
         super.worldObj.spawnEntityInWorld(projectile);
      }

   }

   public boolean canBePushed() {
      return true;
   }

   public void knockBack(Entity par1Entity, float damage, double par3, double par5) {
      super.isAirBorne = true;
      float f = MathHelper.sqrt_double(par3 * par3 + par5 * par5);
      float distance = 0.2F;
      super.motionX /= 2.0D;
      super.motionY /= 2.0D;
      super.motionZ /= 2.0D;
      super.motionX -= par3 / (double)f * (double)distance;
      super.motionY += (double)distance;
      super.motionZ -= par5 / (double)f * (double)distance;
      if(super.motionY > 0.4000000059604645D) {
         super.motionY = 0.4000000059604645D;
      }

   }

   public void switchToNextFormation() {
      List nearbyKnights = this.getNearbyKnights();
      if(this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START) {
         this.switchToFormation(EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK);
      } else if(this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK) {
         if(nearbyKnights.size() > 1) {
            this.switchToFormation(EntityTFKnightPhantom.Formation.WAITING_FOR_LEADER);
         } else {
            switch(super.rand.nextInt(3)) {
            case 0:
               this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlySword));
               break;
            case 1:
               this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlyAxe));
               break;
            case 2:
               this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlyPick));
            }

            this.switchToFormation(EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START);
         }
      } else if(this.currentFormation == EntityTFKnightPhantom.Formation.WAITING_FOR_LEADER) {
         if(nearbyKnights.size() > 1) {
            this.switchToFormation(((EntityTFKnightPhantom)nearbyKnights.get(1)).currentFormation);
            this.ticksProgress = ((EntityTFKnightPhantom)nearbyKnights.get(1)).ticksProgress;
         } else {
            this.switchToFormation(EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START);
         }
      } else if(this.isThisTheLeader(nearbyKnights)) {
         this.pickRandomFormation();
         this.broadcastMyFormation(nearbyKnights);
         if(this.isNobodyCharging(nearbyKnights)) {
            this.makeARandomKnightCharge(nearbyKnights);
         }
      }

   }

   private List getNearbyKnights() {
      List nearbyKnights = super.worldObj.getEntitiesWithinAABB(EntityTFKnightPhantom.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 8.0D, 32.0D));
      return nearbyKnights;
   }

   protected void pickRandomFormation() {
      switch(super.rand.nextInt(8)) {
      case 0:
         this.currentFormation = EntityTFKnightPhantom.Formation.SMALL_CLOCKWISE;
         break;
      case 1:
         this.currentFormation = EntityTFKnightPhantom.Formation.SMALL_ANTICLOCKWISE;
         break;
      case 2:
         this.currentFormation = EntityTFKnightPhantom.Formation.SMALL_ANTICLOCKWISE;
         break;
      case 3:
         this.currentFormation = EntityTFKnightPhantom.Formation.CHARGE_PLUSX;
         break;
      case 4:
         this.currentFormation = EntityTFKnightPhantom.Formation.CHARGE_MINUSX;
         break;
      case 5:
         this.currentFormation = EntityTFKnightPhantom.Formation.CHARGE_PLUSZ;
         break;
      case 6:
         this.currentFormation = EntityTFKnightPhantom.Formation.CHARGE_MINUSZ;
         break;
      case 7:
         this.currentFormation = EntityTFKnightPhantom.Formation.SMALL_CLOCKWISE;
      }

      this.switchToFormation(this.currentFormation);
   }

   private boolean isThisTheLeader(List nearbyKnights) {
      boolean iAmTheLowest = true;
      Iterator var3 = nearbyKnights.iterator();

      while(var3.hasNext()) {
         EntityTFKnightPhantom knight = (EntityTFKnightPhantom)var3.next();
         if(knight.getNumber() < this.getNumber()) {
            iAmTheLowest = false;
            break;
         }
      }

      return iAmTheLowest;
   }

   private boolean isNobodyCharging(List nearbyKnights) {
      boolean noCharge = true;
      Iterator var3 = nearbyKnights.iterator();

      while(var3.hasNext()) {
         EntityTFKnightPhantom knight = (EntityTFKnightPhantom)var3.next();
         if(knight.isChargingAtPlayer()) {
            noCharge = false;
            break;
         }
      }

      return noCharge;
   }

   private void makeARandomKnightCharge(List nearbyKnights) {
      int randomNum = super.rand.nextInt(nearbyKnights.size());
      ((EntityTFKnightPhantom)nearbyKnights.get(randomNum)).switchToFormation(EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START);
   }

   private void broadcastMyFormation(List nearbyKnights) {
      Iterator var2 = nearbyKnights.iterator();

      while(var2.hasNext()) {
         EntityTFKnightPhantom knight = (EntityTFKnightPhantom)var2.next();
         if(!knight.isChargingAtPlayer()) {
            knight.switchToFormation(this.currentFormation);
         }
      }

   }

   public boolean isChargingAtPlayer() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setChargingAtPlayer(boolean flag) {
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)127));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)0));
      }

   }

   protected String getLivingSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   private void switchToFormationByNumber(int formationNumber) {
      this.currentFormation = EntityTFKnightPhantom.Formation.values()[formationNumber];
      this.ticksProgress = 0;
   }

   public void switchToFormation(EntityTFKnightPhantom.Formation formation) {
      this.currentFormation = formation;
      this.ticksProgress = 0;
      this.setChargingAtPlayer(this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START || this.currentFormation == EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK);
   }

   public int getFormationAsNumber() {
      return this.currentFormation.ordinal();
   }

   public int getTicksProgress() {
      return this.ticksProgress;
   }

   public void setTicksProgress(int ticksProgress) {
      this.ticksProgress = ticksProgress;
   }

   public int getMaxTicksForFormation() {
      switch(EntityTFKnightPhantom.NamelessClass777275205.$SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[this.currentFormation.ordinal()]) {
      case 1:
      default:
         return 90;
      case 2:
         return 180;
      case 3:
         return 90;
      case 4:
         return 180;
      case 5:
         return 90;
      case 6:
         return 180;
      case 7:
         return 180;
      case 8:
         return 180;
      case 9:
         return 180;
      case 10:
         return 50;
      case 11:
         return 50;
      case 12:
         return 10;
      }
   }

   private Vec3 getDestination() {
      if(!this.hasHome()) {
         ;
      }

      switch(EntityTFKnightPhantom.NamelessClass777275205.$SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[this.currentFormation.ordinal()]) {
      case 1:
      case 10:
         return this.getHoverPosition(8.5F);
      case 2:
         return this.getCirclePosition(8.5F, true);
      case 3:
         return this.getCirclePosition(2.5F, true);
      case 4:
         return this.getCirclePosition(8.5F, false);
      case 5:
         return this.getCirclePosition(2.5F, false);
      case 6:
         return this.getMoveAcrossPosition(true, true);
      case 7:
         return this.getMoveAcrossPosition(false, true);
      case 8:
         return this.getMoveAcrossPosition(true, false);
      case 9:
         return this.getMoveAcrossPosition(false, false);
      case 11:
         return this.getAttackPlayerPosition();
      case 12:
         return this.getLoiterPosition();
      default:
         return this.getLoiterPosition();
      }
   }

   private Vec3 getMoveAcrossPosition(boolean plus, boolean alongX) {
      float offset0 = (float)this.getNumber() * 3.0F - 7.5F;
      float offset1;
      if(this.ticksProgress < 60) {
         offset1 = -7.0F;
      } else {
         offset1 = -7.0F + (float)(this.ticksProgress - 60) / 120.0F * 14.0F;
      }

      if(!plus) {
         offset1 *= -1.0F;
      }

      double dx = (double)((float)this.getHomePosition().posX + (alongX?offset0:offset1));
      double dy = (double)this.getHomePosition().posY + Math.cos((double)((float)this.ticksProgress / 7.0F + (float)this.getNumber()));
      double dz = (double)((float)this.getHomePosition().posZ + (alongX?offset1:offset0));
      return Vec3.createVectorHelper(dx, dy, dz);
   }

   protected Vec3 getCirclePosition(float distance, boolean clockwise) {
      float angle = (float)this.ticksProgress * 2.0F;
      if(!clockwise) {
         angle *= -1.0F;
      }

      angle += 60.0F * (float)this.getNumber();
      double dx = (double)this.getHomePosition().posX + Math.cos((double)angle * 3.141592653589793D / 180.0D) * (double)distance;
      double dy = (double)this.getHomePosition().posY + Math.cos((double)((float)this.ticksProgress / 7.0F + (float)this.getNumber()));
      double dz = (double)this.getHomePosition().posZ + Math.sin((double)angle * 3.141592653589793D / 180.0D) * (double)distance;
      return Vec3.createVectorHelper(dx, dy, dz);
   }

   private Vec3 getHoverPosition(float distance) {
      double dx = super.lastTickPosX;
      double dy = (double)this.getHomePosition().posY + Math.cos((double)((float)this.ticksProgress / 7.0F + (float)this.getNumber()));
      double dz = super.lastTickPosZ;
      double ox = (double)this.getHomePosition().posX - dx;
      double oz = (double)this.getHomePosition().posZ - dz;
      double dDist = Math.sqrt(ox * ox + oz * oz);
      if(dDist > (double)distance) {
         dx = (double)this.getHomePosition().posX + ox / dDist * (double)distance;
         dz = (double)this.getHomePosition().posZ + oz / dDist * (double)distance;
      }

      return Vec3.createVectorHelper(dx, dy, dz);
   }

   private Vec3 getLoiterPosition() {
      double dx = (double)this.getHomePosition().posX;
      double dy = (double)this.getHomePosition().posY + Math.cos((double)((float)this.ticksProgress / 7.0F + (float)this.getNumber()));
      double dz = (double)this.getHomePosition().posZ;
      return Vec3.createVectorHelper(dx, dy, dz);
   }

   private Vec3 getAttackPlayerPosition() {
      return this.isSwordKnight()?Vec3.createVectorHelper((double)this.chargePosX, (double)this.chargePosY, (double)this.chargePosZ):this.getHoverPosition(8.5F);
   }

   public boolean isSwordKnight() {
      return this.getEquipmentInSlot(0) != null && this.getEquipmentInSlot(0).getItem() == TFItems.knightlySword;
   }

   public boolean isAxeKnight() {
      return this.getEquipmentInSlot(0) != null && this.getEquipmentInSlot(0).getItem() == TFItems.knightlyAxe;
   }

   public boolean isPickKnight() {
      return this.getEquipmentInSlot(0) != null && this.getEquipmentInSlot(0).getItem() == TFItems.knightlyPick;
   }

   public int getNumber() {
      return this.number;
   }

   public void setNumber(int number) {
      this.number = number;
      switch(number % 3) {
      case 0:
         this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlySword));
         break;
      case 1:
         this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlyAxe));
         break;
      case 2:
         this.setCurrentItemOrArmor(0, new ItemStack(TFItems.knightlyPick));
      }

   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      super.writeEntityToNBT(nbttagcompound);
      ChunkCoordinates home = this.getHomePosition();
      nbttagcompound.setTag("Home", this.newDoubleNBTList(new double[]{(double)home.posX, (double)home.posY, (double)home.posZ}));
      nbttagcompound.setBoolean("HasHome", this.hasHome());
      nbttagcompound.setInteger("MyNumber", this.getNumber());
      nbttagcompound.setInteger("Formation", this.getFormationAsNumber());
      nbttagcompound.setInteger("TicksProgress", this.getTicksProgress());
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      if(nbttagcompound.hasKey("Home", 9)) {
         NBTTagList nbttaglist = nbttagcompound.getTagList("Home", 6);
         int hx = (int)nbttaglist.func_150309_d(0);
         int hy = (int)nbttaglist.func_150309_d(1);
         int hz = (int)nbttaglist.func_150309_d(2);
         this.setHomeArea(hx, hy, hz, 20);
      }

      if(!nbttagcompound.getBoolean("HasHome")) {
         this.detachHome();
      }

      this.setNumber(nbttagcompound.getInteger("MyNumber"));
      this.switchToFormationByNumber(nbttagcompound.getInteger("Formation"));
      this.setTicksProgress(nbttagcompound.getInteger("TicksProgress"));
   }

   public boolean isWithinHomeArea(int par1, int par2, int par3) {
      return this.maximumHomeDistance == -1.0F?true:this.homePosition.getDistanceSquared(par1, par2, par3) < this.maximumHomeDistance * this.maximumHomeDistance;
   }

   public void setHomeArea(int par1, int par2, int par3, int par4) {
      this.homePosition.set(par1, par2, par3);
      this.maximumHomeDistance = (float)par4;
   }

   public ChunkCoordinates getHomePosition() {
      return this.homePosition;
   }

   public float getMaximumHomeDistance() {
      return this.maximumHomeDistance;
   }

   public void detachHome() {
      this.maximumHomeDistance = -1.0F;
   }

   public boolean hasHome() {
      return this.maximumHomeDistance != -1.0F;
   }

   // $FF: synthetic class
   static class NamelessClass777275205 {

      // $FF: synthetic field
      static final int[] $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation = new int[EntityTFKnightPhantom.Formation.values().length];


      static {
         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.HOVER.ordinal()] = 1;
         } catch (NoSuchFieldError var12) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.LARGE_CLOCKWISE.ordinal()] = 2;
         } catch (NoSuchFieldError var11) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.SMALL_CLOCKWISE.ordinal()] = 3;
         } catch (NoSuchFieldError var10) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.LARGE_ANTICLOCKWISE.ordinal()] = 4;
         } catch (NoSuchFieldError var9) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.SMALL_ANTICLOCKWISE.ordinal()] = 5;
         } catch (NoSuchFieldError var8) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.CHARGE_PLUSX.ordinal()] = 6;
         } catch (NoSuchFieldError var7) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.CHARGE_MINUSX.ordinal()] = 7;
         } catch (NoSuchFieldError var6) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.CHARGE_PLUSZ.ordinal()] = 8;
         } catch (NoSuchFieldError var5) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.CHARGE_MINUSZ.ordinal()] = 9;
         } catch (NoSuchFieldError var4) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.ATTACK_PLAYER_START.ordinal()] = 10;
         } catch (NoSuchFieldError var3) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.ATTACK_PLAYER_ATTACK.ordinal()] = 11;
         } catch (NoSuchFieldError var2) {
            ;
         }

         try {
            $SwitchMap$twilightforest$entity$boss$EntityTFKnightPhantom$Formation[EntityTFKnightPhantom.Formation.WAITING_FOR_LEADER.ordinal()] = 12;
         } catch (NoSuchFieldError var1) {
            ;
         }

      }
   }

   public static enum Formation {

      HOVER("HOVER", 0),
      LARGE_CLOCKWISE("LARGE_CLOCKWISE", 1),
      SMALL_CLOCKWISE("SMALL_CLOCKWISE", 2),
      LARGE_ANTICLOCKWISE("LARGE_ANTICLOCKWISE", 3),
      SMALL_ANTICLOCKWISE("SMALL_ANTICLOCKWISE", 4),
      CHARGE_PLUSX("CHARGE_PLUSX", 5),
      CHARGE_MINUSX("CHARGE_MINUSX", 6),
      CHARGE_PLUSZ("CHARGE_PLUSZ", 7),
      CHARGE_MINUSZ("CHARGE_MINUSZ", 8),
      WAITING_FOR_LEADER("WAITING_FOR_LEADER", 9),
      ATTACK_PLAYER_START("ATTACK_PLAYER_START", 10),
      ATTACK_PLAYER_ATTACK("ATTACK_PLAYER_ATTACK", 11);
      // $FF: synthetic field
      private static final EntityTFKnightPhantom.Formation[] $VALUES = new EntityTFKnightPhantom.Formation[]{HOVER, LARGE_CLOCKWISE, SMALL_CLOCKWISE, LARGE_ANTICLOCKWISE, SMALL_ANTICLOCKWISE, CHARGE_PLUSX, CHARGE_MINUSX, CHARGE_PLUSZ, CHARGE_MINUSZ, WAITING_FOR_LEADER, ATTACK_PLAYER_START, ATTACK_PLAYER_ATTACK};


      private Formation(String var1, int var2) {}

   }
}

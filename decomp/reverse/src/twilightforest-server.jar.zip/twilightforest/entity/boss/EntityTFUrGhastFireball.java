package twilightforest.entity.boss;

import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFUrGhast;

public class EntityTFUrGhastFireball extends EntityLargeFireball {

   public EntityTFUrGhastFireball(World worldObj, EntityTFUrGhast entityTFTowerBoss, double x, double y, double z) {
      super(worldObj, entityTFTowerBoss, x, y, z);
   }

   protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
      if(!super.worldObj.isRemote && !(par1MovingObjectPosition.entityHit instanceof EntityFireball)) {
         if(par1MovingObjectPosition.entityHit != null) {
            par1MovingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeFireballDamage(this, super.shootingEntity), 16.0F);
         }

         super.worldObj.newExplosion((Entity)null, super.posX, super.posY, super.posZ, (float)super.field_92057_e, true, super.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing"));
         this.setDead();
      }

   }
}

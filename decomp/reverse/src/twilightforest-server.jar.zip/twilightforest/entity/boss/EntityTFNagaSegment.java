package twilightforest.entity.boss;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFNaga;

public class EntityTFNagaSegment extends Entity {

   EntityTFNaga naga;
   int segment;
   String texture;
   private int deathCounter;


   public EntityTFNagaSegment(World par1World) {
      super(par1World);
      this.setSize(1.8F, 1.8F);
      super.stepHeight = 2.0F;
   }

   public EntityTFNagaSegment(EntityTFNaga myNaga, int segNum) {
      this(myNaga.func_82194_d());
      this.naga = myNaga;
      this.segment = segNum;
   }

   public boolean attackEntityFrom(DamageSource damagesource, float damage) {
      return !damagesource.isExplosion() && !damagesource.isFireDamage()?(this.naga != null?this.naga.attackEntityFrom(damagesource, (float)Math.round(damage * 2.0F / 3.0F)):false):false;
   }

   public void onUpdate() {
      super.onUpdate();
      if(this.naga == null || this.naga.isDead) {
         this.setDead();
      }

      ++super.ticksExisted;
      super.lastTickPosX = super.posX;
      super.lastTickPosY = super.posY;

      for(super.lastTickPosZ = super.posZ; super.rotationYaw - super.prevRotationYaw < -180.0F; super.prevRotationYaw -= 360.0F) {
         ;
      }

      while(super.rotationYaw - super.prevRotationYaw >= 180.0F) {
         super.prevRotationYaw += 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch < -180.0F) {
         super.prevRotationPitch -= 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch >= 180.0F) {
         super.prevRotationPitch += 360.0F;
      }

      if(!super.onGround) {
         super.motionY -= 0.08D;
      } else {
         super.motionX *= 0.800000011920929D;
         super.motionZ *= 0.800000011920929D;
      }

      this.moveEntity(super.motionX, super.motionY, super.motionZ);
      this.collideWithOthers();
      if(this.deathCounter > 0) {
         --this.deathCounter;
         if(this.deathCounter == 0) {
            for(int k = 0; k < 20; ++k) {
               double d = super.rand.nextGaussian() * 0.02D;
               double d1 = super.rand.nextGaussian() * 0.02D;
               double d2 = super.rand.nextGaussian() * 0.02D;
               String explosionType = super.rand.nextBoolean()?"largeexplode":"explode";
               super.worldObj.spawnParticle(explosionType, super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, d, d1, d2);
            }

            this.setDead();
            super.worldObj.removeEntity(this);
         }
      }

   }

   protected void collideWithOthers() {
      List list = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.expand(0.20000000298023224D, 0.0D, 0.20000000298023224D));
      Iterator var2 = list.iterator();

      while(var2.hasNext()) {
         Entity entity = (Entity)var2.next();
         if(entity.canBePushed()) {
            this.collideWithEntity(entity);
         }
      }

   }

   private void collideWithEntity(Entity entity) {
      entity.applyEntityCollision(this);
      if(entity instanceof EntityLivingBase && !(entity instanceof EntityTFNaga) && !(entity instanceof EntityTFNagaSegment)) {
         this.naga.attackTime = 10;
         int attackStrength = 2;
         if(entity instanceof EntityAnimal) {
            attackStrength *= 3;
         }

         entity.attackEntityFrom(DamageSource.causeMobDamage(this.naga), (float)attackStrength);
      }

   }

   public void setRotation(float par1, float par2) {
      super.rotationYaw = MathHelper.wrapAngleTo180_float(par1 % 360.0F);
      super.rotationPitch = par2 % 360.0F;
   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public boolean canBePushed() {
      return false;
   }

   protected boolean canDespawn() {
      return false;
   }

   public boolean isEntityEqual(Entity entity) {
      return this == entity || this.naga == entity;
   }

   protected void entityInit() {}

   protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

   protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {}

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {}

   @SideOnly(Side.CLIENT)
   public String getTexture() {
      return this.texture;
   }

   public void selfDestruct() {
      this.deathCounter = 30;
   }
}

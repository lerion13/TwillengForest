package twilightforest.entity.boss;

import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFSnowQueen;

public class EntityTFSnowQueenIceShield extends Entity {

   EntityTFSnowQueen queen;


   public EntityTFSnowQueenIceShield(World par1World) {
      super(par1World);
      this.setSize(0.75F, 0.75F);
   }

   public EntityTFSnowQueenIceShield(EntityTFSnowQueen goblin) {
      this(goblin.func_82194_d());
      this.queen = goblin;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      super.worldObj.playSoundAtEntity(this, "random.break", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      return false;
   }

   public void onUpdate() {
      super.onUpdate();
      ++super.ticksExisted;
      super.lastTickPosX = super.posX;
      super.lastTickPosY = super.posY;

      for(super.lastTickPosZ = super.posZ; super.rotationYaw - super.prevRotationYaw < -180.0F; super.prevRotationYaw -= 360.0F) {
         ;
      }

      while(super.rotationYaw - super.prevRotationYaw >= 180.0F) {
         super.prevRotationYaw += 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch < -180.0F) {
         super.prevRotationPitch -= 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch >= 180.0F) {
         super.prevRotationPitch += 360.0F;
      }

   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public boolean canBePushed() {
      return false;
   }

   public boolean isEntityEqual(Entity entity) {
      return this == entity || this.queen == entity;
   }

   protected void entityInit() {}

   protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

   protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {}
}

package twilightforest.entity.boss;

import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.TwilightForestMod;
import twilightforest.entity.ai.EntityAIStayNearHome;
import twilightforest.entity.ai.EntityAITFThrowRider;
import twilightforest.entity.ai.EntityAITFYetiRampage;
import twilightforest.entity.ai.EntityAITFYetiTired;
import twilightforest.entity.boss.EntityTFFallingIce;
import twilightforest.entity.boss.EntityTFIceBomb;
import twilightforest.item.TFItems;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFYetiAlpha extends EntityMob implements IRangedAttackMob {

   private static final int RAMPAGE_FLAG = 16;
   private static final int TIRED_FLAG = 17;
   private int collisionCounter;
   private boolean canRampage;


   public EntityTFYetiAlpha(World par1World) {
      super(par1World);
      this.setSize(3.8F, 5.0F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAITFYetiTired(this, 100));
      super.tasks.addTask(2, new EntityAITFThrowRider(this, 1.0F));
      super.tasks.addTask(3, new EntityAIStayNearHome(this, 2.0F));
      super.tasks.addTask(4, new EntityAITFYetiRampage(this, 10, 180));
      super.tasks.addTask(5, new EntityAIArrowAttack(this, 1.0D, 40, 40, 40.0F));
      super.tasks.addTask(6, new EntityAIWander(this, 2.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(8, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
      super.experienceValue = 317;
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(16, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(200.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.38D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0D);
      this.getEntityAttribute(SharedMonsterAttributes.followRange).setBaseValue(40.0D);
   }

   public void onLivingUpdate() {
      if(super.riddenByEntity != null && super.riddenByEntity.isSneaking()) {
         super.riddenByEntity.setSneaking(false);
      }

      super.onLivingUpdate();
      if(super.riddenByEntity != null) {
         this.getLookHelper().setLookPositionWithEntity(super.riddenByEntity, 100.0F, 100.0F);
      }

      if(super.isCollided) {
         ++this.collisionCounter;
      }

      if(this.collisionCounter >= 15) {
         if(!super.worldObj.isRemote) {
            this.destroyBlocksInAABB(super.boundingBox);
         }

         this.collisionCounter = 0;
      }

      if(this.isRampaging()) {
         float i = (float)super.ticksExisted / 10.0F;

         for(int i1 = 0; i1 < 20; ++i1) {
            this.addSnowEffect(i + (float)(i1 * 50), (float)i1 + i);
         }

         super.limbSwingAmount = (float)((double)super.limbSwingAmount + 0.6D);
      }

      if(this.isTired()) {
         for(int var3 = 0; var3 < 20; ++var3) {
            super.worldObj.spawnParticle("splash", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width * 0.5D, super.posY + (double)this.getEyeHeight(), super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width * 0.5D, (double)((super.rand.nextFloat() - 0.5F) * 0.75F), 0.0D, (double)((super.rand.nextFloat() - 0.5F) * 0.75F));
         }
      }

   }

   private void addSnowEffect(float rotation, float hgt) {
      double px = 3.0D * Math.cos((double)rotation);
      double py = (double)(hgt % 5.0F);
      double pz = 3.0D * Math.sin((double)rotation);
      TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowstuff", super.lastTickPosX + px, super.lastTickPosY + py, super.lastTickPosZ + pz, 0.0D, 0.0D, 0.0D);
   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      if(super.interact(par1EntityPlayer)) {
         return true;
      } else if(!super.worldObj.isRemote && (super.riddenByEntity == null || super.riddenByEntity == par1EntityPlayer)) {
         par1EntityPlayer.mountEntity(this);
         return true;
      } else {
         return false;
      }
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      if(super.riddenByEntity == null && par1Entity.ridingEntity == null) {
         par1Entity.mountEntity(this);
      }

      return super.attackEntityAsMob(par1Entity);
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      if(!this.canRampage && !this.isTired() && par1DamageSource.isProjectile()) {
         return false;
      } else {
         boolean success = super.attackEntityFrom(par1DamageSource, par2);
         this.canRampage = true;
         return success;
      }
   }

   protected void dropFewItems(boolean flag, int looting) {
      Item fur = this.getDropItem();
      int drops;
      if(fur != null) {
         int bombs = 6 + super.rand.nextInt(6 + looting);

         for(drops = 0; drops < bombs; ++drops) {
            this.dropItem(fur, 1);
         }
      }

      Item var7 = TFItems.iceBomb;
      drops = 6 + super.rand.nextInt(6 + looting);

      for(int d = 0; d < drops; ++d) {
         this.dropItem(var7, 1);
      }

   }

   protected Item getDropItem() {
      return TFItems.alphaFur;
   }

   public void updateRiderPosition() {
      if(super.riddenByEntity != null) {
         Vec3 riderPos = this.getRiderPosition();
         super.riddenByEntity.setPosition(riderPos.xCoord, riderPos.yCoord, riderPos.zCoord);
      }

   }

   public double getMountedYOffset() {
      return 5.75D;
   }

   public Vec3 getRiderPosition() {
      if(super.riddenByEntity != null) {
         float distance = 0.4F;
         double var1 = Math.cos((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         double var3 = Math.sin((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         return Vec3.createVectorHelper(super.posX + var1, super.posY + this.getMountedYOffset() + super.riddenByEntity.getYOffset(), super.posZ + var3);
      } else {
         return Vec3.createVectorHelper(super.posX, super.posY, super.posZ);
      }
   }

   public boolean canRiderInteract() {
      return true;
   }

   public boolean destroyBlocksInAABB(AxisAlignedBB par1AxisAlignedBB) {
      int minX = MathHelper.floor_double(par1AxisAlignedBB.minX);
      int minY = MathHelper.floor_double(par1AxisAlignedBB.minY);
      int minZ = MathHelper.floor_double(par1AxisAlignedBB.minZ);
      int maxX = MathHelper.floor_double(par1AxisAlignedBB.maxX);
      int maxY = MathHelper.floor_double(par1AxisAlignedBB.maxY);
      int maxZ = MathHelper.floor_double(par1AxisAlignedBB.maxZ);
      boolean wasBlocked = false;

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dy = minY; dy <= maxY; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               Block currentID = super.worldObj.getBlock(dx, dy, dz);
               if(currentID != Blocks.air) {
                  int currentMeta = super.worldObj.getBlockMetadata(dx, dy, dz);
                  if(currentID != Blocks.obsidian && currentID != Blocks.end_stone && currentID != Blocks.bedrock) {
                     super.worldObj.setBlock(dx, dy, dz, Blocks.air, 0, 2);
                     super.worldObj.playAuxSFX(2001, dx, dy, dz, Block.getIdFromBlock(currentID) + (currentMeta << 12));
                  } else {
                     wasBlocked = true;
                  }
               }
            }
         }
      }

      return wasBlocked;
   }

   public void makeRandomBlockFall() {
      this.makeRandomBlockFall(30);
   }

   private void makeRandomBlockFall(int range) {
      int bx = MathHelper.floor_double(super.posX) + this.getRNG().nextInt(range) - this.getRNG().nextInt(range);
      int bz = MathHelper.floor_double(super.posZ) + this.getRNG().nextInt(range) - this.getRNG().nextInt(range);
      int by = MathHelper.floor_double(super.posY + (double)this.getEyeHeight());
      this.makeBlockFallAbove(bx, bz, by);
   }

   private void makeBlockFallAbove(int bx, int bz, int by) {
      if(super.worldObj.isAirBlock(bx, by, bz)) {
         for(int i = 1; i < 30; ++i) {
            if(!super.worldObj.isAirBlock(bx, by + i, bz)) {
               this.makeBlockFall(bx, by + i, bz);
               break;
            }
         }
      }

   }

   public void makeNearbyBlockFall() {
      this.makeRandomBlockFall(15);
   }

   public void makeBlockAboveTargetFall() {
      if(this.getAttackTarget() != null) {
         int bx = MathHelper.floor_double(this.getAttackTarget().posX);
         int bz = MathHelper.floor_double(this.getAttackTarget().posZ);
         int by = MathHelper.floor_double(this.getAttackTarget().posY + (double)this.getAttackTarget().getEyeHeight());
         this.makeBlockFallAbove(bx, bz, by);
      }

   }

   private void makeBlockFall(int bx, int by, int bz) {
      Block currentID = super.worldObj.getBlock(bx, by, bz);
      int currentMeta = super.worldObj.getBlockMetadata(bx, by, bz);
      super.worldObj.setBlock(bx, by, bz, Blocks.packed_ice);
      super.worldObj.playAuxSFX(2001, bx, by, bz, Block.getIdFromBlock(currentID) + (currentMeta << 12));
      EntityTFFallingIce ice = new EntityTFFallingIce(super.worldObj, bx, by - 3, bz);
      super.worldObj.spawnEntityInWorld(ice);
   }

   public void attackEntityWithRangedAttack(EntityLivingBase target, float par2) {
      if(!this.canRampage) {
         EntityTFIceBomb ice = new EntityTFIceBomb(super.worldObj, this);
         double d0 = target.posX - super.posX;
         double d1 = target.posY + (double)target.getEyeHeight() - 1.100000023841858D - target.posY;
         double d2 = target.posZ - super.posZ;
         float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
         ice.setThrowableHeading(d0, d1 + (double)f1, d2, 0.75F, 12.0F);
         this.playSound("random.bow", 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
         super.worldObj.spawnEntityInWorld(ice);
      }

   }

   public boolean canDespawn() {
      return false;
   }

   public boolean canRampage() {
      return this.canRampage;
   }

   public void setRampaging(boolean par1) {
      this.getDataWatcher().updateObject(16, Byte.valueOf((byte)(par1?1:0)));
   }

   public boolean isRampaging() {
      return this.getDataWatcher().getWatchableObjectByte(16) == 1;
   }

   public void setTired(boolean par1) {
      this.getDataWatcher().updateObject(17, Byte.valueOf((byte)(par1?1:0)));
      this.canRampage = false;
   }

   public boolean isTired() {
      return this.getDataWatcher().getWatchableObjectByte(17) == 1;
   }

   protected void fall(float par1) {
      super.fall(par1);
      if(this.isRampaging()) {
         this.playSound("random.bow", 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
         int i = MathHelper.floor_double(super.posX);
         int j = MathHelper.floor_double(super.posY - 0.20000000298023224D - (double)super.yOffset);
         int k = MathHelper.floor_double(super.posZ);
         super.worldObj.playAuxSFX(2006, i, j, k, 20);
         super.worldObj.playAuxSFX(2006, i, j, k, 30);
         if(!super.worldObj.isRemote) {
            this.hitNearbyEntities();
         }
      }

   }

   private void hitNearbyEntities() {
      ArrayList nearby = new ArrayList(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.expand(5.0D, 0.0D, 5.0D)));
      Iterator var2 = nearby.iterator();

      while(var2.hasNext()) {
         Entity entity = (Entity)var2.next();
         if(entity instanceof EntityLivingBase) {
            boolean hit = entity.attackEntityFrom(DamageSource.causeMobDamage(this), 5.0F);
            if(hit) {
               entity.motionY += 0.4000000059604645D;
            }
         }
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightProgressYeti);
      }

      if(!super.worldObj.isRemote) {
         int dx = MathHelper.floor_double(super.posX);
         int dy = MathHelper.floor_double(super.posY);
         int dz = MathHelper.floor_double(super.posZ);
         if(super.worldObj.provider instanceof WorldProviderTwilightForest) {
            ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
            TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(dx, dz, super.worldObj);
            if(nearbyFeature == TFFeature.yetiCave) {
               chunkProvider.setStructureConquered(dx, dy, dz, true);
            }
         }
      }

   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      ChunkCoordinates home = this.getHomePosition();
      nbttagcompound.setTag("Home", this.newDoubleNBTList(new double[]{(double)home.posX, (double)home.posY, (double)home.posZ}));
      nbttagcompound.setBoolean("HasHome", this.hasHome());
      super.writeEntityToNBT(nbttagcompound);
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      if(nbttagcompound.hasKey("Home", 9)) {
         NBTTagList nbttaglist = nbttagcompound.getTagList("Home", 6);
         int hx = (int)nbttaglist.func_150309_d(0);
         int hy = (int)nbttaglist.func_150309_d(1);
         int hz = (int)nbttaglist.func_150309_d(2);
         this.setHomeArea(hx, hy, hz, 30);
      }

      if(!nbttagcompound.getBoolean("HasHome")) {
         this.detachHome();
      }

   }
}

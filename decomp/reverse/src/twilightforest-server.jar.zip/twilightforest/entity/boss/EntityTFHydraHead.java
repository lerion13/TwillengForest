package twilightforest.entity.boss;

import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFHydra;
import twilightforest.entity.boss.EntityTFHydraPart;

public class EntityTFHydraHead extends EntityTFHydraPart {

   public EntityTFHydraHead(World world) {
      super(world);
      super.ignoreFrustumCheck = true;
   }

   public EntityTFHydraHead(EntityTFHydra hydra, String s, float f, float f1) {
      super(hydra, s, f, f1);
   }

   public int getVerticalFaceSpeed() {
      return 500;
   }

   protected void onDeathUpdate() {
      ++super.deathTime;
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(18, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(19, Byte.valueOf((byte)0));
   }

   public float getMouthOpen() {
      return (float)(super.dataWatcher.getWatchableObjectByte(18) & 255) / 255.0F;
   }

   public int getState() {
      return super.dataWatcher.getWatchableObjectByte(19) & 255;
   }

   public void setMouthOpen(float openness) {
      if(openness < 0.0F) {
         openness = 0.0F;
      }

      if(openness > 1.0F) {
         openness = 1.0F;
      }

      int openByte = Math.round(openness * 255.0F);
      openByte &= 255;
      super.dataWatcher.updateObject(18, Byte.valueOf((byte)openByte));
   }

   public void setState(int state) {
      state &= 255;
      super.dataWatcher.updateObject(19, Byte.valueOf((byte)state));
   }
}

package twilightforest.entity.boss;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFMinotaur;
import twilightforest.item.TFItems;

public class EntityTFMinoshroom extends EntityTFMinotaur {

   public EntityTFMinoshroom(World par1World) {
      super(par1World);
      this.setSize(1.49F, 2.9F);
      super.experienceValue = 100;
      this.setCurrentItemOrArmor(0, new ItemStack(TFItems.minotaurAxe));
      super.equipmentDropChances[0] = 0.0F;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(120.0D);
   }

   protected Item getDropItem() {
      return TFItems.meefStroganoff;
   }

   protected void dropFewItems(boolean par1, int par2) {
      int numDrops = super.rand.nextInt(4) + 2 + super.rand.nextInt(1 + par2);

      for(int i = 0; i < numDrops; ++i) {
         this.dropItem(TFItems.meefStroganoff, 1);
      }

   }

   protected boolean canDespawn() {
      return false;
   }

   protected void dropEquipment(boolean par1, int par2) {
      super.dropEquipment(par1, par2);
      this.entityDropItem(new ItemStack(TFItems.minotaurAxe), 0.0F);
   }
}

package twilightforest.entity.boss;

import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.boss.EntityTFLich;

public class EntityTFLichMinion extends EntityZombie {

   EntityTFLich master;


   public EntityTFLichMinion(World par1World) {
      super(par1World);
      this.master = null;
   }

   public EntityTFLichMinion(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   public EntityTFLichMinion(World par1World, EntityTFLich entityTFLich) {
      super(par1World);
      this.master = entityTFLich;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      EntityLivingBase prevTarget = this.getAttackTarget();
      if(super.attackEntityFrom(par1DamageSource, par2)) {
         if(par1DamageSource.getEntity() instanceof EntityTFLich) {
            this.setAttackTarget(prevTarget);
            this.setRevengeTarget(prevTarget);
            this.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 200, 4));
            this.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 200, 1));
         }

         return true;
      } else {
         return false;
      }
   }

   public void onLivingUpdate() {
      if(this.master == null) {
         this.findNewMaster();
      }

      if(this.master == null || this.master.isDead) {
         this.setHealth(0.0F);
      }

      super.onLivingUpdate();
   }

   private void findNewMaster() {
      List nearbyLiches = super.worldObj.getEntitiesWithinAABB(EntityTFLich.class, AxisAlignedBB.getBoundingBox(super.posX, super.posY, super.posZ, super.posX + 1.0D, super.posY + 1.0D, super.posZ + 1.0D).expand(32.0D, 16.0D, 32.0D));
      Iterator var2 = nearbyLiches.iterator();

      while(var2.hasNext()) {
         EntityTFLich nearbyLich = (EntityTFLich)var2.next();
         if(!nearbyLich.isShadowClone() && nearbyLich.wantsNewMinion(this)) {
            this.master = nearbyLich;
            this.master.makeBlackMagicTrail(super.posX, super.posY + (double)this.getEyeHeight(), super.posZ, this.master.posX, this.master.posY + (double)this.master.getEyeHeight(), this.master.posZ);
            this.setAttackTarget(this.master.getAttackTarget());
            break;
         }
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   protected void addRandomArmor() {
      float[] equipChances = new float[]{0.0F, 0.25F, 0.75F, 1.0F};
      if(super.rand.nextFloat() < equipChances[2]) {
         int var1 = super.rand.nextInt(2);
         float var2 = super.worldObj.difficultySetting == EnumDifficulty.HARD?0.1F:0.25F;
         if(super.rand.nextFloat() < 0.07F) {
            ++var1;
         }

         if(super.rand.nextFloat() < 0.07F) {
            ++var1;
         }

         if(super.rand.nextFloat() < 0.07F) {
            ++var1;
         }

         for(int var3 = 3; var3 >= 0; --var3) {
            ItemStack var4 = this.func_130225_q(var3);
            if(var3 < 3 && super.rand.nextFloat() < var2) {
               break;
            }

            if(var4 == null) {
               Item var5 = getArmorItemForSlot(var3 + 1, var1);
               if(var5 != null) {
                  this.setCurrentItemOrArmor(var3 + 1, new ItemStack(var5));
               }
            }
         }
      }

   }
}

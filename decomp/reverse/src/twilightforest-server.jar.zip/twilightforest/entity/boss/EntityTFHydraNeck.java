package twilightforest.entity.boss;

import twilightforest.entity.boss.EntityTFHydra;
import twilightforest.entity.boss.EntityTFHydraPart;

public class EntityTFHydraNeck extends EntityTFHydraPart {

   public EntityTFHydraNeck(EntityTFHydra hydra, String s, float f, float f1) {
      super(hydra, s, f, f1);
   }
}

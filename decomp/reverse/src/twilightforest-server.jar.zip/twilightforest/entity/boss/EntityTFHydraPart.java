package twilightforest.entity.boss;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.entity.boss.EntityTFHydra;

public class EntityTFHydraPart extends EntityLiving {

   public EntityTFHydra hydraObj;


   public EntityTFHydraPart(World world) {
      super(world);
      super.isImmuneToFire = true;
   }

   public EntityTFHydraPart(EntityTFHydra hydra, String s, float f, float f1) {
      super(hydra.worldObj);
      this.setSize(f, f1);
      this.hydraObj = hydra;
      this.setPartName(s);
      super.isImmuneToFire = true;
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, "");
   }

   public String getPartName() {
      return super.dataWatcher.getWatchableObjectString(17);
   }

   public void setPartName(String name) {
      super.dataWatcher.updateObject(17, name);
   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      super.writeEntityToNBT(nbttagcompound);
      nbttagcompound.setString("PartName", this.getPartName());
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      this.setPartName(nbttagcompound.getString("PartName"));
   }

   public void onUpdate() {
      if(this.hydraObj != null && this.hydraObj.deathTime > 190) {
         this.setDead();
      }

      if(this.hydraObj == null && super.ticksExisted > 1200) {
         this.setDead();
      }

      super.onEntityUpdate();
      super.lastTickPosX = super.posX;
      super.lastTickPosY = super.posY;
      super.lastTickPosZ = super.posZ;
      if(super.newPosRotationIncrements > 0) {
         double var1 = super.posX + (super.newPosX - super.posX) / (double)super.newPosRotationIncrements;
         double var3 = super.posY + (super.newPosY - super.posY) / (double)super.newPosRotationIncrements;
         double var5 = super.posZ + (super.newPosZ - super.posZ) / (double)super.newPosRotationIncrements;
         double var7 = MathHelper.wrapAngleTo180_double(super.newRotationYaw - (double)super.rotationYaw);
         super.rotationYaw = (float)((double)super.rotationYaw + var7 / (double)super.newPosRotationIncrements);
         super.rotationPitch = (float)((double)super.rotationPitch + (super.newRotationPitch - (double)super.rotationPitch) / (double)super.newPosRotationIncrements);
         --super.newPosRotationIncrements;
         this.setPosition(var1, var3, var5);
         this.setRotation(super.rotationYaw, super.rotationPitch);
      }

      super.rotationYawHead = super.rotationYaw;

      for(super.prevRotationYawHead = super.prevRotationYaw; super.rotationYaw - super.prevRotationYaw < -180.0F; super.prevRotationYaw -= 360.0F) {
         ;
      }

      while(super.rotationYaw - super.prevRotationYaw >= 180.0F) {
         super.prevRotationYaw += 360.0F;
      }

      while(super.renderYawOffset - super.prevRenderYawOffset < -180.0F) {
         super.prevRenderYawOffset -= 360.0F;
      }

      while(super.renderYawOffset - super.prevRenderYawOffset >= 180.0F) {
         super.prevRenderYawOffset += 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch < -180.0F) {
         super.prevRotationPitch -= 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch >= 180.0F) {
         super.prevRotationPitch += 360.0F;
      }

      while(super.rotationYawHead - super.prevRotationYawHead < -180.0F) {
         super.prevRotationYawHead -= 360.0F;
      }

      while(super.rotationYawHead - super.prevRotationYawHead >= 180.0F) {
         super.prevRotationYawHead += 360.0F;
      }

   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1000.0D);
   }

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      return this.hydraObj != null?this.hydraObj.attackEntityFromPart(this, damagesource, i):false;
   }

   public boolean isEntityEqual(Entity entity) {
      return this == entity || this.hydraObj == entity;
   }

   protected void setRotation(float par1, float par2) {
      super.rotationYaw = par1 % 360.0F;
      super.rotationPitch = par2 % 360.0F;
   }
}

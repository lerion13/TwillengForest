package twilightforest.entity.boss;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.boss.IBossDisplayData;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.block.TFBlocks;
import twilightforest.entity.boss.EntityTFNagaSegment;
import twilightforest.item.TFItems;
import twilightforest.world.ChunkProviderTwilightForest;
import twilightforest.world.TFWorldChunkManager;
import twilightforest.world.WorldProviderTwilightForest;

public class EntityTFNaga extends EntityMob implements IMob, IBossDisplayData, IEntityMultiPart {

   private static int TICKS_BEFORE_HEALING = 600;
   private static int MAX_SEGMENTS = 12;
   int currentSegments = 0;
   float segmentHealth;
   int LEASH_X = 46;
   int LEASH_Y = 7;
   int LEASH_Z = 46;
   EntityTFNagaSegment[] body;
   protected PathEntity field_70786_d;
   protected Entity targetEntity;
   int circleCount;
   int intimidateTimer;
   int crumblePlayerTimer;
   int chargeCount;
   boolean clockwise;
   public int ticksSinceDamaged = 0;


   public EntityTFNaga(World world) {
      super(world);
      this.setSize(1.75F, 3.0F);
      super.stepHeight = 2.0F;
      this.setHealth(this.getMaxHealth());
      this.segmentHealth = this.getMaxHealth() / 10.0F;
      this.setSegmentsPerHealth();
      super.experienceValue = 217;
      super.ignoreFrustumCheck = true;
      this.circleCount = 15;
      this.body = new EntityTFNagaSegment[MAX_SEGMENTS];

      for(int i = 0; i < this.body.length; ++i) {
         this.body[i] = new EntityTFNagaSegment(this, i);
         world.spawnEntityInWorld(this.body[i]);
      }

      this.goNormal();
   }

   protected void entityInit() {
      super.entityInit();
   }

   protected boolean isAIEnabled() {
      return true;
   }

   public float getMaxHealthPerDifficulty() {
      return super.worldObj != null?(super.worldObj.difficultySetting == EnumDifficulty.EASY?120.0F:(super.worldObj.difficultySetting == EnumDifficulty.NORMAL?200.0F:(super.worldObj.difficultySetting == EnumDifficulty.HARD?250.0F:200.0F))):200.0F;
   }

   protected boolean canDespawn() {
      return false;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue((double)this.getMaxHealthPerDifficulty());
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(2.0D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(6.0D);
   }

   protected int setSegmentsPerHealth() {
      int oldSegments = this.currentSegments;
      int newSegments = (int)(this.getHealth() / this.segmentHealth + (float)(this.getHealth() > 0.0F?2:0));
      if(newSegments < 0) {
         newSegments = 0;
      }

      if(newSegments > MAX_SEGMENTS) {
         newSegments = MAX_SEGMENTS;
      }

      if(newSegments != oldSegments) {
         if(newSegments < oldSegments) {
            for(int i = newSegments; i < oldSegments; ++i) {
               if(this.body != null && this.body[i] != null) {
                  this.body[i].selfDestruct();
               }
            }
         } else {
            this.spawnBodySegments();
         }
      }

      this.currentSegments = newSegments;
      this.setMovementFactorPerSegments();
      return this.currentSegments;
   }

   protected void setMovementFactorPerSegments() {
      float movementFactor = 0.6F - (float)this.currentSegments / 12.0F * 0.2F;
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue((double)movementFactor);
   }

   public boolean canTriggerWalking() {
      return false;
   }

   public boolean handleLavaMovement() {
      return false;
   }

   public void onUpdate() {
      this.despawnIfInvalid();
      int i;
      if(super.deathTime > 0) {
         for(i = 0; i < 5; ++i) {
            double d = super.rand.nextGaussian() * 0.02D;
            double d1 = super.rand.nextGaussian() * 0.02D;
            double d2 = super.rand.nextGaussian() * 0.02D;
            String explosionType = super.rand.nextBoolean()?"hugeexplosion":"explode";
            super.worldObj.spawnParticle(explosionType, super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, d, d1, d2);
         }
      }

      ++this.ticksSinceDamaged;
      if(!super.worldObj.isRemote && this.ticksSinceDamaged > TICKS_BEFORE_HEALING && this.ticksSinceDamaged % 20 == 0) {
         this.heal(1.0F);
      }

      this.setSegmentsPerHealth();
      super.onUpdate();
      this.moveSegments();

      for(i = 0; i < this.body.length; ++i) {
         if(!this.body[i].addedToChunk && !super.worldObj.isRemote) {
            super.worldObj.spawnEntityInWorld(this.body[i]);
         }
      }

   }

   protected void updateAITasks() {
      super.updateAITasks();
      if(super.isCollidedHorizontally && this.hasTarget()) {
         this.breakNearbyBlocks();
      }

      if(this.targetEntity != null && !this.isEntityWithinHomeArea(this.targetEntity)) {
         this.targetEntity = null;
      }

      if(this.targetEntity == null) {
         this.targetEntity = this.findTarget();
         if(this.targetEntity != null) {
            this.acquireNewPath();
         }
      } else if(!this.targetEntity.isEntityAlive()) {
         this.targetEntity = null;
      } else {
         float inWater = this.targetEntity.getDistanceToEntity(this);
         if(inWater > 80.0F) {
            this.targetEntity = null;
         } else if(this.canEntityBeSeen(this.targetEntity)) {
            this.attackEntity(this.targetEntity, inWater);
         }
      }

      if(!this.hasPath()) {
         this.acquireNewPath();
      }

      boolean inWater1 = this.isInWater();
      boolean inLava = this.handleLavaMovement();
      Vec3 vec3d = this.hasPath()?this.field_70786_d.getPosition(this):null;
      double d1 = (double)(super.width * 4.0F);

      while(vec3d != null && vec3d.squareDistanceTo(super.posX, vec3d.yCoord, super.posZ) < d1 * d1) {
         this.field_70786_d.incrementPathIndex();
         if(this.field_70786_d.isFinished()) {
            vec3d = null;
            this.field_70786_d = null;
         } else {
            vec3d = this.field_70786_d.getPosition(this);
         }
      }

      super.isJumping = false;
      if(vec3d != null) {
         d1 = vec3d.xCoord - super.posX;
         double d2 = vec3d.zCoord - super.posZ;
         double dist = (double)MathHelper.sqrt_double(d1 * d1 + d2 * d2);
         int i = MathHelper.floor_double(super.boundingBox.minY + 0.5D);
         double d3 = vec3d.yCoord - (double)i;
         float f2 = (float)(Math.atan2(d2, d1) * 180.0D / 3.1415927410125732D) - 90.0F;
         float f3 = f2 - super.rotationYaw;
         super.moveForward = this.getMoveSpeed();
         this.setAIMoveSpeed(0.5F);
         if(dist > 4.0D && this.chargeCount == 0) {
            super.moveStrafing = MathHelper.cos((float)super.ticksExisted * 0.3F) * this.getMoveSpeed() * 0.6F;
         }

         while(f3 < -180.0F) {
            f3 += 360.0F;
         }

         while(f3 >= 180.0F) {
            f3 -= 360.0F;
         }

         if(f3 > 30.0F) {
            f3 = 30.0F;
         }

         if(f3 < -30.0F) {
            f3 = -30.0F;
         }

         super.rotationYaw += f3;
         if(d3 > 0.6D) {
            super.isJumping = true;
         }
      }

      if(this.intimidateTimer > 0 && this.hasTarget()) {
         this.faceEntity(this.targetEntity, 30.0F, 30.0F);
         super.moveForward = 0.1F;
      }

      if(this.intimidateTimer > 0 && this.hasTarget()) {
         this.faceEntity(this.targetEntity, 30.0F, 30.0F);
         super.moveForward = 0.1F;
      }

      if(super.rand.nextFloat() < 0.8F && (inWater1 || inLava)) {
         super.isJumping = true;
      }

   }

   private float getMoveSpeed() {
      return 0.5F;
   }

   private void setMoveSpeed(float f) {
      this.setAIMoveSpeed(f);
   }

   protected void breakNearbyBlocks() {
      int minx = MathHelper.floor_double(super.boundingBox.minX - 0.5D);
      int miny = MathHelper.floor_double(super.boundingBox.minY + 1.01D);
      int minz = MathHelper.floor_double(super.boundingBox.minZ - 0.5D);
      int maxx = MathHelper.floor_double(super.boundingBox.maxX + 0.5D);
      int maxy = MathHelper.floor_double(super.boundingBox.maxY + 0.001D);
      int maxz = MathHelper.floor_double(super.boundingBox.maxZ + 0.5D);
      if(super.worldObj.checkChunksExist(minx, miny, minz, maxx, maxy, maxz)) {
         for(int dx = minx; dx <= maxx; ++dx) {
            for(int dy = miny; dy <= maxy; ++dy) {
               for(int dz = minz; dz <= maxz; ++dz) {
                  Block i5 = super.worldObj.getBlock(dx, dy, dz);
                  if(i5 != Blocks.air) {
                     this.breakBlock(dx, dy, dz);
                  }
               }
            }
         }
      }

   }

   protected String getLivingSound() {
      return super.rand.nextInt(3) != 0?"TwilightForest:mob.naga.hiss":"TwilightForest:mob.naga.rattle";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.naga.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.naga.hurt";
   }

   protected void acquireNewPath() {
      if(!this.hasTarget()) {
         this.wanderRandomly();
      } else if(this.intimidateTimer > 0) {
         this.field_70786_d = null;
         --this.intimidateTimer;
         if(this.intimidateTimer == 0) {
            this.clockwise = !this.clockwise;
            if(this.targetEntity.boundingBox.minY > super.boundingBox.maxY) {
               this.doCrumblePlayer();
            } else {
               this.doCharge();
            }
         }

      } else {
         if(this.crumblePlayerTimer > 0) {
            this.field_70786_d = null;
            --this.crumblePlayerTimer;
            this.crumbleBelowTarget(2);
            this.crumbleBelowTarget(3);
            if(this.crumblePlayerTimer == 0) {
               this.doCharge();
            }
         }

         if(this.chargeCount > 0) {
            --this.chargeCount;
            Vec3 radius = this.findCirclePoint(this.targetEntity, 14.0D, 3.141592653589793D);
            this.field_70786_d = super.worldObj.getEntityPathToXYZ(this, MathHelper.floor_double(radius.xCoord), MathHelper.floor_double(radius.yCoord), MathHelper.floor_double(radius.zCoord), 40.0F, true, true, true, true);
            if(this.chargeCount == 0) {
               this.doCircle();
            }
         }

         if(this.circleCount > 0) {
            --this.circleCount;
            double var6 = this.circleCount % 2 == 0?12.0D:14.0D;
            double rotation = 1.0D;
            if(this.circleCount > 1 && this.circleCount < 3) {
               var6 = 16.0D;
            }

            if(this.circleCount == 1) {
               rotation = 0.1D;
            }

            Vec3 tpoint = this.findCirclePoint(this.targetEntity, var6, rotation);
            this.field_70786_d = super.worldObj.getEntityPathToXYZ(this, (int)tpoint.xCoord, (int)tpoint.yCoord, (int)tpoint.zCoord, 40.0F, true, true, true, true);
            if(this.circleCount == 0) {
               this.doIntimidate();
            }
         }

      }
   }

   protected void crumbleBelowTarget(int range) {
      int floor = (int)super.boundingBox.minY;
      int targetY = (int)this.targetEntity.boundingBox.minY;
      if(targetY > floor) {
         int dx = (int)this.targetEntity.posX + super.rand.nextInt(range) - super.rand.nextInt(range);
         int dz = (int)this.targetEntity.posZ + super.rand.nextInt(range) - super.rand.nextInt(range);
         int dy = targetY - super.rand.nextInt(range) + super.rand.nextInt(range > 1?range - 1:range);
         if(dy <= floor) {
            dy = targetY;
         }

         if(super.worldObj.getBlock(dx, dy, dz) != Blocks.air) {
            this.breakBlock(dx, dy, dz);

            for(int k = 0; k < 20; ++k) {
               double d = super.rand.nextGaussian() * 0.02D;
               double d1 = super.rand.nextGaussian() * 0.02D;
               double d2 = super.rand.nextGaussian() * 0.02D;
               super.worldObj.spawnParticle("crit", super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, d, d1, d2);
            }
         }
      }

   }

   protected void breakBlock(int dx, int dy, int dz) {
      Block whatsThere = super.worldObj.getBlock(dx, dy, dz);
      int whatsMeta = super.worldObj.getBlockMetadata(dx, dy, dz);
      if(whatsThere != Blocks.air) {
         whatsThere.dropBlockAsItem(super.worldObj, dx, dy, dz, whatsMeta, 0);
         super.worldObj.setBlock(dx, dy, dz, Blocks.air, 0, 2);
         super.worldObj.playAuxSFX(2001, dx, dy, dz, Block.getIdFromBlock(whatsThere) + (whatsMeta << 12));
      }

   }

   protected void doCircle() {
      this.circleCount += 10 + super.rand.nextInt(10);
      this.goNormal();
   }

   protected void doCrumblePlayer() {
      this.crumblePlayerTimer = 20 + super.rand.nextInt(20);
      this.goSlow();
   }

   protected void doCharge() {
      this.chargeCount = 4;
      this.goFast();
   }

   protected void doIntimidate() {
      this.intimidateTimer += 15 + super.rand.nextInt(10);
      this.goSlow();
   }

   protected void goSlow() {
      super.moveStrafing = 0.0F;
      this.setMoveSpeed(0.1F);
      this.field_70786_d = null;
   }

   protected void goNormal() {
      this.setMoveSpeed(0.6F);
   }

   protected void goFast() {
      this.setMoveSpeed(1.0F);
   }

   public boolean canBePushed() {
      return false;
   }

   protected Vec3 findCirclePoint(Entity toCircle, double radius, double rotation) {
      double vecx = super.posX - toCircle.posX;
      double vecz = super.posZ - toCircle.posZ;
      float rangle = (float)Math.atan2(vecz, vecx);
      rangle = (float)((double)rangle + (this.clockwise?rotation:-rotation));
      double dx = (double)MathHelper.cos(rangle) * radius;
      double dz = (double)MathHelper.sin(rangle) * radius;
      double dy = Math.min(super.boundingBox.minY, toCircle.posY);
      return Vec3.createVectorHelper(toCircle.posX + dx, dy, toCircle.posZ + dz);
   }

   public boolean hasTarget() {
      return this.targetEntity != null;
   }

   protected Entity findTarget() {
      EntityPlayer entityplayer = super.worldObj.getClosestVulnerablePlayerToEntity(this, 32.0D);
      return entityplayer != null && this.canEntityBeSeen(entityplayer) && this.isEntityWithinHomeArea(entityplayer)?entityplayer:null;
   }

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      if(damagesource.getSourceOfDamage() != null && !this.isEntityWithinHomeArea(damagesource.getSourceOfDamage())) {
         return false;
      } else if(damagesource.getEntity() != null && !this.isEntityWithinHomeArea(damagesource.getEntity())) {
         return false;
      } else if(super.attackEntityFrom(damagesource, i)) {
         this.setSegmentsPerHealth();
         Entity entity = damagesource.getEntity();
         if(entity != this) {
            this.targetEntity = entity;
         }

         this.ticksSinceDamaged = 0;
         return true;
      } else {
         return false;
      }
   }

   protected void attackEntity(Entity toAttack, float f) {
      if(super.attackTime <= 0 && f < 4.0F && toAttack.boundingBox.maxY > super.boundingBox.minY - 2.5D && toAttack.boundingBox.minY < super.boundingBox.maxY + 2.5D) {
         super.attackTime = 20;
         this.attackEntityAsMob(toAttack);
         if((double)this.getMoveSpeed() > 0.8D) {
            toAttack.addVelocity((double)(-MathHelper.sin(super.rotationYaw * 3.141593F / 180.0F) * 1.0F), 0.1D, (double)(MathHelper.cos(super.rotationYaw * 3.141593F / 180.0F) * 1.0F));
         }
      }

   }

   protected void wanderRandomly() {
      this.goNormal();
      boolean flag = false;
      int tx = -1;
      int ty = -1;
      int tz = -1;
      float worstweight = -99999.0F;

      for(int l = 0; l < 10; ++l) {
         int dx = MathHelper.floor_double(super.posX + (double)super.rand.nextInt(21) - 6.0D);
         int dy = MathHelper.floor_double(super.posY + (double)super.rand.nextInt(7) - 3.0D);
         int dz = MathHelper.floor_double(super.posZ + (double)super.rand.nextInt(21) - 6.0D);
         if(!this.isWithinHomeDistance(dx, dy, dz)) {
            dx = this.getHomePosition().posX + super.rand.nextInt(21) - super.rand.nextInt(21);
            dy = this.getHomePosition().posY + super.rand.nextInt(7) - super.rand.nextInt(7);
            dz = this.getHomePosition().posZ + super.rand.nextInt(21) - super.rand.nextInt(21);
         }

         float weight = this.getBlockPathWeight(dx, dy, dz);
         if(weight > worstweight) {
            worstweight = weight;
            tx = dx;
            ty = dy;
            tz = dz;
            flag = true;
         }
      }

      if(flag) {
         this.field_70786_d = super.worldObj.getEntityPathToXYZ(this, tx, ty, tz, 80.0F, true, true, true, true);
      }

   }

   public float getBlockPathWeight(int i, int j, int k) {
      return !this.isWithinHomeDistance(i, j, k)?Float.MIN_VALUE:0.0F;
   }

   public boolean hasPath() {
      return this.field_70786_d != null;
   }

   protected Item getDropItem() {
      return TFItems.nagaScale;
   }

   protected void dropFewItems(boolean flag, int z) {
      Item i = this.getDropItem();
      if(i != null) {
         int j = 6 + super.rand.nextInt(6);

         for(int k = 0; k < j; ++k) {
            this.dropItem(i, 1);
         }
      }

      this.entityDropItem(new ItemStack(TFItems.trophy, 1, 1), 0.0F);
   }

   protected void despawnIfInvalid() {
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.despawnMe();
      }

   }

   protected void despawnMe() {
      if(this.isLeashed()) {
         ChunkCoordinates home = this.getHomePosition();
         super.worldObj.setBlock(home.posX, home.posY, home.posZ, TFBlocks.bossSpawner, 0, 2);
      }

      this.setDead();
   }

   public boolean isLeashed() {
      return this.getMaximumHomeDistance() > -1.0F;
   }

   public boolean isWithinHomeDistance(int x, int y, int z) {
      if(this.getMaximumHomeDistance() == -1.0F) {
         return true;
      } else {
         int distX = Math.abs(this.getHomePosition().posX - x);
         int distY = Math.abs(this.getHomePosition().posY - y);
         int distZ = Math.abs(this.getHomePosition().posZ - z);
         return distX <= this.LEASH_X && distY <= this.LEASH_Y && distZ <= this.LEASH_Z;
      }
   }

   public boolean isEntityWithinHomeArea(Entity entity) {
      return this.isWithinHomeDistance(MathHelper.floor_double(entity.posX), MathHelper.floor_double(entity.posY), MathHelper.floor_double(entity.posZ));
   }

   protected void spawnBodySegments() {
      if(!super.worldObj.isRemote) {
         if(this.body == null) {
            this.body = new EntityTFNagaSegment[MAX_SEGMENTS];
         }

         for(int i = 0; i < this.currentSegments; ++i) {
            if(this.body[i] == null || this.body[i].isDead) {
               this.body[i] = new EntityTFNagaSegment(this, i);
               this.body[i].setLocationAndAngles(super.posX + 0.1D * (double)i, super.posY + 0.5D, super.posZ + 0.1D * (double)i, super.rand.nextFloat() * 360.0F, 0.0F);
               super.worldObj.spawnEntityInWorld(this.body[i]);
            }
         }
      }

   }

   protected void moveSegments() {
      for(int i = 0; i < this.currentSegments; ++i) {
         Object leader;
         if(i == 0) {
            leader = this;
         } else {
            leader = this.body[i - 1];
         }

         double followX = ((Entity)leader).posX;
         double followY = ((Entity)leader).posY;
         double followZ = ((Entity)leader).posZ;
         float angle = (((Entity)leader).rotationYaw + 180.0F) * 3.141593F / 180.0F;
         double straightenForce = 0.05D + 1.0D / (double)((float)(i + 1)) * 0.5D;
         double idealX = (double)(-MathHelper.sin(angle)) * straightenForce;
         double idealZ = (double)MathHelper.cos(angle) * straightenForce;
         Vec3 diff = Vec3.createVectorHelper(this.body[i].posX - followX, this.body[i].posY - followY, this.body[i].posZ - followZ);
         diff = diff.normalize();
         diff = diff.addVector(idealX, 0.0D, idealZ);
         diff = diff.normalize();
         double f = 2.0D;
         double destX = followX + f * diff.xCoord;
         double destY = followY + f * diff.yCoord;
         double destZ = followZ + f * diff.zCoord;
         this.body[i].setPosition(destX, destY, destZ);
         this.body[i].motionX = f * diff.xCoord;
         this.body[i].motionY = f * diff.yCoord;
         this.body[i].motionZ = f * diff.zCoord;
         double distance = (double)MathHelper.sqrt_double(diff.xCoord * diff.xCoord + diff.zCoord * diff.zCoord);
         if(i == 0) {
            diff.yCoord -= 0.15D;
         }

         this.body[i].setRotation((float)(Math.atan2(diff.zCoord, diff.xCoord) * 180.0D / 3.141592653589793D) + 90.0F, -((float)(Math.atan2(diff.yCoord, distance) * 180.0D / 3.141592653589793D)));
      }

   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      ChunkCoordinates home = this.getHomePosition();
      nbttagcompound.setTag("Home", this.newDoubleNBTList(new double[]{(double)home.posX, (double)home.posY, (double)home.posZ}));
      nbttagcompound.setBoolean("HasHome", this.hasHome());
      super.writeEntityToNBT(nbttagcompound);
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      if(nbttagcompound.hasKey("Home", 9)) {
         NBTTagList nbttaglist = nbttagcompound.getTagList("Home", 6);
         int hx = (int)nbttaglist.func_150309_d(0);
         int hy = (int)nbttaglist.func_150309_d(1);
         int hz = (int)nbttaglist.func_150309_d(2);
         this.setHomeArea(hx, hy, hz, 20);
      }

      if(!nbttagcompound.getBoolean("HasHome")) {
         this.detachHome();
      }

      this.setSegmentsPerHealth();
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightKillNaga);
      }

      if(!super.worldObj.isRemote && super.worldObj.provider instanceof WorldProviderTwilightForest) {
         int dx = MathHelper.floor_double(super.posX);
         int dy = MathHelper.floor_double(super.posY);
         int dz = MathHelper.floor_double(super.posZ);
         ChunkProviderTwilightForest chunkProvider = ((WorldProviderTwilightForest)super.worldObj.provider).getChunkProvider();
         TFFeature nearbyFeature = ((TFWorldChunkManager)super.worldObj.provider.worldChunkMgr).getFeatureAt(dx, dz, super.worldObj);
         if(nearbyFeature == TFFeature.nagaCourtyard) {
            chunkProvider.setStructureConquered(dx, dy, dz, true);
         }
      }

   }

   public World func_82194_d() {
      return super.worldObj;
   }

   public boolean attackEntityFromPart(EntityDragonPart entitydragonpart, DamageSource damagesource, float i) {
      return false;
   }

   public Entity[] getParts() {
      return this.body;
   }

   public float getMaximumHomeDistance() {
      return this.func_110174_bM();
   }

}

package twilightforest.entity.boss;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.entity.boss.EntityTFYetiAlpha;

public class EntityTFFallingIce extends Entity {

   private static final int HANG_TIME = 100;
   private int fallTime;
   private float hurtAmount;
   private int hurtMax;


   public EntityTFFallingIce(World par1World) {
      super(par1World);
      this.setSize(2.98F, 2.98F);
      this.hurtAmount = 10.0F;
      this.hurtMax = 30;
   }

   public EntityTFFallingIce(World par1World, int x, int y, int z) {
      this(par1World);
      super.preventEntitySpawning = true;
      this.setPosition((double)x, (double)y, (double)z);
      super.motionX = 0.0D;
      super.motionY = 0.0D;
      super.motionZ = 0.0D;
      super.prevPosX = (double)x;
      super.prevPosY = (double)y;
      super.prevPosZ = (double)z;
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   protected void entityInit() {}

   public boolean canBeCollidedWith() {
      return !super.isDead;
   }

   public void onUpdate() {
      super.prevPosX = super.posX;
      super.prevPosY = super.posY;
      super.prevPosZ = super.posZ;
      ++this.fallTime;
      if(this.fallTime > 100) {
         super.motionY -= 0.03999999910593033D;
      }

      this.moveEntity(super.motionX, super.motionY, super.motionZ);
      super.motionX *= 0.9800000190734863D;
      super.motionY *= 0.9800000190734863D;
      super.motionZ *= 0.9800000190734863D;
      if(!super.worldObj.isRemote && super.onGround) {
         super.motionX *= 0.699999988079071D;
         super.motionZ *= 0.699999988079071D;
         super.motionY *= -0.5D;
         this.setDead();
      }

      if(!super.worldObj.isRemote) {
         ArrayList nearby = new ArrayList(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox));
         Iterator var2 = nearby.iterator();

         while(var2.hasNext()) {
            Entity entity = (Entity)var2.next();
            if(entity instanceof EntityTFFallingIce) {
               EntityTFFallingIce otherIce = (EntityTFFallingIce)entity;
               if(otherIce.getFallTime() < this.fallTime) {
                  otherIce.setDead();
               }
            }
         }

         this.destroyIceInAABB(super.boundingBox.expand(0.5D, 0.0D, 0.5D));
      }

      this.makeTrail();
   }

   public void makeTrail() {
      for(int i = 0; i < 2; ++i) {
         double dx = super.posX + (double)(2.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         double dy = super.posY - 3.0D + (double)(3.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         double dz = super.posZ + (double)(2.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowwarning", dx, dy, dz, 0.0D, -1.0D, 0.0D);
      }

   }

   protected void fall(float par1) {
      int distance = MathHelper.ceiling_float_int(par1 - 1.0F);
      if(distance > 0) {
         ArrayList i = new ArrayList(super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.expand(2.0D, 0.0D, 2.0D)));
         DamageSource dx = DamageSource.fallingBlock;
         Iterator var5 = i.iterator();

         while(var5.hasNext()) {
            Entity dy = (Entity)var5.next();
            if(!(dy instanceof EntityTFYetiAlpha)) {
               dy.attackEntityFrom(dx, (float)Math.min(MathHelper.floor_float((float)distance * this.hurtAmount), this.hurtMax));
            }
         }
      }

      for(int var10 = 0; var10 < 200; ++var10) {
         double var11 = super.posX + (double)(3.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         double var12 = super.posY + 2.0D + (double)(3.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         double dz = super.posZ + (double)(3.0F * (super.rand.nextFloat() - super.rand.nextFloat()));
         super.worldObj.spawnParticle("blockcrack_" + Block.getIdFromBlock(Blocks.packed_ice) + "_0", var11, var12, dz, 0.0D, 0.0D, 0.0D);
      }

      this.playSound(Blocks.anvil.stepSound.getBreakSound(), 3.0F, 0.5F);
      this.playSound(Blocks.packed_ice.stepSound.getBreakSound(), 3.0F, 0.5F);
   }

   public void destroyIceInAABB(AxisAlignedBB par1AxisAlignedBB) {
      int minX = MathHelper.floor_double(par1AxisAlignedBB.minX);
      int minY = MathHelper.floor_double(par1AxisAlignedBB.minY);
      int minZ = MathHelper.floor_double(par1AxisAlignedBB.minZ);
      int maxX = MathHelper.floor_double(par1AxisAlignedBB.maxX);
      int maxY = MathHelper.floor_double(par1AxisAlignedBB.maxY);
      int maxZ = MathHelper.floor_double(par1AxisAlignedBB.maxZ);

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dy = minY; dy <= maxY; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               Block block = super.worldObj.getBlock(dx, dy, dz);
               if(block == Blocks.ice || block == Blocks.packed_ice || block == Blocks.stone) {
                  super.worldObj.setBlock(dx, dy, dz, Blocks.air, 0, 3);
               }
            }
         }
      }

   }

   protected void readEntityFromNBT(NBTTagCompound var1) {}

   protected void writeEntityToNBT(NBTTagCompound var1) {}

   @SideOnly(Side.CLIENT)
   public boolean canRenderOnFire() {
      return false;
   }

   public Block getBlock() {
      return Blocks.packed_ice;
   }

   public int getFallTime() {
      return this.fallTime;
   }
}

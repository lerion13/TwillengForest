package twilightforest.entity;

import cpw.mods.fml.common.network.NetworkRegistry.TargetPoint;
import cpw.mods.fml.common.network.internal.FMLProxyPacket;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFGenericPacketHandler;
import twilightforest.TwilightForestMod;
import twilightforest.item.ItemTFCubeOfAnnihilation;

public class EntityTFCubeOfAnnihilation extends EntityThrowable {

   boolean hasHitObstacle = false;


   public EntityTFCubeOfAnnihilation(World par1World) {
      super(par1World);
      this.setSize(1.1F, 1.0F);
      super.isImmuneToFire = true;
   }

   public EntityTFCubeOfAnnihilation(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
      this.setSize(1.0F, 1.0F);
      super.isImmuneToFire = true;
   }

   public EntityTFCubeOfAnnihilation(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
      this.setSize(1.0F, 1.0F);
      super.isImmuneToFire = true;
   }

   protected float getGravityVelocity() {
      return 0.0F;
   }

   protected void onImpact(MovingObjectPosition mop) {
      if(mop.entityHit != null && mop.entityHit instanceof EntityLivingBase && mop.entityHit.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)this.getThrower()), 10.0F)) {
         super.ticksExisted += 60;
      }

      if(!super.worldObj.isAirBlock(mop.blockX, mop.blockY, mop.blockZ) && !super.worldObj.isRemote) {
         this.affectBlocksInAABB(super.boundingBox.expand(0.20000000298023224D, 0.20000000298023224D, 0.20000000298023224D), this.getThrower());
      }

   }

   private boolean affectBlocksInAABB(AxisAlignedBB par1AxisAlignedBB, EntityLivingBase entity) {
      int minX = MathHelper.floor_double(par1AxisAlignedBB.minX);
      int minY = MathHelper.floor_double(par1AxisAlignedBB.minY);
      int minZ = MathHelper.floor_double(par1AxisAlignedBB.minZ);
      int maxX = MathHelper.floor_double(par1AxisAlignedBB.maxX);
      int maxY = MathHelper.floor_double(par1AxisAlignedBB.maxY);
      int maxZ = MathHelper.floor_double(par1AxisAlignedBB.maxZ);
      boolean hitBlock = false;

      for(int dx = minX; dx <= maxX; ++dx) {
         for(int dy = minY; dy <= maxY; ++dy) {
            for(int dz = minZ; dz <= maxZ; ++dz) {
               Block block = super.worldObj.getBlock(dx, dy, dz);
               super.worldObj.getBlockMetadata(dx, dy, dz);
               if(block != Blocks.air) {
                  if(block.getExplosionResistance(this) >= 8.0F || block.getBlockHardness(super.worldObj, dx, dy, dz) < 0.0F) {
                     this.hasHitObstacle = true;
                  }

                  hitBlock = true;
               }
            }
         }
      }

      return hitBlock;
   }

   private void sendAnnihilateBlockPacket(World world, int x, int y, int z) {
      FMLProxyPacket message = TFGenericPacketHandler.makeAnnihilateBlockPacket(x, y, z);
      TargetPoint targetPoint = new TargetPoint(world.provider.dimensionId, (double)x, 64.0D, (double)z, 64.0D);
      TwilightForestMod.genericChannel.sendToAllAround(message, targetPoint);
   }

   public void onUpdate() {
      super.onUpdate();
      if(!super.worldObj.isRemote) {
         if(this.getThrower() == null) {
            this.setDead();
            return;
         }

         if(this.isReturning()) {
            List destPoint1 = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, super.boundingBox.addCoord(super.motionX, super.motionY, super.motionZ).expand(1.0D, 1.0D, 1.0D));
            if(destPoint1.contains(this.getThrower()) && !super.worldObj.isRemote) {
               if(this.getThrower() instanceof EntityPlayer) {
                  ItemTFCubeOfAnnihilation.setCubeAsReturned((EntityPlayer)this.getThrower());
               }

               this.setDead();
            }
         }

         Vec3 destPoint11 = Vec3.createVectorHelper(this.getThrower().posX, this.getThrower().posY + (double)this.getThrower().getEyeHeight(), this.getThrower().posZ);
         Vec3 velocity;
         float currentSpeed;
         if(!this.isReturning()) {
            velocity = this.getThrower().getLookVec();
            currentSpeed = 16.0F;
            velocity.xCoord *= (double)currentSpeed;
            velocity.yCoord *= (double)currentSpeed;
            velocity.zCoord *= (double)currentSpeed;
            destPoint11.xCoord += velocity.xCoord;
            destPoint11.yCoord += velocity.yCoord;
            destPoint11.zCoord += velocity.zCoord;
         }

         velocity = Vec3.createVectorHelper(super.posX - destPoint11.xCoord, super.posY + (double)(super.height / 2.0F) - destPoint11.yCoord, super.posZ - destPoint11.zCoord);
         super.motionX -= velocity.xCoord;
         super.motionY -= velocity.yCoord;
         super.motionZ -= velocity.zCoord;
         currentSpeed = MathHelper.sqrt_double(super.motionX * super.motionX + super.motionY * super.motionY + super.motionZ * super.motionZ);
         float maxSpeed = 0.5F;
         if(currentSpeed > maxSpeed) {
            super.motionX /= (double)(currentSpeed / maxSpeed);
            super.motionY /= (double)(currentSpeed / maxSpeed);
            super.motionZ /= (double)(currentSpeed / maxSpeed);
         } else {
            float slow = 0.5F;
            super.motionX *= (double)slow;
            super.motionY *= (double)slow;
            super.motionZ *= (double)slow;
         }

         this.affectBlocksInAABB(super.boundingBox.expand(0.20000000298023224D, 0.20000000298023224D, 0.20000000298023224D), this.getThrower());
      }

   }

   public boolean isReturning() {
      if(!this.hasHitObstacle && this.getThrower() != null && this.getThrower() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)this.getThrower();
         return !player.isUsingItem();
      } else {
         return true;
      }
   }

   protected float func_70182_d() {
      return 1.5F;
   }
}

package twilightforest.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntityTFIceSnowball extends EntityThrowable {

   private static final int DAMAGE = 8;


   public EntityTFIceSnowball(World par1World) {
      super(par1World);
   }

   public EntityTFIceSnowball(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
   }

   public void onUpdate() {
      super.onUpdate();
      this.makeTrail();
   }

   protected float getGravityVelocity() {
      return 0.006F;
   }

   public void makeTrail() {
      for(int i = 0; i < 2; ++i) {
         double dx = super.posX + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dy = super.posY + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dz = super.posZ + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         super.worldObj.spawnParticle("snowballpoof", dx, dy, dz, 0.0D, 0.0D, 0.0D);
      }

   }

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      this.setBeenAttacked();
      this.pop();
      return true;
   }

   protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
      if(par1MovingObjectPosition.entityHit != null && par1MovingObjectPosition.entityHit instanceof EntityLivingBase && par1MovingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.getThrower()), 8.0F)) {
         ;
      }

      this.pop();
   }

   protected void pop() {
      for(int i = 0; i < 8; ++i) {
         super.worldObj.spawnParticle("snowballpoof", super.posX, super.posY, super.posZ, super.rand.nextGaussian() * 0.05D, super.rand.nextDouble() * 0.2D, super.rand.nextGaussian() * 0.05D);
      }

      if(!super.worldObj.isRemote) {
         this.setDead();
      }

   }
}

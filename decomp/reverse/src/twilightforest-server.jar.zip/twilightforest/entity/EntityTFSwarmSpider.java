package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;

public class EntityTFSwarmSpider extends EntitySpider {

   protected boolean shouldSpawn;


   public EntityTFSwarmSpider(World world) {
      this(world, true);
   }

   public EntityTFSwarmSpider(World world, boolean spawnMore) {
      super(world);
      this.shouldSpawn = false;
      this.setSize(0.8F, 0.4F);
      this.setSpawnMore(spawnMore);
      super.experienceValue = 2;
   }

   public EntityTFSwarmSpider(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(3.0D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(1.0D);
   }

   public float spiderScaleAmount() {
      return 0.5F;
   }

   public float getRenderSizeModifier() {
      return 0.5F;
   }

   public void onUpdate() {
      if(this.shouldSpawnMore()) {
         if(!super.worldObj.isRemote) {
            int more = 1 + super.rand.nextInt(2);

            for(int i = 0; i < more; ++i) {
               if(!this.spawnAnother()) {
                  this.spawnAnother();
               }
            }
         }

         this.setSpawnMore(false);
      }

      super.onUpdate();
   }

   protected void attackEntity(Entity entity, float f) {
      if(super.attackTime <= 0 && (!super.isAirBorne || super.rand.nextInt(4) != 0)) {
         super.attackTime = 20;
      } else {
         super.attackEntity(entity, f);
      }

   }

   protected Entity findPlayerToAttack() {
      double var2 = 16.0D;
      return super.worldObj.getClosestVulnerablePlayerToEntity(this, var2);
   }

   protected boolean spawnAnother() {
      EntityTFSwarmSpider another = new EntityTFSwarmSpider(super.worldObj, false);
      double sx = super.posX + (super.rand.nextBoolean()?0.9D:-0.9D);
      double sy = super.posY;
      double sz = super.posZ + (super.rand.nextBoolean()?0.9D:-0.9D);
      another.setLocationAndAngles(sx, sy, sz, super.rand.nextFloat() * 360.0F, 0.0F);
      if(!another.getCanSpawnHere()) {
         another.setDead();
         return false;
      } else {
         super.worldObj.spawnEntityInWorld(another);
         return true;
      }
   }

   protected boolean isValidLightLevel() {
      int chunkX = MathHelper.floor_double(super.posX) >> 4;
      int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
      return TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hedgeMaze?true:super.isValidLightLevel();
   }

   public boolean shouldSpawnMore() {
      return this.shouldSpawn;
   }

   public void setSpawnMore(boolean flag) {
      this.shouldSpawn = flag;
   }

   public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
      super.writeEntityToNBT(nbttagcompound);
      nbttagcompound.setBoolean("SpawnMore", this.shouldSpawnMore());
   }

   public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
      super.readEntityFromNBT(nbttagcompound);
      this.setSpawnMore(nbttagcompound.getBoolean("SpawnMore"));
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         if(TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hedgeMaze) {
            ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHedge);
         }
      }

   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 1.5F;
   }

   public int getMaxSpawnedInChunk() {
      return 16;
   }
}

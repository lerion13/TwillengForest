package twilightforest.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.ai.EntityAITFChargeAttack;
import twilightforest.entity.ai.EntityAITFKidnapRider;

public class EntityTFPinchBeetle extends EntityMob {

   public EntityTFPinchBeetle(World world) {
      super(world);
      this.setSize(1.2F, 1.1F);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAITFKidnapRider(this, 2.0F));
      super.tasks.addTask(2, new EntityAITFChargeAttack(this, 2.0F));
      super.tasks.addTask(4, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   public int getTotalArmorValue() {
      int var1 = super.getTotalArmorValue() + 2;
      if(var1 > 20) {
         var1 = 20;
      }

      return var1;
   }

   protected String getLivingSound() {
      return null;
   }

   protected String getHurtSound() {
      return "mob.spider.say";
   }

   protected String getDeathSound() {
      return "mob.spider.death";
   }

   protected void func_145780_a(int var1, int var2, int var3, Block var4) {
      super.worldObj.playSoundAtEntity(this, "mob.spider.step", 0.15F, 1.0F);
   }

   public void onLivingUpdate() {
      if(super.riddenByEntity != null) {
         this.setSize(1.9F, 2.0F);
         if(super.riddenByEntity.isSneaking()) {
            super.riddenByEntity.setSneaking(false);
         }
      } else {
         this.setSize(1.2F, 1.1F);
      }

      super.onLivingUpdate();
      if(super.riddenByEntity != null) {
         this.getLookHelper().setLookPositionWithEntity(super.riddenByEntity, 100.0F, 100.0F);
         Vec3 riderPos = this.getRiderPosition();
         this.func_145771_j(riderPos.xCoord, riderPos.yCoord, riderPos.zCoord);
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public int getAttackStrength(Entity par1Entity) {
      return 8;
   }

   @SideOnly(Side.CLIENT)
   public float getShadowSize() {
      return 1.1F;
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      if(super.riddenByEntity == null && par1Entity.ridingEntity == null) {
         par1Entity.mountEntity(this);
      }

      return super.attackEntityAsMob(par1Entity);
   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      return super.interact(par1EntityPlayer);
   }

   public float getEyeHeight() {
      return 0.25F;
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.ARTHROPOD;
   }

   public void updateRiderPosition() {
      if(super.riddenByEntity != null) {
         Vec3 riderPos = this.getRiderPosition();
         super.riddenByEntity.setPosition(riderPos.xCoord, riderPos.yCoord, riderPos.zCoord);
      }

   }

   public double getMountedYOffset() {
      return 0.75D;
   }

   public Vec3 getRiderPosition() {
      if(super.riddenByEntity != null) {
         float distance = 0.9F;
         double var1 = Math.cos((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         double var3 = Math.sin((double)(super.rotationYaw + 90.0F) * 3.141592653589793D / 180.0D) * (double)distance;
         return Vec3.createVectorHelper(super.posX + var1, super.posY + this.getMountedYOffset() + super.riddenByEntity.getYOffset(), super.posZ + var3);
      } else {
         return Vec3.createVectorHelper(super.posX, super.posY, super.posZ);
      }
   }

   public boolean canRiderInteract() {
      return true;
   }
}

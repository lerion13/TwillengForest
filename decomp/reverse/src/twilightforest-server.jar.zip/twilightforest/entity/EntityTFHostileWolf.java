package twilightforest.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;

public class EntityTFHostileWolf extends EntityWolf implements IMob {

   public EntityTFHostileWolf(World world) {
      super(world);
      this.setAngry(true);
      super.targetTasks.addTask(4, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   public EntityTFHostileWolf(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10.0D);
   }

   public void onUpdate() {
      super.onUpdate();
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.setDead();
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public boolean getCanSpawnHere() {
      int chunkX = MathHelper.floor_double(super.posX) >> 4;
      int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
      return TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hedgeMaze?super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).size() == 0 && !super.worldObj.isAnyLiquid(super.boundingBox):this.isValidLightLevel() && super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).size() == 0 && !super.worldObj.isAnyLiquid(super.boundingBox);
   }

   protected boolean isValidLightLevel() {
      int var1 = MathHelper.floor_double(super.posX);
      int var2 = MathHelper.floor_double(super.boundingBox.minY);
      int var3 = MathHelper.floor_double(super.posZ);
      if(super.worldObj.getSavedLightValue(EnumSkyBlock.Sky, var1, var2, var3) > super.rand.nextInt(32)) {
         return false;
      } else {
         int var4 = super.worldObj.getBlockLightValue(var1, var2, var3);
         if(super.worldObj.isThundering()) {
            int var5 = super.worldObj.skylightSubtracted;
            super.worldObj.skylightSubtracted = 10;
            var4 = super.worldObj.getBlockLightValue(var1, var2, var3);
            super.worldObj.skylightSubtracted = var5;
         }

         return var4 <= super.rand.nextInt(8);
      }
   }

   public boolean isBreedingItem(ItemStack par1ItemStack) {
      return false;
   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      return false;
   }
}

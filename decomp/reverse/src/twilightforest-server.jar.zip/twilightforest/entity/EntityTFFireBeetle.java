package twilightforest.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.IBreathAttacker;
import twilightforest.entity.ai.EntityAITFBreathAttack;

public class EntityTFFireBeetle extends EntityMob implements IBreathAttacker {

   public static final int BREATH_DURATION = 10;
   public static final int BREATH_DAMAGE = 2;


   public EntityTFFireBeetle(World world) {
      super(world);
      this.setSize(1.1F, 0.75F);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAITFBreathAttack(this, 1.0F, 5.0F, 30, 0.1F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   public EntityTFFireBeetle(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(25.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   protected String getLivingSound() {
      return null;
   }

   protected String getHurtSound() {
      return "mob.spider.say";
   }

   protected String getDeathSound() {
      return "mob.spider.death";
   }

   protected void func_145780_a(int var1, int var2, int var3, Block var4) {
      super.worldObj.playSoundAtEntity(this, "mob.spider.step", 0.15F, 1.0F);
   }

   protected Item getDropItem() {
      return Items.gunpowder;
   }

   public boolean isBreathing() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setBreathing(boolean flag) {
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)127));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)0));
      }

   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.isBreathing()) {
         Vec3 look = this.getLookVec();
         double dist = 0.9D;
         double px = super.posX + look.xCoord * dist;
         double py = super.posY + 0.25D + look.yCoord * dist;
         double pz = super.posZ + look.zCoord * dist;

         for(int i = 0; i < 2; ++i) {
            double dx = look.xCoord;
            double dy = look.yCoord;
            double dz = look.zCoord;
            double spread = 5.0D + this.getRNG().nextDouble() * 2.5D;
            double velocity = 0.15D + this.getRNG().nextDouble() * 0.15D;
            dx += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dy += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dz += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dx *= velocity;
            dy *= velocity;
            dz *= velocity;
            super.worldObj.spawnParticle(this.getFlameParticle(), px, py, pz, dx, dy, dz);
         }

         this.playBreathSound();
      }

   }

   public String getFlameParticle() {
      return "flame";
   }

   public void playBreathSound() {
      super.worldObj.playSoundEffect(super.posX + 0.5D, super.posY + 0.5D, super.posZ + 0.5D, "mob.ghast.fireball", super.rand.nextFloat() * 0.5F, super.rand.nextFloat() * 0.5F);
   }

   @SideOnly(Side.CLIENT)
   public int getBrightnessForRender(float par1) {
      return this.isBreathing()?15728880:super.getBrightnessForRender(par1);
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public int getVerticalFaceSpeed() {
      return 500;
   }

   @SideOnly(Side.CLIENT)
   public float getShadowSize() {
      return 1.1F;
   }

   public float getEyeHeight() {
      return 0.25F;
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.ARTHROPOD;
   }

   public void doBreathAttack(Entity target) {
      if(!target.isImmuneToFire() && target.attackEntityFrom(DamageSource.inFire, 2.0F)) {
         target.setFire(10);
      }

   }
}

package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityFlying;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;

public class EntityTFWraith extends EntityFlying implements IMob {

   public int courseChangeCooldown;
   public double waypointX;
   public double waypointY;
   public double waypointZ;
   private Entity targetedEntity;
   private int aggroCooldown;
   public int prevAttackCounter;
   public int attackCounter;


   public EntityTFWraith(World world) {
      super(world);
   }

   public EntityTFWraith(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.5D);
      this.getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
   }

   public void onLivingUpdate() {
      if(super.worldObj.isDaytime()) {
         float f = this.getBrightness(1.0F);
         if(f > 0.5F && super.worldObj.canBlockSeeTheSky(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posY), MathHelper.floor_double(super.posZ)) && super.rand.nextFloat() * 30.0F < (f - 0.4F) * 2.0F) {
            ;
         }
      }

      super.onLivingUpdate();
   }

   public boolean canTriggerWalking() {
      return false;
   }

   protected void updateEntityActionState() {
      if(!super.worldObj.isRemote && super.worldObj.difficultySetting == EnumDifficulty.PEACEFUL) {
         this.setDead();
      }

      this.despawnEntity();
      this.prevAttackCounter = this.attackCounter;
      double d = this.waypointX - super.posX;
      double d1 = this.waypointY - super.posY;
      double d2 = this.waypointZ - super.posZ;
      double d3 = (double)MathHelper.sqrt_double(d * d + d1 * d1 + d2 * d2);
      if(d3 < 1.0D || d3 > 60.0D) {
         this.waypointX = super.posX + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
         this.waypointY = super.posY + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
         this.waypointZ = super.posZ + (double)((super.rand.nextFloat() * 2.0F - 1.0F) * 16.0F);
      }

      if(this.courseChangeCooldown-- <= 0) {
         this.courseChangeCooldown += super.rand.nextInt(5) + 2;
         if(this.isCourseTraversable(this.waypointX, this.waypointY, this.waypointZ, d3)) {
            super.motionX += d / d3 * 0.1D;
            super.motionY += d1 / d3 * 0.1D;
            super.motionZ += d2 / d3 * 0.1D;
         } else {
            this.waypointX = super.posX;
            this.waypointY = super.posY;
            this.waypointZ = super.posZ;
            this.targetedEntity = null;
         }
      }

      if(this.targetedEntity != null && this.targetedEntity.isDead) {
         this.targetedEntity = null;
      }

      if(this.targetedEntity != null && this.aggroCooldown-- > 0) {
         float d4 = this.targetedEntity.getDistanceToEntity(this);
         if(this.canEntityBeSeen(this.targetedEntity)) {
            this.attackEntity(this.targetedEntity, d4);
         } else {
            this.attackBlockedEntity(this.targetedEntity, d4);
         }
      } else {
         this.targetedEntity = this.findPlayerToAttack();
         if(this.targetedEntity != null) {
            this.aggroCooldown = 20;
         }
      }

      double var15 = 64.0D;
      if(this.targetedEntity != null && this.targetedEntity.getDistanceSqToEntity(this) < var15 * var15) {
         double d5 = this.targetedEntity.posX - super.posX;
         double d7 = this.targetedEntity.posZ - super.posZ;
         super.renderYawOffset = super.rotationYaw = -((float)Math.atan2(d5, d7)) * 180.0F / 3.141593F;
         if(this.canEntityBeSeen(this.targetedEntity)) {
            if(this.attackCounter == 10) {
               ;
            }

            ++this.attackCounter;
            if(this.attackCounter == 20) {
               this.waypointX = this.targetedEntity.posX;
               this.waypointY = this.targetedEntity.posY - (double)this.targetedEntity.height + 0.5D;
               this.waypointZ = this.targetedEntity.posZ;
               this.attackCounter = -40;
            }
         } else if(this.attackCounter > 0) {
            --this.attackCounter;
         }
      } else {
         super.renderYawOffset = super.rotationYaw = -((float)Math.atan2(super.motionX, super.motionZ)) * 180.0F / 3.141593F;
         if(this.attackCounter > 0) {
            --this.attackCounter;
         }
      }

   }

   protected void attackEntity(Entity entity, float f) {
      if(super.attackTime <= 0 && f < 2.0F && entity.boundingBox.maxY > super.boundingBox.minY && entity.boundingBox.minY < super.boundingBox.maxY) {
         super.attackTime = 20;
         float damage = (float)this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getBaseValue();
         entity.attackEntityFrom(DamageSource.causeMobDamage(this), damage);
      }

   }

   protected void attackBlockedEntity(Entity entity, float f) {}

   public boolean attackEntityFrom(DamageSource damagesource, float i) {
      if(super.attackEntityFrom(damagesource, i)) {
         Entity entity = damagesource.getEntity();
         if(super.riddenByEntity != entity && super.ridingEntity != entity) {
            if(entity != this) {
               this.targetedEntity = entity;
            }

            return true;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   protected Entity findPlayerToAttack() {
      EntityPlayer entityplayer = super.worldObj.getClosestVulnerablePlayerToEntity(this, 16.0D);
      return entityplayer != null && this.canEntityBeSeen(entityplayer)?entityplayer:null;
   }

   private boolean isCourseTraversable(double d, double d1, double d2, double d3) {
      double d4 = (this.waypointX - super.posX) / d3;
      double d5 = (this.waypointY - super.posY) / d3;
      double d6 = (this.waypointZ - super.posZ) / d3;
      AxisAlignedBB axisalignedbb = super.boundingBox.copy();

      for(int i = 1; (double)i < d3; ++i) {
         axisalignedbb.offset(d4, d5, d6);
         if(super.worldObj.getCollidingBoundingBoxes(this, axisalignedbb).size() > 0) {
            return false;
         }
      }

      return true;
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.wraith.wraith";
   }

   protected Item getDropItem() {
      return Items.glowstone_dust;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         if(TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hill3) {
            ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHill3);
         }
      }

   }

   protected boolean isValidLightLevel() {
      int i = MathHelper.floor_double(super.posX);
      int j = MathHelper.floor_double(super.boundingBox.minY);
      int k = MathHelper.floor_double(super.posZ);
      if(super.worldObj.getSavedLightValue(EnumSkyBlock.Sky, i, j, k) > super.rand.nextInt(32)) {
         return false;
      } else {
         int l = super.worldObj.getBlockLightValue(i, j, k);
         if(super.worldObj.isThundering()) {
            int i1 = super.worldObj.skylightSubtracted;
            super.worldObj.skylightSubtracted = 10;
            l = super.worldObj.getBlockLightValue(i, j, k);
            super.worldObj.skylightSubtracted = i1;
         }

         return l <= super.rand.nextInt(8);
      }
   }

   public boolean getCanSpawnHere() {
      return super.worldObj.difficultySetting != EnumDifficulty.PEACEFUL && this.isValidLightLevel() && super.getCanSpawnHere();
   }
}

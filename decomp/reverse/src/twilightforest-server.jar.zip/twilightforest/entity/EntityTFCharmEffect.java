package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.item.TFItems;

public class EntityTFCharmEffect extends Entity {

   private static final int DATA_OWNER = 17;
   private static final int DATA_ITEMID = 16;
   private static final double DISTANCE = 1.75D;
   private EntityLivingBase orbiting;
   private double newPosX;
   private double newPosY;
   private double newPosZ;
   private double newRotationYaw;
   private double newRotationPitch;
   private int newPosRotationIncrements;
   public float offset;


   public EntityTFCharmEffect(World par1World) {
      super(par1World);
      this.setSize(0.25F, 0.25F);
      this.setItemID(TFItems.charmOfLife1);
   }

   public EntityTFCharmEffect(World par1World, EntityLivingBase par2EntityLiving, Item item) {
      super(par1World);
      this.setSize(0.25F, 0.25F);
      this.orbiting = par2EntityLiving;
      this.setItemID(item);
      Vec3 look = Vec3.createVectorHelper(1.75D, 0.0D, 0.0D);
      this.setLocationAndAngles(par2EntityLiving.posX, par2EntityLiving.posY + (double)par2EntityLiving.getEyeHeight(), par2EntityLiving.posZ, par2EntityLiving.rotationYaw, par2EntityLiving.rotationPitch);
      super.posX += look.xCoord * 1.75D;
      super.posZ += look.zCoord * 1.75D;
      this.setPosition(super.posX, super.posY, super.posZ);
      super.yOffset = 0.0F;
   }

   public void onUpdate() {
      super.lastTickPosX = super.posX;
      super.lastTickPosY = super.posY;
      super.lastTickPosZ = super.posZ;
      super.onUpdate();
      double dx;
      double dy;
      double dz;
      if(this.newPosRotationIncrements > 0) {
         double rotation = super.posX + (this.newPosX - super.posX) / (double)this.newPosRotationIncrements;
         dx = super.posY + (this.newPosY - super.posY) / (double)this.newPosRotationIncrements;
         dy = super.posZ + (this.newPosZ - super.posZ) / (double)this.newPosRotationIncrements;
         dz = MathHelper.wrapAngleTo180_double(this.newRotationYaw - (double)super.rotationYaw);
         super.rotationYaw = (float)((double)super.rotationYaw + dz / (double)this.newPosRotationIncrements);
         super.rotationPitch = (float)((double)super.rotationPitch + (this.newRotationPitch - (double)super.rotationPitch) / (double)this.newPosRotationIncrements);
         --this.newPosRotationIncrements;
         this.setPosition(rotation, dx, dy);
         this.setRotation(super.rotationYaw, super.rotationPitch);
      }

      float var9 = (float)super.ticksExisted / 5.0F + this.offset;
      if(this.orbiting == null) {
         this.orbiting = this.getOwner();
      }

      if(this.orbiting != null && !super.worldObj.isRemote) {
         this.setLocationAndAngles(this.orbiting.posX, this.orbiting.posY + (double)this.orbiting.getEyeHeight(), this.orbiting.posZ, this.orbiting.rotationYaw, this.orbiting.rotationPitch);
         Vec3 i = Vec3.createVectorHelper(1.75D, 0.0D, 0.0D);
         i.rotateAroundY(var9);
         super.posX += i.xCoord;
         super.posZ += i.zCoord;
         this.setPosition(super.posX, super.posY, super.posZ);
      }

      if(this.getItemID() > 0) {
         for(int var10 = 0; var10 < 3; ++var10) {
            dx = super.posX + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
            dy = super.posY + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
            dz = super.posZ + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
            super.worldObj.spawnParticle("iconcrack_" + this.getItemID(), dx, dy, dz, 0.0D, 0.2D, 0.0D);
         }
      }

      if(super.ticksExisted > 200 || this.orbiting == null || this.orbiting.isDead) {
         this.setDead();
      }

   }

   public void setPositionAndRotation2(double par1, double par3, double par5, float par7, float par8, int par9) {
      super.yOffset = 0.0F;
      this.newPosX = par1;
      this.newPosY = par3;
      this.newPosZ = par5;
      this.newRotationYaw = (double)par7;
      this.newRotationPitch = (double)par8;
      this.newPosRotationIncrements = par9;
   }

   protected void entityInit() {
      super.dataWatcher.addObject(16, Integer.valueOf(0));
      super.dataWatcher.addObject(17, "");
   }

   public String getOwnerName() {
      return super.dataWatcher.getWatchableObjectString(17);
   }

   public void setOwner(String par1Str) {
      super.dataWatcher.updateObject(17, par1Str);
   }

   public EntityLivingBase getOwner() {
      return super.worldObj.getPlayerEntityByName(this.getOwnerName());
   }

   public int getItemID() {
      return super.dataWatcher.getWatchableObjectInt(16);
   }

   public void setItemID(Item charmOfLife1) {}

   protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      par1NBTTagCompound.setString("Owner", this.getOwnerName());
      par1NBTTagCompound.setShort("ItemID", (short)this.getItemID());
   }

   protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      this.setOwner(par1NBTTagCompound.getString("Owner"));
   }
}

package twilightforest.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.ai.EntityAITFFlockToSameKind;
import twilightforest.entity.ai.EntityAITFPanicOnFlockDeath;

public class EntityTFKobold extends EntityMob {

   private boolean shy;


   public EntityTFKobold(World world) {
      super(world);
      this.setSize(0.8F, 1.1F);
      this.shy = true;
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAITFPanicOnFlockDeath(this, 2.0F));
      super.tasks.addTask(2, new EntityAILeapAtTarget(this, 0.3F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(4, new EntityAITFFlockToSameKind(this, 1.0D));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   public EntityTFKobold(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(13.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.kobold.kobold";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.kobold.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.kobold.die";
   }

   protected Item getDropItem() {
      return Items.wheat;
   }

   protected void dropFewItems(boolean flag, int i) {
      super.dropFewItems(flag, i);
      if(super.rand.nextInt(2) == 0) {
         this.dropItem(Items.gold_nugget, 1 + i);
      }

   }

   public boolean isShy() {
      return this.shy && super.recentlyHit <= 0;
   }

   public boolean isPanicked() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setPanicked(boolean flag) {
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)127));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)0));
      }

   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.isPanicked()) {
         for(int i = 0; i < 2; ++i) {
            super.worldObj.spawnParticle("splash", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width * 0.5D, super.posY + (double)this.getEyeHeight(), super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width * 0.5D, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }
}

package twilightforest.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIArrowAttack;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TwilightForestMod;
import twilightforest.entity.EntityTFIceSnowball;

public class EntityTFIceShooter extends EntityMob implements IRangedAttackMob {

   public EntityTFIceShooter(World par1World) {
      super(par1World);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIArrowAttack(this, 1.25D, 20, 10.0F));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(3, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.setSize(0.8F, 1.8F);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23000000417232513D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   public float getEyeHeight() {
      return super.height * 0.6F;
   }

   protected Item getDropItem() {
      return Items.snowball;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();

      for(int i = 0; i < 3; ++i) {
         float px = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         float py = this.getEyeHeight() + (super.rand.nextFloat() - super.rand.nextFloat()) * 0.5F;
         float pz = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowguardian", super.lastTickPosX + (double)px, super.lastTickPosY + (double)py, super.lastTickPosZ + (double)pz, 0.0D, 0.0D, 0.0D);
      }

   }

   protected String getLivingSound() {
      return "TwilightForest:mob.ice.noise";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.ice.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.ice.death";
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }

   public void attackEntityWithRangedAttack(EntityLivingBase par1EntityLivingBase, float par2) {
      EntityTFIceSnowball entitysnowball = new EntityTFIceSnowball(super.worldObj, this);
      double d0 = par1EntityLivingBase.posX - super.posX;
      double d1 = par1EntityLivingBase.posY + (double)par1EntityLivingBase.getEyeHeight() - 1.100000023841858D - entitysnowball.posY;
      double d2 = par1EntityLivingBase.posZ - super.posZ;
      float f1 = MathHelper.sqrt_double(d0 * d0 + d2 * d2) * 0.2F;
      entitysnowball.setThrowableHeading(d0, d1 + (double)f1, d2, 0.6F, 12.0F);
      this.playSound("random.bow", 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
      super.worldObj.spawnEntityInWorld(entitysnowball);
   }
}

package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class EntityTFMazeSlime extends EntitySlime {

   private String slimeParticleString;


   public EntityTFMazeSlime(World par1World) {
      super(par1World);
      this.setSlimeSize(1 << 1 + super.rand.nextInt(2));
   }

   protected EntitySlime createInstance() {
      return new EntityTFMazeSlime(super.worldObj);
   }

   public void setSlimeSize(int par1) {
      super.setSlimeSize(par1);
      super.experienceValue = par1 + 3;
   }

   public boolean getCanSpawnHere() {
      return super.worldObj.difficultySetting != EnumDifficulty.PEACEFUL && super.worldObj.checkNoEntityCollision(super.boundingBox) && super.worldObj.getCollidingBoundingBoxes(this, super.boundingBox).isEmpty() && !super.worldObj.isAnyLiquid(super.boundingBox) && this.isValidLightLevel();
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      int size = this.getSlimeSize();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(2.0D * (double)size * (double)size);
   }

   protected boolean canDamagePlayer() {
      return true;
   }

   protected int getAttackStrength() {
      return super.getAttackStrength() + 3;
   }

   protected String getSlimeParticle() {
      if(this.slimeParticleString == null) {
         this.slimeParticleString = "blockcrack_" + Block.getIdFromBlock(TFBlocks.mazestone) + "_1";
      }

      return this.slimeParticleString;
   }

   protected boolean isValidLightLevel() {
      int var1 = MathHelper.floor_double(super.posX);
      int var2 = MathHelper.floor_double(super.boundingBox.minY);
      int var3 = MathHelper.floor_double(super.posZ);
      if(super.worldObj.getSavedLightValue(EnumSkyBlock.Sky, var1, var2, var3) > super.rand.nextInt(32)) {
         return false;
      } else {
         int var4 = super.worldObj.getBlockLightValue(var1, var2, var3);
         if(super.worldObj.isThundering()) {
            int var5 = super.worldObj.skylightSubtracted;
            super.worldObj.skylightSubtracted = 10;
            var4 = super.worldObj.getBlockLightValue(var1, var2, var3);
            super.worldObj.skylightSubtracted = var5;
         }

         return var4 <= super.rand.nextInt(8);
      }
   }

   protected float getSoundVolume() {
      return 0.1F * (float)this.getSlimeSize();
   }

   protected void dropRareDrop(int par1) {
      this.dropItem(TFItems.charmOfKeeping1, 1);
   }
}

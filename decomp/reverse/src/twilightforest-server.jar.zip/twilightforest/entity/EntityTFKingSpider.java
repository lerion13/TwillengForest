package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFSkeletonDruid;

public class EntityTFKingSpider extends EntitySpider {

   public EntityTFKingSpider(World world) {
      super(world);
      this.setSize(1.6F, 1.6F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(2, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(3, new EntityAILeapAtTarget(this, 0.3F));
      super.tasks.addTask(6, new EntityAIWander(this, 0.20000000298023224D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      super.tasks.addTask(8, new EntityAILookIdle(this));
      super.targetTasks.addTask(2, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.35D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(6.0D);
   }

   protected Entity findPlayerToAttack() {
      double var2 = 16.0D;
      return super.worldObj.getClosestVulnerablePlayerToEntity(this, var2);
   }

   public float spiderScaleAmount() {
      return 1.9F;
   }

   public float getRenderSizeModifier() {
      return 2.0F;
   }

   public boolean isOnLadder() {
      return false;
   }

   public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData) {
      IEntityLivingData par1EntityLivingData1 = super.onSpawnWithEgg(par1EntityLivingData);
      EntityTFSkeletonDruid druid = new EntityTFSkeletonDruid(super.worldObj);
      druid.setLocationAndAngles(super.posX, super.posY, super.posZ, super.rotationYaw, 0.0F);
      druid.onSpawnWithEgg((IEntityLivingData)null);
      super.worldObj.spawnEntityInWorld(druid);
      druid.mountEntity(this);
      return (IEntityLivingData)par1EntityLivingData1;
   }

   public double getMountedYOffset() {
      return (double)super.height * 0.5D;
   }
}

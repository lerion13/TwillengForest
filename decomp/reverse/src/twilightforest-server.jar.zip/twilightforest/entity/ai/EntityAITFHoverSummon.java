package twilightforest.entity.ai;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import twilightforest.entity.boss.EntityTFSnowQueen;

public class EntityAITFHoverSummon extends EntityAIBase {

   private static final float HOVER_HEIGHT = 6.0F;
   private static final float HOVER_RADIUS = 6.0F;
   private static final int MAX_MINIONS_AT_ONCE = 4;
   private Class classTarget;
   private EntityTFSnowQueen attacker;
   private double hoverPosX;
   private double hoverPosY;
   private double hoverPosZ;
   private int seekTimer;
   private int maxSeekTime;


   public EntityAITFHoverSummon(EntityTFSnowQueen entityTFSnowQueen, Class class1, double speed) {
      this.attacker = entityTFSnowQueen;
      this.classTarget = class1;
      this.setMutexBits(3);
      this.maxSeekTime = 80;
   }

   public boolean shouldExecute() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      return target == null?false:(!target.isEntityAlive()?false:(this.classTarget != null && !this.classTarget.isAssignableFrom(target.getClass())?false:(this.attacker.getCurrentPhase() != EntityTFSnowQueen.Phase.SUMMON?false:this.attacker.canEntityBeSeen(target))));
   }

   public boolean continueExecuting() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      if(target != null && target.isEntityAlive()) {
         if(this.attacker.getCurrentPhase() != EntityTFSnowQueen.Phase.SUMMON) {
            return false;
         } else if(this.seekTimer > this.maxSeekTime) {
            return false;
         } else {
            boolean isVisible = this.canEntitySee(this.attacker, this.hoverPosX, this.hoverPosY, this.hoverPosZ);
            if(!isVisible) {
               ;
            }

            return isVisible;
         }
      } else {
         return false;
      }
   }

   public void startExecuting() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      if(target != null) {
         this.makeNewHoverSpot(target);
      }

   }

   public void resetTask() {}

   public void updateTask() {
      ++this.seekTimer;
      EntityLivingBase target = this.attacker.getAttackTarget();
      if(this.attacker.getDistanceSq(this.hoverPosX, this.hoverPosY, this.hoverPosZ) <= 1.0D) {
         this.checkAndSummon();
         this.makeNewHoverSpot(target);
      }

      double offsetX = this.hoverPosX - this.attacker.posX;
      double offsetY = this.hoverPosY - this.attacker.posY;
      double offsetZ = this.hoverPosZ - this.attacker.posZ;
      double distanceDesired = offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ;
      distanceDesired = (double)MathHelper.sqrt_double(distanceDesired);
      double velX = offsetX / distanceDesired * 0.05D;
      double velY = offsetY / distanceDesired * 0.1D;
      double velZ = offsetZ / distanceDesired * 0.05D;
      velY += 0.05000000074505806D;
      this.attacker.addVelocity(velX, velY, velZ);
      if(target != null) {
         this.attacker.faceEntity(target, 30.0F, 30.0F);
         this.attacker.getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);
      }

   }

   private void makeNewHoverSpot(EntityLivingBase target) {
      double hx = 0.0D;
      double hy = 0.0D;
      double hz = 0.0D;
      byte tries = 100;

      for(int i = 0; i < tries; ++i) {
         hx = target.posX + (double)((this.attacker.getRNG().nextFloat() - this.attacker.getRNG().nextFloat()) * 6.0F);
         hy = target.posY + 6.0D;
         hz = target.posZ + (double)((this.attacker.getRNG().nextFloat() - this.attacker.getRNG().nextFloat()) * 6.0F);
         if(!this.isPositionOccupied(hx, hy, hz) && this.canEntitySee(this.attacker, hx, hy, hz) && this.canEntitySee(target, hx, hy, hz)) {
            break;
         }
      }

      if(tries == 99) {
         System.out.println("Found no spots, giving up");
      }

      this.hoverPosX = hx;
      this.hoverPosY = hy;
      this.hoverPosZ = hz;
      this.seekTimer = 0;
   }

   private boolean isPositionOccupied(double hx, double hy, double hz) {
      float radius = this.attacker.width / 2.0F;
      AxisAlignedBB aabb = AxisAlignedBB.getBoundingBox(hx - (double)radius, hy, hz - (double)radius, hx + (double)radius, hy + (double)this.attacker.height, hz + (double)radius);
      boolean isOccupied = this.attacker.worldObj.getCollidingBoundingBoxes(this.attacker, aabb).isEmpty();
      return isOccupied;
   }

   protected boolean canEntitySee(Entity entity, double dx, double dy, double dz) {
      return entity.worldObj.rayTraceBlocks(Vec3.createVectorHelper(entity.posX, entity.posY + (double)entity.getEyeHeight(), entity.posZ), Vec3.createVectorHelper(dx, dy, dz)) == null;
   }

   private void checkAndSummon() {
      if(this.attacker.getSummonsRemaining() > 0 && this.attacker.countMyMinions() < 4) {
         this.attacker.summonMinionAt(this.attacker.getAttackTarget());
      }

   }
}

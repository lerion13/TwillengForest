package twilightforest.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.pathfinding.PathEntity;
import net.minecraft.pathfinding.PathPoint;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityAITFGiantAttackOnCollide extends EntityAIBase {

   World worldObj;
   EntityCreature attacker;
   int attackTick;
   double speedTowardsTarget;
   boolean longMemory;
   PathEntity entityPathEntity;
   Class classTarget;
   private int delayTicks;
   private double pathX;
   private double pathY;
   private double pathZ;
   private int failedPathFindingPenalty;


   public EntityAITFGiantAttackOnCollide(EntityCreature par1EntityCreature, Class par2Class, double par3, boolean par5) {
      this(par1EntityCreature, par3, par5);
      this.classTarget = par2Class;
   }

   public EntityAITFGiantAttackOnCollide(EntityCreature par1EntityCreature, double par2, boolean par4) {
      this.attacker = par1EntityCreature;
      this.worldObj = par1EntityCreature.worldObj;
      this.speedTowardsTarget = par2;
      this.longMemory = par4;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
      if(entitylivingbase == null) {
         return false;
      } else if(!entitylivingbase.isEntityAlive()) {
         return false;
      } else if(this.classTarget != null && !this.classTarget.isAssignableFrom(entitylivingbase.getClass())) {
         return false;
      } else if(--this.delayTicks <= 0) {
         this.entityPathEntity = this.attacker.getNavigator().getPathToEntityLiving(entitylivingbase);
         this.delayTicks = 4 + this.attacker.getRNG().nextInt(7);
         return this.entityPathEntity != null;
      } else {
         return true;
      }
   }

   public boolean continueExecuting() {
      EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
      return entitylivingbase == null?false:(!entitylivingbase.isEntityAlive()?false:(!this.longMemory?!this.attacker.getNavigator().noPath():this.attacker.isWithinHomeDistance(MathHelper.floor_double(entitylivingbase.posX), MathHelper.floor_double(entitylivingbase.posY), MathHelper.floor_double(entitylivingbase.posZ))));
   }

   public void startExecuting() {
      this.attacker.getNavigator().setPath(this.entityPathEntity, this.speedTowardsTarget);
      this.delayTicks = 0;
   }

   public void resetTask() {
      this.attacker.getNavigator().clearPathEntity();
   }

   public void updateTask() {
      EntityLivingBase entitylivingbase = this.attacker.getAttackTarget();
      this.attacker.getLookHelper().setLookPositionWithEntity(entitylivingbase, 30.0F, 30.0F);
      double distanceToAttacker = this.attacker.getDistanceSq(entitylivingbase.posX, entitylivingbase.boundingBox.minY, entitylivingbase.posZ);
      double attackRange = (double)(this.attacker.width * this.attacker.height);
      --this.delayTicks;
      if((this.longMemory || this.attacker.getEntitySenses().canSee(entitylivingbase)) && this.delayTicks <= 0 && (this.pathX == 0.0D && this.pathY == 0.0D && this.pathZ == 0.0D || entitylivingbase.getDistanceSq(this.pathX, this.pathY, this.pathZ) >= 1.0D || this.attacker.getRNG().nextFloat() < 0.05F)) {
         this.pathX = entitylivingbase.posX;
         this.pathY = entitylivingbase.boundingBox.minY;
         this.pathZ = entitylivingbase.posZ;
         this.delayTicks = this.failedPathFindingPenalty + 4 + this.attacker.getRNG().nextInt(7);
         if(this.attacker.getNavigator().getPath() != null) {
            PathPoint finalPathPoint = this.attacker.getNavigator().getPath().getFinalPathPoint();
            if(finalPathPoint != null && entitylivingbase.getDistanceSq((double)finalPathPoint.xCoord, (double)finalPathPoint.yCoord, (double)finalPathPoint.zCoord) < 1.0D) {
               this.failedPathFindingPenalty = 0;
            } else {
               this.failedPathFindingPenalty += 10;
            }
         } else {
            this.failedPathFindingPenalty += 10;
         }

         if(distanceToAttacker > 1024.0D) {
            this.delayTicks += 10;
         } else if(distanceToAttacker > 256.0D) {
            this.delayTicks += 5;
         }

         if(!this.attacker.getNavigator().tryMoveToEntityLiving(entitylivingbase, this.speedTowardsTarget)) {
            this.delayTicks += 15;
         }
      }

      this.attackTick = Math.max(this.attackTick - 1, 0);
      if(distanceToAttacker <= attackRange && this.attackTick <= 0) {
         this.attackTick = 20;
         if(this.attacker.getHeldItem() != null) {
            this.attacker.swingItem();
         }

         this.attacker.attackEntityAsMob(entitylivingbase);
      }

   }
}

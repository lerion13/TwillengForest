package twilightforest.entity.ai;

import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.Vec3;

public class EntityAITFFlockToSameKind extends EntityAIBase {

   private static final double MAX_DIST = 256.0D;
   private static final double MIN_DIST = 25.0D;
   EntityLiving flockCreature;
   Vec3 flockPosition;
   double speed;
   private int moveTimer;


   public EntityAITFFlockToSameKind(EntityLiving par1EntityLiving, double par2) {
      this.flockCreature = par1EntityLiving;
      this.speed = par2;
   }

   public boolean shouldExecute() {
      if(this.flockCreature.getRNG().nextInt(40) != 0) {
         return false;
      } else {
         List flockList = this.flockCreature.worldObj.getEntitiesWithinAABB(this.flockCreature.getClass(), this.flockCreature.boundingBox.expand(16.0D, 4.0D, 16.0D));
         int flocknum = 0;
         double flockX = 0.0D;
         double flockY = 0.0D;
         double flockZ = 0.0D;

         EntityLiving flocker;
         for(Iterator var9 = flockList.iterator(); var9.hasNext(); flockZ += flocker.posZ) {
            flocker = (EntityLiving)var9.next();
            ++flocknum;
            flockX += flocker.posX;
            flockY += flocker.posY;
         }

         flockX /= (double)flocknum;
         flockY /= (double)flocknum;
         flockZ /= (double)flocknum;
         if(this.flockCreature.getDistanceSq(flockX, flockY, flockZ) < 25.0D) {
            return false;
         } else {
            this.flockPosition = Vec3.createVectorHelper(flockX, flockY, flockZ);
            return true;
         }
      }
   }

   public boolean continueExecuting() {
      if(this.flockPosition == null) {
         return false;
      } else {
         double distance = this.flockCreature.getDistanceSq(this.flockPosition.xCoord, this.flockPosition.yCoord, this.flockPosition.zCoord);
         return distance >= 25.0D && distance <= 256.0D;
      }
   }

   public void startExecuting() {
      this.moveTimer = 0;
   }

   public void resetTask() {
      this.flockPosition = null;
   }

   public void updateTask() {
      if(--this.moveTimer <= 0) {
         this.moveTimer = 10;
         this.flockCreature.getNavigator().tryMoveToXYZ(this.flockPosition.xCoord, this.flockPosition.yCoord, this.flockPosition.zCoord, this.speed);
      }

   }
}

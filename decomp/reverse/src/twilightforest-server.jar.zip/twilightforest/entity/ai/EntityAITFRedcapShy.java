package twilightforest.entity.ai;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import twilightforest.entity.EntityTFRedcap;
import twilightforest.entity.ai.EntityAITFRedcapBase;

public class EntityAITFRedcapShy extends EntityAITFRedcapBase {

   EntityLivingBase entityTarget;
   float speed;
   boolean lefty;
   double xPosition;
   double yPosition;
   double zPosition;
   double minDistance = 3.0D;
   double maxDistance = 6.0D;


   public EntityAITFRedcapShy(EntityTFRedcap entityTFRedcap, float moveSpeed) {
      super.entityObj = entityTFRedcap;
      this.speed = moveSpeed;
      this.lefty = (new Random()).nextBoolean();
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      EntityLivingBase attackTarget = super.entityObj.getAttackTarget();
      if(attackTarget != null && super.entityObj.isShy() && (double)attackTarget.getDistanceToEntity(super.entityObj) <= this.maxDistance && (double)attackTarget.getDistanceToEntity(super.entityObj) >= this.minDistance && this.isTargetLookingAtMe(attackTarget)) {
         this.entityTarget = attackTarget;
         Vec3 avoidPos = this.findCirclePoint(super.entityObj, this.entityTarget, 5.0D, this.lefty?1.0D:-1.0D);
         if(avoidPos == null) {
            return false;
         } else {
            this.xPosition = avoidPos.xCoord;
            this.yPosition = avoidPos.yCoord;
            this.zPosition = avoidPos.zCoord;
            return true;
         }
      } else {
         return false;
      }
   }

   public void startExecuting() {
      super.entityObj.getNavigator().tryMoveToXYZ(this.xPosition, this.yPosition, this.zPosition, (double)this.speed);
   }

   public boolean continueExecuting() {
      EntityLivingBase attackTarget = super.entityObj.getAttackTarget();
      if(attackTarget == null) {
         return false;
      } else if(!this.entityTarget.isEntityAlive()) {
         return false;
      } else if(super.entityObj.getNavigator().noPath()) {
         return false;
      } else {
         boolean shouldContinue = super.entityObj.isShy() && (double)attackTarget.getDistanceToEntity(super.entityObj) < this.maxDistance && (double)attackTarget.getDistanceToEntity(super.entityObj) > this.minDistance && this.isTargetLookingAtMe(attackTarget);
         return shouldContinue;
      }
   }

   public void updateTask() {
      super.entityObj.getLookHelper().setLookPositionWithEntity(this.entityTarget, 30.0F, 30.0F);
   }

   public void resetTask() {
      this.entityTarget = null;
      super.entityObj.getNavigator().clearPathEntity();
   }

   protected Vec3 findCirclePoint(Entity circler, Entity toCircle, double radius, double rotation) {
      double vecx = circler.posX - toCircle.posX;
      double vecz = circler.posZ - toCircle.posZ;
      float rangle = (float)Math.atan2(vecz, vecx);
      rangle = (float)((double)rangle + rotation);
      double dx = (double)MathHelper.cos(rangle) * radius;
      double dz = (double)MathHelper.sin(rangle) * radius;
      return Vec3.createVectorHelper(toCircle.posX + dx, circler.boundingBox.minY, toCircle.posZ + dz);
   }
}

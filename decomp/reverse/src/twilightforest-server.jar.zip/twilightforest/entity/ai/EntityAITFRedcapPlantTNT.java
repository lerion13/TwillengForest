package twilightforest.entity.ai;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import twilightforest.entity.EntityTFRedcap;
import twilightforest.entity.ai.EntityAITFRedcapBase;

public class EntityAITFRedcapPlantTNT extends EntityAITFRedcapBase {

   public EntityAITFRedcapPlantTNT(EntityTFRedcap entityTFRedcap) {
      super.entityObj = entityTFRedcap;
   }

   public boolean shouldExecute() {
      EntityLivingBase attackTarget = super.entityObj.getAttackTarget();
      return attackTarget != null && super.entityObj.getTntLeft() > 0 && super.entityObj.getDistanceSqToEntity(attackTarget) < 25.0D && !this.isTargetLookingAtMe(attackTarget) && !this.isLitTNTNearby(8) && this.findBlockTNTNearby(5) == null;
   }

   public void startExecuting() {
      int entityPosX = MathHelper.floor_double(super.entityObj.posX);
      int entityPosY = MathHelper.floor_double(super.entityObj.posY);
      int entityPosZ = MathHelper.floor_double(super.entityObj.posZ);
      super.entityObj.setCurrentItemOrArmor(0, EntityTFRedcap.heldTNT);
      if(super.entityObj.worldObj.isAirBlock(entityPosX, entityPosY, entityPosZ)) {
         super.entityObj.setTntLeft(super.entityObj.getTntLeft() - 1);
         super.entityObj.playLivingSound();
         super.entityObj.worldObj.setBlock(entityPosX, entityPosY, entityPosZ, Blocks.tnt, 0, 3);
      }

   }

   public void resetTask() {
      super.entityObj.setCurrentItemOrArmor(0, super.entityObj.getPick());
   }
}

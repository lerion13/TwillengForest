package twilightforest.entity.ai;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import twilightforest.entity.boss.EntityTFSnowQueen;

public class EntityAITFHoverThenDrop extends EntityAIBase {

   private static final float HOVER_HEIGHT = 6.0F;
   private static final float HOVER_RADIUS = 0.0F;
   private Class classTarget;
   private EntityTFSnowQueen attacker;
   private double hoverPosX;
   private double hoverPosY;
   private double hoverPosZ;
   private int hoverTimer;
   private int dropTimer;
   private int maxHoverTime;
   private int maxDropTime;
   private int seekTimer;
   private int maxSeekTime;
   private double dropY;


   public EntityAITFHoverThenDrop(EntityTFSnowQueen entityTFSnowQueen, Class class1, int hoverTime, int dropTime) {
      this.attacker = entityTFSnowQueen;
      this.classTarget = class1;
      this.setMutexBits(3);
      this.maxHoverTime = hoverTime;
      this.maxSeekTime = hoverTime;
      this.maxDropTime = dropTime;
      this.hoverTimer = 0;
   }

   public boolean shouldExecute() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      return target == null?false:(!target.isEntityAlive()?false:(this.classTarget != null && !this.classTarget.isAssignableFrom(target.getClass())?false:this.attacker.getCurrentPhase() == EntityTFSnowQueen.Phase.DROP));
   }

   public boolean continueExecuting() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      if(target != null && target.isEntityAlive()) {
         if(this.attacker.getCurrentPhase() != EntityTFSnowQueen.Phase.DROP) {
            return false;
         } else if(this.seekTimer > this.maxSeekTime) {
            return false;
         } else if(this.attacker.getDistanceSq(this.hoverPosX, this.hoverPosY, this.hoverPosZ) <= 1.0D) {
            ++this.hoverTimer;
            return true;
         } else if(this.dropTimer < this.maxDropTime) {
            return true;
         } else {
            this.attacker.incrementSuccessfulDrops();
            return false;
         }
      } else {
         return false;
      }
   }

   public void startExecuting() {
      EntityLivingBase target = this.attacker.getAttackTarget();
      if(target != null) {
         this.makeNewHoverSpot(target);
      }

   }

   public void resetTask() {
      this.hoverTimer = 0;
      this.dropTimer = 0;
   }

   public void updateTask() {
      if(this.hoverTimer > 0) {
         ++this.hoverTimer;
      } else {
         ++this.seekTimer;
      }

      if(this.hoverTimer < this.maxHoverTime) {
         double offsetX = this.hoverPosX - this.attacker.posX;
         double offsetY = this.hoverPosY - this.attacker.posY;
         double offsetZ = this.hoverPosZ - this.attacker.posZ;
         double distanceDesired = offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ;
         distanceDesired = (double)MathHelper.sqrt_double(distanceDesired);
         double velX = offsetX / distanceDesired * 0.05D;
         double velY = offsetY / distanceDesired * 0.1D;
         double velZ = offsetZ / distanceDesired * 0.05D;
         velY += 0.05000000074505806D;
         this.attacker.addVelocity(velX, velY, velZ);
         EntityLivingBase target = this.attacker.getAttackTarget();
         if(target != null) {
            this.attacker.faceEntity(target, 30.0F, 30.0F);
            this.attacker.getLookHelper().setLookPositionWithEntity(target, 30.0F, 30.0F);
         }
      } else {
         ++this.dropTimer;
         if(this.attacker.posY > this.dropY) {
            this.attacker.destroyBlocksInAABB(this.attacker.boundingBox.expand(1.0D, 0.5D, 1.0D));
         }
      }

   }

   private void makeNewHoverSpot(EntityLivingBase target) {
      double hx = 0.0D;
      double hy = 0.0D;
      double hz = 0.0D;
      byte tries = 100;

      for(int i = 0; i < tries; ++i) {
         hx = target.posX + (double)((this.attacker.getRNG().nextFloat() - this.attacker.getRNG().nextFloat()) * 0.0F);
         hy = target.posY + 6.0D;
         hz = target.posZ + (double)((this.attacker.getRNG().nextFloat() - this.attacker.getRNG().nextFloat()) * 0.0F);
         if(!this.isPositionOccupied(hx, hy, hz) && this.canEntitySee(this.attacker, hx, hy, hz) && this.canEntitySee(target, hx, hy, hz)) {
            break;
         }
      }

      if(tries == 99) {
         System.out.println("Found no spots, giving up");
      }

      this.hoverPosX = hx;
      this.hoverPosY = hy;
      this.hoverPosZ = hz;
      this.dropY = target.posY - 1.0D;
      this.seekTimer = 0;
   }

   private boolean isPositionOccupied(double hx, double hy, double hz) {
      float radius = this.attacker.width / 2.0F;
      AxisAlignedBB aabb = AxisAlignedBB.getBoundingBox(hx - (double)radius, hy, hz - (double)radius, hx + (double)radius, hy + (double)this.attacker.height, hz + (double)radius);
      boolean isOccupied = this.attacker.worldObj.getCollidingBoundingBoxes(this.attacker, aabb).isEmpty();
      return isOccupied;
   }

   protected boolean canEntitySee(Entity entity, double dx, double dy, double dz) {
      return entity.worldObj.rayTraceBlocks(Vec3.createVectorHelper(entity.posX, entity.posY + (double)entity.getEyeHeight(), entity.posZ), Vec3.createVectorHelper(dx, dy, dz)) == null;
   }
}

package twilightforest.entity.ai;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAITarget;

public class EntityAITFFlockTarget extends EntityAITarget {

   EntityLivingBase flockCreature;
   EntityLivingBase flockTarget;


   public EntityAITFFlockTarget(EntityCreature par1EntityLiving, boolean b) {
      super(par1EntityLiving, false);
      this.flockCreature = par1EntityLiving;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      List flockList = this.flockCreature.worldObj.getEntitiesWithinAABB(this.flockCreature.getClass(), this.flockCreature.boundingBox.expand(16.0D, 4.0D, 16.0D));
      ArrayList targetList = new ArrayList();
      Iterator randomTarget = flockList.iterator();

      while(randomTarget.hasNext()) {
         EntityLivingBase flocker = (EntityLivingBase)randomTarget.next();
         if(flocker.getAITarget() != null) {
            targetList.add(flocker.getAITarget());
         }
      }

      if(targetList.isEmpty()) {
         return false;
      } else {
         EntityLivingBase randomTarget1 = (EntityLivingBase)targetList.get(this.flockCreature.worldObj.rand.nextInt(targetList.size()));
         System.out.println("randomTarget = " + randomTarget1);
         this.flockTarget = randomTarget1;
         return this.isSuitableTarget(this.flockTarget, true);
      }
   }

   public void startExecuting() {
      super.taskOwner.setAttackTarget(this.flockTarget);
      super.startExecuting();
   }
}

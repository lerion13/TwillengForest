package twilightforest.entity.ai;

import net.minecraft.init.Blocks;
import net.minecraft.util.ChunkCoordinates;
import twilightforest.entity.EntityTFRedcap;
import twilightforest.entity.ai.EntityAITFRedcapBase;

public class EntityAITFRedcapLightTNT extends EntityAITFRedcapBase {

   private float pursueSpeed;
   private int delayTemptCounter;
   private int tntX;
   private int tntY;
   private int tntZ;


   public EntityAITFRedcapLightTNT(EntityTFRedcap hostEntity, float speed) {
      super.entityObj = hostEntity;
      this.pursueSpeed = speed;
      this.setMutexBits(3);
   }

   public boolean shouldExecute() {
      ChunkCoordinates nearbyTNT = this.findBlockTNTNearby(8);
      if(this.delayTemptCounter > 0) {
         --this.delayTemptCounter;
         return false;
      } else if(nearbyTNT != null) {
         this.tntX = nearbyTNT.posX;
         this.tntY = nearbyTNT.posY;
         this.tntZ = nearbyTNT.posZ;
         return true;
      } else {
         return false;
      }
   }

   public boolean continueExecuting() {
      return super.entityObj.worldObj.getBlock(this.tntX, this.tntY, this.tntZ) == Blocks.tnt;
   }

   public void startExecuting() {
      super.entityObj.setCurrentItemOrArmor(0, EntityTFRedcap.heldFlint);
   }

   public void resetTask() {
      super.entityObj.getNavigator().clearPathEntity();
      super.entityObj.setCurrentItemOrArmor(0, super.entityObj.getPick());
      this.delayTemptCounter = 20;
   }

   public void updateTask() {
      super.entityObj.getLookHelper().setLookPosition((double)this.tntX, (double)this.tntY, (double)this.tntZ, 30.0F, (float)super.entityObj.getVerticalFaceSpeed());
      if(super.entityObj.getDistance((double)this.tntX, (double)this.tntY, (double)this.tntZ) < 2.4D) {
         super.entityObj.playLivingSound();
         Blocks.tnt.onBlockDestroyedByPlayer(super.entityObj.worldObj, this.tntX, this.tntY, this.tntZ, 1);
         super.entityObj.worldObj.setBlock(this.tntX, this.tntY, this.tntZ, Blocks.air, 0, 2);
         super.entityObj.getNavigator().clearPathEntity();
      } else {
         super.entityObj.getNavigator().tryMoveToXYZ((double)this.tntX, (double)this.tntY, (double)this.tntZ, (double)this.pursueSpeed);
      }

   }
}

package twilightforest.entity.ai;

import net.minecraft.entity.ai.EntityAIBase;
import twilightforest.entity.boss.EntityTFYetiAlpha;

public class EntityAITFYetiTired extends EntityAIBase {

   private EntityTFYetiAlpha yeti;
   private int tiredDuration;
   private int tiredTimer;


   public EntityAITFYetiTired(EntityTFYetiAlpha entityTFYetiAlpha, int i) {
      this.yeti = entityTFYetiAlpha;
      this.tiredDuration = i;
      this.setMutexBits(5);
   }

   public boolean shouldExecute() {
      return this.yeti.isTired();
   }

   public boolean continueExecuting() {
      return this.tiredTimer < this.tiredDuration;
   }

   public boolean isInterruptible() {
      return false;
   }

   public void startExecuting() {
      this.tiredTimer = 0;
   }

   public void resetTask() {
      this.tiredTimer = 0;
      this.yeti.setTired(false);
   }

   public void updateTask() {
      ++this.tiredTimer;
   }
}

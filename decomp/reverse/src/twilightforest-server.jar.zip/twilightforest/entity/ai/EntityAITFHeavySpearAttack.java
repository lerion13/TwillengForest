package twilightforest.entity.ai;

import net.minecraft.entity.ai.EntityAIBase;
import twilightforest.entity.EntityTFGoblinKnightUpper;

public class EntityAITFHeavySpearAttack extends EntityAIBase {

   private EntityTFGoblinKnightUpper entity;


   public EntityAITFHeavySpearAttack(EntityTFGoblinKnightUpper par1EntityCreature) {
      this.entity = par1EntityCreature;
      this.setMutexBits(7);
   }

   public boolean shouldExecute() {
      return this.entity.heavySpearTimer > 0 && this.entity.heavySpearTimer < 50;
   }

   public boolean continueExecuting() {
      return this.entity.heavySpearTimer > 0 && this.entity.heavySpearTimer < 50;
   }
}

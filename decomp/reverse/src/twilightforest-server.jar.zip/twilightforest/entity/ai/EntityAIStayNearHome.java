package twilightforest.entity.ai;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.util.Vec3;

public class EntityAIStayNearHome extends EntityAIBase {

   private EntityCreature entity;
   private float speed;


   public EntityAIStayNearHome(EntityCreature entityTFYetiAlpha, float sp) {
      this.entity = entityTFYetiAlpha;
      this.speed = sp;
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      boolean isOutOfRange = !this.entity.isWithinHomeDistanceCurrentPosition();
      return isOutOfRange;
   }

   public boolean continueExecuting() {
      return !this.entity.getNavigator().noPath();
   }

   public void startExecuting() {
      if(this.entity.getDistanceSq((double)this.entity.getHomePosition().posX, (double)this.entity.getHomePosition().posY, (double)this.entity.getHomePosition().posZ) > 256.0D) {
         Vec3 vec3 = RandomPositionGenerator.findRandomTargetBlockTowards(this.entity, 14, 3, Vec3.createVectorHelper((double)this.entity.getHomePosition().posX + 0.5D, (double)this.entity.getHomePosition().posY, (double)this.entity.getHomePosition().posZ + 0.5D));
         if(vec3 != null) {
            this.entity.getNavigator().tryMoveToXYZ(vec3.xCoord, vec3.yCoord, vec3.zCoord, (double)this.speed);
         }
      } else {
         this.entity.getNavigator().tryMoveToXYZ((double)this.entity.getHomePosition().posX + 0.5D, (double)this.entity.getHomePosition().posY, (double)this.entity.getHomePosition().posZ + 0.5D, (double)this.speed);
      }

   }
}

package twilightforest.entity.ai;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import twilightforest.entity.EntityTFRedcap;

public class EntityAITFAvoidFrontalAttack extends EntityAIBase {

   EntityLivingBase entityTarget;
   EntityLiving me;
   float speed;
   boolean lefty;
   double xPosition;
   double yPosition;
   double zPosition;
   double minDistance = 3.0D;
   double maxDistance = 6.0D;


   public EntityAITFAvoidFrontalAttack(EntityTFRedcap entityTFRedcap, float moveSpeed) {
      this.me = entityTFRedcap;
      this.speed = moveSpeed;
      this.lefty = this.me.worldObj.rand.nextBoolean();
      this.setMutexBits(1);
   }

   public boolean shouldExecute() {
      EntityLivingBase attackTarget = this.me.getAttackTarget();
      if(attackTarget != null && (double)attackTarget.getDistanceToEntity(this.me) <= this.maxDistance && (double)attackTarget.getDistanceToEntity(this.me) >= this.minDistance && this.isTargetLookingAtMe(attackTarget)) {
         this.entityTarget = attackTarget;
         Vec3 avoidPos = this.findCirclePoint(this.me, this.entityTarget, 5.0D, this.lefty?1.0D:-1.0D);
         if(avoidPos == null) {
            return false;
         } else {
            this.xPosition = avoidPos.xCoord;
            this.yPosition = avoidPos.yCoord;
            this.zPosition = avoidPos.zCoord;
            return true;
         }
      } else {
         return false;
      }
   }

   public void startExecuting() {
      this.me.getNavigator().tryMoveToXYZ(this.xPosition, this.yPosition, this.zPosition, (double)this.speed);
   }

   public boolean continueExecuting() {
      EntityLivingBase attackTarget = this.me.getAttackTarget();
      if(attackTarget == null) {
         return false;
      } else if(!this.entityTarget.isEntityAlive()) {
         return false;
      } else if(this.me.getNavigator().noPath()) {
         return false;
      } else {
         boolean shouldContinue = (double)attackTarget.getDistanceToEntity(this.me) < this.maxDistance && (double)attackTarget.getDistanceToEntity(this.me) > this.minDistance && this.isTargetLookingAtMe(attackTarget);
         return shouldContinue;
      }
   }

   public void updateTask() {
      this.me.getLookHelper().setLookPositionWithEntity(this.entityTarget, 30.0F, 30.0F);
   }

   public void resetTask() {
      this.entityTarget = null;
      this.me.getNavigator().clearPathEntity();
   }

   protected Vec3 findCirclePoint(Entity circler, Entity toCircle, double radius, double rotation) {
      double vecx = circler.posX - toCircle.posX;
      double vecz = circler.posZ - toCircle.posZ;
      float rangle = (float)Math.atan2(vecz, vecx);
      rangle = (float)((double)rangle + rotation);
      double dx = (double)MathHelper.cos(rangle) * radius;
      double dz = (double)MathHelper.sin(rangle) * radius;
      return Vec3.createVectorHelper(toCircle.posX + dx, circler.boundingBox.minY, toCircle.posZ + dz);
   }

   public boolean isTargetLookingAtMe(EntityLivingBase attackTarget) {
      double dx = this.me.posX - attackTarget.posX;
      double dz = this.me.posZ - attackTarget.posZ;
      float angle = (float)(Math.atan2(dz, dx) * 180.0D / 3.1415927410125732D) - 90.0F;
      float difference = MathHelper.abs((attackTarget.rotationYaw - angle) % 360.0F);
      return difference < 60.0F || difference > 300.0F;
   }
}

package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFGoblinKnightUpper;
import twilightforest.entity.ai.EntityAITFRiderSpearAttack;
import twilightforest.item.TFItems;

public class EntityTFGoblinKnightLower extends EntityMob {

   private static final int DATA_EQUIP = 17;


   public EntityTFGoblinKnightLower(World par1World) {
      super(par1World);
      this.setSize(0.7F, 1.1F);
      super.tasks.addTask(0, new EntityAITFRiderSpearAttack(this));
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
      this.setHasArmor(true);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   public boolean hasArmor() {
      return (super.dataWatcher.getWatchableObjectByte(17) & 1) > 0;
   }

   public void setHasArmor(boolean flag) {
      byte otherFlags = super.dataWatcher.getWatchableObjectByte(17);
      otherFlags = (byte)(otherFlags & 126);
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)(otherFlags | 1)));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf(otherFlags));
      }

   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("hasArmor", this.hasArmor());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setHasArmor(par1NBTTagCompound.getBoolean("hasArmor"));
   }

   public void initCreature() {
      EntityTFGoblinKnightUpper upper = new EntityTFGoblinKnightUpper(super.worldObj);
      upper.setLocationAndAngles(super.posX, super.posY, super.posZ, super.rotationYaw, 0.0F);
      upper.onSpawnWithEgg((IEntityLivingData)null);
      super.worldObj.spawnEntityInWorld(upper);
      upper.mountEntity(this);
   }

   public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData) {
      IEntityLivingData par1EntityLivingData1 = super.onSpawnWithEgg(par1EntityLivingData);
      EntityTFGoblinKnightUpper upper = new EntityTFGoblinKnightUpper(super.worldObj);
      upper.setLocationAndAngles(super.posX, super.posY, super.posZ, super.rotationYaw, 0.0F);
      upper.onSpawnWithEgg((IEntityLivingData)null);
      super.worldObj.spawnEntityInWorld(upper);
      upper.mountEntity(this);
      return (IEntityLivingData)par1EntityLivingData1;
   }

   public double getMountedYOffset() {
      return 1.0D;
   }

   public void onUpdate() {
      if(this.isEntityAlive() && super.riddenByEntity != null && super.riddenByEntity instanceof EntityLiving && this.getAttackTarget() == null) {
         this.setAttackTarget(((EntityLiving)super.riddenByEntity).getAttackTarget());
      }

      super.onUpdate();
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      return super.riddenByEntity != null && super.riddenByEntity instanceof EntityLiving?((EntityLiving)super.riddenByEntity).attackEntityAsMob(par1Entity):super.attackEntityAsMob(par1Entity);
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float damageAmount) {
      Entity attacker = null;
      if(par1DamageSource.getSourceOfDamage() != null) {
         attacker = par1DamageSource.getSourceOfDamage();
      }

      if(par1DamageSource.getEntity() != null) {
         attacker = par1DamageSource.getEntity();
      }

      if(attacker != null) {
         double attackSuccess = super.posX - attacker.posX;
         double dz = super.posZ - attacker.posZ;
         float angle = (float)(Math.atan2(dz, attackSuccess) * 180.0D / 3.141592653589793D) - 90.0F;
         float difference = MathHelper.abs((super.renderYawOffset - angle) % 360.0F);
         EntityTFGoblinKnightUpper upper = null;
         if(super.riddenByEntity != null && super.riddenByEntity instanceof EntityTFGoblinKnightUpper) {
            upper = (EntityTFGoblinKnightUpper)super.riddenByEntity;
         }

         if(upper != null && upper.hasShield() && difference > 150.0F && difference < 230.0F && upper.takeHitOnShield(par1DamageSource, damageAmount)) {
            return false;
         }

         if(this.hasArmor() && (difference > 300.0F || difference < 60.0F)) {
            this.breakArmor();
         }
      }

      boolean attackSuccess1 = super.attackEntityFrom(par1DamageSource, damageAmount);
      return attackSuccess1;
   }

   public void breakArmor() {
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.setHasArmor(false);
   }

   public int getTotalArmorValue() {
      int armor = super.getTotalArmorValue();
      if(this.hasArmor()) {
         armor += 17;
      }

      if(armor > 20) {
         armor = 20;
      }

      return armor;
   }

   protected Item getDropItemId() {
      return TFItems.armorShard;
   }
}

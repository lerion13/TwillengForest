package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TwilightForestMod;
import twilightforest.block.TFBlocks;

public class EntityTFIceExploder extends EntityMob {

   private static final float EXPLOSION_RADIUS = 1.0F;


   public EntityTFIceExploder(World par1World) {
      super(par1World);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(3, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.setSize(0.8F, 1.8F);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23000000417232513D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected Item getDropItem() {
      return Items.snowball;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();

      for(int i = 0; i < 3; ++i) {
         float px = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         float py = this.getEyeHeight() + (super.rand.nextFloat() - super.rand.nextFloat()) * 0.5F;
         float pz = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowguardian", super.lastTickPosX + (double)px, super.lastTickPosY + (double)py, super.lastTickPosZ + (double)pz, 0.0D, 0.0D, 0.0D);
      }

   }

   protected String getLivingSound() {
      return "TwilightForest:mob.ice.noise";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.ice.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.ice.death";
   }

   public float getEyeHeight() {
      return super.height * 0.6F;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   protected void onDeathUpdate() {
      ++super.deathTime;
      if(super.deathTime == 60) {
         boolean flag = super.worldObj.getGameRules().getGameRuleBooleanValue("mobGriefing");
         super.worldObj.createExplosion(this, super.posX, super.posY, super.posZ, 1.0F, flag);
         if(flag) {
            this.detonate();
         }

         int i;
         if(!super.worldObj.isRemote && (super.recentlyHit > 0 || this.isPlayer()) && this.func_146066_aG() && super.worldObj.getGameRules().getGameRuleBooleanValue("doMobLoot")) {
            i = this.getExperiencePoints(super.attackingPlayer);

            while(i > 0) {
               int d2 = EntityXPOrb.getXPSplit(i);
               i -= d2;
               super.worldObj.spawnEntityInWorld(new EntityXPOrb(super.worldObj, super.posX, super.posY, super.posZ, d2));
            }
         }

         this.setDead();

         for(i = 0; i < 20; ++i) {
            double var9 = super.rand.nextGaussian() * 0.02D;
            double d0 = super.rand.nextGaussian() * 0.02D;
            double d1 = super.rand.nextGaussian() * 0.02D;
            super.worldObj.spawnParticle("explode", super.posX + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, super.posY + (double)(super.rand.nextFloat() * super.height), super.posZ + (double)(super.rand.nextFloat() * super.width * 2.0F) - (double)super.width, var9, d0, d1);
         }
      }

   }

   private void detonate() {
      byte range = 4;
      int sx = MathHelper.floor_double(super.posX);
      int sy = MathHelper.floor_double(super.posY);
      int sz = MathHelper.floor_double(super.posZ);

      for(int dx = -range; dx <= range; ++dx) {
         for(int dy = -range; dy <= range; ++dy) {
            for(int dz = -range; dz <= range; ++dz) {
               double distance = Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
               float randRange = (float)range + (super.rand.nextFloat() - super.rand.nextFloat()) * 2.0F;
               if(distance < (double)randRange) {
                  this.transformBlock(sx + dx, sy + dy, sz + dz);
               }
            }
         }
      }

   }

   private void transformBlock(int x, int y, int z) {
      Block block = super.worldObj.getBlock(x, y, z);
      int meta = super.worldObj.getBlockMetadata(x, y, z);
      if(block.getExplosionResistance(this) < 8.0F && block.getBlockHardness(super.worldObj, x, y, z) >= 0.0F) {
         int blockColor = 16777215;

         try {
            blockColor = block.colorMultiplier(super.worldObj, x, y, z);
         } catch (NoSuchMethodError var8) {
            ;
         }

         if(blockColor == 16777215) {
            blockColor = block.getMapColor(meta).colorValue;
         }

         if(this.shouldTransformGlass(block, x, y, z)) {
            super.worldObj.setBlock(x, y, z, Blocks.stained_glass, this.getMetaForColor(blockColor), 3);
         } else if(this.shouldTransformClay(block, x, y, z)) {
            super.worldObj.setBlock(x, y, z, Blocks.stained_hardened_clay, this.getMetaForColor(blockColor), 3);
         }
      }

   }

   private boolean shouldTransformClay(Block block, int x, int y, int z) {
      return block.isNormalCube(super.worldObj, x, y, z);
   }

   private boolean shouldTransformGlass(Block block, int x, int y, int z) {
      return block != Blocks.air && this.isBlockNormalBounds(block, x, y, z) && (!block.getMaterial().isOpaque() || block.isLeaves(super.worldObj, x, y, z) || block == Blocks.ice || block == TFBlocks.auroraBlock);
   }

   private boolean isBlockNormalBounds(Block block, int x, int y, int z) {
      return block.getBlockBoundsMaxX() == 1.0D && block.getBlockBoundsMaxY() == 1.0D && block.getBlockBoundsMaxZ() == 1.0D && block.getBlockBoundsMinX() == 0.0D && block.getBlockBoundsMinY() == 0.0D && block.getBlockBoundsMinZ() == 0.0D;
   }

   private int getMetaForColor(int blockColor) {
      int red = blockColor >> 16 & 255;
      int green = blockColor >> 8 & 255;
      int blue = blockColor & 255;
      int bestColor = 0;
      int bestDifference = 1024;

      for(int i = 0; i < 15; ++i) {
         int iColor = Blocks.wool.getMapColor(i).colorValue;
         int iRed = iColor >> 16 & 255;
         int iGreen = iColor >> 8 & 255;
         int iBlue = iColor & 255;
         int difference = Math.abs(red - iRed) + Math.abs(green - iGreen) + Math.abs(blue - iBlue);
         if(difference < bestDifference) {
            bestColor = i;
            bestDifference = difference;
         }
      }

      return bestColor;
   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }
}

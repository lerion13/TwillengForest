package twilightforest.entity.passive;

import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.entity.ai.EntityAITFEatLoose;
import twilightforest.entity.ai.EntityAITFFindLoose;
import twilightforest.item.TFItems;

public class EntityTFQuestRam extends EntityAnimal {

   private int randomTickDivider;


   public EntityTFQuestRam(World par1World) {
      super(par1World);
      this.setSize(1.25F, 2.9F);
      this.randomTickDivider = 0;
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIPanic(this, 1.3799999952316284D));
      super.tasks.addTask(2, new EntityAITempt(this, 1.0D, Item.getItemFromBlock(Blocks.wool), false));
      super.tasks.addTask(3, new EntityAITFEatLoose(this, Item.getItemFromBlock(Blocks.wool)));
      super.tasks.addTask(4, new EntityAITFFindLoose(this, 1.0F, Item.getItemFromBlock(Blocks.wool)));
      super.tasks.addTask(5, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(6, new EntityAILookIdle(this));
   }

   public EntityAnimal createChild(EntityAgeable entityanimal) {
      return null;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(70.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23000000417232513D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(16, Integer.valueOf(0));
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   public boolean isAIEnabled() {
      return true;
   }

   protected boolean canDespawn() {
      return false;
   }

   protected void updateAITick() {
      if(--this.randomTickDivider <= 0) {
         this.randomTickDivider = 70 + super.rand.nextInt(50);
         int chunkX = MathHelper.floor_double(super.posX) / 16;
         int chunkZ = MathHelper.floor_double(super.posZ) / 16;
         TFFeature nearFeature = TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj);
         if(nearFeature != TFFeature.questGrove) {
            this.detachHome();
         } else {
            ChunkCoordinates cc = TFFeature.getNearestCenterXYZ(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posZ), super.worldObj);
            this.setHomeArea(cc.posX, cc.posY, cc.posZ, 13);
         }

         if(this.countColorsSet() > 15 && !this.getRewarded()) {
            this.rewardQuest();
            this.setRewarded(true);
         }
      }

      super.updateAITick();
   }

   private void rewardQuest() {
      this.func_145778_a(Item.getItemFromBlock(Blocks.diamond_block), 1, 1.0F);
      this.func_145778_a(Item.getItemFromBlock(Blocks.iron_block), 1, 1.0F);
      this.func_145778_a(Item.getItemFromBlock(Blocks.emerald_block), 1, 1.0F);
      this.func_145778_a(Item.getItemFromBlock(Blocks.gold_block), 1, 1.0F);
      this.func_145778_a(Item.getItemFromBlock(Blocks.lapis_block), 1, 1.0F);
      this.func_145778_a(TFItems.crumbleHorn, 1, 1.0F);
      this.rewardNearbyPlayers(super.worldObj, super.posX, super.posY, super.posZ);
   }

   private void rewardNearbyPlayers(World world, double posX, double posY, double posZ) {
      List nearbyPlayers = world.getEntitiesWithinAABB(EntityPlayer.class, AxisAlignedBB.getBoundingBox(posX, posY, posZ, posX + 1.0D, posY + 1.0D, posZ + 1.0D).expand(16.0D, 16.0D, 16.0D));
      Iterator var9 = nearbyPlayers.iterator();

      while(var9.hasNext()) {
         EntityPlayer player = (EntityPlayer)var9.next();
         player.triggerAchievement(TFAchievementPage.twilightQuestRam);
      }

   }

   public boolean interact(EntityPlayer par1EntityPlayer) {
      ItemStack currentItem = par1EntityPlayer.inventory.getCurrentItem();
      if(currentItem != null && currentItem.getItem() == Item.getItemFromBlock(Blocks.wool) && !this.isColorPresent(currentItem.getItemDamage())) {
         this.setColorPresent(currentItem.getItemDamage());
         this.animateAddColor(currentItem.getItemDamage(), 50);
         if(!par1EntityPlayer.capabilities.isCreativeMode) {
            --currentItem.stackSize;
            if(currentItem.stackSize <= 0) {
               par1EntityPlayer.inventory.setInventorySlotContents(par1EntityPlayer.inventory.currentItem, (ItemStack)null);
            }
         }

         return true;
      } else {
         return super.interact(par1EntityPlayer);
      }
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      this.checkAndAnimateColors();
   }

   public void checkAndAnimateColors() {
      if(this.countColorsSet() > 15 && !this.getRewarded()) {
         this.animateAddColor(super.rand.nextInt(16), 5);
      }

   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("ColorFlags", this.getColorFlags());
      par1NBTTagCompound.setBoolean("Rewarded", this.getRewarded());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setColorFlags(par1NBTTagCompound.getInteger("ColorFlags"));
      this.setRewarded(par1NBTTagCompound.getBoolean("Rewarded"));
   }

   public int getColorFlags() {
      return super.dataWatcher.getWatchableObjectInt(16);
   }

   public void setColorFlags(int par1) {
      super.dataWatcher.updateObject(16, Integer.valueOf(par1));
   }

   public boolean isColorPresent(int color) {
      int flags = this.getColorFlags();
      return (flags & (int)Math.pow(2.0D, (double)color)) > 0;
   }

   public void setColorPresent(int color) {
      int flags = this.getColorFlags();
      this.setColorFlags(flags | (int)Math.pow(2.0D, (double)color));
   }

   public boolean getRewarded() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setRewarded(boolean par1) {
      super.dataWatcher.updateObject(17, par1?Byte.valueOf((byte)1):Byte.valueOf((byte)0));
   }

   public void animateAddColor(int color, int iterations) {
      for(int i = 0; i < iterations; ++i) {
         super.worldObj.spawnParticle("mobSpell", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width * 1.5D, super.posY + super.rand.nextDouble() * (double)super.height * 1.5D, super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width * 1.5D, (double)EntitySheep.fleeceColorTable[color][0], (double)EntitySheep.fleeceColorTable[color][1], (double)EntitySheep.fleeceColorTable[color][2]);
      }

      this.playLivingSound();
   }

   public int countColorsSet() {
      int count = 0;

      for(int i = 0; i < 16; ++i) {
         if(this.isColorPresent(i)) {
            ++count;
         }
      }

      return count;
   }

   public void playLivingSound() {
      super.worldObj.playSoundAtEntity(this, "mob.sheep.say", this.getSoundVolume(), this.getSoundPitch());
   }

   protected float getSoundVolume() {
      return 5.0F;
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.7F;
   }

   protected String getLivingSound() {
      return "mob.sheep.say";
   }

   protected String getHurtSound() {
      return "mob.sheep.say";
   }

   protected String getDeathSound() {
      return "mob.sheep.say";
   }

   protected void func_145780_a(int p_145780_1_, int p_145780_2_, int p_145780_3_, Block p_145780_4_) {
      this.playSound("mob.sheep.step", 0.15F, 1.0F);
   }

   public float getMaximumHomeDistance() {
      return this.func_110174_bM();
   }
}

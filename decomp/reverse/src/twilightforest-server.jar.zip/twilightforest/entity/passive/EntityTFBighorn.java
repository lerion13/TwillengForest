package twilightforest.entity.passive;

import java.util.Random;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;

public class EntityTFBighorn extends EntitySheep {

   public EntityTFBighorn(World world) {
      super(world);
      this.setSize(0.9F, 1.3F);
   }

   public EntityTFBighorn(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   public static int getRandomFleeceColor(Random random) {
      return random.nextInt(2) == 0?12:random.nextInt(15);
   }

   public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData) {
      par1EntityLivingData = super.onSpawnWithEgg(par1EntityLivingData);
      this.setFleeceColor(getRandomFleeceColor(super.worldObj.rand));
      return par1EntityLivingData;
   }

   public EntitySheep createChild(EntityAgeable entityanimal) {
      EntityTFBighorn otherParent = (EntityTFBighorn)entityanimal;
      EntityTFBighorn babySheep = new EntityTFBighorn(super.worldObj);
      if(super.rand.nextBoolean()) {
         babySheep.setFleeceColor(this.getFleeceColor());
      } else {
         babySheep.setFleeceColor(otherParent.getFleeceColor());
      }

      return babySheep;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }
}

package twilightforest.entity.passive;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityTFMobileFirefly extends EntityAmbientCreature {

   private ChunkCoordinates currentFlightTarget;


   public EntityTFMobileFirefly(World par1World) {
      super(par1World);
      this.setSize(0.5F, 0.5F);
   }

   protected float getSoundVolume() {
      return 0.1F;
   }

   protected float getSoundPitch() {
      return super.getSoundPitch() * 0.95F;
   }

   protected String getHurtSound() {
      return "mob.bat.hurt";
   }

   protected String getDeathSound() {
      return "mob.bat.death";
   }

   public boolean canBePushed() {
      return false;
   }

   protected void collideWithEntity(Entity par1Entity) {}

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(6.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   public void onUpdate() {
      super.onUpdate();
      super.motionY *= 0.6000000238418579D;
   }

   protected void updateAITasks() {
      super.updateAITasks();
      if(this.currentFlightTarget != null && (!super.worldObj.isAirBlock(this.currentFlightTarget.posX, this.currentFlightTarget.posY, this.currentFlightTarget.posZ) || this.currentFlightTarget.posY < 1)) {
         this.currentFlightTarget = null;
      }

      if(this.currentFlightTarget == null || super.rand.nextInt(30) == 0 || this.currentFlightTarget.getDistanceSquared((int)super.posX, (int)super.posY, (int)super.posZ) < 4.0F) {
         this.currentFlightTarget = new ChunkCoordinates((int)super.posX + super.rand.nextInt(7) - super.rand.nextInt(7), (int)super.posY + super.rand.nextInt(6) - 2, (int)super.posZ + super.rand.nextInt(7) - super.rand.nextInt(7));
      }

      double var1 = (double)this.currentFlightTarget.posX + 0.5D - super.posX;
      double var3 = (double)this.currentFlightTarget.posY + 0.1D - super.posY;
      double var5 = (double)this.currentFlightTarget.posZ + 0.5D - super.posZ;
      double speed = 0.05000000149011612D;
      super.motionX += (Math.signum(var1) * 0.5D - super.motionX) * speed;
      super.motionY += (Math.signum(var3) * 0.699999988079071D - super.motionY) * speed * 2.0D;
      super.motionZ += (Math.signum(var5) * 0.5D - super.motionZ) * speed;
      float var7 = (float)(Math.atan2(super.motionZ, super.motionX) * 180.0D / 3.141592653589793D) - 90.0F;
      float var8 = MathHelper.wrapAngleTo180_float(var7 - super.rotationYaw);
      super.moveForward = 0.5F;
      super.rotationYaw += var8;
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   protected void fall(float par1) {}

   protected void updateFallState(double par1, boolean par3) {}

   public boolean doesEntityNotTriggerPressurePlate() {
      return true;
   }

   public boolean getCanSpawnHere() {
      int var1 = MathHelper.floor_double(super.boundingBox.minY);
      if(var1 >= 63) {
         return false;
      } else {
         int var2 = MathHelper.floor_double(super.posX);
         int var3 = MathHelper.floor_double(super.posZ);
         int var4 = super.worldObj.getBlockLightValue(var2, var1, var3);
         byte var5 = 4;
         return var4 > super.rand.nextInt(var5)?false:super.getCanSpawnHere();
      }
   }

   @SideOnly(Side.CLIENT)
   public int getBrightnessForRender(float par1) {
      return 15728880;
   }

   public float getGlowBrightness() {
      return (float)Math.sin((double)super.ticksExisted / 7.0D) + 1.0F;
   }
}

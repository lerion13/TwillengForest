package twilightforest.entity.passive;

import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;

public class EntityTFSquirrel extends EntityCreature implements IAnimals {

   public EntityTFSquirrel(World par1World) {
      super(par1World);
      this.setSize(0.3F, 0.7F);
      super.stepHeight = 1.0F;
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIPanic(this, 1.3799999952316284D));
      super.tasks.addTask(2, new EntityAITempt(this, 1.0D, Items.wheat_seeds, true));
      super.tasks.addTask(3, new EntityAIAvoidEntity(this, EntityPlayer.class, 2.0F, 0.800000011920929D, 1.399999976158142D));
      super.tasks.addTask(5, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(6, new EntityAIWander(this, 1.25D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      super.tasks.addTask(8, new EntityAILookIdle(this));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3D);
   }

   protected void fall(float par1) {}

   public boolean isAIEnabled() {
      return true;
   }

   public float getRenderSizeModifier() {
      return 0.3F;
   }

   public float getBlockPathWeight(int par1, int par2, int par3) {
      Material underMaterial = super.worldObj.getBlock(par1, par2 - 1, par3).getMaterial();
      return underMaterial == Material.leaves?12.0F:(underMaterial == Material.wood?15.0F:(underMaterial == Material.grass?10.0F:super.worldObj.getLightBrightness(par1, par2, par3) - 0.5F));
   }

   protected boolean canDespawn() {
      return false;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }
}

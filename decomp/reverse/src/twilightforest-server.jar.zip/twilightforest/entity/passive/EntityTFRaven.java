package twilightforest.entity.passive;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityLookHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import twilightforest.entity.ai.EntityTFRavenLookHelper;
import twilightforest.entity.passive.EntityTFTinyBird;
import twilightforest.item.TFItems;

public class EntityTFRaven extends EntityTFTinyBird {

   EntityTFRavenLookHelper ravenLook = new EntityTFRavenLookHelper(this);


   public EntityTFRaven(World par1World) {
      super(par1World);
      this.setSize(0.3F, 0.7F);
      super.stepHeight = 1.0F;
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIPanic(this, 1.5D));
      super.tasks.addTask(2, new EntityAITempt(this, 0.8500000238418579D, Items.wheat_seeds, true));
      super.tasks.addTask(5, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.20000001192092895D);
   }

   protected void updateAITasks() {
      super.updateAITasks();
      this.ravenLook.onUpdateLook();
   }

   public EntityLookHelper getLookHelper() {
      return this.ravenLook;
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.raven.caw";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.raven.squawk";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.raven.squawk";
   }

   protected Item getDropItem() {
      return TFItems.feather;
   }

   public float getRenderSizeModifier() {
      return 0.3F;
   }

   public boolean isSpooked() {
      return super.hurtTime > 0;
   }
}

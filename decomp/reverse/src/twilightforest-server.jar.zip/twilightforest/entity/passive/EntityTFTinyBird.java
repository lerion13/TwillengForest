package twilightforest.entity.passive;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ForgeDirection;
import twilightforest.TFAchievementPage;
import twilightforest.entity.ai.EntityAITFBirdFly;
import twilightforest.entity.passive.EntityTFBird;

public class EntityTFTinyBird extends EntityTFBird {

   private static final int DATA_BIRDTYPE = 16;
   private static final int DATA_BIRDFLAGS = 17;
   private ChunkCoordinates currentFlightTarget;
   private int currentFlightTime;


   public EntityTFTinyBird(World par1World) {
      super(par1World);
      this.setSize(0.5F, 0.9F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(0, new EntityAITFBirdFly(this));
      super.tasks.addTask(1, new EntityAITempt(this, 1.0D, Items.wheat_seeds, true));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      super.tasks.addTask(4, new EntityAILookIdle(this));
      this.setBirdType(super.rand.nextInt(4));
      this.setIsBirdLanded(true);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(16, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(1.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.20000001192092895D);
   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setInteger("BirdType", this.getBirdType());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setBirdType(par1NBTTagCompound.getInteger("BirdType"));
   }

   public int getBirdType() {
      return super.dataWatcher.getWatchableObjectByte(16);
   }

   public void setBirdType(int par1) {
      super.dataWatcher.updateObject(16, Byte.valueOf((byte)par1));
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.tinybird.chirp";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.tinybird.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.tinybird.hurt";
   }

   public float getRenderSizeModifier() {
      return 0.3F;
   }

   protected boolean canDespawn() {
      return false;
   }

   public float getBlockPathWeight(int par1, int par2, int par3) {
      Material underMaterial = super.worldObj.getBlock(par1, par2 - 1, par3).getMaterial();
      return underMaterial == Material.leaves?200.0F:(underMaterial == Material.wood?15.0F:(underMaterial == Material.grass?9.0F:super.worldObj.getLightBrightness(par1, par2, par3) - 0.5F));
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public void onUpdate() {
      super.onUpdate();
      if(!this.isBirdLanded()) {
         super.motionY *= 0.6000000238418579D;
      }

   }

   protected void updateAITasks() {
      super.updateAITasks();
      if(this.isBirdLanded()) {
         this.currentFlightTime = 0;
         if(super.rand.nextInt(200) == 0 && !this.isLandableBlock(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posY - 1.0D), MathHelper.floor_double(super.posZ))) {
            this.setIsBirdLanded(false);
            super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
            super.motionY = 0.4D;
         } else if(this.isSpooked()) {
            this.setIsBirdLanded(false);
            super.motionY = 0.4D;
            super.worldObj.playAuxSFXAtEntity((EntityPlayer)null, 1015, (int)super.posX, (int)super.posY, (int)super.posZ, 0);
         }
      } else {
         ++this.currentFlightTime;
         if(this.currentFlightTarget != null && (!super.worldObj.isAirBlock(this.currentFlightTarget.posX, this.currentFlightTarget.posY, this.currentFlightTarget.posZ) || this.currentFlightTarget.posY < 1)) {
            this.currentFlightTarget = null;
         }

         if(this.currentFlightTarget == null || super.rand.nextInt(30) == 0 || this.currentFlightTarget.getDistanceSquared((int)super.posX, (int)super.posY, (int)super.posZ) < 4.0F) {
            int d0 = this.currentFlightTime < 100?2:4;
            this.currentFlightTarget = new ChunkCoordinates((int)super.posX + super.rand.nextInt(7) - super.rand.nextInt(7), (int)super.posY + super.rand.nextInt(6) - d0, (int)super.posZ + super.rand.nextInt(7) - super.rand.nextInt(7));
         }

         double var9 = (double)this.currentFlightTarget.posX + 0.5D - super.posX;
         double d1 = (double)this.currentFlightTarget.posY + 0.1D - super.posY;
         double d2 = (double)this.currentFlightTarget.posZ + 0.5D - super.posZ;
         super.motionX += (Math.signum(var9) * 0.5D - super.motionX) * 0.10000000149011612D;
         super.motionY += (Math.signum(d1) * 0.699999988079071D - super.motionY) * 0.10000000149011612D;
         super.motionZ += (Math.signum(d2) * 0.5D - super.motionZ) * 0.10000000149011612D;
         float f = (float)(Math.atan2(super.motionZ, super.motionX) * 180.0D / 3.141592653589793D) - 90.0F;
         float f1 = MathHelper.wrapAngleTo180_float(f - super.rotationYaw);
         super.moveForward = 0.5F;
         super.rotationYaw += f1;
         if(super.rand.nextInt(10) == 0 && this.isLandableBlock(MathHelper.floor_double(super.posX), MathHelper.floor_double(super.posY - 1.0D), MathHelper.floor_double(super.posZ))) {
            this.setIsBirdLanded(true);
            super.motionY = 0.0D;
         }
      }

   }

   public boolean isSpooked() {
      EntityPlayer closestPlayer = super.worldObj.getClosestPlayerToEntity(this, 4.0D);
      return super.hurtTime > 0 || closestPlayer != null && (closestPlayer.inventory.getCurrentItem() == null || closestPlayer.inventory.getCurrentItem().getItem() != Items.wheat_seeds);
   }

   public boolean isLandableBlock(int x, int y, int z) {
      Block block = super.worldObj.getBlock(x, y, z);
      return block == Blocks.air?false:block.isLeaves(super.worldObj, x, y, z) || block.isSideSolid(super.worldObj, x, y, z, ForgeDirection.UP);
   }

   public boolean isBirdLanded() {
      return (super.dataWatcher.getWatchableObjectByte(17) & 1) != 0;
   }

   public void setIsBirdLanded(boolean par1) {
      byte b0 = super.dataWatcher.getWatchableObjectByte(17);
      if(par1) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)(b0 | 1)));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)(b0 & -2)));
      }

   }

   public boolean canBePushed() {
      return false;
   }

   protected void collideWithEntity(Entity par1Entity) {}

   protected void collideWithNearbyEntities() {}
}

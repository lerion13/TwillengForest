package twilightforest.entity.passive;

import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public abstract class EntityTFBird extends EntityAnimal {

   public float flapLength = 0.0F;
   public float flapIntensity = 0.0F;
   public float lastFlapIntensity;
   public float lastFlapLength;
   public float flapSpeed = 1.0F;


   public EntityTFBird(World par1World) {
      super(par1World);
   }

   public boolean isAIEnabled() {
      return true;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      this.lastFlapLength = this.flapLength;
      this.lastFlapIntensity = this.flapIntensity;
      this.flapIntensity = (float)((double)this.flapIntensity + (double)(super.onGround?-1:4) * 0.3D);
      if(this.flapIntensity < 0.0F) {
         this.flapIntensity = 0.0F;
      }

      if(this.flapIntensity > 1.0F) {
         this.flapIntensity = 1.0F;
      }

      if(!super.onGround && this.flapSpeed < 1.0F) {
         this.flapSpeed = 1.0F;
      }

      this.flapSpeed = (float)((double)this.flapSpeed * 0.9D);
      if(!super.onGround && super.motionY < 0.0D) {
         super.motionY *= 0.6D;
      }

      this.flapLength += this.flapSpeed * 2.0F;
   }

   protected void fall(float par1) {}

   protected boolean canTriggerWalking() {
      return false;
   }

   protected Item getDropItem() {
      return Items.feather;
   }

   public EntityAnimal createChild(EntityAgeable entityanimal) {
      return null;
   }

   public boolean isBirdLanded() {
      return true;
   }
}

package twilightforest.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.block.TFBlocks;

public class EntityTFTowerGolem extends EntityMob {

   private int attackTimer;


   public EntityTFTowerGolem(World par1World) {
      super(par1World);
      this.setSize(1.4F, 2.9F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 6.0F));
      super.tasks.addTask(3, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(9.0D);
   }

   public int getTotalArmorValue() {
      int var1 = super.getTotalArmorValue() + 2;
      if(var1 > 20) {
         var1 = 20;
      }

      return var1;
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      this.attackTimer = 10;
      super.worldObj.setEntityState(this, (byte)4);
      boolean attackSuccess = super.attackEntityAsMob(par1Entity);
      if(attackSuccess) {
         par1Entity.motionY += 0.4000000059604645D;
      }

      this.playSound("mob.irongolem.throw", 1.0F, 1.0F);
      return attackSuccess;
   }

   protected String getLivingSound() {
      return "none";
   }

   protected String getHurtSound() {
      return "mob.irongolem.hit";
   }

   protected String getDeathSound() {
      return "mob.irongolem.death";
   }

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {
      this.playSound("mob.irongolem.walk", 1.0F, 1.0F);
   }

   protected void collideWithEntity(Entity par1Entity) {
      if(par1Entity instanceof IMob && this.getRNG().nextInt(10) == 0) {
         this.setAttackTarget((EntityLivingBase)par1Entity);
      }

      super.collideWithEntity(par1Entity);
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.attackTimer > 0) {
         --this.attackTimer;
      }

      if(super.motionX * super.motionX + super.motionZ * super.motionZ > 2.500000277905201E-7D && super.rand.nextInt(5) == 0) {
         int var1 = MathHelper.floor_double(super.posX);
         int var2 = MathHelper.floor_double(super.posY - 0.20000000298023224D - (double)super.yOffset);
         int var3 = MathHelper.floor_double(super.posZ);
         Block block = super.worldObj.getBlock(var1, var2, var3);
         if(block.getMaterial() != Material.air) {
            super.worldObj.spawnParticle("blockcrack_" + Block.getIdFromBlock(block) + "_" + super.worldObj.getBlockMetadata(var1, var2, var3), super.posX + ((double)super.rand.nextFloat() - 0.5D) * (double)super.width, super.boundingBox.minY + 0.1D, super.posZ + ((double)super.rand.nextFloat() - 0.5D) * (double)super.width, 4.0D * ((double)super.rand.nextFloat() - 0.5D), 0.5D, ((double)super.rand.nextFloat() - 0.5D) * 4.0D);
         }
      }

      if(super.rand.nextBoolean()) {
         super.worldObj.spawnParticle("reddust", super.posX + (super.rand.nextDouble() - 0.5D) * (double)super.width, super.posY + super.rand.nextDouble() * (double)super.height - 0.25D, super.posZ + (super.rand.nextDouble() - 0.5D) * (double)super.width, 0.0D, 0.0D, 0.0D);
      }

   }

   @SideOnly(Side.CLIENT)
   public void handleHealthUpdate(byte par1) {
      if(par1 == 4) {
         this.attackTimer = 10;
         this.playSound("mob.irongolem.throw", 1.0F, 1.0F);
      } else {
         super.handleHealthUpdate(par1);
      }

   }

   @SideOnly(Side.CLIENT)
   public int getAttackTimer() {
      return this.attackTimer;
   }

   protected void dropFewItems(boolean par1, int par2) {
      int var4 = super.rand.nextInt(3);

      int i;
      for(i = 0; i < var4; ++i) {
         this.dropItem(Items.iron_ingot, 1);
      }

      var4 = super.rand.nextInt(3);

      for(i = 0; i < var4; ++i) {
         this.dropItem(Item.getItemFromBlock(TFBlocks.towerWood), 1);
      }

   }

   public int getMaxSpawnedInChunk() {
      return 16;
   }
}

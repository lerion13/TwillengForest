package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.ai.EntityAITFChargeAttack;
import twilightforest.item.TFItems;

public class EntityTFMinotaur extends EntityMob {

   public EntityTFMinotaur(World par1World) {
      super(par1World);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAITFChargeAttack(this, 2.0F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
      this.setCurrentItemOrArmor(0, new ItemStack(Items.golden_axe));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.25D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(7.0D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   public boolean isCharging() {
      return super.dataWatcher.getWatchableObjectByte(17) != 0;
   }

   public void setCharging(boolean flag) {
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)127));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)0));
      }

   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      boolean success = super.attackEntityAsMob(par1Entity);
      if(success && this.isCharging()) {
         par1Entity.motionY += 0.4000000059604645D;
         super.worldObj.playSoundAtEntity(this, "mob.irongolem.throw", 1.0F, 1.0F);
      }

      return success;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.isCharging()) {
         super.limbSwingAmount = (float)((double)super.limbSwingAmount + 0.6D);
      }

   }

   protected String getLivingSound() {
      return "mob.cow.say";
   }

   protected String getHurtSound() {
      return "mob.cow.hurt";
   }

   protected String getDeathSound() {
      return "mob.cow.hurt";
   }

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {
      super.worldObj.playSoundAtEntity(this, "mob.cow.step", 0.15F, 0.8F);
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.7F;
   }

   protected Item getDropItem() {
      return TFItems.meefRaw;
   }

   protected void dropFewItems(boolean par1, int par2) {
      int numDrops = super.rand.nextInt(2) + super.rand.nextInt(1 + par2);

      for(int i = 0; i < numDrops; ++i) {
         if(this.isBurning()) {
            this.dropItem(TFItems.meefSteak, 1);
         } else {
            this.dropItem(TFItems.meefRaw, 1);
         }
      }

   }

   protected void dropRareDrop(int par1) {
      this.dropItem(TFItems.mazeMapFocus, 1);
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }
}

package twilightforest.entity;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.entity.ai.EntityAITFHeavySpearAttack;
import twilightforest.item.TFItems;

public class EntityTFGoblinKnightUpper extends EntityMob {

   private static final int SHIELD_DAMAGE_THRESHOLD = 10;
   private static final int DATA_EQUIP = 17;
   public int shieldHits;
   public int heavySpearTimer;


   public EntityTFGoblinKnightUpper(World par1World) {
      super(par1World);
      this.setSize(1.1F, 1.3F);
      super.tasks.addTask(0, new EntityAITFHeavySpearAttack(this));
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
      this.setHasArmor(true);
      this.setHasShield(true);
      this.shieldHits = 0;
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
   }

   public boolean hasArmor() {
      return (super.dataWatcher.getWatchableObjectByte(17) & 1) > 0;
   }

   public void setHasArmor(boolean flag) {
      byte otherFlags = super.dataWatcher.getWatchableObjectByte(17);
      otherFlags = (byte)(otherFlags & 126);
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)(otherFlags | 1)));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf(otherFlags));
      }

   }

   public boolean hasShield() {
      return (super.dataWatcher.getWatchableObjectByte(17) & 2) > 0;
   }

   public void setHasShield(boolean flag) {
      byte otherFlags = super.dataWatcher.getWatchableObjectByte(17);
      otherFlags = (byte)(otherFlags & 125);
      if(flag) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)(otherFlags | 2)));
      } else {
         super.dataWatcher.updateObject(17, Byte.valueOf(otherFlags));
      }

   }

   public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
      super.writeEntityToNBT(par1NBTTagCompound);
      par1NBTTagCompound.setBoolean("hasArmor", this.hasArmor());
      par1NBTTagCompound.setBoolean("hasShield", this.hasShield());
   }

   public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
      super.readEntityFromNBT(par1NBTTagCompound);
      this.setHasArmor(par1NBTTagCompound.getBoolean("hasArmor"));
      this.setHasShield(par1NBTTagCompound.getBoolean("hasShield"));
   }

   public void onUpdate() {
      if(this.isEntityAlive()) {
         if(super.ridingEntity != null && super.ridingEntity instanceof EntityLiving && this.getAttackTarget() == null) {
            this.setAttackTarget(((EntityLiving)super.ridingEntity).getAttackTarget());
         }

         if(this.heavySpearTimer > 0) {
            --this.heavySpearTimer;
            if(this.heavySpearTimer == 25) {
               this.landHeavySpearAttack();
            }
         }

         if(super.ridingEntity == null && this.hasShield()) {
            this.breakShield();
         }
      }

      super.onUpdate();
   }

   private void landHeavySpearAttack() {
      Vec3 vector = this.getLookVec();
      double dist = 1.25D;
      double px = super.posX + vector.xCoord * dist;
      double py = super.boundingBox.minY - 0.75D;
      double pz = super.posZ + vector.zCoord * dist;

      for(int radius = 0; radius < 50; ++radius) {
         super.worldObj.spawnParticle("largesmoke", px, py, pz, (double)((super.rand.nextFloat() - super.rand.nextFloat()) * 0.25F), 0.0D, (double)((super.rand.nextFloat() - super.rand.nextFloat()) * 0.25F));
      }

      double var16 = 1.5D;
      AxisAlignedBB spearBB = AxisAlignedBB.getBoundingBox(px - var16, py - var16, pz - var16, px + var16, py + var16, pz + var16);
      List inBox = super.worldObj.getEntitiesWithinAABB(Entity.class, spearBB);
      Iterator var14 = inBox.iterator();

      while(var14.hasNext()) {
         Entity entity = (Entity)var14.next();
         if(super.ridingEntity != null && entity != super.ridingEntity && entity != this) {
            super.attackEntityAsMob(entity);
         }
      }

   }

   public int getAttackStrength(Entity par1Entity) {
      return this.heavySpearTimer > 0?20:8;
   }

   public void updateRidden() {
      super.updateRidden();
      if(super.ridingEntity != null) {
         super.renderYawOffset = ((EntityLiving)super.ridingEntity).renderYawOffset;
      }

   }

   @SideOnly(Side.CLIENT)
   public void handleHealthUpdate(byte par1) {
      if(par1 == 4) {
         this.heavySpearTimer = 60;
      } else {
         super.handleHealthUpdate(par1);
      }

   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      if(this.heavySpearTimer > 0) {
         return false;
      } else if(super.rand.nextInt(2) == 0) {
         this.startHeavySpearAttack();
         return false;
      } else {
         this.swingItem();
         return super.attackEntityAsMob(par1Entity);
      }
   }

   private void startHeavySpearAttack() {
      this.heavySpearTimer = 60;
      super.worldObj.setEntityState(this, (byte)4);
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float damageAmount) {
      if(par1DamageSource == DamageSource.inWall && super.ridingEntity != null) {
         return false;
      } else {
         Entity attacker = null;
         if(par1DamageSource.getSourceOfDamage() != null) {
            attacker = par1DamageSource.getSourceOfDamage();
         }

         if(par1DamageSource.getEntity() != null) {
            attacker = par1DamageSource.getEntity();
         }

         if(attacker != null) {
            double attackSuccess = super.posX - attacker.posX;
            double dz = super.posZ - attacker.posZ;
            float angle = (float)(Math.atan2(dz, attackSuccess) * 180.0D / 3.141592653589793D) - 90.0F;
            float difference = MathHelper.abs((super.renderYawOffset - angle) % 360.0F);
            if(this.hasShield() && difference > 150.0F && difference < 230.0F) {
               if(this.takeHitOnShield(par1DamageSource, damageAmount)) {
                  return false;
               }
            } else if(this.hasShield() && super.rand.nextBoolean()) {
               this.damageShield();
            }

            if(this.hasArmor() && (difference > 300.0F || difference < 60.0F)) {
               this.breakArmor();
            }
         }

         boolean attackSuccess1 = super.attackEntityFrom(par1DamageSource, damageAmount);
         if(attackSuccess1 && super.ridingEntity != null && super.ridingEntity instanceof EntityLiving && attacker != null) {
            ((EntityLiving)super.ridingEntity).knockBack(attacker, damageAmount, 0.1D, 0.1D);
         }

         return attackSuccess1;
      }
   }

   public void breakArmor() {
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.setHasArmor(false);
   }

   public void breakShield() {
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.renderBrokenItemStack(new ItemStack(Items.iron_chestplate));
      this.setHasShield(false);
   }

   public boolean takeHitOnShield(DamageSource par1DamageSource, float damageAmount) {
      if(damageAmount > 10.0F && !super.worldObj.isRemote) {
         this.damageShield();
      } else {
         super.worldObj.playSoundAtEntity(this, "random.break", 1.0F, ((super.rand.nextFloat() - super.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      }

      Object toKnockback = super.ridingEntity != null && super.ridingEntity instanceof EntityLiving?(EntityLiving)super.ridingEntity:this;
      if(par1DamageSource.getEntity() != null) {
         double d0 = par1DamageSource.getEntity().posX - super.posX;

         double d1;
         for(d1 = par1DamageSource.getEntity().posZ - super.posZ; d0 * d0 + d1 * d1 < 1.0E-4D; d1 = (Math.random() - Math.random()) * 0.01D) {
            d0 = (Math.random() - Math.random()) * 0.01D;
         }

         ((EntityLiving)toKnockback).knockBack(par1DamageSource.getEntity(), 0.0F, d0 / 4.0D, d1 / 4.0D);
         if(par1DamageSource.getEntity() instanceof EntityLiving) {
            this.setRevengeTarget((EntityLiving)par1DamageSource.getEntity());
         }
      }

      return true;
   }

   private void damageShield() {
      super.worldObj.playSoundAtEntity(this, "mob.zombie.metal", 0.25F, 0.25F);
      ++this.shieldHits;
      if(!super.worldObj.isRemote && this.shieldHits >= 3) {
         this.breakShield();
      }

   }

   public int getTotalArmorValue() {
      int armor = super.getTotalArmorValue();
      if(this.hasArmor()) {
         armor += 20;
      }

      if(armor > 20) {
         armor = 20;
      }

      return armor;
   }

   protected Item getDropItem() {
      return TFItems.armorShard;
   }
}

package twilightforest.entity;

import java.util.Iterator;
import java.util.List;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntitySeekerArrow extends EntityArrow {

   private EntityLivingBase homingTarget;
   double seekDistance = 5.0D;


   public EntitySeekerArrow(World par1World) {
      super(par1World);
   }

   public EntitySeekerArrow(World world, EntityPlayer player, float velocity) {
      super(world, player, velocity);
   }

   public void onUpdate() {
      if(this.isThisArrowFlying()) {
         double dotProduct;
         if(this.homingTarget == null) {
            double targetVec = super.lastTickPosX;
            dotProduct = super.lastTickPosY;
            double currentSpeed = super.lastTickPosZ;
            double maxX = super.lastTickPosX;
            double maxY = super.lastTickPosY;
            double maxZ = super.lastTickPosZ;
            AxisAlignedBB targetBB = AxisAlignedBB.getBoundingBox(targetVec, dotProduct, currentSpeed, maxX, maxY, maxZ);
            Vec3 courseVec1 = Vec3.createVectorHelper(super.motionX * this.seekDistance, super.motionY * this.seekDistance, super.motionZ * this.seekDistance);
            courseVec1.rotateAroundY(0.5235988F);
            targetBB = targetBB.addCoord(courseVec1.xCoord, courseVec1.yCoord, courseVec1.zCoord);
            courseVec1 = Vec3.createVectorHelper(super.motionX * this.seekDistance, super.motionY * this.seekDistance, super.motionZ * this.seekDistance);
            courseVec1.rotateAroundY(-0.5235988F);
            targetBB = targetBB.addCoord(courseVec1.xCoord, courseVec1.yCoord, courseVec1.zCoord);
            targetBB.minY -= 3.0D;
            targetBB.maxY += 3.0D;
            List targets = super.worldObj.getEntitiesWithinAABBExcludingEntity(this, targetBB, IEntitySelector.selectAnything);
            double closestDot = 1.0D;
            Iterator var18 = targets.iterator();

            while(var18.hasNext()) {
               Object thing = var18.next();
               if(thing instanceof EntityLivingBase && !(thing instanceof EntityPlayer)) {
                  EntityLivingBase living = (EntityLivingBase)thing;
                  System.out.println("Possible target : " + living);
                  courseVec1 = Vec3.createVectorHelper(super.motionX, super.motionY, super.motionZ);
                  courseVec1 = courseVec1.normalize();
                  Vec3 targetVec1 = Vec3.createVectorHelper(super.posX - living.posX, super.posY - (living.posY + (double)living.getEyeHeight()), super.posZ - living.posZ);
                  targetVec1 = targetVec1.normalize();
                  double dot = courseVec1.dotProduct(targetVec1);
                  if(dot < closestDot) {
                     this.homingTarget = living;
                     closestDot = dot;
                  }
               }
            }

            if(targets.size() > 0) {
               ;
            }
         } else {
            Vec3 targetVec2 = Vec3.createVectorHelper(super.posX - this.homingTarget.posX, super.posY - (this.homingTarget.posY + (double)this.homingTarget.getEyeHeight()), super.posZ - this.homingTarget.posZ);
            targetVec2 = targetVec2.normalize();
            Vec3 courseVec = Vec3.createVectorHelper(super.motionX * this.seekDistance, super.motionY * this.seekDistance, super.motionZ * this.seekDistance);
            courseVec = courseVec.normalize();
            dotProduct = courseVec.dotProduct(targetVec2);
            if(dotProduct < 0.0D) {
               float currentSpeed1 = MathHelper.sqrt_double(super.motionX * super.motionX + super.motionY * super.motionY + super.motionZ * super.motionZ);
               currentSpeed1 = (float)((double)currentSpeed1 * 1.0D);
               targetVec2.xCoord *= (double)currentSpeed1;
               targetVec2.yCoord *= (double)currentSpeed1;
               targetVec2.zCoord *= (double)currentSpeed1;
               double dx = MathHelper.clamp_double(targetVec2.xCoord, -2.0D, 2.0D);
               double dy = MathHelper.clamp_double(targetVec2.yCoord, -1.0D, 1.0D);
               double dz = MathHelper.clamp_double(targetVec2.zCoord, -2.0D, 2.0D);
               super.motionX -= dx;
               super.motionY -= dy;
               super.motionZ -= dz;
            } else {
               this.homingTarget = null;
            }
         }

         super.motionY += 0.04500000178813934D;
      }

      super.onUpdate();
   }

   private boolean isThisArrowFlying() {
      return (double)MathHelper.sqrt_double(super.motionX * super.motionX + super.motionY * super.motionY + super.motionZ * super.motionZ) > 1.0D;
   }
}

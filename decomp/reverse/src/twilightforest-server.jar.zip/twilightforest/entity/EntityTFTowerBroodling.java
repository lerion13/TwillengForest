package twilightforest.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFSwarmSpider;

public class EntityTFTowerBroodling extends EntityTFSwarmSpider {

   public EntityTFTowerBroodling(World world) {
      this(world, true);
   }

   public EntityTFTowerBroodling(World world, boolean spawnMore) {
      super(world, spawnMore);
      super.experienceValue = 3;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(7.0D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(4.0D);
   }

   protected boolean spawnAnother() {
      EntityTFTowerBroodling another = new EntityTFTowerBroodling(super.worldObj, false);
      double sx = super.posX + (super.rand.nextBoolean()?0.9D:-0.9D);
      double sy = super.posY;
      double sz = super.posZ + (super.rand.nextBoolean()?0.9D:-0.9D);
      another.setLocationAndAngles(sx, sy, sz, super.rand.nextFloat() * 360.0F, 0.0F);
      if(!another.getCanSpawnHere()) {
         another.setDead();
         return false;
      } else {
         super.worldObj.spawnEntityInWorld(another);
         return true;
      }
   }
}

package twilightforest.entity;

import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.entity.ai.EntityAITFChargeAttack;
import twilightforest.item.TFItems;

public class EntityTFBoggard extends EntityMob {

   private boolean shy;


   public EntityTFBoggard(World world) {
      super(world);
      this.setSize(0.8F, 1.1F);
      this.shy = true;
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAITFChargeAttack(this, 2.0F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, false));
   }

   public EntityTFBoggard(World world, double x, double y, double z) {
      this(world);
      this.setPosition(x, y, z);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(14.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.redcap.redcap";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.redcap.redcaphurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.redcap.redcapdie";
   }

   protected Item getDropItem() {
      return Items.iron_boots;
   }

   protected void dropFewItems(boolean flag, int i) {
      if(super.rand.nextInt(5) == 0) {
         this.dropItem(TFItems.mazeMapFocus, 1 + i);
      }

      if(super.rand.nextInt(6) == 0) {
         this.dropItem(Items.iron_boots, 1 + i);
      }

      if(super.rand.nextInt(9) == 0) {
         this.dropItem(Items.iron_pickaxe, 1 + i);
      }

   }

   public boolean isShy() {
      return this.shy && super.recentlyHit <= 0;
   }

   public boolean isTargetLookingAtMe() {
      double dx = super.posX - super.entityToAttack.posX;
      double dz = super.posZ - super.entityToAttack.posZ;
      float angle = (float)(Math.atan2(dz, dx) * 180.0D / 3.1415927410125732D) - 90.0F;
      float difference = MathHelper.abs((super.entityToAttack.rotationYaw - angle) % 360.0F);
      return difference < 60.0F || difference > 300.0F;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
         int chunkX = MathHelper.floor_double(super.posX) >> 4;
         int chunkZ = MathHelper.floor_double(super.posZ) >> 4;
         if(TFFeature.getNearestFeature(chunkX, chunkZ, super.worldObj) == TFFeature.hill1) {
            ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHill1);
         }
      }

   }

   public void moveEntityWithHeading(float par1, float par2) {
      super.moveEntityWithHeading(par1, par2);
   }
}

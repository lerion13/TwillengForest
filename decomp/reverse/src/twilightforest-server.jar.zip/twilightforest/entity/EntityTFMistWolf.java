package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFHostileWolf;

public class EntityTFMistWolf extends EntityTFHostileWolf {

   public EntityTFMistWolf(World world) {
      super(world);
      this.setSize(1.4F, 1.9F);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
   }

   public int getAttackStrength(Entity par1Entity) {
      return 6;
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int damage = this.getAttackStrength(par1Entity);
      if(par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)damage)) {
         float myBrightness = this.getBrightness(1.0F);
         if(par1Entity instanceof EntityLivingBase && myBrightness < 0.1F) {
            byte effectDuration = 0;
            if(super.worldObj.difficultySetting != EnumDifficulty.EASY) {
               if(super.worldObj.difficultySetting == EnumDifficulty.NORMAL) {
                  effectDuration = 7;
               } else if(super.worldObj.difficultySetting == EnumDifficulty.HARD) {
                  effectDuration = 15;
               }
            }

            if(effectDuration > 0) {
               ((EntityLivingBase)par1Entity).addPotionEffect(new PotionEffect(Potion.blindness.id, effectDuration * 20, 0));
            }
         }

         return true;
      } else {
         return false;
      }
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.6F;
   }
}

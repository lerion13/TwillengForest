package twilightforest.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;

public class EntityTFTwilightWandBolt extends EntityThrowable {

   public EntityTFTwilightWandBolt(World par1World) {
      super(par1World);
   }

   public EntityTFTwilightWandBolt(World par1World, double par2, double par4, double par6) {
      super(par1World, par2, par4, par6);
   }

   public EntityTFTwilightWandBolt(World par1World, EntityLivingBase par2EntityLiving) {
      super(par1World, par2EntityLiving);
   }

   public void onUpdate() {
      super.onUpdate();
      this.makeTrail();
   }

   public void makeTrail() {
      for(int i = 0; i < 5; ++i) {
         double dx = super.posX + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dy = super.posY + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double dz = super.posZ + 0.5D * (super.rand.nextDouble() - super.rand.nextDouble());
         double s1 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.17F);
         double s2 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.8F);
         double s3 = (double)((super.rand.nextFloat() * 0.5F + 0.5F) * 0.69F);
         super.worldObj.spawnParticle("mobSpell", dx, dy, dz, s1, s2, s3);
      }

   }

   protected float getGravityVelocity() {
      return 0.003F;
   }

   protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
      if(par1MovingObjectPosition.entityHit != null && par1MovingObjectPosition.entityHit instanceof EntityLivingBase && par1MovingObjectPosition.entityHit.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, this.getThrower()), 6.0F)) {
         ;
      }

      for(int i = 0; i < 8; ++i) {
         super.worldObj.spawnParticle("iconcrack_" + Item.getIdFromItem(Items.ender_pearl), super.posX, super.posY, super.posZ, super.rand.nextGaussian() * 0.05D, super.rand.nextDouble() * 0.2D, super.rand.nextGaussian() * 0.05D);
      }

      if(!super.worldObj.isRemote) {
         this.setDead();
      }

   }
}

package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.Facing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import twilightforest.block.TFBlocks;
import twilightforest.item.TFItems;

public class EntityTFTowerTermite extends EntityMob {

   private int allySummonCooldown;


   public EntityTFTowerTermite(World par1World) {
      super(par1World);
      this.setSize(0.3F, 0.7F);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(4, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(15.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.27D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(5.0D);
   }

   protected boolean canTriggerWalking() {
      return false;
   }

   protected Entity findPlayerToAttack() {
      double var1 = 8.0D;
      return super.worldObj.getClosestVulnerablePlayerToEntity(this, var1);
   }

   protected String getLivingSound() {
      return "mob.silverfish.say";
   }

   protected String getHurtSound() {
      return "mob.silverfish.hit";
   }

   protected String getDeathSound() {
      return "mob.silverfish.kill";
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, int par2) {
      if(this.isEntityInvulnerable()) {
         return false;
      } else {
         if(this.allySummonCooldown <= 0 && (par1DamageSource instanceof EntityDamageSource || par1DamageSource == DamageSource.magic)) {
            this.allySummonCooldown = 20;
         }

         return super.attackEntityFrom(par1DamageSource, (float)par2);
      }
   }

   protected void updateAITasks() {
      super.updateAITasks();
      if(this.allySummonCooldown > 0) {
         --this.allySummonCooldown;
         if(this.allySummonCooldown == 0) {
            this.tryToSummonAllies();
         }
      }

      if(this.getAttackTarget() == null && this.getNavigator().noPath()) {
         this.tryToBurrow();
      }

   }

   protected void tryToSummonAllies() {
      int sx = MathHelper.floor_double(super.posX);
      int sy = MathHelper.floor_double(super.posY);
      int sz = MathHelper.floor_double(super.posZ);
      boolean stopSummoning = false;

      for(int dy = 0; !stopSummoning && dy <= 5 && dy >= -5; dy = dy <= 0?1 - dy:0 - dy) {
         for(int dx = 0; !stopSummoning && dx <= 10 && dx >= -10; dx = dx <= 0?1 - dx:0 - dx) {
            for(int dz = 0; !stopSummoning && dz <= 10 && dz >= -10; dz = dz <= 0?1 - dz:0 - dz) {
               Block blockID = super.worldObj.getBlock(sx + dx, sy + dy, sz + dz);
               int blockMeta = super.worldObj.getBlockMetadata(sx + dx, sy + dy, sz + dz);
               if(blockID == TFBlocks.towerWood && blockMeta == 4) {
                  super.worldObj.playAuxSFX(2001, sx + dx, sy + dy, sz + dz, Block.getIdFromBlock(blockID) + (blockMeta << 12));
                  super.worldObj.setBlock(sx + dx, sy + dy, sz + dz, Blocks.air, 0, 3);
                  TFBlocks.towerWood.onBlockDestroyedByPlayer(super.worldObj, sx + dx, sy + dy, sz + dz, 4);
                  if(super.rand.nextBoolean()) {
                     stopSummoning = true;
                     break;
                  }
               }
            }
         }
      }

   }

   protected void tryToBurrow() {
      int x = MathHelper.floor_double(super.posX);
      int y = MathHelper.floor_double(super.posY + 0.5D);
      int z = MathHelper.floor_double(super.posZ);
      int randomFacing = super.rand.nextInt(6);
      x += Facing.offsetsXForSide[randomFacing];
      y += Facing.offsetsYForSide[randomFacing];
      z += Facing.offsetsZForSide[randomFacing];
      Block blockIDNearby = super.worldObj.getBlock(x, y, z);
      int blockMetaNearby = super.worldObj.getBlockMetadata(x, y, z);
      if(this.canBurrowIn(blockIDNearby, blockMetaNearby)) {
         super.worldObj.setBlock(x, y, z, TFBlocks.towerWood, 4, 3);
         this.spawnExplosionParticle();
         this.setDead();
      }

   }

   protected boolean canBurrowIn(Block blockIDNearby, int blockMetaNearby) {
      return blockIDNearby == TFBlocks.towerWood && blockMetaNearby == 0;
   }

   protected boolean isInfestedBlock(Block blockIDNearby, int blockMetaNearby) {
      return blockIDNearby == TFBlocks.towerWood && blockMetaNearby == 4;
   }

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {
      this.playSound("mob.silverfish.step", 0.15F, 1.0F);
   }

   protected Item getDropItem() {
      return TFItems.borerEssence;
   }

   public void onUpdate() {
      super.renderYawOffset = super.rotationYaw;
      super.onUpdate();
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.ARTHROPOD;
   }
}

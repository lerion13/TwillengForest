package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.entity.EntityTFHostileWolf;
import twilightforest.entity.IBreathAttacker;
import twilightforest.entity.ai.EntityAITFBreathAttack;
import twilightforest.item.TFItems;

public class EntityTFWinterWolf extends EntityTFHostileWolf implements IBreathAttacker {

   private static final int BREATH_FLAG = 21;
   public static final int BREATH_DURATION = 10;
   public static final int BREATH_DAMAGE = 2;


   public EntityTFWinterWolf(World world) {
      super(world);
      this.setSize(1.4F, 1.9F);
      super.tasks.taskEntries.clear();
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(2, new EntityAITFBreathAttack(this, 1.0F, 5.0F, 30, 0.1F));
      super.tasks.addTask(3, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.targetTasks.taskEntries.clear();
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(30.0D);
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(21, Byte.valueOf((byte)0));
   }

   public int getAttackStrength(Entity par1Entity) {
      return 6;
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      int damage = this.getAttackStrength(par1Entity);
      return par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)damage);
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();
      if(this.isBreathing()) {
         Vec3 look = this.getLookVec();
         double dist = 0.5D;
         double px = super.posX + look.xCoord * dist;
         double py = super.posY + 1.25D + look.yCoord * dist;
         double pz = super.posZ + look.zCoord * dist;

         for(int i = 0; i < 10; ++i) {
            double dx = look.xCoord;
            double dy = look.yCoord;
            double dz = look.zCoord;
            double spread = 5.0D + this.getRNG().nextDouble() * 2.5D;
            double velocity = 3.0D + this.getRNG().nextDouble() * 0.15D;
            dx += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dy += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dz += this.getRNG().nextGaussian() * 0.007499999832361937D * spread;
            dx *= velocity;
            dy *= velocity;
            dz *= velocity;
            TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowstuff", px, py, pz, dx, dy, dz);
         }

         this.playBreathSound();
      }

   }

   public void playBreathSound() {
      super.worldObj.playSoundEffect(super.posX + 0.5D, super.posY + 0.5D, super.posZ + 0.5D, "mob.ghast.fireball", super.rand.nextFloat() * 0.5F, super.rand.nextFloat() * 0.5F);
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.6F;
   }

   public boolean isBreathing() {
      return this.getDataWatcher().getWatchableObjectByte(21) == 1;
   }

   public void setBreathing(boolean flag) {
      this.getDataWatcher().updateObject(21, Byte.valueOf((byte)(flag?1:0)));
   }

   public void doBreathAttack(Entity target) {}

   protected boolean isValidLightLevel() {
      int x = MathHelper.floor_double(super.posX);
      int z = MathHelper.floor_double(super.posZ);
      return super.worldObj.getBiomeGenForCoords(x, z) == TFBiomeBase.tfSnow?true:super.isValidLightLevel();
   }

   protected Item getDropItem() {
      return TFItems.arcticFur;
   }
}

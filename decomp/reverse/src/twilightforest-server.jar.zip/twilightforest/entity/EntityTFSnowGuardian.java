package twilightforest.entity;

import net.minecraft.entity.IEntityLivingData;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import twilightforest.TwilightForestMod;
import twilightforest.item.TFItems;

public class EntityTFSnowGuardian extends EntityMob {

   public EntityTFSnowGuardian(World par1World) {
      super(par1World);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(2, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(3, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(3, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.setSize(0.6F, 1.8F);
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.23000000417232513D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(3.0D);
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(10.0D);
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.ice.noise";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.ice.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.ice.death";
   }

   protected float getSoundPitch() {
      return (super.rand.nextFloat() - super.rand.nextFloat()) * 0.2F + 0.8F;
   }

   protected void addRandomArmor() {
      int type = super.rand.nextInt(4);
      this.setCurrentItemOrArmor(0, new ItemStack(this.makeItemForSlot(0, type)));
      this.setCurrentItemOrArmor(3, new ItemStack(this.makeItemForSlot(3, type)));
      this.setCurrentItemOrArmor(4, new ItemStack(this.makeItemForSlot(4, type)));
   }

   protected Item makeItemForSlot(int slot, int type) {
      switch(slot) {
      case 0:
      default:
         switch(type) {
         case 0:
         default:
            return TFItems.ironwoodSword;
         case 1:
            return TFItems.steeleafSword;
         case 2:
            return TFItems.knightlySword;
         case 3:
            return TFItems.knightlySword;
         }
      case 1:
         switch(type) {
         case 0:
         default:
            return TFItems.ironwoodBoots;
         case 1:
            return TFItems.steeleafBoots;
         case 2:
            return TFItems.knightlyBoots;
         case 3:
            return TFItems.arcticBoots;
         }
      case 2:
         switch(type) {
         case 0:
         default:
            return TFItems.ironwoodLegs;
         case 1:
            return TFItems.steeleafLegs;
         case 2:
            return TFItems.knightlyLegs;
         case 3:
            return TFItems.arcticLegs;
         }
      case 3:
         switch(type) {
         case 0:
         default:
            return TFItems.ironwoodPlate;
         case 1:
            return TFItems.steeleafPlate;
         case 2:
            return TFItems.knightlyPlate;
         case 3:
            return TFItems.arcticPlate;
         }
      case 4:
         switch(type) {
         case 0:
         default:
            return TFItems.ironwoodHelm;
         case 1:
            return TFItems.steeleafHelm;
         case 2:
            return TFItems.knightlyHelm;
         case 3:
            return TFItems.arcticHelm;
         }
      }
   }

   protected Item getDropItem() {
      return Items.snowball;
   }

   protected void enchantEquipment() {
      super.enchantEquipment();
   }

   public IEntityLivingData onSpawnWithEgg(IEntityLivingData par1EntityLivingData) {
      IEntityLivingData data = super.onSpawnWithEgg(par1EntityLivingData);
      this.addRandomArmor();
      return data;
   }

   public void onLivingUpdate() {
      super.onLivingUpdate();

      for(int i = 0; i < 3; ++i) {
         float px = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         float py = this.getEyeHeight() + (super.rand.nextFloat() - super.rand.nextFloat()) * 0.5F;
         float pz = (super.rand.nextFloat() - super.rand.nextFloat()) * 0.3F;
         TwilightForestMod.proxy.spawnParticle(super.worldObj, "snowguardian", super.lastTickPosX + (double)px, super.lastTickPosY + (double)py, super.lastTickPosZ + (double)pz, 0.0D, 0.0D, 0.0D);
      }

   }

   public int getMaxSpawnedInChunk() {
      return 8;
   }
}

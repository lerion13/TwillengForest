package twilightforest.entity;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityMultiPart;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.boss.EntityDragonPart;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import twilightforest.TFAchievementPage;
import twilightforest.entity.EntityTFGoblinChain;
import twilightforest.entity.EntityTFSpikeBlock;
import twilightforest.item.TFItems;

public class EntityTFBlockGoblin extends EntityMob implements IEntityMultiPart {

   private static final float CHAIN_SPEED = 16.0F;
   private static final int DATA_CHAINLENGTH = 17;
   private static final int DATA_CHAINPOS = 18;
   int recoilCounter;
   float chainAngle;
   public EntityTFSpikeBlock block;
   public EntityTFGoblinChain chain1;
   public EntityTFGoblinChain chain2;
   public EntityTFGoblinChain chain3;
   public Entity[] partsArray;


   public EntityTFBlockGoblin(World world) {
      super(world);
      this.setSize(0.9F, 1.4F);
      super.tasks.addTask(0, new EntityAISwimming(this));
      super.tasks.addTask(1, new EntityAIAvoidEntity(this, EntityTNTPrimed.class, 2.0F, 0.800000011920929D, 1.5D));
      super.tasks.addTask(5, new EntityAIAttackOnCollide(this, EntityPlayer.class, 1.0D, false));
      super.tasks.addTask(6, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(7, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(7, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIHurtByTarget(this, false));
      super.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityPlayer.class, 0, true));
      this.recoilCounter = 0;
      this.partsArray = new Entity[]{this.block = new EntityTFSpikeBlock(this), this.chain1 = new EntityTFGoblinChain(this), this.chain2 = new EntityTFGoblinChain(this), this.chain3 = new EntityTFGoblinChain(this)};
   }

   protected void entityInit() {
      super.entityInit();
      super.dataWatcher.addObject(17, Byte.valueOf((byte)0));
      super.dataWatcher.addObject(18, Byte.valueOf((byte)0));
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(20.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.28D);
      this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(8.0D);
   }

   protected String getLivingSound() {
      return "TwilightForest:mob.redcap.redcap";
   }

   protected String getHurtSound() {
      return "TwilightForest:mob.redcap.hurt";
   }

   protected String getDeathSound() {
      return "TwilightForest:mob.redcap.die";
   }

   protected Item getDropItemId() {
      return TFItems.armorShard;
   }

   public void onDeath(DamageSource par1DamageSource) {
      super.onDeath(par1DamageSource);
      if(par1DamageSource.getSourceOfDamage() instanceof EntityPlayer) {
         ((EntityPlayer)par1DamageSource.getSourceOfDamage()).triggerAchievement(TFAchievementPage.twilightHunter);
      }

   }

   public double getChainYOffset() {
      return 1.5D - (double)this.getChainLength() / 4.0D;
   }

   public Vec3 getChainPosition() {
      return this.getChainPosition(this.getChainAngle(), this.getChainLength());
   }

   public Vec3 getChainPosition(float angle, float distance) {
      double var1 = Math.cos((double)angle * 3.141592653589793D / 180.0D) * (double)distance;
      double var3 = Math.sin((double)angle * 3.141592653589793D / 180.0D) * (double)distance;
      return Vec3.createVectorHelper(super.posX + var1, super.posY + this.getChainYOffset(), super.posZ + var3);
   }

   public boolean isSwingingChain() {
      return super.isSwingInProgress || this.getAttackTarget() != null && this.recoilCounter == 0;
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      this.swingItem();
      return false;
   }

   public void onUpdate() {
      super.onUpdate();
      this.block.onUpdate();
      this.chain1.onUpdate();
      this.chain2.onUpdate();
      this.chain3.onUpdate();
      if(this.recoilCounter > 0) {
         --this.recoilCounter;
      }

      this.chainAngle += 16.0F;
      this.chainAngle %= 360.0F;
      if(!super.worldObj.isRemote) {
         super.dataWatcher.updateObject(17, Byte.valueOf((byte)((int)Math.floor((double)(this.getChainLength() * 127.0F)))));
         super.dataWatcher.updateObject(18, Byte.valueOf((byte)((int)Math.floor((double)(this.getChainAngle() / 360.0F * 255.0F)))));
      } else if(Math.abs(this.chainAngle - this.getChainAngle()) > 32.0F) {
         this.chainAngle = this.getChainAngle();
      }

      Vec3 blockPos = this.getChainPosition();
      this.block.setPosition(blockPos.xCoord, blockPos.yCoord, blockPos.zCoord);
      this.block.rotationYaw = this.getChainAngle();
      double sx = super.posX;
      double sy = super.posY + (double)super.height - 0.1D;
      double sz = super.posZ;
      double ox = sx - blockPos.xCoord;
      double oy = sy - blockPos.yCoord - (double)this.block.height / 3.0D;
      double oz = sz - blockPos.zCoord;
      this.chain1.setPosition(sx - ox * 0.4D, sy - oy * 0.4D, sz - oz * 0.4D);
      this.chain2.setPosition(sx - ox * 0.5D, sy - oy * 0.5D, sz - oz * 0.5D);
      this.chain3.setPosition(sx - ox * 0.6D, sy - oy * 0.6D, sz - oz * 0.6D);
      if(!super.worldObj.isRemote && this.isSwingingChain()) {
         this.applyBlockCollisions(this.block);
      }

   }

   protected void applyBlockCollisions(Entity collider) {
      List list = super.worldObj.getEntitiesWithinAABBExcludingEntity(collider, collider.boundingBox.expand(0.20000000298023224D, 0.0D, 0.20000000298023224D));
      if(list != null && !list.isEmpty()) {
         for(int i = 0; i < list.size(); ++i) {
            Entity entity = (Entity)list.get(i);
            if(entity.canBePushed()) {
               this.applyBlockCollision(collider, entity);
            }
         }
      }

   }

   protected void applyBlockCollision(Entity collider, Entity collided) {
      if(collided != this) {
         collided.applyEntityCollision(collider);
         if(collided instanceof EntityLivingBase) {
            boolean attackSuccess = super.attackEntityAsMob(collided);
            if(attackSuccess) {
               collided.motionY += 0.4000000059604645D;
               this.playSound("mob.irongolem.throw", 1.0F, 1.0F);
               this.recoilCounter = 40;
            }
         }
      }

   }

   public float getChainAngle() {
      return !super.worldObj.isRemote?this.chainAngle:(float)(super.dataWatcher.getWatchableObjectByte(18) & 255) / 255.0F * 360.0F;
   }

   public float getChainLength() {
      return !super.worldObj.isRemote?(this.isSwingingChain()?0.9F:0.3F):(float)(super.dataWatcher.getWatchableObjectByte(17) & 255) / 127.0F;
   }

   public World func_82194_d() {
      return super.worldObj;
   }

   public boolean attackEntityFromPart(EntityDragonPart entitydragonpart, DamageSource damagesource, float i) {
      return false;
   }

   public Entity[] getParts() {
      return this.partsArray;
   }

   public int getTotalArmorValue() {
      int i = super.getTotalArmorValue() + 11;
      if(i > 20) {
         i = 20;
      }

      return i;
   }
}

package twilightforest.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIFollowOwner;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILeapAtTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIOwnerHurtByTarget;
import net.minecraft.entity.ai.EntityAIOwnerHurtTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.potion.Potion;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

public class EntityTFLoyalZombie extends EntityTameable {

   public EntityTFLoyalZombie(World par1World) {
      super(par1World);
      this.setSize(0.6F, 1.8F);
      this.getNavigator().setAvoidsWater(true);
      super.tasks.addTask(1, new EntityAISwimming(this));
      super.tasks.addTask(3, new EntityAILeapAtTarget(this, 0.4F));
      super.tasks.addTask(4, new EntityAIAttackOnCollide(this, 1.0D, true));
      super.tasks.addTask(5, new EntityAIFollowOwner(this, 1.0D, 10.0F, 2.0F));
      super.tasks.addTask(7, new EntityAIWander(this, 1.0D));
      super.tasks.addTask(9, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
      super.tasks.addTask(9, new EntityAILookIdle(this));
      super.targetTasks.addTask(1, new EntityAIOwnerHurtByTarget(this));
      super.targetTasks.addTask(2, new EntityAIOwnerHurtTarget(this));
      super.targetTasks.addTask(3, new EntityAIHurtByTarget(this, true));
      super.targetTasks.addTask(4, new EntityAINearestAttackableTarget(this, EntityMob.class, 0, true));
   }

   public EntityAnimal createChild(EntityAgeable entityanimal) {
      return null;
   }

   protected void applyEntityAttributes() {
      super.applyEntityAttributes();
      this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(40.0D);
      this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(0.3D);
   }

   public boolean attackEntityAsMob(Entity par1Entity) {
      byte attackpower = 7;
      boolean success = par1Entity.attackEntityFrom(DamageSource.causeMobDamage(this), (float)attackpower);
      if(success) {
         par1Entity.motionY += 0.2000000059604645D;
      }

      return success;
   }

   public void onLivingUpdate() {
      if(!super.worldObj.isRemote && this.getActivePotionEffect(Potion.damageBoost) == null) {
         this.setFire(100);
      }

      super.onLivingUpdate();
   }

   protected boolean canDespawn() {
      return !this.isTamed();
   }

   public int getTotalArmorValue() {
      return 3;
   }

   protected boolean isAIEnabled() {
      return true;
   }

   protected String getLivingSound() {
      return "mob.zombie.say";
   }

   protected String getHurtSound() {
      return "mob.zombie.hurt";
   }

   protected String getDeathSound() {
      return "mob.zombie.death";
   }

   protected void func_145780_a(int par1, int par2, int par3, Block par4) {
      super.worldObj.playSoundAtEntity(this, "mob.zombie.step", 0.15F, 1.0F);
   }

   protected Item getDropItem() {
      return Item.getItemById(0);
   }

   public EnumCreatureAttribute getCreatureAttribute() {
      return EnumCreatureAttribute.UNDEAD;
   }
}

package twilightforest.entity;

import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import twilightforest.entity.EntityTFBlockGoblin;

public class EntityTFSpikeBlock extends Entity {

   EntityTFBlockGoblin goblin;


   public EntityTFSpikeBlock(World par1World) {
      super(par1World);
      this.setSize(0.75F, 0.75F);
   }

   public EntityTFSpikeBlock(EntityTFBlockGoblin goblin) {
      this(goblin.func_82194_d());
      this.goblin = goblin;
   }

   public boolean attackEntityFrom(DamageSource par1DamageSource, float par2) {
      return false;
   }

   public void onUpdate() {
      super.onUpdate();
      ++super.ticksExisted;
      super.lastTickPosX = super.posX;
      super.lastTickPosY = super.posY;

      for(super.lastTickPosZ = super.posZ; super.rotationYaw - super.prevRotationYaw < -180.0F; super.prevRotationYaw -= 360.0F) {
         ;
      }

      while(super.rotationYaw - super.prevRotationYaw >= 180.0F) {
         super.prevRotationYaw += 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch < -180.0F) {
         super.prevRotationPitch -= 360.0F;
      }

      while(super.rotationPitch - super.prevRotationPitch >= 180.0F) {
         super.prevRotationPitch += 360.0F;
      }

   }

   public boolean canBeCollidedWith() {
      return false;
   }

   public boolean canBePushed() {
      return false;
   }

   public boolean isEntityEqual(Entity entity) {
      return this == entity || this.goblin == entity;
   }

   protected void entityInit() {}

   protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

   protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {}
}

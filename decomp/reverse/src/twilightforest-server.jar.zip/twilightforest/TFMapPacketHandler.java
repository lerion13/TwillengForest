package twilightforest;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent.ClientCustomPacketEvent;
import cpw.mods.fml.common.network.internal.FMLProxyPacket;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandler.Sharable;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.S34PacketMaps;
import twilightforest.TFMazeMapData;
import twilightforest.TwilightForestMod;
import twilightforest.item.ItemTFMagicMap;
import twilightforest.item.ItemTFMazeMap;

@Sharable
public class TFMapPacketHandler {

   public S34PacketMaps readMapPacket(ByteBuf byteBuf) {
      S34PacketMaps mapPacket = new S34PacketMaps();

      try {
         mapPacket.readPacketData(new PacketBuffer(byteBuf));
      } catch (IOException var4) {
         var4.printStackTrace();
      }

      return mapPacket;
   }

   public static Packet makeMagicMapPacket(String mapChannel, short mapID, byte[] datas) {
      S34PacketMaps mapPacket = new S34PacketMaps(mapID, datas);
      PacketBuffer payload = new PacketBuffer(Unpooled.buffer());

      try {
         mapPacket.writePacketData(payload);
      } catch (IOException var6) {
         var6.printStackTrace();
      }

      FMLProxyPacket pkt = new FMLProxyPacket(payload, mapChannel);
      return pkt;
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void incomingPacket(ClientCustomPacketEvent event) {
      S34PacketMaps mapPacket;
      if(event.packet.channel().equals("magicmap")) {
         mapPacket = this.readMapPacket(event.packet.payload());
         ItemTFMagicMap.getMPMapData(mapPacket.func_149188_c(), TwilightForestMod.proxy.getClientWorld()).updateMPMapData(mapPacket.func_149187_d());
      } else if(event.packet.channel().equals("mazemap")) {
         mapPacket = this.readMapPacket(event.packet.payload());
         TFMazeMapData data = ItemTFMazeMap.getMPMapData(mapPacket.func_149188_c(), TwilightForestMod.proxy.getClientWorld());
         data.updateMPMapData(mapPacket.func_149187_d());
         Minecraft.getMinecraft().entityRenderer.getMapItemRenderer().func_148246_a(data);
      }

   }
}

package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeStream extends TFBiomeBase {

   public TFBiomeStream(int i) {
      super(i);
      super.temperature = 0.5F;
      super.rainfall = 1.0F;
      this.getTFBiomeDecorator().setWaterlilyPerChunk(2);
      super.spawnableCreatureList.clear();
   }
}

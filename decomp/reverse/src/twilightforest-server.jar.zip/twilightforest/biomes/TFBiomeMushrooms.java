package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeMushrooms extends TFBiomeBase {

   public TFBiomeMushrooms(int i) {
      super(i);
      super.rainfall = 0.8F;
      super.temperature = 0.8F;
      this.getTFBiomeDecorator().setTreesPerChunk(8);
      this.getTFBiomeDecorator().setMushroomsPerChunk(8);
      this.getTFBiomeDecorator().setBigMushroomsPerChunk(2);
      this.getTFBiomeDecorator().alternateCanopyChance = 0.2F;
   }
}

package twilightforest.biomes;

import java.util.Random;
import net.minecraft.block.BlockFlower;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import net.minecraft.world.gen.feature.WorldGenVines;
import net.minecraft.world.gen.feature.WorldGenerator;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.block.TFBlocks;
import twilightforest.world.TFGenLargeRainboak;
import twilightforest.world.TFGenSmallRainboak;
import twilightforest.world.TFWorld;

public class TFBiomeEnchantedForest extends TFBiomeBase {

   Random colorRNG = new Random();


   public TFBiomeEnchantedForest(int i) {
      super(i);
      this.getTFBiomeDecorator().setGrassPerChunk(12);
      this.getTFBiomeDecorator().setFlowersPerChunk(8);
   }

   public int getBiomeGrassColor(int x, int y, int z) {
      return (super.getBiomeGrassColor(x, y, z) & 16776960) + this.getEnchantedColor(x, z);
   }

   public int getBiomeFoliageColor(int x, int y, int z) {
      return (super.getBiomeFoliageColor(x, y, z) & 16776960) + this.getEnchantedColor(x, z);
   }

   private int getEnchantedColor(int x, int z) {
      int cx = 256 * Math.round((float)(x - 8) / 256.0F) + 8;
      int cz = 256 * Math.round((float)(z - 8) / 256.0F) + 8;
      int dist = (int)MathHelper.sqrt_float((float)((cx - x) * (cx - x) + (cz - z) * (cz - z)));
      int color = dist * 64;
      color %= 512;
      if(color > 255) {
         color = 511 - color;
      }

      color = 255 - color;
      int randomFlicker = this.colorRNG.nextInt(32) - 16;
      if(0 < color + randomFlicker && color + randomFlicker > 255) {
         color += randomFlicker;
      }

      return color;
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(15) == 0?new TFGenSmallRainboak():(random.nextInt(50) == 0?new TFGenLargeRainboak():(random.nextInt(5) == 0?super.birchGen:(random.nextInt(10) == 0?new WorldGenBigTree(false):super.worldGeneratorTrees))));
   }

   public WorldGenerator getRandomWorldGenForGrass(Random par1Random) {
      return par1Random.nextInt(3) > 0?new WorldGenTallGrass(Blocks.tallgrass, 2):(par1Random.nextInt(3) == 0?new WorldGenTallGrass(TFBlocks.plant, 8):new WorldGenTallGrass(Blocks.tallgrass, 1));
   }

   public void decorate(World par1World, Random par2Random, int par3, int par4) {
      super.decorate(par1World, par2Random, par3, par4);
      WorldGenVines worldgenvines = new WorldGenVines();

      int i;
      int rx;
      int ry;
      for(i = 0; i < 20; ++i) {
         rx = par3 + par2Random.nextInt(16) + 8;
         byte rz = (byte)TFWorld.SEALEVEL;
         ry = par4 + par2Random.nextInt(16) + 8;
         worldgenvines.generate(par1World, par2Random, rx, rz, ry);
      }

      BiomeGenBase.genTallFlowers.func_150548_a(3);

      for(i = 0; i < 20; ++i) {
         rx = par3 + par2Random.nextInt(16) + 8;
         int var10 = par4 + par2Random.nextInt(16) + 8;
         ry = par2Random.nextInt(par1World.getHeightValue(rx, var10) + 32);
         BiomeGenBase.genTallFlowers.generate(par1World, par2Random, rx, ry, var10);
      }

      super.decorate(par1World, par2Random, par3, par4);
   }

   public String func_150572_a(Random p_150572_1_, int p_150572_2_, int p_150572_3_, int p_150572_4_) {
      return p_150572_1_.nextInt(3) > 0?BlockFlower.field_149859_a[1]:(p_150572_1_.nextBoolean()?BlockFlower.field_149859_a[2]:BlockFlower.field_149859_a[3]);
   }
}

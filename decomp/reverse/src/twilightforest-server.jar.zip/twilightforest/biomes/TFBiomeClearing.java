package twilightforest.biomes;

import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import net.minecraft.world.gen.feature.WorldGenerator;
import twilightforest.biomes.TFBiomeBase;

public class TFBiomeClearing extends TFBiomeBase {

   public TFBiomeClearing(int i) {
      super(i);
      super.temperature = 0.8F;
      super.rainfall = 0.4F;
      this.getTFBiomeDecorator().canopyPerChunk = -999.0F;
      this.getTFBiomeDecorator().setTreesPerChunk(-999);
      this.getTFBiomeDecorator().setFlowersPerChunk(4);
      this.getTFBiomeDecorator().setGrassPerChunk(10);
   }

   public WorldGenerator getRandomWorldGenForGrass(Random par1Random) {
      return new WorldGenTallGrass(Blocks.tallgrass, 1);
   }
}

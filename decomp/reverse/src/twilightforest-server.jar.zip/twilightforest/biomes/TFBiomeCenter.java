package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeCenter extends TFBiomeBase {

   public TFBiomeCenter(int i) {
      super(i);
   }
}

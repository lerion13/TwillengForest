package twilightforest.biomes;

import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
import twilightforest.biomes.TFBiomeBase;

public class TFBiomeTwilightLake extends TFBiomeBase {

   public TFBiomeTwilightLake(int i) {
      super(i);
      super.temperature = 0.66F;
      super.rainfall = 1.0F;
      super.spawnableWaterCreatureList.add(new SpawnListEntry(EntitySquid.class, 10, 4, 4));
   }
}

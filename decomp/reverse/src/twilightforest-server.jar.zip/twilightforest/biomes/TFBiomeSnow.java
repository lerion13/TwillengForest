package twilightforest.biomes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.Achievement;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenTaiga1;
import net.minecraft.world.gen.feature.WorldGenTaiga2;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.entity.EntityTFWinterWolf;
import twilightforest.entity.EntityTFYeti;
import twilightforest.world.TFGenLargeWinter;

public class TFBiomeSnow extends TFBiomeBase {

   private static final int MONSTER_SPAWN_RATE = 10;
   Random monsterRNG = new Random(53439L);
   ArrayList emptyList = new ArrayList();


   public TFBiomeSnow(int i) {
      super(i);
      this.getTFBiomeDecorator().setTreesPerChunk(7);
      this.getTFBiomeDecorator().setGrassPerChunk(1);
      super.temperature = 0.125F;
      super.rainfall = 0.9F;
      this.getTFBiomeDecorator().canopyPerChunk = -999.0F;
      this.getTFBiomeDecorator().generateLakes = false;
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFYeti.class, 20, 4, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFWinterWolf.class, 5, 1, 4));
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(3) == 0?new WorldGenTaiga1():(random.nextInt(8) == 0?new TFGenLargeWinter():new WorldGenTaiga2(true)));
   }

   public boolean getEnableSnow() {
      return true;
   }

   public boolean canSpawnLightningBolt() {
      return false;
   }

   public List getSpawnableList(EnumCreatureType par1EnumCreatureType) {
      return (List)(par1EnumCreatureType == EnumCreatureType.monster?(this.monsterRNG.nextInt(10) == 0?super.spawnableMonsterList:this.emptyList):(par1EnumCreatureType == EnumCreatureType.creature?super.spawnableCreatureList:(par1EnumCreatureType == EnumCreatureType.waterCreature?super.spawnableWaterCreatureList:(par1EnumCreatureType == EnumCreatureType.ambient?super.spawnableCaveCreatureList:null))));
   }

   protected Achievement getRequiredAchievement() {
      return TFAchievementPage.twilightProgressUrghast;
   }

   public void enforceProgession(EntityPlayer player, World world) {
      if(!world.isRemote && world.getWorldTime() % 60L == 0L) {
         player.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 100, 2));
         if(world.rand.nextInt(4) == 0) {
            TFFeature.yetiCave.trySpawnHintMonster(world, player);
         }
      }

   }
}

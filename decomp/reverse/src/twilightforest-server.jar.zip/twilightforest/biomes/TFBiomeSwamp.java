package twilightforest.biomes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.Achievement;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenShrub;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import net.minecraft.world.gen.feature.WorldGenVines;
import net.minecraft.world.gen.feature.WorldGenerator;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.biomes.TFGenHugeWaterLily;
import twilightforest.block.TFBlocks;
import twilightforest.entity.EntityTFMosquitoSwarm;
import twilightforest.world.TFGenHugeLilyPad;
import twilightforest.world.TFWorld;

public class TFBiomeSwamp extends TFBiomeBase {

   private static final int MONSTER_SPAWN_RATE = 20;
   Random monsterRNG = new Random(53439L);
   ArrayList emptyList = new ArrayList();
   WorldGenVines worldgenvines = new WorldGenVines();
   WorldGenerator hugeLilyPadGen = new TFGenHugeLilyPad();
   WorldGenerator hugeWaterLilyGen = new TFGenHugeWaterLily();


   public TFBiomeSwamp(int i) {
      super(i);
      super.temperature = 0.8F;
      super.rainfall = 0.9F;
      this.getTFBiomeDecorator().setDeadBushPerChunk(1);
      this.getTFBiomeDecorator().setMushroomsPerChunk(8);
      this.getTFBiomeDecorator().setReedsPerChunk(10);
      this.getTFBiomeDecorator().setClayPerChunk(1);
      this.getTFBiomeDecorator().setTreesPerChunk(2);
      this.getTFBiomeDecorator().setWaterlilyPerChunk(20);
      super.waterColorMultiplier = 14745518;
      this.getTFBiomeDecorator().canopyPerChunk = -999.0F;
      this.getTFBiomeDecorator().lakesPerChunk = 2;
      this.getTFBiomeDecorator().mangrovesPerChunk = 3;
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFMosquitoSwarm.class, 10, 1, 1));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityCreeper.class, 10, 4, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityZombie.class, 10, 4, 4));
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(3) == 0?new WorldGenShrub(3, 0):super.worldGeneratorSwamp);
   }

   public WorldGenerator getRandomWorldGenForGrass(Random par1Random) {
      return par1Random.nextInt(4) == 0?new WorldGenTallGrass(Blocks.tallgrass, 2):(par1Random.nextInt(4) == 0?new WorldGenTallGrass(TFBlocks.plant, 4):new WorldGenTallGrass(Blocks.tallgrass, 1));
   }

   public void decorate(World par1World, Random par2Random, int par3, int par4) {
      super.decorate(par1World, par2Random, par3, par4);

      int i;
      int x;
      int z;
      for(i = 0; i < 50; ++i) {
         x = par3 + par2Random.nextInt(16) + 8;
         byte y = (byte)TFWorld.SEALEVEL;
         z = par4 + par2Random.nextInt(16) + 8;
         this.worldgenvines.generate(par1World, par2Random, x, y, z);
      }

      int var9;
      for(i = 0; i < 25; ++i) {
         x = par3 + par2Random.nextInt(16) + 8;
         var9 = TFWorld.SEALEVEL;
         z = par4 + par2Random.nextInt(16) + 8;
         this.hugeLilyPadGen.generate(par1World, par2Random, x, var9, z);
      }

      for(i = 0; i < 2; ++i) {
         x = par3 + par2Random.nextInt(16) + 8;
         var9 = TFWorld.SEALEVEL;
         z = par4 + par2Random.nextInt(16) + 8;
         this.hugeWaterLilyGen.generate(par1World, par2Random, x, var9, z);
      }

   }

   public int getBiomeGrassColor(int x, int y, int z) {
      double var1 = (double)this.getFloatTemperature(x, y, z);
      double var3 = (double)this.getFloatRainfall();
      return ((ColorizerGrass.getGrassColor(var1, var3) & 16711422) + 5115470) / 2;
   }

   public int getBiomeFoliageColor(int x, int y, int z) {
      double var1 = (double)this.getFloatTemperature(x, y, z);
      double var3 = (double)this.getFloatRainfall();
      return ((ColorizerFoliage.getFoliageColor(var1, var3) & 16711422) + 5115470) / 2;
   }

   public List getSpawnableList(EnumCreatureType par1EnumCreatureType) {
      return (List)(par1EnumCreatureType == EnumCreatureType.monster?(this.monsterRNG.nextInt(20) == 0?super.spawnableMonsterList:this.emptyList):(par1EnumCreatureType == EnumCreatureType.creature?super.spawnableCreatureList:(par1EnumCreatureType == EnumCreatureType.waterCreature?super.spawnableWaterCreatureList:(par1EnumCreatureType == EnumCreatureType.ambient?super.spawnableCaveCreatureList:null))));
   }

   protected Achievement getRequiredAchievement() {
      return TFAchievementPage.twilightProgressLich;
   }

   public void enforceProgession(EntityPlayer player, World world) {
      if(!world.isRemote && world.getWorldTime() % 60L == 0L) {
         PotionEffect currentHunger = player.getActivePotionEffect(Potion.hunger);
         int hungerLevel = currentHunger != null?currentHunger.getAmplifier() + 1:1;
         player.addPotionEffect(new PotionEffect(Potion.hunger.id, 100, hungerLevel));
         if(world.rand.nextInt(4) == 0) {
            TFFeature.labyrinth.trySpawnHintMonster(world, player);
         }
      }

   }
}

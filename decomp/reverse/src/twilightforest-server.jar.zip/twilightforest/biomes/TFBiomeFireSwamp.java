package twilightforest.biomes;

import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.stats.Achievement;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenShrub;
import net.minecraft.world.gen.feature.WorldGenVines;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.block.TFBlocks;
import twilightforest.world.TFGenFireJet;
import twilightforest.world.TFWorld;

public class TFBiomeFireSwamp extends TFBiomeBase {

   protected TFBiomeFireSwamp(int i) {
      super(i);
      super.temperature = 1.0F;
      super.rainfall = 0.4F;
      this.getTFBiomeDecorator().setDeadBushPerChunk(2);
      this.getTFBiomeDecorator().setMushroomsPerChunk(8);
      this.getTFBiomeDecorator().setReedsPerChunk(4);
      this.getTFBiomeDecorator().setClayPerChunk(1);
      this.getTFBiomeDecorator().setTreesPerChunk(3);
      this.getTFBiomeDecorator().setWaterlilyPerChunk(6);
      super.waterColorMultiplier = 7089196;
      this.getTFBiomeDecorator().canopyPerChunk = -999.0F;
      this.getTFBiomeDecorator().lavaPoolChance = 0.125F;
      this.getTFBiomeDecorator().mangrovesPerChunk = 3;
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(3) == 0?new WorldGenShrub(3, 0):super.worldGeneratorSwamp);
   }

   public void decorate(World par1World, Random par2Random, int mapX, int mapZ) {
      super.decorate(par1World, par2Random, mapX, mapZ);
      TFFeature nearFeature = TFFeature.getNearestFeature(mapX >> 4, mapZ >> 4, par1World);
      if(nearFeature.areChunkDecorationsEnabled) {
         WorldGenVines worldgenvines = new WorldGenVines();

         int genFireJet;
         byte i;
         int j;
         for(int genSmoker = 0; genSmoker < 50; ++genSmoker) {
            genFireJet = mapX + par2Random.nextInt(16) + 8;
            i = (byte)TFWorld.SEALEVEL;
            j = mapZ + par2Random.nextInt(16) + 8;
            worldgenvines.generate(par1World, par2Random, genFireJet, i, j);
         }

         TFGenFireJet var13 = new TFGenFireJet(TFBlocks.fireJet, 0);
         if(par2Random.nextInt(4) == 0) {
            genFireJet = mapX + par2Random.nextInt(16) + 8;
            i = (byte)TFWorld.SEALEVEL;
            j = mapZ + par2Random.nextInt(16) + 8;
            var13.generate(par1World, par2Random, genFireJet, i, j);
         }

         TFGenFireJet var14 = new TFGenFireJet(TFBlocks.fireJet, 8);

         for(int var15 = 0; var15 < 1; ++var15) {
            j = mapX + par2Random.nextInt(16) + 8;
            byte byte0 = (byte)TFWorld.SEALEVEL;
            int k = mapZ + par2Random.nextInt(16) + 8;
            var14.generate(par1World, par2Random, j, byte0, k);
         }
      }

   }

   public int getBiomeGrassColor(int x, int y, int z) {
      return 5713443;
   }

   public int getBiomeFoliageColor(int x, int y, int z) {
      return 6563343;
   }

   protected Achievement getRequiredAchievement() {
      return TFAchievementPage.twilightProgressLabyrinth;
   }

   public void enforceProgession(EntityPlayer player, World world) {
      if(!world.isRemote && world.getWorldTime() % 60L == 0L) {
         player.setFire(8);
      }

      if(world.rand.nextInt(4) == 0) {
         TFFeature.hydraLair.trySpawnHintMonster(world, player);
      }

   }
}

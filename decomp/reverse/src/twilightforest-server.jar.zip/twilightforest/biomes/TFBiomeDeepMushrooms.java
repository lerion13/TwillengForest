package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeDeepMushrooms extends TFBiomeBase {

   public TFBiomeDeepMushrooms(int i) {
      super(i);
      super.temperature = 0.8F;
      super.rainfall = 1.0F;
      super.rootHeight = 0.15F;
      super.heightVariation = 0.4F;
      this.getTFBiomeDecorator().setTreesPerChunk(1);
      this.getTFBiomeDecorator().setMushroomsPerChunk(12);
      this.getTFBiomeDecorator().setBigMushroomsPerChunk(8);
      this.getTFBiomeDecorator().myceliumPerChunk = 3;
      this.getTFBiomeDecorator().alternateCanopyChance = 0.9F;
   }
}

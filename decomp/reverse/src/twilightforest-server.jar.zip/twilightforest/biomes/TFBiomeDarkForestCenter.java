package twilightforest.biomes;

import net.minecraft.world.biome.BiomeGenBase;
import twilightforest.biomes.TFBiomeDarkForest;

public class TFBiomeDarkForestCenter extends TFBiomeDarkForest {

   public TFBiomeDarkForestCenter(int i) {
      super(i);
   }

   public int getBiomeGrassColor(int x, int y, int z) {
      double d0 = BiomeGenBase.plantNoise.func_151601_a((double)x * 0.0225D, (double)z * 0.0225D);
      return d0 < -0.2D?6714688:5587220;
   }

   public int getBiomeFoliageColor(int x, int y, int z) {
      double d0 = BiomeGenBase.plantNoise.func_151601_a((double)x * 0.0225D, (double)z * 0.0225D);
      return d0 < -0.1D?16351774:15289876;
   }
}

package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeTwilightForest extends TFBiomeBase {

   public TFBiomeTwilightForest(int i) {
      super(i);
   }
}

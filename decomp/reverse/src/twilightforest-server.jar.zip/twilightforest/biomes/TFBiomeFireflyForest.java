package twilightforest.biomes;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockFlower;
import net.minecraft.init.Blocks;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.gen.feature.WorldGenPumpkin;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import twilightforest.biomes.TFBiomeTwilightForest;
import twilightforest.block.TFBlocks;
import twilightforest.world.TFGenHangingLamps;
import twilightforest.world.TFGenLampposts;
import twilightforest.world.TFWorld;

public class TFBiomeFireflyForest extends TFBiomeTwilightForest {

   private static final int LAMPPOST_CHANCE = 4;
   TFGenHangingLamps tfGenHangingLamps;
   TFGenLampposts tfGenLampposts;
   WorldGenTallGrass worldGenMushgloom;


   public TFBiomeFireflyForest(int i) {
      super(i);
      this.worldGenMushgloom = new WorldGenTallGrass(TFBlocks.plant, 9);
      this.tfGenHangingLamps = new TFGenHangingLamps();
      this.tfGenLampposts = new TFGenLampposts();
      super.temperature = 0.5F;
      super.rainfall = 1.0F;
      super.theBiomeDecorator.flowersPerChunk = 4;
      super.theBiomeDecorator.grassPerChunk = 1;
      this.getTFBiomeDecorator().setTreesPerChunk(2);
   }

   public void decorate(World world, Random rand, int mapX, int mapZ) {
      int flowerCycles = rand.nextInt(3) - 1;
      int successfulFlowers = 0;

      int rx;
      int rz;
      int ry;
      int ry1;
      while(successfulFlowers < flowerCycles) {
         rx = rand.nextInt(3);
         if(rx == 0) {
            BiomeGenBase.genTallFlowers.func_150548_a(1);
         } else if(rx == 1) {
            BiomeGenBase.genTallFlowers.func_150548_a(4);
         } else if(rx == 2) {
            BiomeGenBase.genTallFlowers.func_150548_a(5);
         }

         rz = 0;

         while(true) {
            if(rz < 1) {
               ry = mapX + rand.nextInt(16) + 8;
               ry1 = mapZ + rand.nextInt(16) + 8;
               int l1 = rand.nextInt(world.getHeightValue(ry, ry1) + 32);
               if(!BiomeGenBase.genTallFlowers.generate(world, rand, ry, l1, ry1)) {
                  ++rz;
                  continue;
               }
            }

            ++successfulFlowers;
            break;
         }
      }

      super.decorate(world, rand, mapX, mapZ);
      if(rand.nextInt(24) == 0) {
         rx = mapX + rand.nextInt(16) + 8;
         rz = mapZ + rand.nextInt(16) + 8;
         ry = this.getGroundLevel(world, rx, rz);
         this.worldGenMushgloom.generate(world, rand, rx, ry, rz);
      }

      for(rx = 0; rx < 30; ++rx) {
         rz = mapX + rand.nextInt(16) + 8;
         ry = mapZ + rand.nextInt(16) + 8;
         ry1 = TFWorld.SEALEVEL + rand.nextInt(TFWorld.CHUNKHEIGHT - TFWorld.SEALEVEL);
         this.tfGenHangingLamps.generate(world, rand, rz, ry1, ry);
      }

      if(rand.nextInt(4) == 0) {
         rx = mapX + rand.nextInt(16) + 8;
         rz = mapZ + rand.nextInt(16) + 8;
         ry = this.getGroundLevel(world, rx, rz);
         this.tfGenLampposts.generate(world, rand, rx, ry, rz);
      }

      if(rand.nextInt(32) == 0) {
         rx = mapX + rand.nextInt(16) + 8;
         rz = mapZ + rand.nextInt(16) + 8;
         ry = this.getGroundLevel(world, rx, rz);
         (new WorldGenPumpkin()).generate(world, rand, rx, ry, rz);
      }

   }

   public int getGroundLevel(World world, int x, int z) {
      Chunk chunk = world.getChunkFromBlockCoords(x, z);
      int lastDirt = TFWorld.SEALEVEL;

      for(int y = TFWorld.SEALEVEL; y < TFWorld.CHUNKHEIGHT - 1; ++y) {
         Block blockID = chunk.getBlock(x & 15, y, z & 15);
         if(blockID == Blocks.grass) {
            return y + 1;
         }

         if(blockID == Blocks.dirt || blockID == Blocks.stone || blockID == Blocks.gravel) {
            lastDirt = y + 1;
         }
      }

      return lastDirt;
   }

   public String func_150572_a(Random p_150572_1_, int p_150572_2_, int p_150572_3_, int p_150572_4_) {
      double flowerVar = MathHelper.clamp_double((1.0D + BiomeGenBase.plantNoise.func_151601_a((double)p_150572_2_ / 48.0D, (double)p_150572_4_ / 48.0D)) / 2.0D, 0.0D, 0.9999D);
      int flowerIndex = (int)(flowerVar * (double)BlockFlower.field_149859_a.length);
      if(flowerIndex == 1) {
         flowerIndex = 0;
      }

      return BlockFlower.field_149859_a[flowerIndex];
   }
}

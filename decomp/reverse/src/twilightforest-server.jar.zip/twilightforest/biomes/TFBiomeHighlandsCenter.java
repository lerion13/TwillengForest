package twilightforest.biomes;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.stats.Achievement;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenTaiga2;
import twilightforest.TFAchievementPage;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.block.TFBlocks;

public class TFBiomeHighlandsCenter extends TFBiomeBase {

   public TFBiomeHighlandsCenter(int i) {
      super(i);
      super.topBlock = TFBlocks.deadrock;
      super.field_150604_aj = 0;
      super.fillerBlock = TFBlocks.deadrock;
      super.field_76754_C = 1;
      super.temperature = 0.3F;
      super.rainfall = 0.2F;
      this.getTFBiomeDecorator().canopyPerChunk = -999.0F;
      this.getTFBiomeDecorator().setTreesPerChunk(-999);
      super.theBiomeDecorator.generateLakes = false;
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(4) == 0?new WorldGenBigTree(false):(random.nextInt(10) == 0?new WorldGenTaiga2(true):super.birchGen));
   }

   public Block getStoneReplacementBlock() {
      return TFBlocks.deadrock;
   }

   public byte getStoneReplacementMeta() {
      return (byte)2;
   }

   protected Achievement getRequiredAchievement() {
      return TFAchievementPage.twilightProgressGlacier;
   }
}

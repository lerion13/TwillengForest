package twilightforest.biomes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.Achievement;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeDecorator;
import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenShrub;
import twilightforest.TFAchievementPage;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeBase;
import twilightforest.biomes.TFDarkForestBiomeDecorator;
import twilightforest.entity.EntityTFKingSpider;
import twilightforest.entity.EntityTFKobold;
import twilightforest.entity.EntityTFMistWolf;
import twilightforest.entity.EntityTFSkeletonDruid;

public class TFBiomeDarkForest extends TFBiomeBase {

   private static final int MONSTER_SPAWN_RATE = 20;
   Random monsterRNG;
   ArrayList emptyList = new ArrayList();


   public TFBiomeDarkForest(int i) {
      super(i);
      super.temperature = 0.7F;
      super.rainfall = 0.8F;
      this.getTFBiomeDecorator().canopyPerChunk = 5.5F;
      this.getTFBiomeDecorator().setTreesPerChunk(10);
      this.getTFBiomeDecorator().setGrassPerChunk(-99);
      this.getTFBiomeDecorator().setFlowersPerChunk(-99);
      this.getTFBiomeDecorator().setMushroomsPerChunk(2);
      this.getTFBiomeDecorator().setDeadBushPerChunk(10);
      super.rootHeight = 0.05F;
      super.heightVariation = 0.05F;
      this.monsterRNG = new Random();
      super.spawnableMonsterList.add(new SpawnListEntry(EntityEnderman.class, 1, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityZombie.class, 5, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntitySkeleton.class, 5, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFMistWolf.class, 10, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFSkeletonDruid.class, 10, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFKingSpider.class, 10, 1, 4));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityTFKobold.class, 10, 4, 8));
      super.spawnableMonsterList.add(new SpawnListEntry(EntityWitch.class, 1, 1, 1));
      super.theBiomeDecorator.generateLakes = false;
   }

   public BiomeDecorator createBiomeDecorator() {
      return new TFDarkForestBiomeDecorator();
   }

   public WorldGenAbstractTree func_150567_a(Random random) {
      return (WorldGenAbstractTree)(random.nextInt(5) == 0?new WorldGenShrub(3, 0):(random.nextInt(8) == 0?super.birchGen:super.worldGeneratorTrees));
   }

   public int getBiomeGrassColor(int x, int y, int z) {
      double var1 = (double)this.getFloatTemperature(x, y, z);
      double var3 = (double)this.getFloatRainfall();
      return ((ColorizerGrass.getGrassColor(var1, var3) & 16711422) + 1969742) / 2;
   }

   public int getBiomeFoliageColor(int x, int y, int z) {
      double var1 = (double)this.getFloatTemperature(x, y, z);
      double var3 = (double)this.getFloatRainfall();
      return ((ColorizerFoliage.getFoliageColor(var1, var3) & 16711422) + 1969742) / 2;
   }

   public List getSpawnableList(EnumCreatureType par1EnumCreatureType) {
      return (List)(par1EnumCreatureType == EnumCreatureType.monster?(this.monsterRNG.nextInt(20) == 0?super.spawnableMonsterList:this.emptyList):(par1EnumCreatureType == EnumCreatureType.creature?super.spawnableCreatureList:(par1EnumCreatureType == EnumCreatureType.waterCreature?super.spawnableWaterCreatureList:(par1EnumCreatureType == EnumCreatureType.ambient?super.spawnableCaveCreatureList:null))));
   }

   public boolean isHighHumidity() {
      return true;
   }

   protected Achievement getRequiredAchievement() {
      return TFAchievementPage.twilightProgressHydra;
   }

   public void enforceProgession(EntityPlayer player, World world) {
      if(!world.isRemote && world.getWorldTime() % 60L == 0L) {
         player.addPotionEffect(new PotionEffect(Potion.blindness.id, 100, 0));
         if(world.rand.nextInt(4) == 0) {
            TFFeature.tfStronghold.trySpawnHintMonster(world, player);
         }
      }

   }
}

package twilightforest.biomes;

import twilightforest.biomes.TFBiomeBase;

public class TFBiomeCenter2 extends TFBiomeBase {

   public TFBiomeCenter2(int i) {
      super(i);
   }
}

package twilightforest.biomes;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.gen.feature.WorldGenAbstractTree;
import net.minecraft.world.gen.feature.WorldGenPumpkin;
import net.minecraft.world.gen.feature.WorldGenTallGrass;
import twilightforest.TFFeature;
import twilightforest.biomes.TFBiomeDecorator;
import twilightforest.block.TFBlocks;
import twilightforest.world.TFGenDarkCanopyTree;
import twilightforest.world.TFGenTallGrass;
import twilightforest.world.TFTreeGenerator;
import twilightforest.world.TFWorld;

public class TFDarkForestBiomeDecorator extends TFBiomeDecorator {

   TFTreeGenerator darkCanopyTreeGen = new TFGenDarkCanopyTree();
   TFGenTallGrass worldGenDeadBush;
   WorldGenTallGrass worldGenForestGrass;
   WorldGenTallGrass worldGenMushgloom;


   public TFDarkForestBiomeDecorator() {
      this.worldGenDeadBush = new TFGenTallGrass(TFBlocks.plant, 11, 8);
      this.worldGenForestGrass = new WorldGenTallGrass(TFBlocks.plant, 10);
      this.worldGenMushgloom = new WorldGenTallGrass(TFBlocks.plant, 9);
   }

   public void decorateChunk(World world, Random rand, BiomeGenBase biome, int mapX, int mapZ) {
      TFFeature nearFeature = TFFeature.getNearestFeature(mapX >> 4, mapZ >> 4, world);
      if(nearFeature.areChunkDecorationsEnabled) {
         int nc = (int)super.canopyPerChunk + (rand.nextFloat() < super.canopyPerChunk - (float)((int)super.canopyPerChunk)?1:0);

         int rx;
         int rz;
         int ry;
         int ry1;
         for(rx = 0; rx < nc; ++rx) {
            rz = mapX + rand.nextInt(16) + 8;
            ry = mapZ + rand.nextInt(16) + 8;
            ry1 = world.getHeightValue(rz, ry);
            this.darkCanopyTreeGen.generate(world, rand, rz, ry1, ry);
         }

         for(rx = 0; rx < super.treesPerChunk; ++rx) {
            rz = mapX + rand.nextInt(16) + 8;
            ry = mapZ + rand.nextInt(16) + 8;
            ry1 = this.getGroundLevel(world, rz, ry);
            WorldGenAbstractTree var5 = biome.func_150567_a(rand);
            var5.setScale(1.0D, 1.0D, 1.0D);
            var5.generate(world, rand, rz, ry1, ry);
         }

         for(rx = 0; rx < super.deadBushPerChunk; ++rx) {
            rz = mapX + rand.nextInt(16) + 8;
            ry = mapZ + rand.nextInt(16) + 8;
            ry1 = rand.nextInt(128);
            this.worldGenDeadBush.generate(world, rand, rz, ry1, ry);
         }

         for(rx = 0; rx < super.deadBushPerChunk; ++rx) {
            rz = mapX + rand.nextInt(16) + 8;
            ry = mapZ + rand.nextInt(16) + 8;
            ry1 = rand.nextInt(128);
            this.worldGenForestGrass.generate(world, rand, rz, ry1, ry);
         }

         for(rx = 0; rx < super.mushroomsPerChunk; ++rx) {
            if(rand.nextInt(8) == 0) {
               rz = mapX + rand.nextInt(16) + 8;
               ry = mapZ + rand.nextInt(16) + 8;
               ry1 = this.getGroundLevel(world, rz, ry);
               super.mushroomBrownGen.generate(world, rand, rz, ry1, ry);
            }

            if(rand.nextInt(16) == 0) {
               rz = mapX + rand.nextInt(16) + 8;
               ry = mapZ + rand.nextInt(16) + 8;
               ry1 = this.getGroundLevel(world, rz, ry);
               super.mushroomRedGen.generate(world, rand, rz, ry1, ry);
            }

            if(rand.nextInt(24) == 0) {
               rz = mapX + rand.nextInt(16) + 8;
               ry = mapZ + rand.nextInt(16) + 8;
               ry1 = this.getGroundLevel(world, rz, ry);
               this.worldGenMushgloom.generate(world, rand, rz, ry1, ry);
            }
         }

         if(rand.nextInt(4) == 0) {
            rx = mapX + rand.nextInt(16) + 8;
            rz = mapZ + rand.nextInt(16) + 8;
            ry = rand.nextInt(128);
            super.mushroomBrownGen.generate(world, rand, rx, ry, rz);
         }

         if(rand.nextInt(8) == 0) {
            rx = mapX + rand.nextInt(16) + 8;
            rz = mapZ + rand.nextInt(16) + 8;
            ry = rand.nextInt(128);
            super.mushroomRedGen.generate(world, rand, rx, ry, rz);
         }

         if(rand.nextInt(32) == 0) {
            rx = mapX + rand.nextInt(16) + 8;
            rz = mapZ + rand.nextInt(16) + 8;
            ry = this.getGroundLevel(world, rx, rz);
            (new WorldGenPumpkin()).generate(world, rand, rx, ry, rz);
         }
      }

      this.decorateUnderground(world, rand, mapX, mapZ);
      this.decorateOnlyOres(world, rand, mapX, mapZ);
   }

   public int getGroundLevel(World world, int x, int z) {
      Chunk chunk = world.getChunkFromBlockCoords(x, z);
      int lastDirt = TFWorld.SEALEVEL;

      for(int y = TFWorld.SEALEVEL; y < TFWorld.CHUNKHEIGHT - 1; ++y) {
         Block blockID = chunk.getBlock(x & 15, y, z & 15);
         if(blockID == Blocks.grass) {
            return y + 1;
         }

         if(blockID == Blocks.dirt || blockID == Blocks.stone || blockID == Blocks.gravel) {
            lastDirt = y + 1;
         }
      }

      return lastDirt;
   }
}

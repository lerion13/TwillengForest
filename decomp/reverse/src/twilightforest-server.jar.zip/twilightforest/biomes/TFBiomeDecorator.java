package twilightforest.biomes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.init.Blocks;
import net.minecraft.util.WeightedRandom;
import net.minecraft.util.WeightedRandom.Item;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeDecorator;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.feature.WorldGenLakes;
import net.minecraft.world.gen.feature.WorldGenLiquids;
import twilightforest.TFFeature;
import twilightforest.TwilightForestMod;
import twilightforest.world.TFGenCanopyMushroom;
import twilightforest.world.TFGenCanopyTree;
import twilightforest.world.TFGenFallenHollowLog;
import twilightforest.world.TFGenFallenSmallLog;
import twilightforest.world.TFGenFoundation;
import twilightforest.world.TFGenGroveRuins;
import twilightforest.world.TFGenHollowStump;
import twilightforest.world.TFGenHollowTree;
import twilightforest.world.TFGenMangroveTree;
import twilightforest.world.TFGenMonolith;
import twilightforest.world.TFGenMyceliumBlob;
import twilightforest.world.TFGenOutsideStalagmite;
import twilightforest.world.TFGenPlantRoots;
import twilightforest.world.TFGenStoneCircle;
import twilightforest.world.TFGenTorchBerries;
import twilightforest.world.TFGenWell;
import twilightforest.world.TFGenWitchHut;
import twilightforest.world.TFGenWoodRoots;
import twilightforest.world.TFGenerator;
import twilightforest.world.TFTreeGenerator;

public class TFBiomeDecorator extends BiomeDecorator {

   TFGenCanopyTree canopyTreeGen = new TFGenCanopyTree();
   TFTreeGenerator alternateCanopyGen = new TFGenCanopyMushroom();
   TFGenHollowTree hollowTreeGen = new TFGenHollowTree();
   TFGenMyceliumBlob myceliumBlobGen = new TFGenMyceliumBlob(5);
   WorldGenLakes extraLakeGen;
   WorldGenLakes extraLavaPoolGen;
   TFGenMangroveTree mangroveTreeGen = new TFGenMangroveTree();
   TFGenPlantRoots plantRootGen;
   TFGenWoodRoots woodRootGen;
   WorldGenLiquids caveWaterGen;
   TFGenTorchBerries torchBerryGen;
   public float canopyPerChunk;
   public float alternateCanopyChance;
   public int myceliumPerChunk;
   public int mangrovesPerChunk;
   public int lakesPerChunk;
   public float lavaPoolChance;
   static final List ruinList = new ArrayList();


   public TFBiomeDecorator() {
      this.extraLakeGen = new WorldGenLakes(Blocks.water);
      this.extraLavaPoolGen = new WorldGenLakes(Blocks.lava);
      this.plantRootGen = new TFGenPlantRoots();
      this.woodRootGen = new TFGenWoodRoots();
      this.caveWaterGen = new WorldGenLiquids(Blocks.flowing_water);
      this.torchBerryGen = new TFGenTorchBerries();
      this.canopyPerChunk = TwilightForestMod.canopyCoverage;
      this.alternateCanopyChance = 0.0F;
      this.myceliumPerChunk = 0;
      this.lakesPerChunk = 0;
      this.lavaPoolChance = 0.0F;
      this.mangrovesPerChunk = 0;
   }

   public void decorateChunk(World world, Random rand, BiomeGenBase biome, int mapX, int mapZ) {
      TFFeature nearFeature = TFFeature.getNearestFeature(mapX >> 4, mapZ >> 4, world);
      if(!nearFeature.areChunkDecorationsEnabled) {
         this.decorateUnderground(world, rand, mapX, mapZ);
         this.decorateOnlyOres(world, rand, mapX, mapZ);
      } else {
         super.currentWorld = null;
         super.decorateChunk(world, rand, biome, mapX, mapZ);
      }

   }

   protected void genDecorations(BiomeGenBase biome) {
      int nc;
      int i;
      int rx;
      if(super.randomGenerator.nextInt(6) == 0) {
         nc = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         i = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         rx = super.currentWorld.getHeightValue(nc, i);
         TFGenerator rz = this.randomFeature(super.randomGenerator);
         if(rz.generate(super.currentWorld, super.randomGenerator, nc, rx, i)) {
            ;
         }
      }

      nc = (int)this.canopyPerChunk + (super.randomGenerator.nextFloat() < this.canopyPerChunk - (float)((int)this.canopyPerChunk)?1:0);

      int ry;
      int var7;
      for(i = 0; i < nc; ++i) {
         rx = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         var7 = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         ry = super.currentWorld.getHeightValue(rx, var7);
         if(this.alternateCanopyChance > 0.0F && super.randomGenerator.nextFloat() <= this.alternateCanopyChance) {
            this.alternateCanopyGen.generate(super.currentWorld, super.randomGenerator, rx, ry, var7);
         } else {
            this.canopyTreeGen.generate(super.currentWorld, super.randomGenerator, rx, ry, var7);
         }
      }

      for(i = 0; i < this.mangrovesPerChunk; ++i) {
         rx = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         var7 = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         ry = super.currentWorld.getHeightValue(rx, var7);
         this.mangroveTreeGen.generate(super.currentWorld, super.randomGenerator, rx, ry, var7);
      }

      for(i = 0; i < this.lakesPerChunk; ++i) {
         rx = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         var7 = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         ry = super.currentWorld.getHeightValue(rx, var7);
         this.extraLakeGen.generate(super.currentWorld, super.randomGenerator, rx, ry, var7);
      }

      if(super.randomGenerator.nextFloat() <= this.lavaPoolChance) {
         i = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         rx = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         var7 = super.currentWorld.getHeightValue(i, rx);
         this.extraLavaPoolGen.generate(super.currentWorld, super.randomGenerator, i, var7, rx);
      }

      for(i = 0; i < this.myceliumPerChunk; ++i) {
         rx = super.chunk_X + super.randomGenerator.nextInt(16) + 8;
         var7 = super.chunk_Z + super.randomGenerator.nextInt(16) + 8;
         ry = super.currentWorld.getHeightValue(rx, var7);
         this.myceliumBlobGen.generate(super.currentWorld, super.randomGenerator, rx, ry, var7);
      }

      super.genDecorations(biome);
      this.decorateUnderground(super.currentWorld, super.randomGenerator, super.chunk_X, super.chunk_Z);
   }

   protected void decorateUnderground(World world, Random rand, int mapX, int mapZ) {
      int i;
      int rx;
      byte ry;
      int rz;
      for(i = 0; i < 12; ++i) {
         rx = mapX + rand.nextInt(16) + 8;
         ry = 64;
         rz = mapZ + rand.nextInt(16) + 8;
         this.plantRootGen.generate(world, rand, rx, ry, rz);
      }

      int var9;
      for(i = 0; i < 20; ++i) {
         rx = mapX + rand.nextInt(16) + 8;
         var9 = rand.nextInt(64);
         rz = mapZ + rand.nextInt(16) + 8;
         this.woodRootGen.generate(world, rand, rx, var9, rz);
      }

      if(super.generateLakes) {
         for(i = 0; i < 50; ++i) {
            rx = mapX + rand.nextInt(16) + 8;
            var9 = rand.nextInt(24) + 4;
            rz = mapZ + rand.nextInt(16) + 8;
            this.caveWaterGen.generate(world, rand, rx, var9, rz);
         }
      }

      for(i = 0; i < 3; ++i) {
         rx = mapX + rand.nextInt(16) + 8;
         ry = 64;
         rz = mapZ + rand.nextInt(16) + 8;
         this.torchBerryGen.generate(world, rand, rx, ry, rz);
      }

   }

   public void decorateOnlyOres(World world, Random rand, int mapX, int mapZ) {
      super.currentWorld = world;
      super.randomGenerator = rand;
      super.chunk_X = mapX;
      super.chunk_Z = mapZ;
      this.generateOres();
      super.currentWorld = null;
      super.randomGenerator = null;
   }

   public TFGenerator randomFeature(Random rand) {
      return ((TFBiomeDecorator.RuinEntry)WeightedRandom.getRandomItem(rand, ruinList)).generator;
   }

   public void setTreesPerChunk(int treesPerChunk) {
      super.treesPerChunk = treesPerChunk;
   }

   public void setBigMushroomsPerChunk(int bigMushroomsPerChunk) {
      super.bigMushroomsPerChunk = bigMushroomsPerChunk;
   }

   public void setClayPerChunk(int clayPerChunk) {
      super.clayPerChunk = clayPerChunk;
   }

   public void setDeadBushPerChunk(int deadBushPerChunk) {
      super.deadBushPerChunk = deadBushPerChunk;
   }

   public void setMushroomsPerChunk(int mushroomsPerChunk) {
      super.mushroomsPerChunk = mushroomsPerChunk;
   }

   public void setFlowersPerChunk(int flowersPerChunk) {
      super.flowersPerChunk = flowersPerChunk;
   }

   public void setReedsPerChunk(int reedsPerChunk) {
      super.reedsPerChunk = reedsPerChunk;
   }

   public void setWaterlilyPerChunk(int waterlilyPerChunk) {
      super.waterlilyPerChunk = waterlilyPerChunk;
   }

   public void setGrassPerChunk(int grassPerChunk) {
      super.grassPerChunk = grassPerChunk;
   }

   static {
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenStoneCircle(), 10));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenWell(), 10));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenWitchHut(), 5));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenOutsideStalagmite(), 12));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenFoundation(), 10));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenMonolith(), 10));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenGroveRuins(), 5));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenHollowStump(), 12));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenFallenHollowLog(), 10));
      ruinList.add(new TFBiomeDecorator.RuinEntry(new TFGenFallenSmallLog(), 10));
   }

   static class RuinEntry extends Item {

      public final TFGenerator generator;


      public RuinEntry(TFGenerator generator, int weight) {
         super(weight);
         this.generator = generator;
      }
   }
}
